import express from 'express';
import path from 'path';
import fs from 'fs';
import cookieParser from 'cookie-parser';
import dotenv from 'dotenv';
import authRoutes from './server/routes/auth.js';
import paymentRoutes from './server/routes/payments.js';
import investmentRoutes from './server/routes/investments.js';
import customerRoutes from './server/routes/customer.js';
import adminRoutes from './server/routes/admin.js';
import securityRoutes from './server/routes/security.js';
import cryptoRoutes from './server/routes/crypto.js';
import businessFinanceRoutes from './server/routes/businessFinance.js';
import promotionsRouter, { adminPromotionsRouter } from './server/routes/promotions.js';
import announcementsRouter from './server/routes/announcements.js';
import { getDb, saveDb } from './server/db/database.js';
import { getPayFastConfig } from './server/services/payfast.js';
import { startPromotionsScheduler } from './server/services/promotionsScheduler.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const isProduction = process.env.NODE_ENV === 'production';

// Crucial: PayFast ITNs are posted as application/x-www-form-urlencoded
// Support 10mb payload for client KYC & document vault base64 uploads
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// Initialize Database on startup
getDb().then(() => {
  console.log('[DATABASE] SQLite database initialized and ready.');
  // Start background promotions scheduler (evaluates in Africa/Johannesburg timezone at 09:00 SAST)
  startPromotionsScheduler();
}).catch((err) => {
  console.error('[DATABASE] Initialization error:', err);
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/investments', investmentRoutes);
app.use('/api/customer/promotions', promotionsRouter);
app.use('/api/customer', customerRoutes);
app.use('/api/security', securityRoutes);
app.use('/api/admin/promotions', adminPromotionsRouter);
app.use('/api/admin/announcements', announcementsRouter);
app.use('/api/admin', adminRoutes);
app.use('/api/crypto', cryptoRoutes);
app.use('/api/business-finance', businessFinanceRoutes);

// System Status Endpoint
app.get('/api/system/status', (req, res) => {
  const pf = getPayFastConfig();
  res.json({
    platform: 'Global Finance Crypto Mining',
    version: '1.0.0',
    payfastEnvironment: pf.environment,
    payfastMerchantId: pf.merchantId ? `${pf.merchantId.slice(0, 4)}****` : 'Not configured',
    livePaymentsEnabled: pf.environment === 'live',
    currency: 'ZAR',
  });
});

// Dev Server vs Production Static Serving
async function startServer() {
  const distPath = path.resolve(process.cwd(), 'dist');
  const hasDist = fs.existsSync(distPath);

  if (!isProduction || !hasDist) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
    console.log('[SERVER] Running with Vite dev middleware on port', PORT);
  } else {
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('[SERVER] Running production static server on port', PORT);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[GLOBAL FINANCE] Server listening on http://0.0.0.0:${PORT}`);
  });

  // Ensure database snapshot is safely saved to disk on process exit
  const handleExit = (signal: string) => {
    try {
      console.log(`[SERVER] ${signal} signal received. Flushing database snapshot...`);
      saveDb();
    } catch (err) {
      console.error('[SERVER] Error saving database on shutdown:', err);
    }
    process.exit(0);
  };

  process.on('SIGTERM', () => handleExit('SIGTERM'));
  process.on('SIGINT', () => handleExit('SIGINT'));
  process.on('beforeExit', () => {
    try {
      saveDb();
    } catch (_) {}
  });
}

startServer();
