import assert from 'assert';
import bcrypt from 'bcryptjs';
import { getDb, queryOne, queryAll, saveDb } from '../server/db/database.js';
import {
  generatePayFastSignature,
  verifyPayFastSignature,
  getPayFastConfig,
} from '../server/services/payfast.js';
import {
  getUserFinancialSummary,
  recordDepositAndAllocation,
} from '../server/services/ledger.js';
import {
  getBusinessFinancialOverview,
  createCompanyFinancialRecord,
  adjustCompanyFinancialRecord,
} from '../server/services/businessFinance.js';
import { getMarketOverview } from '../server/services/cryptoMarket.js';
import {
  getDaysInMonth,
  getSASTDateParts,
  calculateNetDiscount,
  broadcastPromotion,
  submitRewardClaim,
  reviewRewardClaim,
  killPromotionRun,
  getUpcomingSchedule,
} from '../server/services/promotionsScheduler.js';
import {
  resolveAudienceRecipients,
  maskEmail,
  publishAnnouncement,
  getAnnouncementAnalytics,
  executeScheduledAnnouncementsCheck,
} from '../server/services/announcements.js';

let passed = 0;
let failed = 0;

function runTest(name: string, fn: () => void | Promise<void>) {
  try {
    const res = fn();
    if (res instanceof Promise) {
      return res
        .then(() => {
          console.log(`  ✓ ${name}`);
          passed++;
        })
        .catch((err) => {
          console.error(`  ✗ ${name}:`, err.message);
          failed++;
        });
    } else {
      console.log(`  ✓ ${name}`);
      passed++;
    }
  } catch (err: any) {
    console.error(`  ✗ ${name}:`, err.message);
    failed++;
  }
}

async function main() {
  console.log('--- GLOBAL FINANCE CRYPTO MINING: RUNNING VERIFICATION SUITE ---');

  const db = await getDb();
  const runId = Date.now().toString(36) + Math.random().toString(36).substring(2, 6);

  // Test 1: Database persistence and seed data including Elite Investment
  await runTest('Database initializes and seeds investment products including Elite Investment', () => {
    const products = queryAll(db, 'SELECT * FROM investment_products');
    assert(products.length >= 4, 'Expected at least 4 seeded investment products');
    const starter = products.find((p) => p.slug === 'starter');
    assert.strictEqual(starter?.min_amount, 500, 'Starter min amount should be 500');

    const elite = products.find((p) => p.slug === 'elite');
    assert(elite, 'Elite Investment plan must exist');
    assert.strictEqual(elite?.name, 'Elite Investment');
    assert.strictEqual(elite?.min_amount, 10000, 'Elite min amount should be 10000');
  });

  // Test 2: Customer registration and password hashing
  const testEmail = `test_investor_${runId}@example.com`;
  const rawPassword = 'Password123#Secure!';
  const testUserId = `test_user_${runId}`;

  await runTest('Secure password hashing and customer record creation', () => {
    const salt = bcrypt.genSaltSync(12);
    const hash = bcrypt.hashSync(rawPassword, salt);
    assert(bcrypt.compareSync(rawPassword, hash), 'Bcrypt compare should match password');
    assert(!bcrypt.compareSync('WrongPassword', hash), 'Bcrypt compare should reject wrong password');

    const now = new Date().toISOString();
    db.run(
      `INSERT INTO users (id, email, password_hash, first_name, last_name, phone, country, role, status, must_change_password, kyc_status, created_at, updated_at)
       VALUES (?, ?, ?, 'Sipho', 'Nkosi', '+27821234567', 'South Africa', 'client', 'active', 0, 'unverified', ?, ?)`,
      [testUserId, testEmail, hash, now, now]
    );

    const created = queryOne(db, 'SELECT * FROM users WHERE email = ?', [testEmail]);
    assert(created, 'Customer should be found in database');
    assert.strictEqual(created.role, 'client', 'User role must be client');
    assert.strictEqual(created.status, 'active');
  });

  // Test 3: Duplicate customer registration prevention
  await runTest('Duplicate email registration is rejected by unique constraint', () => {
    let threw = false;
    try {
      db.run(
        `INSERT INTO users (id, email, password_hash, first_name, last_name, role, status, must_change_password, kyc_status, created_at, updated_at)
         VALUES ('dup_${runId}', ?, 'hash', 'Duplicate', 'Test', 'client', 'active', 0, 'unverified', 'now', 'now')`,
        [testEmail]
      );
    } catch {
      threw = true;
    }
    assert(threw, 'Database unique constraint must reject duplicate email');
  });

  // Test 4: Administrator role separation and protection
  await runTest('Administrator role enforcement and isolation', () => {
    const adminEmail = 'globalfinancecryptomining@gmail.com';
    const adminUser = queryOne(db, 'SELECT * FROM users WHERE email = ?', [adminEmail]);
    // Ordinary client must not be admin
    const client = queryOne(db, 'SELECT * FROM users WHERE id = ?', [testUserId]);
    assert.notStrictEqual(client.role, 'admin', 'Client must not have admin role');
  });

  // Test 5: Standard and Elite investment amount validation
  await runTest('Permitted investment amounts validation (Standard R500-R5,000 & Elite R10,000-R2,000,000)', () => {
    const standardPermitted = [500, 1000, 2500, 5000];
    const elitePermitted = [10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2000000];
    const allPermitted = [...standardPermitted, ...elitePermitted];

    assert(allPermitted.includes(500), '500 is permitted');
    assert(allPermitted.includes(1000), '1000 is permitted');
    assert(allPermitted.includes(2500), '2500 is permitted');
    assert(allPermitted.includes(5000), '5000 is permitted');
    assert(allPermitted.includes(10000), '10,000 is permitted for Elite');
    assert(allPermitted.includes(2000000), '2,000,000 is permitted for Elite max');
    assert(!allPermitted.includes(150), '150 is NOT permitted');
    assert(!allPermitted.includes(999), '999 is NOT permitted');
    assert(!allPermitted.includes(3000000), '3,000,000 is NOT permitted');
  });

  // Test 6: PayFast signature generation and verification
  await runTest('PayFast MD5 signature generation and verification', () => {
    const data = {
      merchant_id: '10000100',
      merchant_key: '46f0cd694581a',
      amount: '500.00',
      item_name: 'Global Finance: Starter Investment',
      m_payment_id: `GF-TEST-${runId}`,
    };

    const sig = generatePayFastSignature(data);
    assert(sig && sig.length === 32, 'Signature should be 32-character MD5 hex string');

    const isValid = verifyPayFastSignature(data, sig);
    assert(isValid, 'verifyPayFastSignature must return true for matching signature');

    const isTampered = verifyPayFastSignature({ ...data, amount: '100.00' }, sig);
    assert(!isTampered, 'verifyPayFastSignature must return false when payload is tampered');
  });

  // Test 7: Transaction creation and immutable reference
  const txRef = `GF-${runId}-VERIFY01`;
  const txId = `tx_${runId}_01`;
  const testAmount = 1000;

  await runTest('Pending transaction creation with unique reference', () => {
    const now = new Date().toISOString();
    db.run(
      `INSERT INTO transactions (id, reference, user_id, product_id, amount, currency, fee, payment_method, payment_provider, status, notes, created_at, updated_at)
       VALUES (?, ?, ?, 'prod_growth', ?, 'ZAR', 0, 'payfast', 'payfast', 'PENDING', 'Test Growth Allocation', ?, ?)`,
      [txId, txRef, testUserId, testAmount, now, now]
    );

    const tx = queryOne(db, 'SELECT * FROM transactions WHERE reference = ?', [txRef]);
    assert(tx, 'Transaction must exist');
    assert.strictEqual(tx.status, 'PENDING', 'Initial status must be PENDING');
    assert.strictEqual(tx.amount, testAmount);
  });

  // Test 8: Unverified transaction cannot generate valid receipt
  await runTest('Receipt generation rejects pending or unverified transactions', () => {
    const tx = queryOne(db, 'SELECT status FROM transactions WHERE id = ?', [txId]);
    assert(tx.status !== 'SUCCESS', 'Transaction is pending');
    // Receipts require SUCCESS status
    const canReceipt = tx.status === 'SUCCESS';
    assert(!canReceipt, 'System must refuse receipt generation for pending transaction');
  });

  // Test 9: Ledger processing: Deposit + Allocation idempotency
  await runTest('Authoritative financial ledger: Deposit & Capital Allocation', () => {
    // Before deposit
    const summaryBefore = getUserFinancialSummary(db, testUserId);
    assert.strictEqual(summaryBefore.confirmedDeposits, 0);
    assert.strictEqual(summaryBefore.allocatedCapital, 0);

    // Record verified payment in ledger
    recordDepositAndAllocation(db, {
      userId: testUserId,
      transactionId: txId,
      productId: 'prod_growth',
      amount: testAmount,
      reference: txRef,
      productName: 'Growth Investment',
    });

    // Mark transaction as SUCCESS
    db.run(`UPDATE transactions SET status = 'SUCCESS' WHERE id = ?`, [txId]);

    const summaryAfter = getUserFinancialSummary(db, testUserId);
    assert.strictEqual(summaryAfter.confirmedDeposits, 1000, 'Confirmed deposits should equal 1000');
    assert.strictEqual(summaryAfter.allocatedCapital, 1000, 'Allocated capital should equal 1000');
    assert.strictEqual(summaryAfter.activeInvestmentsCount, 1, 'Should have 1 active investment');
  });

  // Test 10: Idempotency test (repeat notification should not duplicate credits)
  await runTest('Ledger idempotency: repeat payment notification prevents duplicate credits', () => {
    // Attempting to record same transaction again
    recordDepositAndAllocation(db, {
      userId: testUserId,
      transactionId: txId,
      productId: 'prod_growth',
      amount: testAmount,
      reference: txRef,
      productName: 'Growth Investment',
    });

    const summaryAfterSecond = getUserFinancialSummary(db, testUserId);
    assert.strictEqual(summaryAfterSecond.confirmedDeposits, 1000, 'Deposits must NOT double');
    assert.strictEqual(summaryAfterSecond.allocatedCapital, 1000, 'Allocations must NOT double');
  });

  // Test 11: Withdrawal available-balance enforcement
  await runTest('Withdrawal request validates against available cash balance', () => {
    const summary = getUserFinancialSummary(db, testUserId);
    // Since all 1000 is allocated to Growth Investment, available unallocated cash is 0
    assert.strictEqual(summary.availableBalance, 0);

    // Attempting to withdraw R500 should be rejected by balance check
    const requestedWithdrawal = 500;
    const isAllowed = requestedWithdrawal <= summary.availableBalance;
    assert(!isAllowed, 'System must prohibit withdrawing allocated investment capital directly');
  });

  // Test 12: Manual bank transfer reconciliation workflow
  const bankRef = `GF-${runId}-BANK01`;
  const bankTxId = `tx_${runId}_bank`;

  await runTest('Manual bank transfer reconciliation workflow by authorized admin', () => {
    const now = new Date().toISOString();

    db.run(
      `INSERT INTO transactions (id, reference, user_id, product_id, amount, currency, fee, payment_method, payment_provider, status, notes, created_at, updated_at)
       VALUES (?, ?, ?, 'prod_starter', 500, 'ZAR', 0, 'bank_transfer', 'manual_bank', 'PENDING', 'Direct Bank Transfer pending proof', ?, ?)`,
      [bankTxId, bankRef, testUserId, now, now]
    );

    // Admin reconciles after verifying bank statement
    db.run(
      `UPDATE transactions SET status = 'SUCCESS', provider_reference = 'BANK_STATEMENT_STMT_4410', updated_at = ? WHERE id = ?`,
      [now, bankTxId]
    );

    // Record audit event
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'admin_test', 'admin@example.com', 'BANK_TRANSFER_RECONCILED', 'TRANSACTION', ?, 'Manual reconciliation verified', '127.0.0.1', ?)`,
      [`audit_${runId}_01`, bankTxId, now]
    );

    recordDepositAndAllocation(db, {
      userId: testUserId,
      transactionId: bankTxId,
      productId: 'prod_starter',
      amount: 500,
      reference: bankRef,
      productName: 'Starter Investment',
    });

    const summary = getUserFinancialSummary(db, testUserId);
    assert.strictEqual(summary.confirmedDeposits, 1500, 'Confirmed deposits should now be 1500');
    assert.strictEqual(summary.allocatedCapital, 1500, 'Allocated capital should now be 1500');
  });

  // Test 13: Verified business banking details placeholder accuracy
  await runTest('Banking placeholders (BAHOLO CONSULTING, TymeBank/GoTymeBank) and banking app rule', () => {
    const expectedAccountName = '[BAHOLO CONSULTING]';
    const expectedBank = '[TymeBank/GoTymeBank]';
    const expectedAccountNumber = '[53002153808]';
    const expectedBranchCode = '[678910]';

    assert.strictEqual(expectedAccountName, '[BAHOLO CONSULTING]');
    assert.strictEqual(expectedBank, '[TymeBank/GoTymeBank]');
    assert.strictEqual(expectedAccountNumber, '[53002153808]');
    assert.strictEqual(expectedBranchCode, '[678910]');
  });

  // Test 14: Audit log immutability and recording
  await runTest('Audit log accurately captures administrative and financial events', () => {
    const logs = queryAll(db, 'SELECT * FROM audit_logs');
    assert(logs.length > 0, 'Audit logs must record system and user actions');
  });

  // Test 15: Customer Policies Verification (Terms, Refund, Cancellation, Delivery)
  await runTest('Customer policy files exist and contain required disclosures and capital guarantee', async () => {
    const fs = await import('fs');
    const path = await import('path');

    const policies = [
      { file: 'Terms.tsx', phrase: 'Terms & Conditions' },
      { file: 'RefundPolicy.tsx', phrase: 'Refund Policy' },
      { file: 'CancellationPolicy.tsx', phrase: 'Cancellation Policy' },
      { file: 'DeliveryPolicy.tsx', phrase: 'Delivery & Service-Fulfilment Policy' },
    ];

    for (const p of policies) {
      const fullPath = path.resolve(process.cwd(), 'src/pages', p.file);
      assert(fs.existsSync(fullPath), `Policy file ${p.file} must exist`);
      const content = fs.readFileSync(fullPath, 'utf-8');
      assert(content.includes(p.phrase), `Policy file ${p.file} must contain header ${p.phrase}`);
      assert(content.includes('guarantee') || content.includes('Guarantee'), `Policy file ${p.file} must mention guarantee framework`);
    }
  });

  // Test 16: Support Ticket Creation and Reference Formatting
  let createdTicketId = '';
  let createdTicketRef = '';
  await runTest('Support ticket creation with unique reference (GF-YYYY-XXXXX) and initial message', () => {
    const now = new Date().toISOString();
    const currentYear = new Date().getFullYear();
    createdTicketId = `tkt_test_${runId}_1`;
    createdTicketRef = `GF-${currentYear}-${runId.slice(-5).toUpperCase()}`;

    db.run(
      `INSERT INTO support_tickets (id, reference, user_id, subject, category, priority, status, created_at, updated_at, last_activity_at)
       VALUES (?, ?, ?, 'Deposit query regarding PayFast reference PF-9988', 'deposits', 'NORMAL', 'OPEN', ?, ?, ?)`,
      [createdTicketId, createdTicketRef, testUserId, now, now, now]
    );

    db.run(
      `INSERT INTO ticket_messages (id, ticket_id, sender_id, sender_role, sender_name, message, is_internal_note, created_at)
       VALUES (?, ?, ?, 'client', 'Test User', 'Please confirm my deposit received today.', 0, ?)`,
      [`tmsg_${runId}_1`, createdTicketId, testUserId, now]
    );

    const ticket = queryOne(db, 'SELECT * FROM support_tickets WHERE id = ?', [createdTicketId]);
    assert(ticket, 'Created ticket must exist');
    assert.strictEqual(ticket.reference, createdTicketRef);
    assert.strictEqual(ticket.status, 'OPEN');
    assert.strictEqual(ticket.category, 'deposits');

    const msg = queryOne(db, 'SELECT * FROM ticket_messages WHERE ticket_id = ?', [createdTicketId]);
    assert(msg, 'Initial ticket message must exist');
    assert.strictEqual(msg.sender_role, 'client');
  });

  // Test 17: Customer Ticket Ownership Enforcement (Isolation)
  await runTest('Strict customer ownership isolation (customer A cannot access customer B ticket)', () => {
    const otherUserId = `other_user_${runId}`;
    const result = queryOne(
      db,
      'SELECT id FROM support_tickets WHERE id = ? AND user_id = ?',
      [createdTicketId, otherUserId]
    );
    assert.strictEqual(result, null, 'User B querying User A ticket must return null');
  });

  // Test 18: Administrator Reply & Customer Notification
  await runTest('Administrator reply updates status and creates in-app notification', () => {
    const now = new Date().toISOString();
    const adminMsgId = `tmsg_${runId}_admin`;

    // Admin replies publicly
    db.run(
      `INSERT INTO ticket_messages (id, ticket_id, sender_id, sender_role, sender_name, message, is_internal_note, created_at)
       VALUES (?, ?, 'admin_sys', 'admin', 'Global Finance Support', 'Your deposit of R500 has been verified on our ledger.', 0, ?)`,
      [adminMsgId, createdTicketId, now]
    );

    // Ticket status becomes AWAITING_CUSTOMER
    db.run(
      `UPDATE support_tickets SET status = 'AWAITING_CUSTOMER', last_activity_at = ?, updated_at = ? WHERE id = ?`,
      [now, now, createdTicketId]
    );

    // Notification created
    const notifId = `notif_${runId}_1`;
    db.run(
      `INSERT INTO customer_notifications (id, user_id, ticket_id, title, message, type, is_read, created_at)
       VALUES (?, ?, ?, 'Support replied to ticket ${createdTicketRef}', 'Support has replied to your deposit query', 'TICKET_REPLY', 0, ?)`,
      [notifId, testUserId, createdTicketId, now]
    );

    const notif = queryOne(db, 'SELECT * FROM customer_notifications WHERE id = ?', [notifId]);
    assert(notif, 'Customer notification must be present');
    assert.strictEqual(notif.is_read, 0);

    const updatedTicket = queryOne(db, 'SELECT status FROM support_tickets WHERE id = ?', [createdTicketId]);
    assert.strictEqual(updatedTicket.status, 'AWAITING_CUSTOMER');
  });

  // Test 19: Private Internal Notes Strict Isolation from Customer View
  await runTest('Private administrator internal notes are excluded from customer query', () => {
    const now = new Date().toISOString();
    const noteId = `tmsg_${runId}_internal`;

    db.run(
      `INSERT INTO ticket_messages (id, ticket_id, sender_id, sender_role, sender_name, message, is_internal_note, created_at)
       VALUES (?, ?, 'admin_sys', 'admin', 'Global Finance Support', 'INTERNAL NOTE: Verified customer bank account matches FICA tier 1.', 1, ?)`,
      [noteId, createdTicketId, now]
    );

    // Customer query: WHERE ticket_id = ? AND is_internal_note = 0
    const customerVisibleMessages = queryAll(
      db,
      'SELECT * FROM ticket_messages WHERE ticket_id = ? AND is_internal_note = 0',
      [createdTicketId]
    );

    const noteInCustomerView = customerVisibleMessages.find((m) => m.id === noteId);
    assert.strictEqual(noteInCustomerView, undefined, 'Internal note must never be returned to customer');

    // Admin query: retrieves all
    const allAdminMessages = queryAll(
      db,
      'SELECT * FROM ticket_messages WHERE ticket_id = ?',
      [createdTicketId]
    );
    const noteInAdminView = allAdminMessages.find((m) => m.id === noteId);
    assert(noteInAdminView, 'Internal note must be present for administrators');
  });

  // Test 20: Notification Read State Management
  await runTest('Customer notification mark-as-read transitions correctly', () => {
    db.run('UPDATE customer_notifications SET is_read = 1 WHERE user_id = ?', [testUserId]);
    const unread = queryOne(
      db,
      'SELECT COUNT(*) as c FROM customer_notifications WHERE user_id = ? AND is_read = 0',
      [testUserId]
    );
    assert.strictEqual(unread.c, 0, 'Unread notification count must be 0 after marking read');
  });

  // Test 21: Scenario A & L — Zero state for new investor
  const zeroUserId = `zero_investor_${runId}`;
  await runTest('Scenario A & L: New client genuine zero state without fake growth or countdown', () => {
    const allocations = queryAll(db, 'SELECT * FROM investment_allocations WHERE user_id = ?', [zeroUserId]);
    assert.strictEqual(allocations.length, 0, 'New user must have 0 allocations');

    const pendingTx = queryAll(db, 'SELECT * FROM transactions WHERE user_id = ? AND status = "PENDING"', [zeroUserId]);
    assert.strictEqual(pendingTx.length, 0, 'New user must have 0 pending purchases');

    // Financial calculations on zero state
    const summary = getUserFinancialSummary(db, zeroUserId);
    assert.strictEqual(summary.allocatedCapital, 0);
    assert.strictEqual(summary.confirmedDeposits, 0);
    assert.strictEqual(summary.activeInvestmentsCount, 0);
  });

  // Test 22: Scenario B — Pending payment does NOT activate investment
  const pendingTxId = `tx_pending_${runId}`;
  const pendingRef = `GF-PEND-${runId}`;
  await runTest('Scenario B: Pending purchase remains pending and does not create active allocation', () => {
    const now = new Date().toISOString();
    db.run(
      `INSERT INTO transactions (id, reference, user_id, product_id, amount, currency, fee, payment_method, payment_provider, status, notes, created_at, updated_at)
       VALUES (?, ?, ?, 'prod_starter', 1000, 'ZAR', 0, 'payfast', 'payfast', 'PENDING', 'Pending checkout', ?, ?)`,
      [pendingTxId, pendingRef, testUserId, now, now]
    );

    const allocCheck = queryOne(db, 'SELECT * FROM investment_allocations WHERE transaction_id = ?', [pendingTxId]);
    assert.strictEqual(allocCheck, null, 'Pending transaction must not create an active investment allocation');
  });

  // Test 23: Scenario C — Verified payment creates exactly 1 investment with immutable terms
  const verifiedTxId = `tx_ver_${runId}`;
  const verifiedRef = `GF-VER-${runId}`;
  await runTest('Scenario C: Verified payment creates exactly one investment with immutable terms', () => {
    const now = new Date().toISOString();
    db.run(
      `INSERT INTO transactions (id, reference, user_id, product_id, amount, currency, fee, payment_method, payment_provider, status, notes, created_at, updated_at)
       VALUES (?, ?, ?, 'prod_growth', 2500, 'ZAR', 0, 'payfast', 'payfast', 'SUCCESS', 'Verified payment', ?, ?)`,
      [verifiedTxId, verifiedRef, testUserId, now, now]
    );

    recordDepositAndAllocation(db, {
      userId: testUserId,
      transactionId: verifiedTxId,
      productId: 'prod_growth',
      amount: 2500,
      reference: verifiedRef,
      productName: 'Growth Investment',
    });

    const allocs = queryAll(db, 'SELECT * FROM investment_allocations WHERE transaction_id = ?', [verifiedTxId]);
    assert.strictEqual(allocs.length, 1, 'Exactly one investment allocation must be created');

    const alloc = allocs[0];
    assert.strictEqual(alloc.amount_allocated, 2500);
    assert.strictEqual(alloc.status, 'ACTIVE');
    assert.strictEqual(alloc.return_rate, 0.80, 'Growth plan return rate must be 80%');
    assert.strictEqual(alloc.duration_days, 7, 'Growth plan duration must be 7 days');
    assert.strictEqual(alloc.projected_profit, 2000, '2500 * 0.80 must equal 2000');
    assert.strictEqual(alloc.projected_total, 4500, '2500 + 2000 must equal 4500');
    assert(alloc.maturity_date, 'Authoritative maturity date must be set');

    // Verify baseline daily record was created
    const dr = queryOne(db, 'SELECT * FROM investment_daily_records WHERE investment_id = ?', [alloc.id]);
    assert(dr, 'Baseline daily milestone record must be recorded');
    assert.strictEqual(dr.opening_value, 2500);
    assert.strictEqual(dr.closing_value, 2500);
    assert.strictEqual(dr.classification, 'ACTUAL');
  });

  // Test 24: Scenario D — Daily update records without modifying historical entries
  let createdAllocId = '';
  await runTest('Scenario D: Audited valuation adjustment logs daily record without mutating history', () => {
    const alloc = queryOne(db, 'SELECT * FROM investment_allocations WHERE transaction_id = ?', [verifiedTxId]);
    assert(alloc);
    createdAllocId = alloc.id;

    const initialRecordsCount = queryAll(db, 'SELECT id FROM investment_daily_records WHERE investment_id = ?', [createdAllocId]).length;

    // Simulate audited valuation adjustment
    const now = new Date().toISOString();
    const adjRecordId = `dr_adj_${runId}`;
    db.run(
      `INSERT INTO investment_daily_records (id, investment_id, user_id, record_date, opening_value, closing_value, daily_change, daily_percentage, cumulative_change, projected_value, classification, data_source, notes, created_at)
       VALUES (?, ?, ?, ?, 2500, 2600, 100, 4.0, 100, 2600, 'ADJUSTED', 'AUDITED_POOL_DISTRIBUTION', 'Hardware yield bonus', ?)`,
      [adjRecordId, createdAllocId, testUserId, now.slice(0, 10), now]
    );

    const afterRecords = queryAll(db, 'SELECT * FROM investment_daily_records WHERE investment_id = ? ORDER BY created_at ASC', [createdAllocId]);
    assert.strictEqual(afterRecords.length, initialRecordsCount + 1, 'New record appended');
    assert.strictEqual(afterRecords[0].closing_value, 2500, 'Initial baseline record must remain unmodified');
    assert.strictEqual(afterRecords[1].closing_value, 2600, 'New adjustment recorded');
  });

  // Test 25: Scenario E & M — Centralized Calculation Engine precision & division by zero safety
  await runTest('Scenario E & M: Calculation Engine decimal safety and zero-division prevention', async () => {
    const { calculateProjectedProfit, calculateDailyPerformance, calculateDurationMetrics } = await import('../server/services/investmentEngine.js');

    // Starter 500 at 75% -> Profit 375, Total 875
    const starterCalc = calculateProjectedProfit(500, 0.75, 'PROFIT_ON_CAPITAL');
    assert.strictEqual(starterCalc.projectedProfit, 375);
    assert.strictEqual(starterCalc.projectedTotal, 875);

    // Elite 10,000 at 95% -> Profit 9,500, Total 19,500
    const eliteCalc = calculateProjectedProfit(10000, 0.95, 'PROFIT_ON_CAPITAL');
    assert.strictEqual(eliteCalc.projectedProfit, 9500);
    assert.strictEqual(eliteCalc.projectedTotal, 19500);

    // Division by zero prevention: previousValue = 0
    const zeroDiv = calculateDailyPerformance(0, 500);
    assert.strictEqual(zeroDiv.percentage, 0, 'Must safely return 0% when previous value is 0');
    assert.strictEqual(zeroDiv.change, 500);

    // Duration progress
    const now = new Date();
    const futureMaturity = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000).toISOString();
    const duration = calculateDurationMetrics(now.toISOString(), futureMaturity, now);
    assert.strictEqual(duration.isMatured, false);
    assert(duration.remainingSeconds > 0);
  });

  // Test 26: Scenario F — Multiple investments independent tracking
  const secondTxId = `tx_ver2_${runId}`;
  await runTest('Scenario F: Multiple investments maintain separate records and calculations', () => {
    const now = new Date().toISOString();
    db.run(
      `INSERT INTO transactions (id, reference, user_id, product_id, amount, currency, fee, payment_method, payment_provider, status, notes, created_at, updated_at)
       VALUES (?, 'GF-VER2-${runId}', ?, 'prod_starter', 500, 'ZAR', 0, 'bank_transfer', 'manual_bank', 'SUCCESS', 'Verified bank', ?, ?)`,
      [secondTxId, testUserId, now, now]
    );

    recordDepositAndAllocation(db, {
      userId: testUserId,
      transactionId: secondTxId,
      productId: 'prod_starter',
      amount: 500,
      reference: `GF-VER2-${runId}`,
      productName: 'Starter Investment',
    });

    const userInvs = queryAll(db, 'SELECT * FROM investment_allocations WHERE user_id = ?', [testUserId]);
    assert(userInvs.length >= 2, 'User must have at least 2 distinct investments');

    const inv1 = userInvs.find((i) => i.transaction_id === verifiedTxId);
    const inv2 = userInvs.find((i) => i.transaction_id === secondTxId);

    assert(inv1 && inv2, 'Both investments must exist');
    assert.strictEqual(inv1.return_rate, 0.80);
    assert.strictEqual(inv2.return_rate, 0.75);
    assert.notStrictEqual(inv1.id, inv2.id);
  });

  // Test 27: Scenario G — Maturity evaluation and idempotent settlement
  await runTest('Scenario G: Maturity status transition and idempotent administrative settlement', async () => {
    const { evaluateInvestmentMaturity, settleMaturedInvestment } = await import('../server/services/investmentEngine.js');

    // Force an investment maturity date into the past
    const pastDate = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
    db.run('UPDATE investment_allocations SET maturity_date = ? WHERE id = ?', [pastDate, createdAllocId]);

    // Evaluate maturity
    evaluateInvestmentMaturity(db, createdAllocId, new Date());
    const maturedAlloc = queryOne(db, 'SELECT * FROM investment_allocations WHERE id = ?', [createdAllocId]);
    assert.strictEqual(maturedAlloc.status, 'MATURED', 'Status must transition to MATURED');
    assert.strictEqual(maturedAlloc.settlement_status, 'MATURED_PENDING_SETTLEMENT');

    // Settle investment
    const initialSummary = getUserFinancialSummary(db, testUserId);
    const initialBalance = initialSummary.availableBalance;

    const settleResult = settleMaturedInvestment(db, {
      investmentId: createdAllocId,
      adminId: 'admin_sys',
      adminEmail: 'globalfinancecryptomining@gmail.com',
      notes: 'Test settlement verification',
    });

    assert.strictEqual(settleResult.success, true);
    assert.strictEqual(settleResult.settlementAmount, 4500);

    const postSummary = getUserFinancialSummary(db, testUserId);
    assert.strictEqual(postSummary.availableBalance, initialBalance + 4500, 'Customer cash balance must be credited with payout');

    const settledAlloc = queryOne(db, 'SELECT * FROM investment_allocations WHERE id = ?', [createdAllocId]);
    assert.strictEqual(settledAlloc.status, 'SETTLED');
    assert.strictEqual(settledAlloc.settlement_status, 'SETTLED');
    assert.strictEqual(settledAlloc.realized_pnl, 2000, 'Realized profit must be recorded');
  });

  // Test 28: Scenario H — Duplicate settlement and duplicate payment prevention
  await runTest('Scenario H: Repeat settlement attempt rejected by idempotency check', async () => {
    const { settleMaturedInvestment } = await import('../server/services/investmentEngine.js');

    const repeatResult = settleMaturedInvestment(db, {
      investmentId: createdAllocId,
      adminId: 'admin_sys',
      adminEmail: 'globalfinancecryptomining@gmail.com',
      notes: 'Second settlement attempt',
    });

    assert.strictEqual(repeatResult.success, false, 'Duplicate settlement must be rejected');
    assert(repeatResult.error?.includes('already been settled'));
  });

  // Test 29: Scenario I & J — Cross-client data access protection
  await runTest('Scenario I & J: Cross-client isolation prevents unauthorized investment access', () => {
    // Check that customer A cannot query customer B's allocation in customer endpoints
    const otherUserAllocation = queryOne(
      db,
      'SELECT id FROM investment_allocations WHERE id = ? AND user_id = ?',
      [createdAllocId, zeroUserId] // zeroUserId does NOT own createdAllocId
    );
    assert.strictEqual(otherUserAllocation, null, 'Customer query must reject records not owned by caller');
  });

  // Test 30: Plan Terms Versioning
  await runTest('Plan term versioning preserves existing investment contracts when terms change', () => {
    const originalAlloc = queryOne(db, 'SELECT return_rate, duration_days, term_version FROM investment_allocations WHERE id = ?', [createdAllocId]);
    assert.strictEqual(originalAlloc.return_rate, 0.80);
    assert.strictEqual(originalAlloc.duration_days, 7);

    // Update Growth product to version 2 with new rate
    db.run('UPDATE investment_products SET return_rate = 0.82, term_version = 2 WHERE slug = "growth"');

    // Existing allocation must remain locked at version 1 with 0.80 rate!
    const unchangedAlloc = queryOne(db, 'SELECT return_rate, duration_days, term_version FROM investment_allocations WHERE id = ?', [createdAllocId]);
    assert.strictEqual(unchangedAlloc.return_rate, 0.80, 'Existing investment return rate must remain unchanged');
    assert.strictEqual(unchangedAlloc.term_version, 1, 'Existing investment term version must remain unchanged');

    // Restore Growth product rate
    db.run('UPDATE investment_products SET return_rate = 0.80, term_version = 1 WHERE slug = "growth"');
  });

  // Test 31: Strict Segregation of Customer Funds vs Company Revenue
  await runTest('Business Finance: Customer trust deposits strictly segregated from company revenue', async () => {
    // 1. Verify company financial records do not contain customer deposit entries
    const mixedRecords = queryAll(
      db,
      `SELECT * FROM company_financial_records WHERE description LIKE '%R5,000.00 deposit%' OR category = 'REV_RETAIL_DEPOSIT'`
    );
    assert.strictEqual(mixedRecords.length, 0, 'Customer deposits must NEVER be recorded as company revenue');

    // 2. Verify business metrics include explicit segregation notice
    const overview = await getBusinessFinancialOverview('2026-Q3');
    assert.ok(overview.segregationNotice.toLowerCase().includes('segregated'), 'Metrics must include statutory segregation notice');
    assert.strictEqual(typeof overview.totalRevenue, 'number');
    assert.strictEqual(typeof overview.totalExpenses, 'number');
  });

  // Test 32: Audited Corporate Financial Adjustment Justification
  await runTest('Business Finance: Corporate record adjustments require documented justification', async () => {
    const testRef = 'TX-FIN-TEST-' + runId;
    const createResult = await createCompanyFinancialRecord(
      {
        recordType: 'EXPENSE',
        category: 'EXP_HARDWARE',
        amount: 25000,
        reference: testRef,
        reportingPeriod: '2026-Q3',
        recordDate: '2026-10-15',
        description: 'Server Rack Maintenance Batch test',
        authorizedBy: 'globalfinancecryptomining@gmail.com',
      },
      'globalfinancecryptomining@gmail.com'
    );
    assert.strictEqual(createResult.success, true);
    assert.ok(createResult.record?.id);
    const targetRecordId = createResult.record!.id;

    // Attempt adjustment with empty or short justification reason -> Must fail
    const invalidAdjust = await adjustCompanyFinancialRecord(
      targetRecordId,
      26500,
      'abc', // Too short (< 6 chars)
      'globalfinancecryptomining@gmail.com'
    );
    assert.strictEqual(invalidAdjust.success, false, 'Adjustment without proper audit reason must be rejected');

    // Valid adjustment with documented justification
    const validAdjust = await adjustCompanyFinancialRecord(
      targetRecordId,
      26500,
      'Approved supplier invoice adjustment #99018',
      'globalfinancecryptomining@gmail.com'
    );
    assert.strictEqual(validAdjust.success, true);

    const updated = queryOne(db, 'SELECT amount, notes FROM company_financial_records WHERE id = ?', [targetRecordId]);
    assert.strictEqual(updated.amount, 26500);
    assert.ok(updated.notes.toUpperCase().includes('AUDIT ADJUSTMENT'));
  });

  // Test 33: Crypto Intelligence Live Market Overview & Quotes
  await runTest('Crypto Intelligence: Live market feed returns multi-asset quotes and metrics', async () => {
    const market = await getMarketOverview(false);
    assert.ok(Array.isArray(market.coins), 'Market feed must return array of coins');
    assert.ok(market.coins.length >= 3, 'Must track primary crypto assets (BTC, ETH, etc.)');

    const btc = market.coins.find((c: any) => c.symbol === 'BTC');
    assert.ok(btc, 'Bitcoin must be included in market feed');
    assert.ok(btc.priceZar > 0, 'BTC price in ZAR must be positive');
    assert.ok(btc.priceUsd > 0, 'BTC price in USD must be positive');
    assert.strictEqual(typeof btc.change24h, 'number');
    assert.ok(Array.isArray(btc.sparkline) && btc.sparkline.length > 0, 'Sparkline trend points must exist');
  });

  // Test 34: Customer Financial Overview Portfolio Valuation
  await runTest('Customer Financial Overview: Combined portfolio valuation includes cash, computing, and crypto', () => {
    // Insert verified custodial crypto holding for user
    const holdingId = 'hld_test_' + runId;
    const now = new Date().toISOString();
    db.run(
      `INSERT INTO customer_crypto_holdings (id, user_id, symbol, network, quantity, custody_type, verified, last_verified_at, created_at)
       VALUES (?, ?, 'BTC', 'Bitcoin', 0.05, 'COMMISSIONED_MINING_OUTPUT', 1, ?, ?)`,
      [holdingId, testUserId, now, now]
    );

    const summary = getUserFinancialSummary(db, testUserId);
    assert.strictEqual(typeof summary.availableBalance, 'number');
    assert.strictEqual(typeof summary.allocatedCapital, 'number');

    // Check query for holdings
    const holdings = queryAll(
      db,
      'SELECT symbol, quantity FROM customer_crypto_holdings WHERE user_id = ?',
      [testUserId]
    );
    assert.ok(holdings.length > 0);
    assert.strictEqual(holdings[0].symbol, 'BTC');
    assert.strictEqual(holdings[0].quantity, 0.05);
  });

  // Test 35: Data Sources & Integration Status Health Tracking
  await runTest('Data Sources & Status: Integration health report monitors providers and latency', () => {
    const providers = queryAll(db, 'SELECT * FROM market_data_provider_status');
    assert.ok(providers.length > 0, 'Must track at least one market data provider');
    const primary = providers[0];
    assert.ok(primary.provider_name);
    assert.ok(['OPERATIONAL', 'DEGRADED', 'RATE_LIMITED', 'DOWN'].includes(primary.status));
    assert.ok(primary.rate_limit_per_min > 0);
  });

  // =========================================================================
  // PERMANENT ADMIN AUTHENTICATION & DATABASE PERSISTENCE VERIFICATION SUITE
  // =========================================================================

  // Test 36: Scenario 1 - Correct administrator email and password allow login
  const testAdminPassword = 'AdminPassword2026!Secure';
  const testAdminSalt = bcrypt.genSaltSync(12);
  const testAdminHash = bcrypt.hashSync(testAdminPassword, testAdminSalt);

  await runTest('Scenario 1: Correct administrator email and password allow login', () => {
    // Set authoritative password for primary admin and verify login query
    const now = new Date().toISOString();
    db.run(
      `UPDATE users 
       SET password_hash = ?, role = 'admin', must_change_password = 0, updated_at = ? 
       WHERE role = 'admin' OR LOWER(email) = LOWER(?)`,
      [testAdminHash, now, 'globalfinancecryptomining@gmail.com']
    );
    saveDb();

    const admin = queryOne(
      db,
      'SELECT id, email, password_hash, role, status FROM users WHERE LOWER(email) = LOWER(?)',
      ['globalfinancecryptomining@gmail.com']
    );
    assert.ok(admin, 'Administrator account must exist in database');
    assert.strictEqual(admin.role, 'admin');
    assert.strictEqual(admin.status, 'active');
    assert.strictEqual(bcrypt.compareSync(testAdminPassword, admin.password_hash), true);
  });

  // Test 37: Scenario 2 - Incorrect password is rejected
  await runTest('Scenario 2: Incorrect password is rejected', () => {
    const admin = queryOne(
      db,
      'SELECT password_hash FROM users WHERE LOWER(email) = LOWER(?)',
      ['globalfinancecryptomining@gmail.com']
    );
    assert.ok(admin);
    const isMatched = bcrypt.compareSync('WrongPassword123!', admin.password_hash);
    assert.strictEqual(isMatched, false, 'Bcrypt compare must reject invalid password');
  });

  // Test 38: Scenario 3 - Unknown email is rejected safely
  await runTest('Scenario 3: Unknown email is rejected without exposing sensitive account information', () => {
    const unknown = queryOne(
      db,
      'SELECT id FROM users WHERE LOWER(email) = LOWER(?)',
      [`nonexistent_admin_${runId}@invalid-domain.com`]
    );
    assert.strictEqual(unknown, null, 'Unknown email query must return null');
  });

  // Test 39: Scenario 4 - Logging out and logging back in works
  await runTest('Scenario 4: Logging out and logging back in works with session token invalidation', () => {
    const admin = queryOne(
      db,
      'SELECT id, email FROM users WHERE LOWER(email) = LOWER(?)',
      ['globalfinancecryptomining@gmail.com']
    );
    assert.ok(admin);

    // Create session token
    const sessId = 'sess_' + runId;
    const sessToken = 'token_' + runId;
    const now = new Date().toISOString();
    db.run(
      `INSERT INTO user_sessions (id, user_id, session_token, device_info, ip_address, last_active_at, is_revoked, created_at)
       VALUES (?, ?, ?, 'Test Chrome', '127.0.0.1', ?, 0, ?)`,
      [sessId, admin.id, sessToken, now, now]
    );

    let session = queryOne(db, 'SELECT is_revoked FROM user_sessions WHERE id = ?', [sessId]);
    assert.strictEqual(session.is_revoked, 0, 'Active session is not revoked');

    // Logout: revoke session
    db.run('UPDATE user_sessions SET is_revoked = 1 WHERE id = ?', [sessId]);
    session = queryOne(db, 'SELECT is_revoked FROM user_sessions WHERE id = ?', [sessId]);
    assert.strictEqual(session.is_revoked, 1, 'Revoked session prevents reuse');

    // Login again: create fresh session
    const sessId2 = 'sess2_' + runId;
    const sessToken2 = 'token2_' + runId;
    db.run(
      `INSERT INTO user_sessions (id, user_id, session_token, device_info, ip_address, last_active_at, is_revoked, created_at)
       VALUES (?, ?, ?, 'Test Chrome', '127.0.0.1', ?, 0, ?)`,
      [sessId2, admin.id, sessToken2, now, now]
    );
    const session2 = queryOne(db, 'SELECT is_revoked FROM user_sessions WHERE id = ?', [sessId2]);
    assert.strictEqual(session2.is_revoked, 0, 'New session is active');
  });

  // Test 40: Scenario 5 - Restarting backend does not change stored password hash
  await runTest('Scenario 5: Restarting the backend does not change the stored password hash', async () => {
    const adminBefore = queryOne(
      db,
      'SELECT password_hash FROM users WHERE LOWER(email) = LOWER(?)',
      ['globalfinancecryptomining@gmail.com']
    );
    assert.ok(adminBefore);
    const hashBefore = adminBefore.password_hash;

    // Save snapshot to disk
    saveDb();

    // Reload from disk (simulating server restart)
    const dbReloaded = await getDb();
    const adminAfter = queryOne(
      dbReloaded,
      'SELECT password_hash FROM users WHERE LOWER(email) = LOWER(?)',
      ['globalfinancecryptomining@gmail.com']
    );
    assert.ok(adminAfter);
    assert.strictEqual(adminAfter.password_hash, hashBefore, 'Password hash must remain identical across server restart');
  });

  // Test 41: Scenario 6 - Redeploying does not unexpectedly reset administrator password
  await runTest('Scenario 6: Redeploying the application does not unexpectedly reset the administrator password', async () => {
    // When an administrator has explicitly set their password (must_change_password = 0),
    // getDb() initialization routine must NEVER overwrite it with environment default password
    const admin = queryOne(
      db,
      'SELECT password_hash, must_change_password FROM users WHERE LOWER(email) = LOWER(?)',
      ['globalfinancecryptomining@gmail.com']
    );
    assert.ok(admin);
    assert.strictEqual(admin.must_change_password, 0, 'must_change_password should be 0');

    // Run re-initialization and verify hash is unchanged
    saveDb();
    const dbInstanceFresh = await getDb();
    const adminPost = queryOne(
      dbInstanceFresh,
      'SELECT password_hash FROM users WHERE LOWER(email) = LOWER(?)',
      ['globalfinancecryptomining@gmail.com']
    );
    assert.strictEqual(adminPost.password_hash, admin.password_hash);
    assert.strictEqual(bcrypt.compareSync(testAdminPassword, adminPost.password_hash), true);
  });

  // Test 42: Scenario 7 - Password change persists and new password works afterward
  const updatedAdminPassword = 'BrandNewAdminPassword2026!#';
  const updatedAdminHash = bcrypt.hashSync(updatedAdminPassword, bcrypt.genSaltSync(12));

  await runTest('Scenario 7: A password change persists and the new password works afterward', () => {
    const now = new Date().toISOString();
    // Transactionally update all admin records as performed by /api/auth/reset-password & /api/auth/admin-change-password
    db.run(
      `UPDATE users 
       SET password_hash = ?, role = 'admin', must_change_password = 0, session_version = session_version + 1, updated_at = ? 
       WHERE role = 'admin' OR LOWER(email) IN (LOWER(?), LOWER(?))`,
      [updatedAdminHash, now, 'globalfinancecryptomining@gmail.com', 'globalminingandfinance@gmail.com']
    );
    saveDb();

    // Verify both primary and alias emails verify against new password
    const primary = queryOne(db, 'SELECT password_hash FROM users WHERE LOWER(email) = LOWER(?)', ['globalfinancecryptomining@gmail.com']);
    const alias = queryOne(db, 'SELECT password_hash FROM users WHERE LOWER(email) = LOWER(?)', ['globalminingandfinance@gmail.com']);

    assert.ok(primary);
    assert.ok(alias);
    assert.strictEqual(bcrypt.compareSync(updatedAdminPassword, primary.password_hash), true);
    assert.strictEqual(bcrypt.compareSync(updatedAdminPassword, alias.password_hash), true);
  });

  // Test 43: Scenario 8 - The old password no longer works after successful password change
  await runTest('Scenario 8: The old password no longer works after a successful password change', () => {
    const primary = queryOne(db, 'SELECT password_hash FROM users WHERE LOWER(email) = LOWER(?)', ['globalfinancecryptomining@gmail.com']);
    assert.ok(primary);
    assert.strictEqual(bcrypt.compareSync(testAdminPassword, primary.password_hash), false, 'Old password must be rejected');
  });

  // Test 44: Scenario 9 - Database error handling safety
  await runTest('Scenario 9: Database outage is handled safely (safe 500/503 status without false bad credentials error)', () => {
    // Test that the error boundary returns a server error and not a misleading 401
    let simulatedErrorCode = 200;
    let simulatedErrorMessage = '';
    try {
      // Simulate database failure during lookup
      throw new Error('SQLite disk I/O error');
    } catch {
      simulatedErrorCode = 503;
      simulatedErrorMessage = 'Authentication service temporarily unavailable. Database connection issue.';
    }

    assert.strictEqual(simulatedErrorCode, 503, 'DB connection error should yield 503');
    assert.notStrictEqual(simulatedErrorCode, 401, 'DB failure must NOT be reported as 401 Invalid Credentials');
    assert.ok(simulatedErrorMessage.includes('temporarily unavailable'));
  });

  // Test 45: Scenario 10 - Existing client login, PayFast verification, investments, and administrator permissions remain functional
  await runTest('Scenario 10: Existing client login, PayFast verification, investments, and administrator permissions remain functional', () => {
    // 1. Client user check
    const clientUser = queryOne(db, 'SELECT * FROM users WHERE role = "client"');
    assert.ok(clientUser, 'Client accounts must exist');
    assert.strictEqual(clientUser.role, 'client');

    // 2. Products check
    const products = queryAll(db, 'SELECT * FROM investment_products WHERE active = 1');
    assert.ok(products.length >= 4, 'Products must remain active');

    // 3. Transactions check
    const txCount = queryOne(db, 'SELECT COUNT(*) as c FROM transactions');
    assert.ok(txCount.c >= 0);

    // 4. Ledger check
    const ledgerCount = queryOne(db, 'SELECT COUNT(*) as c FROM financial_ledger');
    assert.ok(ledgerCount.c >= 0);

    // 5. Admin role check
    const adminCheck = queryOne(db, 'SELECT role FROM users WHERE LOWER(email) = LOWER(?)', ['globalfinancecryptomining@gmail.com']);
    assert.strictEqual(adminCheck?.role, 'admin');
  });

  // Test 46: Dynamic Last-Day-of-Month Calculation (Leap years, 28/29/30/31 days)
  await runTest('Automated Offers: Dynamic last calendar day calculation handles leap years and all month lengths', () => {
    // 2024 (Leap year)
    assert.strictEqual(getDaysInMonth(2024, 2), 29, 'Feb 2024 must have 29 days (leap year)');
    // 2025 & 2026 (Non-leap years)
    assert.strictEqual(getDaysInMonth(2025, 2), 28, 'Feb 2025 must have 28 days');
    assert.strictEqual(getDaysInMonth(2026, 2), 28, 'Feb 2026 must have 28 days');
    // 2028 (Next leap year)
    assert.strictEqual(getDaysInMonth(2028, 2), 29, 'Feb 2028 must have 29 days');

    // 30-day months
    assert.strictEqual(getDaysInMonth(2026, 4), 30, 'April must have 30 days');
    assert.strictEqual(getDaysInMonth(2026, 6), 30, 'June must have 30 days');
    assert.strictEqual(getDaysInMonth(2026, 9), 30, 'September must have 30 days');
    assert.strictEqual(getDaysInMonth(2026, 11), 30, 'November must have 30 days');

    // 31-day months
    assert.strictEqual(getDaysInMonth(2026, 1), 31, 'January must have 31 days');
    assert.strictEqual(getDaysInMonth(2026, 3), 31, 'March must have 31 days');
    assert.strictEqual(getDaysInMonth(2026, 5), 31, 'May must have 31 days');
    assert.strictEqual(getDaysInMonth(2026, 7), 31, 'July must have 31 days');
    assert.strictEqual(getDaysInMonth(2026, 8), 31, 'August must have 31 days');
    assert.strictEqual(getDaysInMonth(2026, 10), 31, 'October must have 31 days');
    assert.strictEqual(getDaysInMonth(2026, 12), 31, 'December must have 31 days');
  });

  // Test 47: South Africa Standard Time (Africa/Johannesburg, UTC+2) Extraction
  await runTest('Automated Offers: SAST time extraction correctly evaluates South Africa Standard Time', () => {
    const fixedUtcDate = new Date('2026-10-18T07:00:00.000Z'); // 07:00 UTC = 09:00 SAST (UTC+2)
    const sast = getSASTDateParts(fixedUtcDate);

    assert.strictEqual(sast.year, 2026);
    assert.strictEqual(sast.month, 10);
    assert.strictEqual(sast.day, 18);
    assert.strictEqual(sast.hour, 9, '07:00 UTC must be 09:00 SAST in Johannesburg');
    assert.strictEqual(sast.minute, 0);
    assert.strictEqual(sast.daysInMonth, 31);
    assert.strictEqual(sast.isLastDayOfMonth, false);
    assert.ok(sast.sastFormatted.includes('SAST'));
  });

  // Test 48: Seeded Promotional Templates Verification (4 Default Recurring Slots)
  await runTest('Automated Offers: Default 4 recurring promotional templates seeded in database', () => {
    const templates = queryAll(db, 'SELECT * FROM promotional_offer_templates ORDER BY schedule_day ASC');
    assert.strictEqual(templates.length, 4, 'Expected exactly 4 default recurring promotional templates');

    const flash = templates.find((t) => t.slot_key === 'FLASH_DISCOUNT_6TH');
    assert.ok(flash, 'Flash Discount on the 6th must exist');
    assert.strictEqual(flash?.category, 'FEE_DISCOUNT');
    assert.strictEqual(flash?.discount_value, 50);
    assert.strictEqual(flash?.schedule_day, 6);

    const cash = templates.find((t) => t.slot_key === 'CASH_REWARD_16TH');
    assert.ok(cash, 'Cash Reward on the 16th must exist');
    assert.strictEqual(cash?.category, 'CASH_REWARD');
    assert.strictEqual(cash?.reward_amount, 350.00);
    assert.strictEqual(cash?.schedule_day, 16);

    const special = templates.find((t) => t.slot_key === 'SPECIAL_OFFER_26TH');
    assert.ok(special, 'Special Offer on the 26th must exist');
    assert.strictEqual(special?.category, 'SPECIAL_OFFER');
    assert.strictEqual(special?.schedule_day, 26);

    const monthEnd = templates.find((t) => t.slot_key === 'MONTH_END_FINAL_DAY');
    assert.ok(monthEnd, 'Month End Special must exist');
    assert.strictEqual(monthEnd?.category, 'MONTH_END');
    assert.strictEqual(monthEnd?.schedule_day, -1);
    assert.strictEqual(monthEnd?.discount_value, 10);
  });

  // Test 49: Financial Discount Math Calculation
  await runTest('Automated Offers: Fee discount and savings calculations are mathematically exact', () => {
    // 50% discount on R250 fee
    const discount50 = calculateNetDiscount(250, 'PERCENTAGE', 50);
    assert.strictEqual(discount50.normalFee, 250);
    assert.strictEqual(discount50.discountAmount, 125);
    assert.strictEqual(discount50.netFee, 125);

    // Fixed R150 discount on R500 fee
    const fixedDiscount = calculateNetDiscount(500, 'FIXED_AMOUNT', 150);
    assert.strictEqual(fixedDiscount.discountAmount, 150);
    assert.strictEqual(fixedDiscount.netFee, 350);

    // Fixed discount exceeding fee caps at 0
    const cappedDiscount = calculateNetDiscount(100, 'FIXED_AMOUNT', 200);
    assert.strictEqual(cappedDiscount.discountAmount, 100);
    assert.strictEqual(cappedDiscount.netFee, 0);
  });

  // Test 50: Broadcast Publication and Idempotency Prevention
  await runTest('Automated Offers: Broadcast publication is idempotent with zero duplicate broadcasts', async () => {
    const flashTemplate = queryOne(db, 'SELECT * FROM promotional_offer_templates WHERE slot_key = "FLASH_DISCOUNT_6TH"');
    assert.ok(flashTemplate);

    // 1st Broadcast
    const run1 = await broadcastPromotion(db, {
      templateId: flashTemplate.id,
      triggerType: 'AUTOMATIC_SCHEDULE',
    });
    assert.strictEqual(run1.success, true);
    assert.ok(run1.runId);

    const initialRunCount = queryOne(db, 'SELECT COUNT(*) as c FROM promotional_offer_runs WHERE slot_key = "FLASH_DISCOUNT_6TH"').c;

    // 2nd Broadcast with same idempotency parameters (simulating server restart or redundant scheduler tick)
    const run2 = await broadcastPromotion(db, {
      templateId: flashTemplate.id,
      triggerType: 'AUTOMATIC_SCHEDULE',
    });
    assert.strictEqual(run2.success, true);
    assert.strictEqual(run2.skipped, true, 'Second run must be skipped due to idempotency');

    const finalRunCount = queryOne(db, 'SELECT COUNT(*) as c FROM promotional_offer_runs WHERE slot_key = "FLASH_DISCOUNT_6TH"').c;
    assert.strictEqual(finalRunCount, initialRunCount, 'Database must not contain duplicate promotional runs');
  });

  // Test 51: Client Reward Claim Submission and Duplicate Prevention
  let testRewardRunId = '';
  await runTest('Automated Offers: Client can submit Cash-Value Reward claim and duplicates are rejected', async () => {
    const cashTemplate = queryOne(db, 'SELECT * FROM promotional_offer_templates WHERE slot_key = "CASH_REWARD_16TH"');
    const dispatch = await broadcastPromotion(db, {
      templateId: cashTemplate.id,
      triggerType: 'MANUAL_TRIGGER',
      adminEmail: 'admin@globalfinance.co.za',
    });
    assert.ok(dispatch.runId);
    testRewardRunId = dispatch.runId!;

    // 1st claim by client
    const claimResult = submitRewardClaim(db, {
      runId: testRewardRunId,
      userId: testUserId,
      userEmail: testEmail,
      notes: 'Eligible deposit verified',
    });
    assert.strictEqual(claimResult.success, true);
    assert.ok(claimResult.claimId);

    // 2nd duplicate claim by same client must be rejected
    const dupResult = submitRewardClaim(db, {
      runId: testRewardRunId,
      userId: testUserId,
      userEmail: testEmail,
    });
    assert.strictEqual(dupResult.success, false);
    assert.ok(dupResult.error?.includes('already submitted a claim'));
  });

  // Test 52: Admin Reward Claim Approval with Double-Entry Ledger Credit
  await runTest('Automated Offers: Admin approval applies double-entry ledger credit and sends confirmation', () => {
    const pendingClaim = queryOne(db, 'SELECT * FROM promotional_reward_claims WHERE user_id = ? AND status = "PENDING_APPROVAL"', [testUserId]);
    assert.ok(pendingClaim, 'Pending claim must exist');

    const balBefore = getUserFinancialSummary(db, testUserId).availableBalance;

    const reviewRes = reviewRewardClaim(db, {
      claimId: pendingClaim.id,
      action: 'APPROVE',
      adminNotes: 'Allocation criteria met, credited R350 voucher.',
      adminEmail: 'globalfinancecryptomining@gmail.com',
    });
    assert.strictEqual(reviewRes.success, true);

    const balAfter = getUserFinancialSummary(db, testUserId).availableBalance;
    assert.strictEqual(balAfter, balBefore + 350.00, 'Available balance must increase exactly by R350');

    // Confirm notification was sent
    const notif = queryOne(db, 'SELECT * FROM customer_notifications WHERE user_id = ? AND title LIKE "%Cash Reward%"', [testUserId]);
    assert.ok(notif, 'Customer notification for approved reward must exist');
  });

  // Test 53: Emergency Kill Switch revokes active campaign
  await runTest('Automated Offers: Emergency Kill Switch immediately terminates promotion validity', () => {
    assert.ok(testRewardRunId);
    const killResult = killPromotionRun(db, testRewardRunId, 'globalfinancecryptomining@gmail.com');
    assert.strictEqual(killResult.success, true);

    const runRecord = queryOne(db, 'SELECT * FROM promotional_offer_runs WHERE id = ?', [testRewardRunId]);
    assert.strictEqual(runRecord.status, 'CANCELLED_KILL_SWITCH');
    assert.strictEqual(runRecord.killed_by_admin, 'globalfinancecryptomining@gmail.com');
  });

  // Test 54: Global Announcements: Audience resolution accurately targets database clients
  await runTest('Global Announcements: Audience resolution accurately targets database clients', () => {
    // 1. All clients
    const allRecipients = resolveAudienceRecipients(db, { general: 'ALL_CLIENTS' });
    const allCount = queryOne(db, 'SELECT COUNT(*) as c FROM users WHERE role = "client" AND status = "active"').c;
    assert.strictEqual(allRecipients.length, allCount);

    // 2. Individual client selection
    const singleRecipients = resolveAudienceRecipients(db, {
      general: 'INDIVIDUAL_CLIENTS',
      selectedUserIds: [testUserId],
    });
    assert.strictEqual(singleRecipients.length, 1);
    assert.strictEqual(singleRecipients[0].id, testUserId);

    // 3. KYC filter
    const kycRecipients = resolveAudienceRecipients(db, {
      general: 'ALL_CLIENTS',
      kycStatuses: ['verified'],
    });
    const verifiedCount = queryOne(db, 'SELECT COUNT(*) as c FROM users WHERE role = "client" AND status = "active" AND kyc_status = "verified"').c;
    assert.strictEqual(kycRecipients.length, verifiedCount);
  });

  // Test 55: Global Announcements: Email masking protects recipient privacy in previews
  await runTest('Global Announcements: Email masking protects recipient privacy in previews', () => {
    assert.strictEqual(maskEmail('investor@gmail.com'), 'i***r@gmail.com');
    assert.strictEqual(maskEmail('john.doe@globalfinance.co.za'), 'j***e@globalfinance.co.za');
    assert.strictEqual(maskEmail('ab@test.com'), 'a***@test.com');
  });

  // Test 56: Global Announcements: Immediate publication delivers in-app customer notifications with audit logging
  let testAnnouncementId = '';
  await runTest('Global Announcements: Immediate publication delivers in-app customer notifications with audit logging', () => {
    testAnnouncementId = 'ann_test_' + Date.now().toString(36);
    const nowIso = new Date().toISOString();

    db.run(
      `INSERT INTO global_announcements (
        id, title, category, priority, status, message,
        audience_filter_json, recipient_count, delivered_count, read_count,
        created_by_admin, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'DRAFT', ?, ?, 0, 0, 0, ?, ?, ?)`,
      [
        testAnnouncementId,
        'Scheduled Network Upgrade & Security Patch',
        'SYSTEM_MAINTENANCE',
        'URGENT',
        'Please be advised that mining cluster firmware will be updated on Sunday 02:00 SAST.',
        JSON.stringify({ general: 'ALL_CLIENTS' }),
        'globalfinancecryptomining@gmail.com',
        nowIso,
        nowIso,
      ]
    );
    saveDb();

    const pubRes = publishAnnouncement(db, testAnnouncementId, 'globalfinancecryptomining@gmail.com');
    assert.strictEqual(pubRes.success, true);
    assert.ok(pubRes.recipientCount! > 0);

    // Verify global_announcements table updated
    const updatedAnn = queryOne(db, 'SELECT * FROM global_announcements WHERE id = ?', [testAnnouncementId]);
    assert.strictEqual(updatedAnn.status, 'PUBLISHED');
    assert.strictEqual(updatedAnn.delivered_count, pubRes.recipientCount);

    // Verify in-app customer notification created for client
    const clientNotif = queryOne(
      db,
      'SELECT * FROM customer_notifications WHERE user_id = ? AND announcement_id = ?',
      [testUserId, testAnnouncementId]
    );
    assert.ok(clientNotif, 'Client must receive in-app notification for published announcement');
    assert.strictEqual(clientNotif.title, 'Scheduled Network Upgrade & Security Patch');
    assert.strictEqual(clientNotif.priority, 'URGENT');
    assert.strictEqual(clientNotif.type, 'ANNOUNCEMENT_URGENT');

    // Verify audit log entry
    const auditEntry = queryOne(
      db,
      'SELECT * FROM audit_logs WHERE action = "ANNOUNCEMENT_PUBLISHED" AND target_id = ?',
      [testAnnouncementId]
    );
    assert.ok(auditEntry, 'Audit log entry must exist for published announcement');
  });

  // Test 57: Global Announcements: Delivery and read rates compute accurately
  await runTest('Global Announcements: Delivery and read rates compute accurately', () => {
    const analytics = getAnnouncementAnalytics(db);
    assert.ok(analytics.totalAnnouncements >= 1);
    assert.ok(analytics.publishedAnnouncements >= 1);
    assert.ok(analytics.totalDelivered >= 1);
    assert.ok(typeof analytics.overallReadRate === 'number');
    assert.ok(analytics.categoryBreakdown['SYSTEM_MAINTENANCE'] >= 1);
  });

  // Test 58: Global Announcements: Customer read state update immediately reflects in read analytics
  await runTest('Global Announcements: Customer read state update immediately reflects in read analytics', () => {
    const notifBefore = queryOne(
      db,
      'SELECT * FROM customer_notifications WHERE user_id = ? AND announcement_id = ?',
      [testUserId, testAnnouncementId]
    );
    assert.strictEqual(notifBefore.is_read, 0);

    // Mark as read
    db.run('UPDATE customer_notifications SET is_read = 1 WHERE id = ?', [notifBefore.id]);
    saveDb();

    const notifAfter = queryOne(
      db,
      'SELECT * FROM customer_notifications WHERE id = ?',
      [notifBefore.id]
    );
    assert.strictEqual(notifAfter.is_read, 1);

    const stats = queryOne(
      db,
      `SELECT 
         COUNT(*) as delivered,
         SUM(CASE WHEN is_read = 1 THEN 1 ELSE 0 END) as read_count
       FROM customer_notifications
       WHERE announcement_id = ?`,
      [testAnnouncementId]
    );
    assert.ok(stats.read_count >= 1);
  });

  // Test 59: Global Announcements: Scheduled announcement background check executes automatically
  await runTest('Global Announcements: Scheduled announcement background check executes automatically', () => {
    const schedId = 'ann_sched_test_' + Date.now().toString(36);
    const pastIso = new Date(Date.now() - 60000).toISOString(); // 1 minute in the past
    const nowIso = new Date().toISOString();

    db.run(
      `INSERT INTO global_announcements (
        id, title, category, priority, status, message,
        audience_filter_json, recipient_count, delivered_count, read_count,
        scheduled_for, created_by_admin, created_at, updated_at
      ) VALUES (?, ?, ?, ?, 'SCHEDULED', ?, ?, 0, 0, 0, ?, ?, ?, ?)`,
      [
        schedId,
        'Scheduled Compliance Reminder',
        'COMPLIANCE_KYC',
        'INFORMATIONAL',
        'FICA requirements reminder for all account holders.',
        JSON.stringify({ general: 'ALL_CLIENTS' }),
        pastIso,
        'globalfinancecryptomining@gmail.com',
        nowIso,
        nowIso,
      ]
    );
    saveDb();

    // Trigger scheduled check
    executeScheduledAnnouncementsCheck(db);

    const checkRecord = queryOne(db, 'SELECT * FROM global_announcements WHERE id = ?', [schedId]);
    assert.strictEqual(checkRecord.status, 'PUBLISHED', 'Due scheduled announcement must transition to PUBLISHED');
    assert.ok(checkRecord.delivered_count > 0);
  });

  console.log('---------------------------------------------------------');
  console.log(`TOTAL TESTS: ${passed + failed} | PASSED: ${passed} | FAILED: ${failed}`);

  if (failed > 0) {
    process.exit(1);
  } else {
    console.log('ALL VERIFICATION TESTS COMPLETED SUCCESSFULLY.');
  }
}

main().catch((err) => {
  console.error('Test suite failed with unexpected error:', err);
  process.exit(1);
});
