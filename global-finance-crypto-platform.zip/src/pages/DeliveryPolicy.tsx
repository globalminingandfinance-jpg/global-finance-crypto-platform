import React from 'react';
import { ArrowLeft, Cpu, Zap, CheckCircle2, Clock, ShieldCheck, AlertCircle, FileText, Mail, Server } from 'lucide-react';

interface DeliveryPolicyProps {
  onNavigate?: (view: string) => void;
}

export const DeliveryPolicy: React.FC<DeliveryPolicyProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-12 text-slate-300">
      {/* Back button */}
      {onNavigate && (
        <button
          onClick={() => onNavigate('home')}
          className="inline-flex items-center space-x-2 text-xs text-amber-400 hover:text-amber-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
      )}

      {/* Header */}
      <div className="space-y-4 border-b border-slate-800 pb-8">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
          <Zap className="w-3.5 h-3.5" />
          <span>DIGITAL SERVICE FULFILMENT & ALLOCATION POLICY</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-slate-100">
          Delivery & Service-Fulfilment Policy
        </h1>
        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
          <span><strong>Effective Date:</strong> October 15, 2026</span>
          <span>•</span>
          <span><strong>Platform:</strong> Global Finance Crypto Mining</span>
          <span>•</span>
          <span><strong>Service Type:</strong> Purely Digital Computational Allocation</span>
        </div>
      </div>

      {/* Critical Non-Physical Goods Notice */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-6 text-xs sm:text-sm space-y-2 leading-relaxed text-amber-100">
        <div className="flex items-center space-x-2 text-amber-300 font-bold text-sm">
          <Cpu className="w-4 h-4 shrink-0 text-amber-400" />
          <span>NOTICE: 100% DIGITAL SERVICE — NO PHYSICAL SHIPMENTS</span>
        </div>
        <p>
          Global Finance Crypto Mining provides <strong>exclusively digital financial technology and computational hashing power allocation services</strong>. We do <strong>NOT</strong> package, dispatch, courier, or deliver any physical merchandise, boxed hardware, or tangible physical goods to residential or commercial street addresses.
        </p>
        <p className="text-[11px] text-amber-200/80">
          All service delivery and allocation fulfilment occurs electronically and instantaneously within our authenticated web platform and cloud infrastructure.
        </p>
      </div>

      {/* Content Sections */}
      <div className="space-y-8 text-xs sm:text-sm leading-relaxed">
        {/* Section 1 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              01
            </span>
            <h2>What the Customer Receives (Deliverables)</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Upon successful payment and verification of your investment transaction, you receive the following verifiable digital deliverables:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-amber-300 font-semibold text-xs">
                  <Server className="w-4 h-4 shrink-0" />
                  <span>1. Dedicated Computational Hash Power Allocation</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  Immediate reservation of high-performance mining cluster capacity corresponding to your chosen plan tier (Starter R500, Growth R1,000, Professional R2,500, or Elite R10,000 – R2,000,000).
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-amber-300 font-semibold text-xs">
                  <FileText className="w-4 h-4 shrink-0" />
                  <span>2. Cryptographically Sealed Official Receipt</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  A downloadable, printable PDF/modal receipt featuring a unique verification reference, payment gateway transaction ID, exact timestamp, and customer metadata.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-amber-300 font-semibold text-xs">
                  <ShieldCheck className="w-4 h-4 shrink-0" />
                  <span>3. Authoritative Double-Entry Ledger Entry</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  Atomic creation of an immutable ledger credit (DEPOSIT) and debit (ALLOCATION) recording your guaranteed principal in your platform account.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-amber-300 font-semibold text-xs">
                  <Cpu className="w-4 h-4 shrink-0" />
                  <span>4. Active Real-Time Dashboard Position</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  Instant visibility in your Customer Dashboard under &quot;My Investments&quot;, displaying allocation status, terms, capital amount, and computational performance tracking.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              02
            </span>
            <h2>Service Provisioning & Fulfilment Timeframes</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Because delivery is 100% digital, delivery times are tied strictly to payment settlement and confirmation:
            </p>
            <div className="space-y-3 pt-2 text-xs">
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-emerald-400">PayFast Online Gateway (Card / Instant EFT)</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-semibold">
                    REAL-TIME / INSTANT (0 – 10 MINUTES)
                  </span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Upon completion of checkout on the official PayFast gateway and cryptographic validation of the Instant Transaction Notification (ITN) by our server, the investment allocation is provisioned <strong>instantaneously</strong>. Your dashboard reflects your new active allocation within moments.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300">Direct Electronic Bank Transfer (Manual EFT)</span>
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-[10px] font-semibold">
                    1 – 24 BUSINESS HOURS
                  </span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Bank transfer orders are initialized with status <span className="font-mono text-amber-400">PENDING</span>. Once funds reflect in our designated business account (Account Name: [BAHOLO CONSULTING], Bank: [TymeBank/GoTymeBank]) and are matched against your unique transaction reference, an authorized administrator reconciles the transaction, activating the allocation and recording ledger entries immediately.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              03
            </span>
            <h2>Investment Capital Guarantee & Principal Protection</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 text-xs space-y-2 text-amber-200">
              <span className="font-bold text-amber-300 block">Fulfillment of Investment Guarantee:</span>
              <p>
                Service delivery includes our explicit <strong>Investment Capital Guarantee</strong>. All invested funds are protected from platform operational loss and are accounted for in an auditable double-entry accounting ledger. Your principal amount remains intact and verifiable throughout the active contract cycle, with full entitlement to redemption upon contract completion.
              </p>
            </div>
          </div>
        </section>

        {/* Section 4 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              04
            </span>
            <h2>Customer Notification on Completion</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>You will receive multiple confirmations when service fulfilment occurs:</p>
            <ul className="list-disc pl-5 space-y-1.5 text-slate-400 text-xs">
              <li><strong>Electronic Confirmation Email:</strong> An automated confirmation containing transaction metadata, allocated tier name, and receipt link is dispatched to your registered email address.</li>
              <li><strong>In-App Badge Update:</strong> Your Customer Dashboard will display a green &quot;ACTIVE&quot; badge next to the investment position.</li>
              <li><strong>Receipt Generation:</strong> The &quot;Receipt&quot; button in your transaction history table will unlock, allowing you to view and download your verified transaction receipt.</li>
            </ul>
          </div>
        </section>

        {/* Section 5 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              05
            </span>
            <h2>Handling Delays, Interruptions & Fulfilment Inquiries</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              In the unlikely event that your payment succeeded but your computational allocation has not been activated within the anticipated timeframe:
            </p>
            <ol className="list-decimal pl-5 space-y-2 text-slate-400 text-xs">
              <li>
                <strong>Check Your Bank Transfer Reference:</strong> If paying via bank transfer, ensure you included your exact unique reference (e.g. GF-20261015-XXXXXXXX) in the transfer description. If omitted, our admin cannot automatically match the transfer.
              </li>
              <li>
                <strong>Contact Support with Proof:</strong> Submit a support ticket or email <span className="text-amber-300 font-mono">[compliance@globalfinancecryptomining.co.za]</span> with your transaction reference and bank proof of payment.
              </li>
              <li>
                <strong>Safety Guarantee:</strong> Your funds are never lost due to connection timeouts or network lag. Every valid transfer is securely accounted for in our pending reconciliation queue and will be credited to your account upon review.
              </li>
            </ol>
          </div>
        </section>
      </div>

      {/* Footer Navigation helper */}
      {onNavigate && (
        <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex flex-wrap gap-4 text-slate-400">
            <button onClick={() => onNavigate('terms')} className="text-amber-400 hover:underline">
              ← View Terms & Conditions
            </button>
            <button onClick={() => onNavigate('refund-policy')} className="text-amber-400 hover:underline">
              View Refund Policy →
            </button>
            <button onClick={() => onNavigate('cancellation-policy')} className="text-amber-400 hover:underline">
              View Cancellation Policy →
            </button>
          </div>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="text-slate-400 hover:text-white"
          >
            ↑ Back to Top
          </button>
        </div>
      )}
    </div>
  );
};
