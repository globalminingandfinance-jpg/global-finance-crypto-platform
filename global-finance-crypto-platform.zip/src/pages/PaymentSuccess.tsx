import React, { useState, useEffect } from 'react';
import { ReceiptData } from '../types/index.js';
import { ReceiptModal } from '../components/ReceiptModal.js';
import { CheckCircle2, Clock, AlertCircle, FileText, ArrowRight, RefreshCw, LayoutDashboard } from 'lucide-react';

interface PaymentSuccessProps {
  reference: string;
  onNavigateDashboard: () => void;
  onNavigateInvestments: () => void;
}

export const PaymentSuccess: React.FC<PaymentSuccessProps> = ({
  reference,
  onNavigateDashboard,
  onNavigateInvestments,
}) => {
  const [loading, setLoading] = useState(true);
  const [verifiedData, setVerifiedData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<ReceiptData | null>(null);

  const checkVerification = async () => {
    if (!reference) {
      setError('No transaction reference supplied in URL.');
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/payments/verify/${encodeURIComponent(reference)}`);
      const data = await res.json();
      if (res.ok && data.transaction) {
        setVerifiedData(data.transaction);
      } else {
        setError(data.error || 'Transaction reference not found.');
      }
    } catch {
      setError('Network error verifying transaction status.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    checkVerification();
  }, [reference]);

  const handleOpenReceipt = async () => {
    if (!reference) return;
    try {
      const res = await fetch(`/api/payments/receipt/${encodeURIComponent(reference)}`);
      const data = await res.json();
      if (res.ok) {
        setSelectedReceipt(data);
      } else {
        alert(data.error || 'Receipt unavailable until transaction is confirmed.');
      }
    } catch {
      alert('Network error retrieving receipt.');
    }
  };

  const isSuccess = verifiedData && verifiedData.status === 'SUCCESS';
  const isPending = verifiedData && verifiedData.status === 'PENDING';

  return (
    <div className="min-h-[80vh] flex items-center justify-center p-4 bg-[#070b12]">
      <ReceiptModal receipt={selectedReceipt} onClose={() => setSelectedReceipt(null)} />

      <div className="w-full max-w-xl bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        {loading ? (
          <div className="text-center py-12 space-y-4">
            <RefreshCw className="w-10 h-10 text-amber-400 animate-spin mx-auto" />
            <h2 className="text-lg font-bold text-slate-100">Verifying Payment With Gateway...</h2>
            <p className="text-xs text-slate-400">
              Querying authoritative database records for reference <span className="font-mono">{reference}</span>...
            </p>
          </div>
        ) : error ? (
          <div className="text-center py-8 space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center justify-center mx-auto">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h2 className="text-xl font-bold text-slate-100">Verification Query Failed</h2>
            <p className="text-xs text-red-400">{error}</p>
            <div className="pt-4 flex justify-center space-x-3">
              <button
                onClick={checkVerification}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800"
              >
                Retry Check
              </button>
              <button
                onClick={onNavigateDashboard}
                className="px-4 py-2 rounded-xl text-xs font-bold text-black bg-amber-400"
              >
                Go to Dashboard
              </button>
            </div>
          </div>
        ) : isPending ? (
          /* Verification Pending View */
          <div className="text-center py-6 space-y-5">
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto shadow-lg shadow-amber-500/10">
              <Clock className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">Payment Verification In Progress</h1>
              <p className="text-xs text-slate-400 mt-2 max-w-md mx-auto leading-relaxed">
                Your payment is being verified. Please check your transaction status shortly.
              </p>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs space-y-2 text-left">
              <div className="flex justify-between">
                <span className="text-slate-500">Transaction Reference:</span>
                <span className="font-mono font-bold text-amber-400">{verifiedData.reference}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Investment Amount:</span>
                <span className="font-mono text-slate-200">R {verifiedData.amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Payment Channel:</span>
                <span className="text-slate-300 uppercase">
                  {verifiedData.paymentMethod === 'payfast' ? 'PayFast Online Gateway' : 'Bank EFT'}
                </span>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={checkVerification}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Refresh Status</span>
              </button>
              <button
                onClick={onNavigateDashboard}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-bold text-black bg-amber-400 hover:bg-amber-300"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Return to Dashboard</span>
              </button>
            </div>
          </div>
        ) : (
          /* Confirmed SUCCESS View */
          <div className="space-y-6">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div>
                <h1 className="text-2xl font-bold font-serif text-slate-100">Payment Successful</h1>
                <p className="text-xs text-emerald-400/90 font-medium mt-1">
                  Your payment has been successfully processed.
                </p>
              </div>
            </div>

            {/* Verified Details Table */}
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-3 text-xs divide-y divide-slate-800/80">
              <div className="flex justify-between items-center pb-2">
                <span className="text-slate-400">Transaction Reference</span>
                <span className="font-mono font-bold text-amber-300">{verifiedData.reference}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-slate-400">Investment Product</span>
                <span className="font-semibold text-slate-100">{verifiedData.productName}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-slate-400">Amount</span>
                <span className="font-mono text-base font-bold text-slate-100">
                  R {verifiedData.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })} {verifiedData.currency}
                </span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-slate-400">Payment Provider</span>
                <span className="text-slate-200">
                  {verifiedData.paymentProvider === 'payfast' ? 'PayFast (Pty) Ltd' : 'Electronic Funds Transfer'}
                </span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-slate-400">Payment Status</span>
                <span className="font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                  {verifiedData.status} (VERIFIED)
                </span>
              </div>
              <div className="flex justify-between items-center pt-2">
                <span className="text-slate-400">Transaction Date</span>
                <span className="text-slate-300">{new Date(verifiedData.createdAt).toLocaleString()}</span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 text-center leading-relaxed">
              Your investment allocation has been recorded in the double-entry financial ledger and is now visible in your customer portal.
            </p>

            {/* Action Buttons */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                onClick={handleOpenReceipt}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors"
              >
                <FileText className="w-4 h-4 text-amber-400" />
                <span>View Official Receipt</span>
              </button>
              <button
                onClick={onNavigateDashboard}
                className="w-full sm:w-auto flex items-center justify-center space-x-2 px-6 py-2.5 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/20"
              >
                <span>Return to Dashboard</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
