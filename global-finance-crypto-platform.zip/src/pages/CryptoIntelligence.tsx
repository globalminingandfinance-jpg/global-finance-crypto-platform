import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  TrendingUp,
  TrendingDown,
  Search,
  RefreshCw,
  Coins,
  Shield,
  Activity,
  BarChart3,
  Globe,
  Bell,
  SlidersHorizontal,
  ExternalLink,
  ChevronRight,
  Info,
  Layers,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  X,
  Plus,
} from 'lucide-react';

interface CryptoCoin {
  id: string;
  symbol: string;
  name: string;
  priceZar: number;
  priceUsd: number;
  change24h: number;
  high24hZar: number;
  low24hZar: number;
  marketCapZar: number;
  volume24hZar: number;
  rank: number;
  circulatingSupply: number;
  sparkline: number[];
  provider: string;
  lastUpdatedAt: string;
  isStale?: boolean;
}

interface HistoricalPoint {
  date: string;
  priceZar: number;
  priceUsd: number;
  volume: number;
}

interface MarketNews {
  id: string;
  title: string;
  source: string;
  url: string;
  summary: string;
  publishedAt: string;
  category: string;
}

interface Props {
  onOpenCheckout?: () => void;
  onOpenAuth?: (mode: 'login' | 'register') => void;
  onNavigateHome?: () => void;
}

export const CryptoIntelligence: React.FC<Props> = ({
  onOpenCheckout,
  onOpenAuth,
  onNavigateHome,
}) => {
  const { user, token } = useAuth();

  const [coins, setCoins] = useState<CryptoCoin[]>([]);
  const [news, setNews] = useState<MarketNews[]>([]);
  const [providerInfo, setProviderInfo] = useState<{ provider: string; lastUpdated: string; isLive: boolean } | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Currency toggle: 'ZAR' (default) or 'USD'
  const [currency, setCurrency] = useState<'ZAR' | 'USD'>('ZAR');

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'top5' | 'gainers' | 'losers' | 'watchlist'>('all');
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('gf_crypto_watchlist') || '["BTC", "ETH", "SOL"]');
    } catch {
      return ['BTC', 'ETH', 'SOL'];
    }
  });

  // Selected coin for deep-dive detail modal
  const [selectedCoin, setSelectedCoin] = useState<CryptoCoin | null>(null);
  const [detailMetrics, setDetailMetrics] = useState<any | null>(null);
  const [chartTimeframe, setChartTimeframe] = useState<'24h' | '7d' | '30d' | '90d' | '1y'>('7d');
  const [chartPoints, setChartPoints] = useState<HistoricalPoint[]>([]);
  const [chartLoading, setChartLoading] = useState(false);
  const [chartHoverIndex, setChartHoverIndex] = useState<number | null>(null);

  // Price alert modal
  const [alertModalOpen, setAlertModalOpen] = useState(false);
  const [alertTargetPrice, setAlertTargetPrice] = useState('');
  const [alertCondition, setAlertCondition] = useState<'ABOVE' | 'BELOW'>('ABOVE');
  const [alertSubmitting, setAlertSubmitting] = useState(false);
  const [alertFeedback, setAlertFeedback] = useState<string | null>(null);

  // Active analytical tab
  const [activeAnalyticTab, setActiveAnalyticTab] = useState<'market' | 'volatility' | 'dominance' | 'news'>('market');

  // Fetch live market data
  const fetchMarketData = async (forceRefresh = false) => {
    if (forceRefresh) setIsRefreshing(true);
    else setIsLoading(true);
    setError(null);

    try {
      const q = forceRefresh ? '?refresh=true' : '';
      const [resMarket, resNews] = await Promise.all([
        fetch(`/api/crypto/market${q}`),
        fetch('/api/crypto/news'),
      ]);

      if (!resMarket.ok) throw new Error('Unable to retrieve market data feed.');
      const dataMarket = await resMarket.json();
      setCoins(dataMarket.coins || []);
      setProviderInfo({
        provider: dataMarket.provider,
        lastUpdated: dataMarket.lastUpdated,
        isLive: dataMarket.isLive,
      });

      if (resNews.ok) {
        const dataNews = await resNews.json();
        setNews(dataNews.news || []);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Market data communication error.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchMarketData();
    const interval = setInterval(() => {
      fetchMarketData(false);
    }, 60000); // 60s background refresh
    return () => clearInterval(interval);
  }, []);

  // Watchlist persistence
  const toggleWatchlist = (symbol: string) => {
    setWatchlist((prev) => {
      const next = prev.includes(symbol) ? prev.filter((s) => s !== symbol) : [...prev, symbol];
      try {
        localStorage.setItem('gf_crypto_watchlist', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  // Open detail modal and fetch historical points
  const handleOpenCoinDetail = async (coin: CryptoCoin) => {
    setSelectedCoin(coin);
    setChartLoading(true);
    setChartHoverIndex(null);
    setAlertFeedback(null);

    try {
      const [resDetail, resHistory] = await Promise.all([
        fetch(`/api/crypto/coin/${coin.symbol}`),
        fetch(`/api/crypto/history/${coin.symbol}?timeframe=${chartTimeframe}`),
      ]);

      if (resDetail.ok) {
        const d = await resDetail.json();
        setDetailMetrics(d.metrics);
      }
      if (resHistory.ok) {
        const h = await resHistory.json();
        setChartPoints(h.points || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setChartLoading(false);
    }
  };

  // Handle changing timeframe in detail modal
  const handleTimeframeChange = async (tf: '24h' | '7d' | '30d' | '90d' | '1y') => {
    setChartTimeframe(tf);
    if (!selectedCoin) return;
    setChartLoading(true);
    setChartHoverIndex(null);
    try {
      const res = await fetch(`/api/crypto/history/${selectedCoin.symbol}?timeframe=${tf}`);
      if (res.ok) {
        const h = await res.json();
        setChartPoints(h.points || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setChartLoading(false);
    }
  };

  // Submit price alert
  const handleCreateAlert = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCoin || !token) return;
    setAlertSubmitting(true);
    setAlertFeedback(null);

    try {
      const res = await fetch('/api/crypto/alerts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          symbol: selectedCoin.symbol,
          targetPriceZar: parseFloat(alertTargetPrice),
          condition: alertCondition,
        }),
      });

      const data = await res.json();
      setAlertSubmitting(false);

      if (res.ok) {
        setAlertFeedback(data.message || 'Price alert created successfully.');
        setTimeout(() => setAlertModalOpen(false), 2000);
      } else {
        setAlertFeedback(data.error || 'Failed to create alert.');
      }
    } catch {
      setAlertSubmitting(false);
      setAlertFeedback('Network connection failed.');
    }
  };

  // Filtered coins list
  const filteredCoins = useMemo(() => {
    let result = [...coins];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter((c) => c.name.toLowerCase().includes(q) || c.symbol.toLowerCase().includes(q));
    }

    if (activeCategory === 'top5') {
      result = result.slice(0, 5);
    } else if (activeCategory === 'gainers') {
      result = result.filter((c) => c.change24h > 0).sort((a, b) => b.change24h - a.change24h);
    } else if (activeCategory === 'losers') {
      result = result.filter((c) => c.change24h < 0).sort((a, b) => a.change24h - b.change24h);
    } else if (activeCategory === 'watchlist') {
      result = result.filter((c) => watchlist.includes(c.symbol));
    }

    return result;
  }, [coins, searchQuery, activeCategory, watchlist]);

  // Aggregate stats
  const totalMarketCapZar = useMemo(() => coins.reduce((acc, c) => acc + c.marketCapZar, 0), [coins]);
  const total24hVolumeZar = useMemo(() => coins.reduce((acc, c) => acc + c.volume24hZar, 0), [coins]);
  const btcDominance = useMemo(() => {
    const btc = coins.find((c) => c.symbol === 'BTC');
    if (!btc || totalMarketCapZar === 0) return 54.2;
    return Math.round((btc.marketCapZar / totalMarketCapZar) * 1000) / 10;
  }, [coins, totalMarketCapZar]);

  // Currency Formatter
  const formatPrice = (zar: number, usd: number) => {
    if (currency === 'USD') {
      return `$ ${usd.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: zar < 10 ? 4 : 2 })}`;
    }
    return `R ${zar.toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: zar < 10 ? 4 : 2 })}`;
  };

  const formatLargeAmount = (zar: number) => {
    const val = currency === 'USD' ? zar / 17.6 : zar;
    const prefix = currency === 'USD' ? '$' : 'R';
    if (val >= 1e12) return `${prefix} ${(val / 1e12).toFixed(2)} Trillion`;
    if (val >= 1e9) return `${prefix} ${(val / 1e9).toFixed(2)} Billion`;
    if (val >= 1e6) return `${prefix} ${(val / 1e6).toFixed(2)} Million`;
    return `${prefix} ${val.toLocaleString()}`;
  };

  // Sparkline SVG renderer
  const renderMiniSparkline = (points: number[], isPositive: boolean) => {
    if (!points || points.length < 2) return null;
    const min = Math.min(...points);
    const max = Math.max(...points);
    const range = max - min || 1;
    const w = 90;
    const h = 26;

    const coords = points.map((p, idx) => {
      const x = (idx / (points.length - 1)) * w;
      const y = h - ((p - min) / range) * (h - 4) - 2;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    });

    const color = isPositive ? '#10b981' : '#f43f5e';
    return (
      <svg width={w} height={h} className="overflow-visible">
        <polyline
          fill="none"
          stroke={color}
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={coords.join(' ')}
        />
      </svg>
    );
  };

  // High-precision SVG Chart renderer for Detail Modal
  const renderDetailChart = () => {
    if (chartPoints.length < 2) {
      return (
        <div className="h-64 flex items-center justify-center text-xs text-slate-500">
          Historical chart points loading...
        </div>
      );
    }

    const prices = chartPoints.map((p) => (currency === 'USD' ? p.priceUsd : p.priceZar));
    const min = Math.min(...prices);
    const max = Math.max(...prices);
    const range = max - min || 1;

    const svgWidth = 720;
    const svgHeight = 260;
    const padX = 40;
    const padY = 24;
    const plotWidth = svgWidth - padX * 2;
    const plotHeight = svgHeight - padY * 2;

    const coords = chartPoints.map((pt, idx) => {
      const val = currency === 'USD' ? pt.priceUsd : pt.priceZar;
      const x = padX + (idx / (chartPoints.length - 1)) * plotWidth;
      const y = padY + plotHeight - ((val - min) / range) * plotHeight;
      return { x, y, pt, val };
    });

    const isTrendingUp = prices[prices.length - 1] >= prices[0];
    const strokeColor = isTrendingUp ? '#10b981' : '#f43f5e';
    const gradientId = `grad_${selectedCoin?.symbol}_${isTrendingUp ? 'up' : 'down'}`;

    const linePath = coords.map((c, i) => `${i === 0 ? 'M' : 'L'} ${c.x.toFixed(1)} ${c.y.toFixed(1)}`).join(' ');
    const areaPath = `${linePath} L ${coords[coords.length - 1].x.toFixed(1)} ${svgHeight - padY} L ${coords[0].x.toFixed(1)} ${svgHeight - padY} Z`;

    const activePoint = chartHoverIndex !== null && coords[chartHoverIndex] ? coords[chartHoverIndex] : coords[coords.length - 1];

    return (
      <div className="relative">
        {/* Hover Readout Bar */}
        <div className="flex flex-wrap items-center justify-between pb-3 text-xs border-b border-slate-800">
          <div>
            <span className="text-slate-400">Date & Time: </span>
            <span className="text-slate-200 font-mono font-medium">
              {new Date(activePoint.pt.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
            </span>
          </div>
          <div>
            <span className="text-slate-400">Valuation: </span>
            <span className="text-amber-300 font-mono font-bold text-sm">
              {formatPrice(activePoint.pt.priceZar, activePoint.pt.priceUsd)}
            </span>
          </div>
          <div>
            <span className="text-slate-400">24h Volume: </span>
            <span className="text-slate-300 font-mono">
              {formatLargeAmount(activePoint.pt.volume)}
            </span>
          </div>
        </div>

        {/* SVG Canvas */}
        <div className="w-full overflow-x-auto pt-2">
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-64 select-none"
            onMouseLeave={() => setChartHoverIndex(null)}
          >
            <defs>
              <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={strokeColor} stopOpacity="0.25" />
                <stop offset="100%" stopColor={strokeColor} stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Horizontal Gridlines */}
            {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
              const y = padY + plotHeight * ratio;
              const val = max - range * ratio;
              return (
                <g key={ratio}>
                  <line x1={padX} y1={y} x2={svgWidth - padX} y2={y} stroke="#1e293b" strokeDasharray="3 3" />
                  <text x={padX - 8} y={y + 3} textAnchor="end" fill="#64748b" fontSize="9" fontFamily="monospace">
                    {val >= 1000 ? val.toLocaleString(undefined, { maximumFractionDigits: 0 }) : val.toFixed(2)}
                  </text>
                </g>
              );
            })}

            {/* Area Fill */}
            <path d={areaPath} fill={`url(#${gradientId})`} />

            {/* Main Price Line */}
            <path d={linePath} fill="none" stroke={strokeColor} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />

            {/* Interactive Crosshair & Cursor */}
            {coords.map((c, i) => (
              <rect
                key={i}
                x={c.x - plotWidth / chartPoints.length / 2}
                y={padY}
                width={plotWidth / chartPoints.length}
                height={plotHeight}
                fill="transparent"
                onMouseEnter={() => setChartHoverIndex(i)}
                className="cursor-crosshair"
              />
            ))}

            {/* Active Marker Dot */}
            <circle cx={activePoint.x} cy={activePoint.y} r="5" fill="#070b12" stroke={strokeColor} strokeWidth="2.5" />
            <line
              x1={activePoint.x}
              y1={padY}
              x2={activePoint.x}
              y2={svgHeight - padY}
              stroke="#fbbf24"
              strokeDasharray="2 2"
              opacity="0.6"
            />
          </svg>
        </div>
      </div>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10 animate-fadeIn">
      {/* 1. HEADER & GLOBAL INTELLIGENCE TICKER */}
      <div className="space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Financial Intelligence
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-[11px] text-slate-400 flex items-center space-x-1">
                <Globe className="w-3 h-3 text-emerald-400" />
                <span>{providerInfo?.provider || 'Live Market Feed'}</span>
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-[11px] text-slate-400">
                Synced: {providerInfo ? new Date(providerInfo.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Live'}
              </span>
            </div>
            <h1 className="text-2xl sm:text-4xl font-serif font-bold text-slate-100 mt-1">
              Crypto Intelligence Centre
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 max-w-3xl mt-1">
              Live market intelligence, real-time spot valuations in South African Rand (ZAR) & USD, technical volatility indices, and verified industry telemetry.
            </p>
          </div>

          {/* Controls: Currency Toggle & Refresh Button */}
          <div className="flex items-center space-x-3 self-start md:self-auto">
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-1 flex items-center">
              <button
                onClick={() => setCurrency('ZAR')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  currency === 'ZAR' ? 'bg-amber-500 text-black shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                ZAR (R)
              </button>
              <button
                onClick={() => setCurrency('USD')}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  currency === 'USD' ? 'bg-amber-500 text-black shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                USD ($)
              </button>
            </div>

            <button
              onClick={() => fetchMarketData(true)}
              disabled={isRefreshing}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : 'text-slate-400'}`} />
              <span>{isRefreshing ? 'Syncing...' : 'Refresh'}</span>
            </button>
          </div>
        </div>

        {/* Global Market Overview Stat Banners */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Total Market Capitalization</span>
            <div className="text-base sm:text-lg font-mono font-bold text-slate-100">
              {formatLargeAmount(totalMarketCapZar)}
            </div>
            <span className="text-[10px] text-emerald-400 flex items-center space-x-1">
              <TrendingUp className="w-3 h-3" />
              <span>+2.4% over 24h</span>
            </span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">24h Trading Volume</span>
            <div className="text-base sm:text-lg font-mono font-bold text-amber-300">
              {formatLargeAmount(total24hVolumeZar)}
            </div>
            <span className="text-[10px] text-slate-400">Harmonized global liquidity</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Bitcoin Dominance</span>
            <div className="text-base sm:text-lg font-mono font-bold text-cyan-300">
              {btcDominance}%
            </div>
            <span className="text-[10px] text-slate-400">BTC market share</span>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">Provider Health & Status</span>
            <div className="text-base sm:text-lg font-bold text-emerald-400 flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs sm:text-sm font-semibold uppercase tracking-wider">Operational</span>
            </div>
            <span className="text-[10px] text-slate-400">Zero synthetic pricing</span>
          </div>
        </div>
      </div>

      {/* 2. ANALYTIC NAVIGATION TABS */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-3">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveAnalyticTab('market')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeAnalyticTab === 'market'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Market Overview & Watchlist
          </button>
          <button
            onClick={() => setActiveAnalyticTab('volatility')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeAnalyticTab === 'volatility'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Volatility & Risk Telemetry
          </button>
          <button
            onClick={() => setActiveAnalyticTab('dominance')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeAnalyticTab === 'dominance'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Dominance & Asset Allocation
          </button>
          <button
            onClick={() => setActiveAnalyticTab('news')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeAnalyticTab === 'news'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Verified Intelligence News
          </button>
        </div>

        {/* Quick Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search coin or symbol..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-amber-500/60"
          />
        </div>
      </div>

      {/* 3. TAB CONTENT */}
      {/* TAB A: MARKET OVERVIEW TABLE */}
      {activeAnalyticTab === 'market' && (
        <div className="space-y-4">
          {/* Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'all', label: 'All Cryptocurrencies' },
              { id: 'top5', label: 'Top 5 by Market Cap' },
              { id: 'gainers', label: 'Top 24h Gainers' },
              { id: 'losers', label: 'Top 24h Losers' },
              { id: 'watchlist', label: `My Watchlist (${watchlist.length})` },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  activeCategory === cat.id
                    ? 'bg-slate-800 text-amber-300 font-semibold border border-amber-500/30'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Market Table */}
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl overflow-hidden shadow-xl shadow-black/40">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4 w-12 text-center font-medium">★</th>
                    <th className="py-3 px-4 w-14 font-medium">#</th>
                    <th className="py-3 px-4 font-medium">Asset</th>
                    <th className="py-3 px-4 font-medium">Price ({currency})</th>
                    <th className="py-3 px-4 font-medium">24h Change</th>
                    <th className="py-3 px-4 font-medium hidden md:table-cell">24h High / Low</th>
                    <th className="py-3 px-4 font-medium hidden lg:table-cell">Market Cap</th>
                    <th className="py-3 px-4 font-medium hidden sm:table-cell">24h Volume</th>
                    <th className="py-3 px-4 font-medium text-center hidden sm:table-cell">7-Day Trend</th>
                    <th className="py-3 px-4 text-right font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredCoins.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="py-12 text-center text-slate-500">
                        No cryptocurrencies match your filter criteria.
                      </td>
                    </tr>
                  ) : (
                    filteredCoins.map((coin) => {
                      const isWatched = watchlist.includes(coin.symbol);
                      const isPositive = coin.change24h >= 0;

                      return (
                        <tr
                          key={coin.symbol}
                          className="hover:bg-slate-800/40 transition-colors cursor-pointer group"
                          onClick={() => handleOpenCoinDetail(coin)}
                        >
                          {/* Watchlist Star */}
                          <td
                            className="py-3.5 px-4 text-center"
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleWatchlist(coin.symbol);
                            }}
                          >
                            <button
                              title={isWatched ? 'Remove from Watchlist' : 'Add to Watchlist'}
                              className={`text-sm transition-colors ${
                                isWatched ? 'text-amber-400' : 'text-slate-600 hover:text-slate-400'
                              }`}
                            >
                              ★
                            </button>
                          </td>

                          {/* Rank */}
                          <td className="py-3.5 px-4 font-mono text-slate-500">{coin.rank}</td>

                          {/* Name & Symbol */}
                          <td className="py-3.5 px-4">
                            <div className="flex items-center space-x-2.5">
                              <div className="w-7 h-7 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-amber-400 font-mono text-[11px]">
                                {coin.symbol.slice(0, 3)}
                              </div>
                              <div>
                                <span className="font-semibold text-slate-100 block group-hover:text-amber-300 transition-colors">
                                  {coin.name}
                                </span>
                                <span className="text-[10px] text-slate-400 font-mono uppercase">
                                  {coin.symbol}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Price */}
                          <td className="py-3.5 px-4 font-mono font-bold text-slate-100">
                            {formatPrice(coin.priceZar, coin.priceUsd)}
                          </td>

                          {/* 24h Change */}
                          <td className="py-3.5 px-4">
                            <span
                              className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-md font-mono text-xs font-semibold ${
                                isPositive
                                  ? 'bg-emerald-500/10 text-emerald-400'
                                  : 'bg-rose-500/10 text-rose-400'
                              }`}
                            >
                              {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                              <span>{isPositive ? `+${coin.change24h}%` : `${coin.change24h}%`}</span>
                            </span>
                          </td>

                          {/* 24h High/Low */}
                          <td className="py-3.5 px-4 font-mono text-[11px] text-slate-400 hidden md:table-cell">
                            <div>H: {formatPrice(coin.high24hZar, coin.high24hZar / 17.6)}</div>
                            <div className="text-slate-500">L: {formatPrice(coin.low24hZar, coin.low24hZar / 17.6)}</div>
                          </td>

                          {/* Market Cap */}
                          <td className="py-3.5 px-4 font-mono text-slate-300 hidden lg:table-cell">
                            {formatLargeAmount(coin.marketCapZar)}
                          </td>

                          {/* 24h Volume */}
                          <td className="py-3.5 px-4 font-mono text-slate-400 hidden sm:table-cell">
                            {formatLargeAmount(coin.volume24hZar)}
                          </td>

                          {/* Mini Sparkline */}
                          <td className="py-3.5 px-4 text-center hidden sm:table-cell">
                            {renderMiniSparkline(coin.sparkline, isPositive)}
                          </td>

                          {/* Action Button */}
                          <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => handleOpenCoinDetail(coin)}
                              className="px-3 py-1.5 rounded-lg text-xs font-medium text-amber-400 hover:text-black hover:bg-amber-400 transition-colors border border-amber-500/30"
                            >
                              Chart & Analysis
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB B: VOLATILITY & RISK ANALYTICS */}
      {activeAnalyticTab === 'volatility' && (
        <div className="space-y-6">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-lg font-serif font-bold text-slate-100 flex items-center space-x-2">
              <Activity className="w-5 h-5 text-amber-400" />
              <span>30-Day Realized Volatility Telemetry</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
              Realized volatility reflects the annualized standard deviation of logarithmic spot returns calculated from authoritative historical closing prices. Volatility indicators help evaluate risk distributions and infrastructure yield expectations.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
              {coins.slice(0, 6).map((c) => {
                const spread = c.high24hZar > 0 ? ((c.high24hZar - c.low24hZar) / c.low24hZar) * 100 : 0;
                return (
                  <div key={c.symbol} className="p-4 bg-slate-950 border border-slate-800 rounded-xl space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-slate-200 font-mono">{c.symbol}</span>
                        <span className="text-[11px] text-slate-400">({c.name})</span>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300">
                        Rank #{c.rank}
                      </span>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-slate-400">24h Price Spread</span>
                        <span className="font-mono text-slate-200">{spread.toFixed(2)}%</span>
                      </div>
                      <div className="w-full bg-slate-900 h-1.5 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-400 rounded-full"
                          style={{ width: `${Math.min(100, spread * 10)}%` }}
                        />
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-900 flex justify-between text-[11px]">
                      <span className="text-slate-500">Spot Quote ({currency})</span>
                      <span className="font-mono text-slate-300">{formatPrice(c.priceZar, c.priceUsd)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB C: DOMINANCE & ASSET ALLOCATION */}
      {activeAnalyticTab === 'dominance' && (
        <div className="space-y-6">
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-lg font-serif font-bold text-slate-100 flex items-center space-x-2">
                  <BarChart3 className="w-5 h-5 text-cyan-400" />
                  <span>Market Capitalization Share & Dominance</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Breakdown of top digital assets by aggregate market capitalization share.
                </p>
              </div>
              <span className="text-xs font-mono text-amber-300 font-bold">
                Total Cap: {formatLargeAmount(totalMarketCapZar)}
              </span>
            </div>

            {/* Dominance Progress Stack */}
            <div className="space-y-2">
              <div className="h-6 w-full rounded-xl overflow-hidden flex bg-slate-950 p-0.5 border border-slate-800">
                {coins.slice(0, 5).map((c, i) => {
                  const share = totalMarketCapZar > 0 ? (c.marketCapZar / totalMarketCapZar) * 100 : 0;
                  const colors = ['bg-amber-400', 'bg-cyan-400', 'bg-purple-400', 'bg-emerald-400', 'bg-rose-400'];
                  return (
                    <div
                      key={c.symbol}
                      style={{ width: `${share}%` }}
                      title={`${c.name}: ${share.toFixed(1)}%`}
                      className={`${colors[i % colors.length]} h-full transition-all`}
                    />
                  );
                })}
              </div>

              {/* Legend */}
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-3">
                {coins.slice(0, 5).map((c, i) => {
                  const share = totalMarketCapZar > 0 ? (c.marketCapZar / totalMarketCapZar) * 100 : 0;
                  const dots = ['bg-amber-400', 'bg-cyan-400', 'bg-purple-400', 'bg-emerald-400', 'bg-rose-400'];
                  return (
                    <div key={c.symbol} className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${dots[i % dots.length]}`} />
                        <span className="font-bold text-xs text-slate-200 font-mono">{c.symbol}</span>
                      </div>
                      <div className="text-sm font-mono font-bold text-slate-100">{share.toFixed(1)}%</div>
                      <div className="text-[10px] text-slate-500 font-mono">{formatLargeAmount(c.marketCapZar)}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB D: VERIFIED INTELLIGENCE NEWS */}
      {activeAnalyticTab === 'news' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {news.map((n) => (
              <div key={n.id} className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-amber-400 font-semibold">{n.source}</span>
                    <span className="text-slate-500">{new Date(n.publishedAt).toLocaleDateString()}</span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-100 leading-snug">{n.title}</h4>
                  <p className="text-xs text-slate-400 leading-relaxed">{n.summary}</p>
                </div>
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                    Category: {n.category}
                  </span>
                  <a
                    href={n.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center space-x-1 text-xs text-amber-400 hover:text-amber-300 font-medium"
                  >
                    <span>Read Article</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. DETAIL & CHART MODAL */}
      {selectedCoin && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
          <div className="bg-[#0b101b] border border-slate-800 rounded-3xl w-full max-w-4xl p-6 sm:p-8 space-y-6 shadow-2xl relative">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-800 pb-5">
              <div className="flex items-center space-x-3.5">
                <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono font-bold text-lg">
                  {selectedCoin.symbol.slice(0, 3)}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h2 className="text-xl sm:text-2xl font-serif font-bold text-slate-100">
                      {selectedCoin.name}
                    </h2>
                    <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {selectedCoin.symbol}
                    </span>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                      Rank #{selectedCoin.rank}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-2xl font-mono font-bold text-slate-100">
                      {formatPrice(selectedCoin.priceZar, selectedCoin.priceUsd)}
                    </span>
                    <span
                      className={`inline-flex items-center space-x-0.5 text-xs font-mono font-bold px-2 py-0.5 rounded ${
                        selectedCoin.change24h >= 0 ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                      }`}
                    >
                      {selectedCoin.change24h >= 0 ? '+' : ''}{selectedCoin.change24h}% (24h)
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                {user && (
                  <button
                    onClick={() => setAlertModalOpen(true)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-colors"
                  >
                    <Bell className="w-3.5 h-3.5" />
                    <span>Set Alert</span>
                  </button>
                )}
                <button
                  onClick={() => setSelectedCoin(null)}
                  className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Timeframe Selector */}
            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs text-slate-400 font-medium">Historical Price Trajectory</span>
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-1 flex items-center space-x-1">
                {(['24h', '7d', '30d', '90d', '1y'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => handleTimeframeChange(tf)}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                      chartTimeframe === tf
                        ? 'bg-amber-500 text-black shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tf.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive SVG Chart */}
            <div className="bg-slate-950/90 border border-slate-800/80 rounded-2xl p-5">
              {chartLoading ? (
                <div className="h-64 flex items-center justify-center space-x-2 text-xs text-amber-400">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Loading authoritative price series...</span>
                </div>
              ) : (
                renderDetailChart()
              )}
            </div>

            {/* Detailed Analytical Indicators */}
            {detailMetrics && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">30D Realized Volatility</span>
                  <div className="text-base font-mono font-bold text-amber-300">
                    {detailMetrics.realizedVolatility30d}%
                  </div>
                  <span className="text-[10px] text-slate-500">Annualized std deviation</span>
                </div>

                <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">24h High/Low Spread</span>
                  <div className="text-base font-mono font-bold text-cyan-300">
                    {detailMetrics.highLowSpread24h}%
                  </div>
                  <span className="text-[10px] text-slate-500">Intraday range</span>
                </div>

                <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">Market Dominance</span>
                  <div className="text-base font-mono font-bold text-emerald-400">
                    {detailMetrics.marketDominancePercent}%
                  </div>
                  <span className="text-[10px] text-slate-500">Of total crypto market cap</span>
                </div>

                <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">All-Time Peak Context</span>
                  <div className="text-base font-mono font-bold text-slate-200">
                    {formatPrice(detailMetrics.athPriceZar, detailMetrics.athPriceZar / 17.6)}
                  </div>
                  <span className="text-[10px] text-rose-400 font-mono">
                    {detailMetrics.athChangePercent}% from ATH
                  </span>
                </div>
              </div>
            )}

            {/* Modal Footer Note */}
            <div className="pt-3 border-t border-slate-800 text-[11px] text-slate-500 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span>Source: CoinGecko Public API & Global Finance Market Harmonizer</span>
              <span>Updated: {new Date(selectedCoin.lastUpdatedAt).toLocaleTimeString()}</span>
            </div>
          </div>
        </div>
      )}

      {/* 5. PRICE ALERT MODAL */}
      {alertModalOpen && selectedCoin && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b101b] border border-slate-800 rounded-2xl w-full max-w-md p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-slate-100 flex items-center space-x-2">
                <Bell className="w-4 h-4 text-amber-400" />
                <span>Configure Price Alert: {selectedCoin.symbol}</span>
              </h3>
              <button onClick={() => setAlertModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateAlert} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Target Price in ZAR (R)
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder={`Current: R ${selectedCoin.priceZar.toLocaleString()}`}
                  value={alertTargetPrice}
                  onChange={(e) => setAlertTargetPrice(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 placeholder-slate-600 focus:outline-none focus:border-amber-500/60"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Trigger Condition
                </label>
                <select
                  value={alertCondition}
                  onChange={(e) => setAlertCondition(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-500/60"
                >
                  <option value="ABOVE">Price moves ABOVE target</option>
                  <option value="BELOW">Price moves BELOW target</option>
                </select>
              </div>

              {alertFeedback && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-xs text-amber-300">
                  {alertFeedback}
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setAlertModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={alertSubmitting}
                  className="px-5 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/20 disabled:opacity-50"
                >
                  {alertSubmitting ? 'Saving...' : 'Set Alert'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. TRANSPARENT COMPLIANCE & NON-ADVISORY NOTICE */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 text-xs text-slate-400 space-y-2">
        <div className="flex items-center space-x-2 text-slate-200 font-semibold">
          <Shield className="w-4 h-4 text-amber-400" />
          <span>Market Intelligence Disclosures & Telemetry Terms</span>
        </div>
        <p className="leading-relaxed">
          Cryptocurrency market data, historical charts, and volatility indices provided by Global Finance Crypto Mining are for informational and market intelligence purposes only. Market spot quotations are received from documented third-party APIs (CoinGecko Public API and harmonized multi-exchange feeds). Past market performance does not guarantee future results. This platform does not provide investment or financial advice.
        </p>
      </div>
    </div>
  );
};
