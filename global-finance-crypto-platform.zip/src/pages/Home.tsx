import React from 'react';
import { InvestmentProduct } from '../types/index.js';
import {
  ShieldCheck,
  Cpu,
  Coins,
  ArrowRight,
  Lock,
  Building2,
  CreditCard,
  CheckCircle2,
  FileText,
  TrendingUp,
  Shield,
  Layers,
  Activity,
} from 'lucide-react';

interface HomeProps {
  onExploreInvestments: () => void;
  onHowItWorks: () => void;
  onSelectProduct: (product: InvestmentProduct) => void;
  onOpenCheckout: () => void;
}

export const Home: React.FC<HomeProps> = ({
  onExploreInvestments,
  onHowItWorks,
  onSelectProduct,
  onOpenCheckout,
}) => {
  const products: InvestmentProduct[] = [
    {
      id: 'prod_starter',
      slug: 'starter',
      name: 'Starter Investment',
      description: 'Designed for customers beginning their digital investment journey.',
      minAmount: 500,
      currency: 'ZAR',
      features: [
        'Starting capital from R500',
        'Access to core computing infrastructure',
        'Bi-weekly performance reporting',
        'Standard digital custody safeguards',
        'Automated financial ledger accounting',
      ],
    },
    {
      id: 'prod_growth',
      slug: 'growth',
      name: 'Growth Investment',
      description: 'Designed for customers looking for a broader investment option.',
      minAmount: 1000,
      currency: 'ZAR',
      features: [
        'Starting capital from R1,000',
        'Enhanced hash allocation & power efficiency',
        'Weekly audit reports & analytics',
        'Dedicated support queue priority',
        'Flexible capital management',
      ],
    },
    {
      id: 'prod_professional',
      slug: 'professional',
      name: 'Professional Investment',
      description: 'Designed for customers seeking a higher-tier investment option.',
      minAmount: 2500,
      currency: 'ZAR',
      features: [
        'Starting capital from R2,500',
        'High-density institutional-grade hardware pool',
        'Daily reconciliation & real-time telemetry',
        'Direct account manager contact',
        'Priority withdrawal processing schedule',
      ],
    },
    {
      id: 'prod_elite',
      slug: 'elite',
      name: 'Elite Investment',
      description: 'Designed for high-tier and premium users seeking maximum computational power and institutional custody.',
      minAmount: 10000,
      currency: 'ZAR',
      features: [
        'Starting capital from R10,000 up to R2,000,000',
        'Dedicated ASIC mining cluster & high-yield hash allocation',
        '24/7 VIP institutional concierge & dedicated portfolio officer',
        'Accelerated daily automated reconciliation & priority payout processing',
        'Customized digital custody structuring & formal compliance certificates',
      ],
    },
  ];

  return (
    <div className="space-y-24 pb-20">
      {/* HERO SECTION */}
      <section className="relative pt-12 md:pt-20 lg:pt-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden">
        {/* Glow ambient background */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-amber-500/10 via-yellow-500/5 to-transparent blur-3xl pointer-events-none rounded-full" />

        <div className="text-center max-w-3xl mx-auto space-y-6 relative z-10">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-amber-500/30 text-amber-300 text-xs font-medium tracking-wide shadow-lg shadow-amber-500/5">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span>Digital Asset Computational Infrastructure</span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold font-serif text-slate-100 tracking-tight leading-[1.15]">
            Build Your Investment Journey.
          </h1>

          <p className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto font-normal leading-relaxed">
            Explore modern digital investment opportunities through a secure and professionally designed financial platform.
          </p>

          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onExploreInvestments}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 px-8 py-4 rounded-xl text-sm font-bold text-black bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-300 hover:from-amber-400 hover:to-yellow-200 transition-all shadow-xl shadow-amber-500/20 active:scale-[0.98]"
            >
              <span>Explore Investments</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onHowItWorks}
              className="w-full sm:w-auto flex items-center justify-center space-x-2 px-8 py-4 rounded-xl text-sm font-semibold text-slate-200 bg-slate-900 border border-slate-800 hover:bg-slate-800 hover:border-slate-700 transition-colors"
            >
              <span>How It Works</span>
            </button>
          </div>

          {/* Quick trust metrics */}
          <div className="pt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto border-t border-slate-800/80 text-left">
            <div className="p-3">
              <span className="text-[11px] text-slate-500 block uppercase tracking-wider font-semibold">Gateway</span>
              <span className="text-sm font-bold text-slate-200">PayFast Integrated</span>
              <p className="text-[11px] text-emerald-400 mt-0.5">Real-time ITN verification</p>
            </div>
            <div className="p-3">
              <span className="text-[11px] text-slate-500 block uppercase tracking-wider font-semibold">Ledger</span>
              <span className="text-sm font-bold text-slate-200">Double-Entry</span>
              <p className="text-[11px] text-slate-400 mt-0.5">Authoritative balance logs</p>
            </div>
            <div className="p-3">
              <span className="text-[11px] text-slate-500 block uppercase tracking-wider font-semibold">Transfers</span>
              <span className="text-sm font-bold text-slate-200">Direct Bank EFT</span>
              <p className="text-[11px] text-slate-400 mt-0.5">Manual audited reconcile</p>
            </div>
            <div className="p-3">
              <span className="text-[11px] text-slate-500 block uppercase tracking-wider font-semibold">Receipts</span>
              <span className="text-sm font-bold text-slate-200">Instant PDF & Print</span>
              <p className="text-[11px] text-slate-400 mt-0.5">Tamper-evident verification</p>
            </div>
          </div>
        </div>
      </section>

      {/* INVESTMENT PRODUCTS SECTION (4 TIERS) */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-14 space-y-3">
          <div className="text-xs font-bold text-amber-400 uppercase tracking-widest">
            Configurable Plans
          </div>
          <h2 className="text-3xl font-serif font-bold text-slate-100">
            Structured Digital Investment Plans
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            Choose a plan tailored to your allocation goals. Standard plans from R500 to R5,000, and our premium Elite tier from R10,000 up to R2,000,000.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((p, idx) => {
            const isHighlight = p.slug === 'growth';
            const isElite = p.slug === 'elite';
            return (
              <div
                key={p.id}
                className={`relative rounded-3xl p-6 transition-all flex flex-col justify-between ${
                  isElite
                    ? 'bg-gradient-to-b from-slate-900 via-amber-950/20 to-slate-950 border-2 border-amber-400 shadow-2xl shadow-amber-500/20'
                    : isHighlight
                    ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border-2 border-amber-500/60 shadow-2xl shadow-amber-500/10'
                    : 'bg-slate-900/80 border border-slate-800 hover:border-slate-700'
                }`}
              >
                {isElite ? (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-black text-[10px] font-black uppercase tracking-wider shadow-lg shadow-amber-500/30 whitespace-nowrap">
                    👑 Premium High-Tier
                  </div>
                ) : isHighlight ? (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-black text-[10px] font-extrabold uppercase tracking-wider shadow-md whitespace-nowrap">
                    Most Popular Choice
                  </div>
                ) : null}

                <div className="space-y-5">
                  <div>
                    <h3 className={`text-lg font-bold font-serif ${isElite ? 'text-amber-300' : 'text-slate-100'}`}>
                      {p.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 min-h-[48px]">{p.description}</p>
                  </div>

                  <div className="bg-slate-950/70 border border-slate-800/80 p-3.5 rounded-2xl">
                    <span className="text-[10px] text-slate-500 block uppercase tracking-wider font-semibold">
                      {isElite ? 'Starting Capital Range' : 'Minimum Allocation'}
                    </span>
                    <div className={`text-2xl font-extrabold font-mono mt-1 ${isElite ? 'text-amber-300' : 'text-amber-400'}`}>
                      R {p.minAmount.toLocaleString()}
                    </div>
                    <span className="text-[10px] text-slate-400 mt-0.5 block font-mono">
                      {isElite ? 'Tiers up to R2,000,000' : 'Permitted: R500 – R5,000'}
                    </span>
                  </div>

                  <ul className="space-y-2.5 text-xs text-slate-300">
                    {p.features.map((feat, fidx) => (
                      <li key={fidx} className="flex items-start space-x-2">
                        <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${isElite ? 'text-amber-300' : 'text-amber-400'}`} />
                        <span className="text-[11px] leading-snug">{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6">
                  <button
                    onClick={() => {
                      onSelectProduct(p);
                      onOpenCheckout();
                    }}
                    className={`w-full py-3 rounded-xl text-xs font-bold transition-all shadow-md ${
                      isElite
                        ? 'text-black bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 hover:from-amber-300 hover:to-yellow-200 shadow-amber-500/30'
                        : isHighlight
                        ? 'text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 shadow-amber-500/20'
                        : 'text-slate-100 bg-slate-800 hover:bg-slate-700 border border-slate-700'
                    }`}
                  >
                    Select {p.name}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* CORE ADVANTAGES & TRANSPARENCY */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="bg-gradient-to-br from-slate-900/90 via-slate-900/60 to-slate-950 border border-slate-800 rounded-3xl p-8 sm:p-12 space-y-10">
          <div className="max-w-2xl space-y-2">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
              Financial Integrity
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-slate-100">
              Clear Separation of Capital, Allocations, and Balances
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              We never fabricate trading returns, simulated mining animations, or misleading profit claims. All actions are grounded in verifiable server-side calculations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-6 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <CreditCard className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-100">PayFast Payment Gateway</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                South Africa's trusted online payment processor. Automatic Instant EFT and card verification with secure server-to-server ITN callback validation.
              </p>
            </div>

            <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-6 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Building2 className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-100">Direct Bank Reconciliation</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Direct bank transfers are reconciled manually by compliance administrators against official bank statements before any capital is credited.
              </p>
            </div>

            <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-6 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                <Layers className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-slate-100">Immutable Ledger Accounting</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Balances are never stored as arbitrary client values. Every credit, debit, and allocation is recorded in an auditable double-entry journal.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* STEP-BY-STEP CUSTOMER JOURNEY */}
      <section className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-xl mx-auto mb-12 space-y-2">
          <div className="text-xs font-bold text-amber-400 uppercase tracking-widest">
            Step-by-Step
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-slate-100">
            How The Investment Journey Works
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              step: '01',
              title: 'Select Investment Plan',
              desc: 'Select Starter (min R500), Growth (min R1,000), or Professional (min R2,500) and pick a permitted amount.',
            },
            {
              step: '02',
              title: 'Secure Checkout',
              desc: 'Provide your customer details and proceed to PayFast or generate unique bank EFT instructions.',
            },
            {
              step: '03',
              title: 'Server Verification',
              desc: 'The backend independently verifies the transaction with the payment gateway and prevents duplicate credits.',
            },
            {
              step: '04',
              title: 'Receipt & Dashboard',
              desc: 'Receive an official transaction receipt and track your active hardware allocations inside your client portal.',
            },
          ].map((item, idx) => (
            <div
              key={idx}
              className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 space-y-3 relative"
            >
              <div className="font-mono text-2xl font-black text-amber-500/30">
                {item.step}
              </div>
              <h3 className="text-sm font-bold text-slate-100">{item.title}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
