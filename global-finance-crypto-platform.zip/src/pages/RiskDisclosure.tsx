import React from 'react';
import { AlertTriangle, ShieldAlert } from 'lucide-react';

export const RiskDisclosure: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-10 text-xs text-slate-300 leading-relaxed">
      <div className="space-y-3 border-b border-slate-800 pb-6">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
          Mandatory Regulatory Disclosure
        </span>
        <h1 className="text-3xl font-serif font-bold text-slate-100 flex items-center space-x-3">
          <AlertTriangle className="w-8 h-8 text-amber-400" />
          <span>Risk Disclosure Notice</span>
        </h1>
        <p className="text-slate-400 text-xs">
          Please read this disclosure thoroughly before engaging in any digital investment or computational allocation.
        </p>
      </div>

      <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-6 text-amber-300 space-y-2">
        <h2 className="text-sm font-bold uppercase tracking-wide">
          CRITICAL FINANCIAL NOTICE: NO GUARANTEED PROFITS OR RETURNS
        </h2>
        <p className="text-xs leading-relaxed">
          Cryptocurrency-related activities, computational hardware leasing, and digital asset investments involve substantial financial, market, and technological risk. Global Finance Crypto Mining DOES NOT offer guaranteed returns, risk-free investments, or principal preservation guarantees.
        </p>
      </div>

      <div className="space-y-6">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">1. Market & Price Volatility</h2>
          <p>
            Cryptocurrency prices and blockchain network reward structures fluctuate unpredictably due to market sentiment, macroeconomic conditions, regulatory changes, and global computational difficulty shifts. Past yields or network hash efficiencies do not guarantee future performance.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">2. Operational & Hardware Risks</h2>
          <p>
            Cryptocurrency mining infrastructure is subject to hardware degradation, firmware vulnerabilities, network connectivity interruptions, power cost fluctuations, and network protocol changes (such as consensus algorithm shifts or hard forks). Deposited funds are not guaranteed to increase in value.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">3. Regulatory & Legal Oversight</h2>
          <p>
            The regulatory landscape for crypto assets in South Africa and globally is continually evolving. Changes in taxation, exchange control, or Financial Sector Conduct Authority (FSCA) regulations may impact digital asset operations. Prospective investors must evaluate their own financial circumstances and seek independent professional financial advice.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">4. Suitability & Loss of Capital</h2>
          <p>
            You should not allocate capital that you cannot afford to lose completely. Digital computational allocations are suitable only for sophisticated clients who understand the speculative and technical nature of blockchain computing infrastructure.
          </p>
        </section>
      </div>
    </div>
  );
};
