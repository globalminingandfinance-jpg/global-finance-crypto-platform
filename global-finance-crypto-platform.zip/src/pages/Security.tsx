import React from 'react';
import { ShieldCheck, Lock, Key, Database, FileCheck, AlertTriangle, CheckCircle2 } from 'lucide-react';

export const Security: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
          Enterprise Security
        </span>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-slate-100">
          Security Comes First.
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-2xl mx-auto">
          We maintain strict security controls across authentication, payment gateways, database persistence, and administrative access. We only disclose controls that have actually been implemented.
        </p>
      </div>

      {/* Grid of Implemented Controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-7 space-y-4">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Lock className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-100">Bcrypt Password Security</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            All user and administrator passwords are encrypted using Bcrypt with 12 salt rounds before being stored. Plaintext passwords are never saved, logged, or transmitted.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-7 space-y-4">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-100">Server-Side Authorization</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Every client and administrator endpoint enforces strict server-side authentication tokens. Frontend visibility is never relied upon as an access boundary.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-7 space-y-4">
          <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Key className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-100">PayFast Gateway Signatures</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Transactions with PayFast are signed with MD5 hashing and verified server-to-server. Browser redirects are not accepted as proof of payment.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-7 space-y-4">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Database className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-100">Immutable Financial Ledger</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Financial state is stored in an auditable double-entry journal. Balances are calculated authoritatively from ledger records to prevent tampering.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-7 space-y-4">
          <div className="w-10 h-10 rounded-xl bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center text-yellow-400">
            <FileCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-100">Administrative Audit Trails</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Every privileged action—including account suspensions, bank transfer reconciliations, and payout reviews—is recorded in an immutable audit table with timestamps and actor details.
          </p>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-7 space-y-4">
          <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-slate-100">Brute Force & Rate Limiting</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Authentication endpoints are protected by in-memory rate limiting to defend against brute-force password guessing and automated enumeration.
          </p>
        </div>
      </div>

      {/* Non-Fabrication Notice */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-6 text-xs text-slate-400 max-w-3xl mx-auto leading-relaxed text-center">
        <strong className="text-slate-300 block mb-1">Our Transparency Commitment:</strong>
        We do not invent external security certifications, regulatory authorizations, or third-party audit claims that have not been formally conducted. Security is implemented through robust code architecture, principle of least privilege, and server-side data isolation.
      </div>
    </div>
  );
};
