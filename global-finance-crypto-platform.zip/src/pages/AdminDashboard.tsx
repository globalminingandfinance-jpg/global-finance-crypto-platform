import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { AuditLog, Transaction, WithdrawalRecord } from '../types/index.js';
import { AdminSupportManager } from '../components/AdminSupportManager.js';
import { AdminDocumentVault } from '../components/AdminDocumentVault.js';
import { AdminInvestmentManager } from '../components/AdminInvestmentManager.js';
import { BusinessFinanceCentre } from '../components/BusinessFinanceCentre.js';
import { DataSourcesStatus } from '../components/DataSourcesStatus.js';
import { AdminPromotionsManager } from '../components/AdminPromotionsManager.js';
import { AdminAnnouncementsCentre } from '../components/AdminAnnouncementsCentre.js';
import {
  LayoutDashboard,
  Megaphone,
  Users,
  Coins,
  History,
  CreditCard,
  ArrowDownToLine,
  FileCheck,
  Settings,
  ShieldAlert,
  Search,
  CheckCircle2,
  XCircle,
  AlertCircle,
  RefreshCw,
  LogOut,
  Building2,
  Lock,
  ChevronRight,
  LifeBuoy,
  FolderLock,
  Activity,
  Tag,
} from 'lucide-react';

interface AdminDashboardProps {
  initialTab?: string;
  onNavigateHome: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ initialTab, onNavigateHome }) => {
  const { user, token, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'announcements'
    | 'offers'
    | 'investments'
    | 'customers'
    | 'transactions'
    | 'payments'
    | 'withdrawals'
    | 'support'
    | 'documents'
    | 'audit'
    | 'settings'
    | 'business-finance'
    | 'data-sources'
  >((initialTab as any) || 'overview');

  useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab as any);
    }
  }, [initialTab]);

  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState<any>(null);
  const [customers, setCustomers] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // Search & filter states
  const [customerSearch, setCustomerSearch] = useState('');
  const [txSearch, setTxSearch] = useState('');
  const [txStatusFilter, setTxStatusFilter] = useState('');

  // Status modal state
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [newStatus, setNewStatus] = useState<'active' | 'suspended'>('suspended');
  const [statusReason, setStatusReason] = useState('');
  const [statusUpdating, setStatusUpdating] = useState(false);

  // Bank reconciliation modal state
  const [reconcileTx, setReconcileTx] = useState<Transaction | null>(null);
  const [reconcileNotes, setReconcileNotes] = useState('');
  const [reconcileAmount, setReconcileAmount] = useState('');
  const [reconciling, setReconciling] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Withdrawal review modal state
  const [reviewWithdrawal, setReviewWithdrawal] = useState<WithdrawalRecord | null>(null);
  const [reviewAction, setReviewAction] = useState<'APPROVE' | 'REJECT'>('APPROVE');
  const [reviewNotes, setReviewNotes] = useState('');
  const [reviewing, setReviewing] = useState(false);

  const fetchAdminData = async () => {
    if (!token) return;
    setIsLoading(true);
    const headers = { Authorization: `Bearer ${token}` };

    try {
      // 1. Overview stats
      const stRes = await fetch('/api/admin/overview', { headers });
      if (stRes.ok) setStats(await stRes.json());

      // 2. Customers
      const cuRes = await fetch(`/api/admin/customers?q=${encodeURIComponent(customerSearch)}`, { headers });
      if (cuRes.ok) {
        const cData = await cuRes.json();
        setCustomers(cData.customers || []);
      }

      // 3. Transactions
      let txUrl = `/api/admin/transactions?q=${encodeURIComponent(txSearch)}`;
      if (txStatusFilter) txUrl += `&status=${encodeURIComponent(txStatusFilter)}`;
      const txRes = await fetch(txUrl, { headers });
      if (txRes.ok) {
        const tData = await txRes.json();
        setTransactions(tData.transactions || []);
      }

      // 4. PayFast Notifications
      const pfRes = await fetch('/api/admin/payments', { headers });
      if (pfRes.ok) {
        const pData = await pfRes.json();
        setPayments(pData.notifications || []);
      }

      // 5. Withdrawals
      const wdRes = await fetch('/api/admin/withdrawals', { headers });
      if (wdRes.ok) {
        const wData = await wdRes.json();
        setWithdrawals(wData.withdrawals || []);
      }

      // 6. Audit logs
      const auRes = await fetch('/api/admin/audit-logs', { headers });
      if (auRes.ok) {
        const aData = await auRes.json();
        setAuditLogs(aData.logs || []);
      }
    } catch (err) {
      console.error('Failed to load administrator records:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [token, customerSearch, txSearch, txStatusFilter]);

  const handleUpdateCustomerStatus = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId || !statusReason.trim()) return;
    setStatusUpdating(true);

    try {
      const res = await fetch(`/api/admin/customers/${selectedCustomerId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          status: newStatus,
          reason: statusReason.trim(),
        }),
      });

      const data = await res.json();
      setStatusUpdating(false);

      if (res.ok) {
        setSelectedCustomerId(null);
        setStatusReason('');
        fetchAdminData();
      } else {
        alert(data.error || 'Failed to update status.');
      }
    } catch {
      setStatusUpdating(false);
      alert('Network error updating customer status.');
    }
  };

  const handleReconcileBankTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reconcileTx) return;
    setReconciling(true);
    setFeedbackMessage(null);

    try {
      const res = await fetch(`/api/admin/transactions/${reconcileTx.id}/reconcile-bank-transfer`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          bankReferenceNotes: reconcileNotes,
          receivedAmount: Number(reconcileAmount || reconcileTx.amount),
        }),
      });

      const data = await res.json();
      setReconciling(false);

      if (res.ok) {
        setReconcileTx(null);
        setReconcileNotes('');
        setFeedbackMessage({ type: 'success', text: data.message });
        fetchAdminData();
      } else {
        setFeedbackMessage({ type: 'error', text: data.error || 'Failed to reconcile bank transfer.' });
      }
    } catch {
      setReconciling(false);
      setFeedbackMessage({ type: 'error', text: 'Network connection failed.' });
    }
  };

  const handleReviewWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewWithdrawal) return;
    setReviewing(true);

    try {
      const res = await fetch(`/api/admin/withdrawals/${reviewWithdrawal.id}/review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: reviewAction,
          notes: reviewNotes,
        }),
      });

      const data = await res.json();
      setReviewing(false);

      if (res.ok) {
        setReviewWithdrawal(null);
        setReviewNotes('');
        fetchAdminData();
      } else {
        alert(data.error || 'Failed to update withdrawal.');
      }
    } catch {
      setReviewing(false);
      alert('Network error.');
    }
  };

  const menu = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'announcements', label: 'Global Announcements Centre', icon: Megaphone },
    { id: 'offers', label: 'Automated Money Offers', icon: Tag },
    { id: 'business-finance', label: 'Business Finance Centre', icon: Building2 },
    { id: 'investments', label: 'Investments & Settle', icon: Coins },
    { id: 'customers', label: 'Customers', icon: Users },
    { id: 'transactions', label: 'Transactions & Reconcile', icon: History },
    { id: 'payments', label: 'PayFast Webhooks', icon: CreditCard },
    { id: 'withdrawals', label: 'Withdrawal Approvals', icon: ArrowDownToLine },
    { id: 'support', label: 'Support & Complaints', icon: LifeBuoy },
    { id: 'documents', label: 'Document Vault & KYC', icon: FolderLock },
    { id: 'data-sources', label: 'Data Sources & Status', icon: Activity },
    { id: 'audit', label: 'Audit Logs', icon: FileCheck },
    { id: 'settings', label: 'Platform Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#060911] text-slate-100 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col shrink-0">
        <div className="p-6 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={onNavigateHome}>
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/40 flex items-center justify-center font-bold text-amber-400 text-xs">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <div className="font-serif font-bold text-sm text-slate-100">
                GLOBAL FINANCE
              </div>
              <div className="text-[10px] text-amber-400 font-mono tracking-wider">
                Admin Console
              </div>
            </div>
          </div>
        </div>

        {/* Admin identity card */}
        <div className="p-4 mx-3 my-3 bg-amber-500/5 border border-amber-500/20 rounded-xl">
          <div className="text-xs font-semibold text-slate-200 truncate">
            {user?.email}
          </div>
          <div className="flex items-center justify-between mt-2">
            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-400 text-black uppercase">
              Super Administrator
            </span>
            <button
              onClick={fetchAdminData}
              title="Refresh database records"
              className="p-1 text-slate-400 hover:text-white"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
          {menu.map((item) => {
            const Icon = item.icon;
            const isSelected = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-black font-bold shadow-md shadow-amber-500/20'
                    : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-black' : 'text-amber-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Bottom actions */}
        <div className="p-4 border-t border-slate-800/80 space-y-2">
          <button
            onClick={onNavigateHome}
            className="w-full flex items-center justify-center space-x-2 py-2 rounded-xl text-xs text-slate-400 hover:text-white bg-slate-900 transition-colors"
          >
            <span>Public Site</span>
          </button>
          <button
            onClick={logout}
            className="w-full flex items-center justify-center space-x-2 py-2 rounded-xl text-xs font-medium text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 sm:p-8 lg:p-10 overflow-y-auto max-w-7xl">
        {feedbackMessage && (
          <div
            className={`mb-6 p-4 rounded-xl text-xs flex items-center space-x-2.5 ${
              feedbackMessage.type === 'success'
                ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
                : 'bg-red-500/10 border border-red-500/30 text-red-400'
            }`}
          >
            {feedbackMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0" />
            )}
            <span>{feedbackMessage.text}</span>
          </div>
        )}

        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">
                Administrator Overview
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Aggregated financial and customer metrics computed directly from immutable database tables.
              </p>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
                <span className="text-xs font-medium text-slate-400 block mb-1">Total Confirmed Deposits</span>
                <div className="text-2xl font-bold font-mono text-emerald-400">
                  R {(stats?.financials?.totalConfirmedDeposits || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">Authoritative settled capital</span>
              </div>

              <div className="bg-slate-900/80 border border-amber-500/30 rounded-2xl p-5">
                <span className="text-xs font-medium text-amber-300 block mb-1">Allocated Investment Capital</span>
                <div className="text-2xl font-bold font-mono text-amber-300">
                  R {(stats?.financials?.totalAllocatedInvestments || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">Active computational plans</span>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
                <span className="text-xs font-medium text-slate-400 block mb-1">Total Registered Customers</span>
                <div className="text-2xl font-bold font-mono text-slate-100">
                  {stats?.customers?.total || 0}
                </div>
                <div className="text-[11px] text-slate-400 mt-1 flex space-x-2">
                  <span className="text-emerald-400">{stats?.customers?.active || 0} Active</span>
                  <span>•</span>
                  <span className="text-red-400">{stats?.customers?.suspended || 0} Suspended</span>
                </div>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
                <span className="text-xs font-medium text-slate-400 block mb-1">Pending Withdrawals</span>
                <div className="text-2xl font-bold font-mono text-purple-400">
                  R {(stats?.financials?.pendingWithdrawalsAmount || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                </div>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  {stats?.financials?.pendingWithdrawalsCount || 0} request(s) awaiting review
                </span>
              </div>
            </div>

            {/* Quick Actions & Status */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-3">
                <h3 className="font-semibold text-sm text-slate-200">Transaction Summary</h3>
                <div className="space-y-2 text-xs divide-y divide-slate-800/80">
                  <div className="pt-2 flex justify-between">
                    <span className="text-slate-400">Total System Transactions</span>
                    <span className="font-mono text-slate-200">{stats?.transactions?.total || 0}</span>
                  </div>
                  <div className="pt-2 flex justify-between">
                    <span className="text-slate-400">Settled (SUCCESS)</span>
                    <span className="font-mono text-emerald-400 font-bold">{stats?.transactions?.success || 0}</span>
                  </div>
                  <div className="pt-2 flex justify-between">
                    <span className="text-slate-400">Pending Gateway / Reconciliation</span>
                    <span className="font-mono text-amber-300 font-bold">{stats?.transactions?.pending || 0}</span>
                  </div>
                  <div className="pt-2 flex justify-between">
                    <span className="text-slate-400">Failed / Cancelled</span>
                    <span className="font-mono text-red-400">{stats?.transactions?.failed || 0}</span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-3">
                <h3 className="font-semibold text-sm text-slate-200">PayFast Gateway Status</h3>
                <div className="space-y-2 text-xs divide-y divide-slate-800/80">
                  <div className="pt-2 flex justify-between">
                    <span className="text-slate-400">Environment</span>
                    <span className="font-mono uppercase text-amber-300 font-bold">
                      {process.env.PAYFAST_ENVIRONMENT === 'live' ? 'Production (Live)' : 'Sandbox Test Mode'}
                    </span>
                  </div>
                  <div className="pt-2 flex justify-between">
                    <span className="text-slate-400">Configured Merchant ID</span>
                    <span className="font-mono text-slate-200">10000100 (Verified Sandbox)</span>
                  </div>
                  <div className="pt-2 flex justify-between">
                    <span className="text-slate-400">Signature Algorithm</span>
                    <span className="font-mono text-slate-200">MD5 Key-Value URL Encoded</span>
                  </div>
                  <div className="pt-2 flex justify-between">
                    <span className="text-slate-400">ITN Webhook Verification</span>
                    <span className="font-mono text-emerald-400 font-semibold">Active & Idempotent</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* CUSTOMERS TAB */}
        {activeTab === 'customers' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold font-serif text-slate-100">Customer Directory</h1>
                <p className="text-xs text-slate-400 mt-1">
                  Comprehensive listing of all registered client investors and account standings.
                </p>
              </div>
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  type="text"
                  value={customerSearch}
                  onChange={(e) => setCustomerSearch(e.target.value)}
                  placeholder="Search customer email or name..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4 font-medium">Customer</th>
                      <th className="py-3 px-4 font-medium">Contact</th>
                      <th className="py-3 px-4 font-medium">Country</th>
                      <th className="py-3 px-4 font-medium">Status</th>
                      <th className="py-3 px-4 font-medium">Deposited</th>
                      <th className="py-3 px-4 font-medium">Allocated</th>
                      <th className="py-3 px-4 font-medium">Created</th>
                      <th className="py-3 px-4 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {customers.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-slate-500">
                          No matching customer accounts found.
                        </td>
                      </tr>
                    ) : (
                      customers.map((c) => (
                        <tr key={c.id} className="hover:bg-slate-800/30">
                          <td className="py-3 px-4">
                            <div className="font-semibold text-slate-200">
                              {c.first_name} {c.last_name}
                            </div>
                            <div className="font-mono text-[11px] text-slate-400">{c.email}</div>
                          </td>
                          <td className="py-3 px-4 text-slate-300 font-mono text-[11px]">
                            {c.phone || '—'}
                          </td>
                          <td className="py-3 px-4 text-slate-400">{c.country}</td>
                          <td className="py-3 px-4">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                c.status === 'active'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                  : 'bg-red-500/10 text-red-400 border border-red-500/30'
                              }`}
                            >
                              {c.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 font-mono text-slate-200">
                            R {(c.total_deposited || 0).toLocaleString()}
                          </td>
                          <td className="py-3 px-4 font-mono text-amber-300">
                            R {(c.total_allocated || 0).toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-slate-400 text-[11px]">
                            {new Date(c.created_at).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              onClick={() => {
                                setSelectedCustomerId(c.id);
                                setNewStatus(c.status === 'active' ? 'suspended' : 'active');
                              }}
                              className="text-amber-400 hover:text-amber-300 font-medium text-xs"
                            >
                              Manage
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TRANSACTIONS & RECONCILIATION TAB */}
        {activeTab === 'transactions' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold font-serif text-slate-100">
                  Transactions & Reconciliation
                </h1>
                <p className="text-xs text-slate-400 mt-1">
                  Inspect all payment references and manually reconcile verified electronic bank transfers.
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <select
                  value={txStatusFilter}
                  onChange={(e) => setTxStatusFilter(e.target.value)}
                  className="bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none"
                >
                  <option value="">All Statuses</option>
                  <option value="SUCCESS">SUCCESS</option>
                  <option value="PENDING">PENDING</option>
                  <option value="FAILED">FAILED</option>
                </select>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={txSearch}
                    onChange={(e) => setTxSearch(e.target.value)}
                    placeholder="Search ref or email..."
                    className="bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-amber-500/60"
                  />
                </div>
              </div>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4 font-medium">Reference</th>
                      <th className="py-3 px-4 font-medium">Customer</th>
                      <th className="py-3 px-4 font-medium">Product</th>
                      <th className="py-3 px-4 font-medium">Amount</th>
                      <th className="py-3 px-4 font-medium">Method</th>
                      <th className="py-3 px-4 font-medium">Status</th>
                      <th className="py-3 px-4 font-medium">Created</th>
                      <th className="py-3 px-4 font-medium text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {transactions.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-slate-500">
                          No matching transactions found.
                        </td>
                      </tr>
                    ) : (
                      transactions.map((tx) => (
                        <tr key={tx.id} className="hover:bg-slate-800/30">
                          <td className="py-3 px-4 font-mono font-bold text-slate-200">
                            {tx.reference}
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-slate-300 block">{tx.customerName}</span>
                            <span className="font-mono text-[11px] text-slate-500">{tx.customerEmail}</span>
                          </td>
                          <td className="py-3 px-4 text-slate-300">{tx.productName}</td>
                          <td className="py-3 px-4 font-mono font-semibold text-slate-100">
                            R {tx.amount.toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-slate-400 uppercase text-[11px]">
                            {tx.paymentMethod === 'payfast' ? 'PayFast' : 'Bank EFT'}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                tx.status === 'SUCCESS'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                  : tx.status === 'PENDING'
                                  ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                                  : 'bg-red-500/10 text-red-400 border border-red-500/30'
                              }`}
                            >
                              {tx.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-400 text-[11px]">
                            {new Date(tx.createdAt).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-4 text-right">
                            {tx.status === 'PENDING' && tx.paymentMethod === 'bank_transfer' ? (
                              <button
                                onClick={() => {
                                  setReconcileTx(tx);
                                  setReconcileAmount(String(tx.amount));
                                }}
                                className="inline-flex items-center space-x-1 px-2.5 py-1 rounded bg-amber-500 text-black font-bold text-[11px] hover:bg-amber-400"
                              >
                                <span>Reconcile</span>
                              </button>
                            ) : (
                              <span className="text-[11px] text-slate-500 font-mono">
                                {tx.providerReference || 'Settled'}
                              </span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* PAYFAST NOTIFICATIONS TAB */}
        {activeTab === 'payments' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">
                PayFast Webhook Logs
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Raw Instant Transaction Notification (ITN) events received from the PayFast payment gateway.
              </p>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Ref (m_payment_id)</th>
                    <th className="py-3 px-4">PayFast Payment ID</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Gross</th>
                    <th className="py-3 px-4">Fee</th>
                    <th className="py-3 px-4">Net</th>
                    <th className="py-3 px-4">Verified</th>
                    <th className="py-3 px-4">Received</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {payments.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        No PayFast webhook notifications received yet.
                      </td>
                    </tr>
                  ) : (
                    payments.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-800/30">
                        <td className="py-3 px-4 font-mono font-bold text-slate-200">
                          {p.transaction_reference}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-400">{p.pf_payment_id || '—'}</td>
                        <td className="py-3 px-4 font-bold text-emerald-400">{p.payment_status}</td>
                        <td className="py-3 px-4 font-mono text-slate-200">R {p.amount_gross}</td>
                        <td className="py-3 px-4 font-mono text-slate-400">R {p.amount_fee}</td>
                        <td className="py-3 px-4 font-mono text-slate-200">R {p.amount_net}</td>
                        <td className="py-3 px-4 text-emerald-400">Signature Validated</td>
                        <td className="py-3 px-4 text-slate-400 text-[11px]">
                          {new Date(p.created_at).toLocaleString()}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* WITHDRAWALS APPROVALS TAB */}
        {activeTab === 'withdrawals' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">
                Withdrawal Approvals
              </h1>
              <p className="text-xs text-slate-400 mt-1">
                Authorized administrator review and manual payout reconciliation.
              </p>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Amount</th>
                    <th className="py-3 px-4">Bank Details</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Requested</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {withdrawals.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500">
                        No pending withdrawal requests.
                      </td>
                    </tr>
                  ) : (
                    withdrawals.map((w) => (
                      <tr key={w.id} className="hover:bg-slate-800/30">
                        <td className="py-3 px-4">
                          <span className="font-semibold text-slate-200 block">
                            {w.accountHolder}
                          </span>
                          <span className="font-mono text-[11px] text-slate-500">
                            {w.customerEmail}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-100">
                          R {w.amount.toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-slate-300">
                          <div>{w.bankName}</div>
                          <div className="font-mono text-[11px] text-slate-400">
                            Acc: {w.accountNumber} | Branch: {w.branchCode}
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              w.status === 'COMPLETED'
                                ? 'bg-emerald-500/10 text-emerald-400'
                                : w.status === 'REJECTED'
                                ? 'bg-red-500/10 text-red-400'
                                : 'bg-amber-500/10 text-amber-300'
                            }`}
                          >
                            {w.status}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-400 text-[11px]">
                          {new Date(w.createdAt).toLocaleDateString()}
                        </td>
                        <td className="py-3 px-4 text-right">
                          {w.status === 'PENDING_REVIEW' ? (
                            <button
                              onClick={() => {
                                setReviewWithdrawal(w);
                                setReviewAction('APPROVE');
                              }}
                              className="px-2.5 py-1 rounded bg-amber-500 text-black font-bold text-[11px] hover:bg-amber-400"
                            >
                              Review
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-500">Completed</span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* AUDIT LOGS TAB */}
        {activeTab === 'audit' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">Audit Logs</h1>
              <p className="text-xs text-slate-400 mt-1">
                Tamper-evident trail of administrative logins, status modifications, bank reconciliations, and compliance events.
              </p>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Timestamp</th>
                    <th className="py-3 px-4">Administrator / Actor</th>
                    <th className="py-3 px-4">Action</th>
                    <th className="py-3 px-4">Target</th>
                    <th className="py-3 px-4">IP Address</th>
                    <th className="py-3 px-4">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                  {auditLogs.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-slate-500 font-sans">
                        No audit events logged yet.
                      </td>
                    </tr>
                  ) : (
                    auditLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-slate-800/30">
                        <td className="py-3 px-4 text-slate-400">
                          {new Date(log.createdAt).toLocaleString()}
                        </td>
                        <td className="py-3 px-4 text-amber-300 font-semibold truncate max-w-[150px]">
                          {log.adminEmail}
                        </td>
                        <td className="py-3 px-4 text-slate-200">{log.action}</td>
                        <td className="py-3 px-4 text-slate-400">{log.targetType} ({log.targetId})</td>
                        <td className="py-3 px-4 text-slate-500">{log.ipAddress || '127.0.0.1'}</td>
                        <td className="py-3 px-4 text-slate-300 font-sans text-xs truncate max-w-xs">
                          {log.details}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* SETTINGS TAB */}
        {activeTab === 'settings' && (
          <div className="space-y-6 max-w-3xl">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">Platform Settings</h1>
              <p className="text-xs text-slate-400 mt-1">
                Gateway credentials, banking parameters, and security configurations.
              </p>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="text-sm font-semibold text-slate-200">PayFast Gateway Parameters</h3>
              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-slate-400 block mb-1">Environment</span>
                  <input
                    type="text"
                    disabled
                    value={process.env.PAYFAST_ENVIRONMENT === 'live' ? 'LIVE PRODUCTION' : 'SANDBOX TEST MODE'}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-amber-300 font-mono font-bold"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Merchant ID</span>
                  <input
                    type="text"
                    disabled
                    value="10000100 (PayFast Sandbox)"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200 font-mono"
                  />
                </div>
                <div>
                  <span className="text-slate-400 block mb-1">Passphrase Enforcement</span>
                  <input
                    type="text"
                    disabled
                    value="Enabled via PAYFAST_PASSPHRASE in server environment"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-400 text-xs"
                  />
                </div>
              </div>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="text-sm font-semibold text-slate-200">Administrator Security Policy</h3>
              <div className="text-xs text-slate-300 space-y-2">
                <p>• Designated administrator email: <strong className="text-amber-300 font-mono">globalfinancecryptomining@gmail.com</strong></p>
                <p>• Password hashes are computed using Bcrypt with 12 rounds.</p>
                <p>• All administrative actions are recorded into the immutable audit trail.</p>
              </div>
            </div>
          </div>
        )}

        {/* GLOBAL ANNOUNCEMENTS CENTRE */}
        {activeTab === 'announcements' && <AdminAnnouncementsCentre token={token} />}

        {/* SUPPORT & COMPLAINTS TAB */}
        {activeTab === 'support' && <AdminSupportManager token={token} />}

        {/* COMPLIANCE DOCUMENT VAULT & KYC TAB */}
        {activeTab === 'documents' && <AdminDocumentVault token={token} />}

        {/* AUTOMATED MONEY OFFERS & PROMOTIONS TAB */}
        {activeTab === 'offers' && <AdminPromotionsManager token={token} />}

        {/* INVESTMENTS MANAGEMENT & SETTLEMENT TAB */}
        {activeTab === 'investments' && <AdminInvestmentManager token={token} />}

        {/* BUSINESS FINANCE CENTRE */}
        {activeTab === 'business-finance' && <BusinessFinanceCentre token={token} />}

        {/* DATA SOURCES & INTEGRATION STATUS */}
        {activeTab === 'data-sources' && <DataSourcesStatus token={token} />}
      </main>

      {/* Customer Status Modal */}
      {selectedCustomerId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-2xl p-6 space-y-4">
            <h3 className="font-bold text-base text-slate-100">Modify Customer Status</h3>
            <form onSubmit={handleUpdateCustomerStatus} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Target Status</label>
                <select
                  value={newStatus}
                  onChange={(e) => setNewStatus(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                >
                  <option value="active">Active (Permitted to log in and transact)</option>
                  <option value="suspended">Suspended (Access completely revoked)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Administrative Reason (Required for audit)</label>
                <textarea
                  required
                  rows={3}
                  value={statusReason}
                  onChange={(e) => setStatusReason(e.target.value)}
                  placeholder="State the justification for suspending or reactivating this account..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 focus:outline-none focus:border-amber-500/60 resize-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedCustomerId(null)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={statusUpdating}
                  className="px-5 py-2 rounded-xl font-bold text-black bg-amber-400 hover:bg-amber-300 disabled:opacity-50"
                >
                  {statusUpdating ? 'Updating...' : 'Save Status'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Reconcile Bank Transfer Modal */}
      {reconcileTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-2xl p-6 space-y-4">
            <h3 className="font-bold text-base text-slate-100 flex items-center space-x-2">
              <Building2 className="w-5 h-5 text-amber-400" />
              <span>Reconcile Bank Transfer</span>
            </h3>
            <p className="text-xs text-slate-400">
              Confirm verified receipt of funds in the business bank account for reference{' '}
              <strong className="text-amber-300 font-mono">{reconcileTx.reference}</strong>.
            </p>

            <form onSubmit={handleReconcileBankTransfer} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Verified Received Amount (ZAR)</label>
                <input
                  type="number"
                  required
                  value={reconcileAmount}
                  onChange={(e) => setReconcileAmount(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm font-mono text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Bank Statement Proof / Audit Notes</label>
                <input
                  type="text"
                  required
                  value={reconcileNotes}
                  onChange={(e) => setReconcileNotes(e.target.value)}
                  placeholder="e.g. Verified on Standard Bank statement dated 14 Oct (Ref 8829)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReconcileTx(null)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={reconciling}
                  className="px-5 py-2 rounded-xl font-bold text-black bg-amber-400 hover:bg-amber-300 disabled:opacity-50"
                >
                  {reconciling ? 'Reconciling...' : 'Confirm & Allocate Capital'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Review Withdrawal Modal */}
      {reviewWithdrawal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-2xl p-6 space-y-4">
            <h3 className="font-bold text-base text-slate-100">Review Withdrawal Payout</h3>
            <p className="text-xs text-slate-400">
              Review requested payout of <strong className="text-amber-300 font-mono">R {reviewWithdrawal.amount.toLocaleString()}</strong> to {reviewWithdrawal.bankName}.
            </p>

            <form onSubmit={handleReviewWithdrawal} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Decision</label>
                <select
                  value={reviewAction}
                  onChange={(e) => setReviewAction(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-semibold"
                >
                  <option value="APPROVE">APPROVE & COMPLETE (Funds Dispatched)</option>
                  <option value="REJECT">REJECT (Insufficient verification or details)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Review Notes</label>
                <input
                  type="text"
                  required
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="e.g. Domestic EFT transfer reference 99014"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setReviewWithdrawal(null)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={reviewing}
                  className="px-5 py-2 rounded-xl font-bold text-black bg-amber-400 hover:bg-amber-300 disabled:opacity-50"
                >
                  {reviewing ? 'Saving...' : 'Submit Decision'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
