import React, { useState } from 'react';
import { InvestmentProduct } from '../types/index.js';
import { ShieldCheck, CheckCircle2, ArrowRight, AlertCircle, Info } from 'lucide-react';

interface InvestmentsProps {
  onSelectProduct: (product: InvestmentProduct) => void;
  onOpenCheckout: () => void;
}

export const Investments: React.FC<InvestmentsProps> = ({
  onSelectProduct,
  onOpenCheckout,
}) => {
  const products: InvestmentProduct[] = [
    {
      id: 'prod_starter',
      slug: 'starter',
      name: 'Starter Investment',
      description: 'Designed for customers beginning their digital investment journey.',
      minAmount: 500,
      currency: 'ZAR',
      features: [
        'Starting capital from R500',
        'Access to core computing infrastructure',
        'Bi-weekly performance reporting',
        'Standard digital custody safeguards',
        'Automated financial ledger accounting',
      ],
    },
    {
      id: 'prod_growth',
      slug: 'growth',
      name: 'Growth Investment',
      description: 'Designed for customers looking for a broader investment option.',
      minAmount: 1000,
      currency: 'ZAR',
      features: [
        'Starting capital from R1,000',
        'Enhanced hash allocation & power efficiency',
        'Weekly audit reports & analytics',
        'Dedicated support queue priority',
        'Flexible capital management',
      ],
    },
    {
      id: 'prod_professional',
      slug: 'professional',
      name: 'Professional Investment',
      description: 'Designed for customers seeking a higher-tier investment option.',
      minAmount: 2500,
      currency: 'ZAR',
      features: [
        'Starting capital from R2,500',
        'High-density institutional-grade hardware pool',
        'Daily reconciliation & real-time telemetry',
        'Direct account manager contact',
        'Priority withdrawal processing schedule',
      ],
    },
    {
      id: 'prod_elite',
      slug: 'elite',
      name: 'Elite Investment',
      description: 'Designed for high-tier and premium users seeking maximum computational power and institutional custody.',
      minAmount: 10000,
      currency: 'ZAR',
      features: [
        'Starting capital from R10,000 up to R2,000,000',
        'Dedicated ASIC mining cluster & high-yield hash allocation',
        '24/7 VIP institutional concierge & dedicated portfolio officer',
        'Accelerated daily automated reconciliation & priority payout processing',
        'Customized digital custody structuring & formal compliance certificates',
      ],
    },
  ];

  const standardAmounts = [500, 1000, 2500, 5000];
  const eliteAmounts = [10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2000000];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-16">
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
          Portfolio Offerings
        </span>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-slate-100">
          Digital Investment Options
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-2xl mx-auto">
          Explore our four computational infrastructure tiers. All plans are denominated in South African Rand (ZAR) with server-side amount validation, from starter retail plans to high-tier Elite allocations up to R2,000,000.
        </p>
      </div>

      {/* Permitted Amounts Notice */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4 max-w-4xl mx-auto">
        <div className="text-center space-y-1">
          <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Permitted Investment Denominations
          </h3>
          <p className="text-[11px] text-slate-500">
            Validated authoritatively on the server. Select your desired tier below.
          </p>
        </div>

        <div className="space-y-3">
          <div>
            <span className="text-[11px] text-slate-400 font-semibold block mb-1 text-center">
              Standard Retail Tiers (Starter, Growth, Professional):
            </span>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {standardAmounts.map((amt) => (
                <div
                  key={amt}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 font-mono text-xs font-medium"
                >
                  R {amt.toLocaleString()}
                </div>
              ))}
            </div>
          </div>

          <div>
            <span className="text-[11px] text-amber-300 font-semibold block mb-1 text-center">
              Elite High-Tier Investment Tiers (R10,000 – R2,000,000):
            </span>
            <div className="flex flex-wrap items-center justify-center gap-2">
              {eliteAmounts.map((amt) => (
                <div
                  key={amt}
                  className="px-3 py-1.5 rounded-xl bg-slate-950 border border-amber-500/40 text-amber-300 font-mono text-xs font-bold"
                >
                  R {amt.toLocaleString()}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Product Cards (4 Columns) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((p) => {
          const isElite = p.slug === 'elite';
          const isGrowth = p.slug === 'growth';
          return (
            <div
              key={p.id}
              className={`rounded-3xl p-6 flex flex-col justify-between transition-all relative ${
                isElite
                  ? 'bg-gradient-to-b from-slate-900 via-amber-950/20 to-slate-950 border-2 border-amber-400 shadow-2xl shadow-amber-500/20'
                  : isGrowth
                  ? 'bg-slate-900/90 border-2 border-amber-500/60 shadow-xl shadow-amber-500/10'
                  : 'bg-slate-900/90 border border-slate-800 hover:border-slate-700'
              }`}
            >
              {isElite ? (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 text-black text-[10px] font-black uppercase tracking-wider shadow-md whitespace-nowrap">
                  👑 High-Tier Premium
                </div>
              ) : isGrowth ? (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-yellow-400 text-black text-[10px] font-bold uppercase tracking-wider shadow-md whitespace-nowrap">
                  Popular Choice
                </div>
              ) : null}

              <div className="space-y-5">
                <div>
                  <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest font-semibold">
                    {isElite ? 'Institutional Tier' : 'Standard Tier'}
                  </span>
                  <h2 className={`text-xl font-bold font-serif mt-1 ${isElite ? 'text-amber-300' : 'text-slate-100'}`}>
                    {p.name}
                  </h2>
                  <p className="text-xs text-slate-400 mt-2 min-h-[48px] leading-relaxed">
                    {p.description}
                  </p>
                </div>

                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80">
                  <span className="text-[10px] text-slate-500 block uppercase tracking-wider font-semibold">
                    {isElite ? 'Capital Range' : 'Minimum Allocation'}
                  </span>
                  <div className={`text-2xl font-bold font-mono mt-1 ${isElite ? 'text-amber-300' : 'text-amber-400'}`}>
                    R {p.minAmount.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-slate-400 mt-0.5 block font-mono">
                    {isElite ? 'Split up to R2,000,000' : 'Permitted: R500 – R5,000'}
                  </span>
                </div>

                <div className="space-y-2.5">
                  <span className="text-xs font-semibold text-slate-200">Key Features:</span>
                  <ul className="space-y-2 text-xs text-slate-300">
                    {p.features.map((feat, fidx) => (
                      <li key={fidx} className="flex items-start space-x-2">
                        <CheckCircle2 className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${isElite ? 'text-amber-300' : 'text-amber-400'}`} />
                        <span className="text-[11px] leading-snug">{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-6">
                <button
                  onClick={() => {
                    onSelectProduct(p);
                    onOpenCheckout();
                  }}
                  className={`w-full py-3 rounded-xl text-xs font-bold transition-all shadow-md ${
                    isElite
                      ? 'text-black bg-gradient-to-r from-amber-400 via-yellow-300 to-amber-500 hover:from-amber-300 hover:to-yellow-200 shadow-amber-500/30'
                      : 'text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 shadow-amber-500/20'
                  }`}
                >
                  Invest in {p.name}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Critical Legal Distinction Box */}
      <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-6 sm:p-8 space-y-4 max-w-4xl mx-auto">
        <div className="flex items-center space-x-2.5 text-amber-300 font-semibold text-sm">
          <Info className="w-5 h-5 shrink-0" />
          <span>Clear Distinction Between Balances, Deposits, and Allocations</span>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          At Global Finance Crypto Mining, we maintain complete transparency regarding customer funds:
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-slate-400">
          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
            <strong className="text-slate-200 block mb-1">1. Confirmed Deposit</strong>
            Actual funds verified as received through the PayFast gateway or verified bank statement.
          </div>
          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
            <strong className="text-slate-200 block mb-1">2. Investment Allocation</strong>
            Capital formally earmarked and deployed to dedicated computing hardware infrastructure.
          </div>
          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
            <strong className="text-slate-200 block mb-1">3. Available Balance</strong>
            Liquid unallocated cash balances in the ledger available for immediate payout or re-investment.
          </div>
          <div className="bg-slate-950/60 p-3.5 rounded-xl border border-slate-800/80">
            <strong className="text-slate-200 block mb-1">4. Actual Returns</strong>
            Only realized returns verified through operational reconciliation. We never simulate or guarantee profits.
          </div>
        </div>
      </div>
    </div>
  );
};
