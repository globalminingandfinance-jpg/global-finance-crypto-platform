import React from 'react';
import { ArrowRight, CheckCircle2, ShieldCheck, CreditCard, Building2, Layers, FileText } from 'lucide-react';

interface HowItWorksProps {
  onOpenCheckout: () => void;
}

export const HowItWorks: React.FC<HowItWorksProps> = ({ onOpenCheckout }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-16">
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
          Platform Architecture
        </span>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-slate-100">
          How Global Finance Works
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-2xl mx-auto">
          From plan selection to cryptographic receipt generation, explore the transparent operational pipeline powering our digital investment platform.
        </p>
      </div>

      {/* 4 Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono font-bold text-lg">
            01
          </div>
          <h2 className="text-xl font-bold font-serif text-slate-100">
            Select Your Computational Plan
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            Choose between the Starter, Growth, or Professional tiers. Our server validates all requests against the authoritative database. Only permitted amounts (R500, R1,000, R2,500, R5,000) are accepted.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>Zero hidden platform initiation fees</span>
            </li>
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>Dedicated server-side transaction reference generated</span>
            </li>
          </ul>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono font-bold text-lg">
            02
          </div>
          <h2 className="text-xl font-bold font-serif text-slate-100">
            Fund via PayFast or Bank Transfer
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            For online settlement, our backend constructs a cryptographically signed payload for PayFast. You complete payment using Instant EFT (all major SA banks) or Visa/Mastercard. Alternatively, direct EFT is supported with manual administrator reconciliation.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>MD5 cryptographic signature protection</span>
            </li>
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>Zero card details ever stored on our servers</span>
            </li>
          </ul>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono font-bold text-lg">
            03
          </div>
          <h2 className="text-xl font-bold font-serif text-slate-100">
            Independent Server-Side Verification
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            A browser redirect is never accepted as proof of payment. Our server listens for PayFast's official Instant Transaction Notification (ITN), performs verification checks against merchant ID, amounts, and signatures, and guarantees idempotency.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>Prevents duplicate submissions and race conditions</span>
            </li>
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>Rejects tampered amounts and unauthorized references</span>
            </li>
          </ul>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-8 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono font-bold text-lg">
            04
          </div>
          <h2 className="text-xl font-bold font-serif text-slate-100">
            Authoritative Ledger Accounting & Receipts
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            Upon successful verification, the double-entry financial ledger credits the deposit and allocates capital toward your hardware pool. You are issued an official printable and downloadable receipt.
          </p>
          <ul className="text-xs text-slate-300 space-y-2 pt-2">
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>Downloadable TXT & PDF-ready print layout</span>
            </li>
            <li className="flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>Full visibility within your authenticated client portal</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="text-center pt-4">
        <button
          onClick={onOpenCheckout}
          className="inline-flex items-center space-x-2 px-8 py-4 rounded-xl text-sm font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-xl shadow-amber-500/20"
        >
          <span>Get Started Now</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
