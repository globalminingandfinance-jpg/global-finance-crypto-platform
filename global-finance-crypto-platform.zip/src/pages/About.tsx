import React from 'react';
import { Shield, Cpu, Users, Globe, CheckCircle2 } from 'lucide-react';

export const About: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
          About Our Platform
        </span>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-slate-100">
          Global Finance Crypto Mining
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-2xl mx-auto">
          Delivering access to digital computational infrastructure through structured financial allocations, rigorous ledger accounting, and transparent South African payment processing.
        </p>
      </div>

      {/* Narrative grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div className="space-y-5 text-xs text-slate-300 leading-relaxed">
          <h2 className="text-2xl font-serif font-bold text-slate-100">
            A Transparent Approach to Digital Asset Computational Infrastructure
          </h2>
          <p>
            Global Finance Crypto Mining was established with a singular focus: bringing modern, verifiable financial engineering to digital infrastructure investments. While the cryptocurrency sector has often suffered from vague promises and non-verifiable claims, our platform operates on immutable double-entry accounting.
          </p>
          <p>
            Whether participating through our Starter (R500), Growth (R1,000), or Professional (R2,500) tiers, each investor is provided with an individual ledger account, real-time PayFast verification, and direct reconciliation records.
          </p>
          <div className="pt-2 grid grid-cols-2 gap-4">
            <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl">
              <span className="text-2xl font-bold font-mono text-amber-400">100%</span>
              <span className="text-slate-400 block text-[11px] mt-0.5">Server-Side Verified Transactions</span>
            </div>
            <div className="bg-slate-900/80 border border-slate-800 p-4 rounded-2xl">
              <span className="text-2xl font-bold font-mono text-amber-400">ZAR</span>
              <span className="text-slate-400 block text-[11px] mt-0.5">Domestic South African Settlement</span>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-8 space-y-6">
          <h3 className="text-base font-bold text-slate-100 font-serif">Core Operating Principles</h3>
          <div className="space-y-4 text-xs">
            <div className="flex items-start space-x-3">
              <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-200 block">No Fabricated Performance</strong>
                <span className="text-slate-400">
                  We never simulate fake mining animations, fictitious profits, or guaranteed investment returns.
                </span>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-200 block">Segregated Accounts</strong>
                <span className="text-slate-400">
                  Investor capital is tracked individually with strict relational foreign key boundaries and session authorization.
                </span>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <CheckCircle2 className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-slate-200 block">Regulatory Readiness</strong>
                <span className="text-slate-400">
                  Built to adhere to POPIA data minimization requirements and transparent terms of service.
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
