import React from 'react';
import { ArrowLeft, Ban, CheckCircle2, Clock, ShieldCheck, AlertCircle, FileText, Mail } from 'lucide-react';

interface CancellationPolicyProps {
  onNavigate?: (view: string) => void;
}

export const CancellationPolicy: React.FC<CancellationPolicyProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-12 text-slate-300">
      {/* Back button */}
      {onNavigate && (
        <button
          onClick={() => onNavigate('home')}
          className="inline-flex items-center space-x-2 text-xs text-amber-400 hover:text-amber-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
      )}

      {/* Header */}
      <div className="space-y-4 border-b border-slate-800 pb-8">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
          <Ban className="w-3.5 h-3.5" />
          <span>ORDER CANCELLATION & SERVICE TERMINATION RULES</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-slate-100">
          Cancellation Policy
        </h1>
        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
          <span><strong>Effective Date:</strong> October 15, 2026</span>
          <span>•</span>
          <span><strong>Platform:</strong> Global Finance Crypto Mining</span>
          <span>•</span>
          <span><strong>Scope:</strong> Orders, Pending Transactions & Computational Contracts</span>
        </div>
      </div>

      {/* Overview Card */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 text-xs sm:text-sm space-y-3 leading-relaxed">
        <h3 className="font-semibold text-slate-200 text-base">Overview & Objectives</h3>
        <p className="text-slate-300">
          This Cancellation Policy explains your rights and obligations when requesting the cancellation of an investment transaction, pending payment, or computational allocation order on Global Finance Crypto Mining.
        </p>
        <p className="text-slate-400 text-xs">
          Our objective is to provide a straightforward, fair cancellation procedure that safeguards client funds while respecting the technical realities of provisioned blockchain computational clusters.
        </p>
      </div>

      {/* Content Sections */}
      <div className="space-y-8 text-xs sm:text-sm leading-relaxed">
        {/* Section 1 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              01
            </span>
            <h2>When Is Cancellation Permitted?</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Cancellation eligibility depends directly on the current state of your order in our database:
            </p>
            <div className="space-y-3 pt-2">
              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>1. Pending Checkout or Unpaid Transaction (Status: PENDING)</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  If you initialized a transaction via PayFast or Bank Transfer and have not completed payment, you may cancel the request at any time without restriction or penalty. Simply discontinue the payment process or notify support to void the pending transaction reference.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>2. Unallocated Funds / Pre-Deployment Window</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  If your payment has reached our accounts but your computational mining hardware allocation has not yet been activated into the cluster network (a buffer period of up to 24 hours), you may request immediate cancellation. In this scenario, 100% of the deposited funds will be returned via the original payment method pursuant to our Refund Policy.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-amber-400 font-semibold text-xs">
                  <Clock className="w-4 h-4 shrink-0" />
                  <span>3. Active Computational Mining Allocations</span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Once your computational mining hardware has been actively provisioned and hash power is contributing to blockchain networks, immediate real-time contract cancellation is not technically instantaneous. Your deployed capital is secured by our <strong>Guaranteed Principal Terms</strong> and is redeemed upon maturity of the plan cycle, or subject to formal administrative early settlement review.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              02
            </span>
            <h2>How to Request Cancellation</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>Customers can initiate cancellation through either of the following steps:</p>
            <ol className="list-decimal pl-5 space-y-2 text-slate-400 text-xs">
              <li>
                <strong>Self-Service Cancellation (Pending Checkout):</strong> In your Customer Dashboard under &quot;Recent Transactions&quot;, any order with status <span className="font-mono text-amber-400">PENDING</span> can be left to expire or closed directly.
              </li>
              <li>
                <strong>Support Notification (Funded Orders):</strong> If payment has already been dispatched from your bank or card, email our administrative team immediately at <span className="text-amber-300 font-mono">[compliance@globalfinancecryptomining.co.za]</span> with the subject line <strong>&quot;URGENT: Transaction Cancellation Request — [Your Reference]&quot;</strong>.
              </li>
            </ol>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-xs space-y-1">
              <span className="font-semibold text-slate-200 block">Required Details for Cancellation:</span>
              <p className="text-slate-400">
                Provide your Customer ID, registered email address, unique transaction reference (e.g. GF-20261015-XXXXXXXX), and the reason for your cancellation.
              </p>
            </div>
          </div>
        </section>

        {/* Section 3 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              03
            </span>
            <h2>Effect of Cancellation on Payments & Ledger Balances</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <ul className="list-disc pl-5 space-y-2 text-slate-400 text-xs">
              <li>
                <strong>Pending Unpaid Orders:</strong> Voided immediately in the database. No ledger credit or debit entries are created, and no financial liability is incurred.
              </li>
              <li>
                <strong>Completed Payments Cancelled Prior to Activation:</strong> A refund entry is created in the financial ledger, reversing the pending deposit. The funds are routed back through PayFast or via EFT back to your originating bank account.
              </li>
              <li>
                <strong>Active Allocations:</strong> In accordance with our capital guarantee, unallocated cash and matured principal remain safeguarded in your Available Balance. Early termination requests for active computational hardware contracts are reviewed on a case-by-case basis by management.
              </li>
            </ul>
          </div>
        </section>

        {/* Section 4 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              04
            </span>
            <h2>Confirmation of Cancellation</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Once a cancellation is successfully executed by the system or approved by an administrator:
            </p>
            <ul className="list-disc pl-5 space-y-1.5 text-slate-400 text-xs">
              <li>An automated confirmation email containing your cancellation reference number will be sent to your registered email address within two (2) hours.</li>
              <li>The transaction status in your Customer Dashboard will update to <span className="font-mono text-slate-300">CANCELLED</span>.</li>
              <li>An immutable entry is logged in the system audit trail recording the cancellation timestamp and responsible party.</li>
            </ul>
          </div>
        </section>

        {/* Section 5 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              05
            </span>
            <h2>Disputes & Support Contact</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              If a cancellation request is delayed, incorrectly processed, or if you have questions regarding the status of a voided transaction, please contact our support desk:
            </p>
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1 text-xs">
              <div><strong>Email:</strong> <span className="text-amber-300 font-mono">[compliance@globalfinancecryptomining.co.za]</span></div>
              <div><strong>Support Desk:</strong> Available via the Customer Dashboard 24/7</div>
              <div><strong>Turnaround Time:</strong> Response guaranteed within 24 business hours</div>
            </div>
          </div>
        </section>
      </div>

      {/* Footer Navigation helper */}
      {onNavigate && (
        <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex flex-wrap gap-4 text-slate-400">
            <button onClick={() => onNavigate('terms')} className="text-amber-400 hover:underline">
              ← View Terms & Conditions
            </button>
            <button onClick={() => onNavigate('refund-policy')} className="text-amber-400 hover:underline">
              View Refund Policy →
            </button>
            <button onClick={() => onNavigate('delivery-policy')} className="text-amber-400 hover:underline">
              View Delivery & Fulfilment Policy →
            </button>
          </div>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="text-slate-400 hover:text-white"
          >
            ↑ Back to Top
          </button>
        </div>
      )}
    </div>
  );
};
