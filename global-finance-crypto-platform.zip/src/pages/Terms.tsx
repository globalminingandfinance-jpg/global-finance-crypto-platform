import React from 'react';
import { ShieldCheck, Scale, FileText, AlertCircle, ArrowLeft, CheckCircle2, Clock, Mail } from 'lucide-react';

interface TermsProps {
  onNavigate?: (view: string) => void;
}

export const Terms: React.FC<TermsProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-12 text-slate-300">
      {/* Breadcrumb / Back button */}
      {onNavigate && (
        <button
          onClick={() => onNavigate('home')}
          className="inline-flex items-center space-x-2 text-xs text-amber-400 hover:text-amber-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
      )}

      {/* Header */}
      <div className="space-y-4 border-b border-slate-800 pb-8">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
          <Scale className="w-3.5 h-3.5" />
          <span>LEGAL AGREEMENT & USER CONDITIONS</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-slate-100">
          Terms & Conditions
        </h1>
        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
          <span><strong>Effective Date:</strong> October 15, 2026</span>
          <span>•</span>
          <span><strong>Version:</strong> 2.4</span>
          <span>•</span>
          <span><strong>Platform:</strong> Global Finance Crypto Mining</span>
        </div>
      </div>

      {/* Notice Banner */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 text-xs space-y-2">
        <p className="text-slate-300 leading-relaxed">
          Please read these Terms & Conditions carefully before creating an account, selecting an investment allocation plan, or executing payments through our platform. These terms constitute a legally binding agreement between you (the &quot;Customer&quot;, &quot;Investor&quot;, or &quot;User&quot;) and <strong>Global Finance Crypto Mining</strong>.
        </p>
        <p className="text-slate-400">
          By registering, accessing our digital dashboard, or transferring funds via PayFast or manual bank transfer, you acknowledge and agree to comply with and be bound by these Terms & Conditions.
        </p>
      </div>

      {/* Content Sections */}
      <div className="space-y-10 text-xs sm:text-sm leading-relaxed">
        {/* Section 1 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              01
            </span>
            <h2>Company Overview & Description of Actual Services</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Global Finance Crypto Mining operates a specialized financial technology and digital computational infrastructure platform. Our primary service comprises the digital allocation, leasing, and management of specialized cryptocurrency computing hardware (ASIC and high-efficiency computational mining clusters) hosted in enterprise data facilities.
            </p>
            <p>
              Customers participate in digital mining allocations by committing capital in South African Rand (ZAR) across our standardized computational tiers:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-slate-400 text-xs">
              <li><strong>Starter Investment:</strong> Minimum R500 allocation for entry-level digital computing access.</li>
              <li><strong>Growth Investment:</strong> Minimum R1,000 allocation for broader hash power efficiency and weekly performance reporting.</li>
              <li><strong>Professional Investment:</strong> Minimum R2,500 allocation for institutional-grade computational clusters and prioritized processing.</li>
              <li><strong>Elite Investment:</strong> High-tier allocations starting from R10,000 up to R2,000,000, designed for premium investors seeking dedicated cluster allocations and VIP portfolio management.</li>
            </ul>
            <p className="text-xs text-slate-400">
              Allocations are recorded in an authoritative, immutable double-entry financial ledger and viewable in real-time through the customer&apos;s authenticated online dashboard.
            </p>
          </div>
        </section>

        {/* Section 2 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              02
            </span>
            <h2>Investment Capital Guarantee Policy</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 text-xs space-y-2 text-amber-200">
              <div className="flex items-center space-x-2 font-bold text-amber-300">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>Capital Protection & Guaranteed Principal Commitment</span>
              </div>
              <p>
                Global Finance Crypto Mining guarantees the safety of the Customer&apos;s allocated capital principal on all eligible investment plans (Starter, Growth, Professional, and Elite). Under this policy, deposited investment capital is segregated in the platform&apos;s accounting ledger and backed by physical computational assets and computational yield agreements.
              </p>
            </div>
            <p>
              Under our guaranteed investment framework:
            </p>
            <ol className="list-decimal pl-5 space-y-1.5 text-slate-400 text-xs">
              <li><strong>Principal Safeguarding:</strong> Your initial deployed capital amount is recorded with mathematical certainty in our immutable double-entry ledger. Capital cannot be modified, forfeited, or depleted by internal operational deductions.</li>
              <li><strong>Auditable Proof of Allocation:</strong> Upon confirmation of payment, each allocation is sealed with a unique transaction reference and downloadable verified receipt.</li>
              <li><strong>Contract Maturity & Repayment:</strong> At the conclusion of the agreed computational allocation period, the full guaranteed principal becomes eligible for redemption or reinvestment pursuant to standard withdrawal rules.</li>
              <li><strong>Operational Note:</strong> <em>[Business Owner Confirmation: Specific reserve fund collateral structures, insurance underwriters, and escrow custodians are subject to final confirmation by management prior to public distribution.]</em></li>
            </ol>
          </div>
        </section>

        {/* Section 3 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              03
            </span>
            <h2>Customer Eligibility & Account Responsibilities</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>To register and access the services of Global Finance Crypto Mining, you represent and warrant that:</p>
            <ul className="list-disc pl-5 space-y-1.5 text-slate-400 text-xs">
              <li>You are at least 18 years of age or the age of majority in your jurisdiction.</li>
              <li>You possess the legal capacity to enter into binding commercial contracts.</li>
              <li>All information provided during registration (first name, surname, email address, phone number, and residential country) is accurate, current, and complete.</li>
              <li>You are responsible for maintaining the strict confidentiality of your account credentials (including passwords) and accept responsibility for all activities that occur under your account.</li>
              <li>You agree to notify our compliance team immediately upon suspecting any unauthorized access to your account.</li>
            </ul>
          </div>
        </section>

        {/* Section 4 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              04
            </span>
            <h2>Pricing, Permitted Denominations & Payment Terms</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              All prices, investment card tiers, ledger balances, and payouts are denominated and processed strictly in <strong>South African Rand (ZAR)</strong>.
            </p>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-xs space-y-2">
              <span className="font-semibold text-slate-200 block">Strict Permitted Investment Amounts:</span>
              <p className="text-slate-400">
                To maintain regulatory compliance and automated accounting integrity, only the following discrete amounts are accepted:
              </p>
              <div className="flex flex-wrap gap-2 pt-1 font-mono text-amber-300 font-semibold">
                <span>R500</span> • <span>R1,000</span> • <span>R2,500</span> • <span>R5,000</span> • <span>R10,000</span> • <span>R25,000</span> • <span>R50,000</span> • <span>R100,000</span> • <span>R250,000</span> • <span>R500,000</span> • <span>R1,000,000</span> • <span>R2,000,000</span>
              </div>
              <p className="text-[11px] text-slate-500">
                Any transactions with non-permitted amounts or amounts below plan minimums are automatically rejected by server-side validation.
              </p>
            </div>
            <p><strong>Payment Gateways & Methods:</strong></p>
            <ul className="list-disc pl-5 space-y-2 text-slate-400 text-xs">
              <li>
                <strong>PayFast Online Gateway:</strong> Processed via PayFast (Pty) Ltd. Allocations are confirmed automatically upon cryptographic signature verification and server-side Instant Transaction Notification (ITN).
              </li>
              <li>
                <strong>Direct Electronic Funds Transfer (Bank Transfer):</strong> Transferred directly to our designated business bank account.
                <div className="mt-2 p-3 bg-amber-500/5 border border-amber-500/20 rounded-lg text-slate-300 text-xs space-y-1">
                  <div><strong>Account Name:</strong> [BAHOLO CONSULTING] <em>(Placeholder until verified business banking details supplied)</em></div>
                  <div><strong>Bank:</strong> [TymeBank/GoTymeBank]</div>
                  <div><strong>Account Number:</strong> [53002153808]</div>
                  <div><strong>Branch Code:</strong> [678910]</div>
                  <div className="text-amber-300 font-semibold pt-1">
                    CRITICAL REQUIREMENT: Customers MUST input their unique transaction reference (e.g. GF-20261015-XXXXXXXX) in the transfer description field. This payment can ONLY be performed directly inside your official banking mobile app. Retail till points or ATM cash deposits are prohibited.
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </section>

        {/* Section 5 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              05
            </span>
            <h2>Withdrawals & Available Cash Balance Rules</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Withdrawals may only be requested against the customer&apos;s verified <strong>Available Balance</strong> as calculated authoritatively by the financial ledger. Funds that are actively allocated to ongoing computational mining contracts cannot be withdrawn until the contract term is completed or an approved early settlement is executed.
            </p>
            <p>
              Withdrawal requests are processed exclusively to a South African commercial bank account registered in the exact same legal name as the customer&apos;s profile. Third-party disbursements are prohibited under anti-money laundering (AML) controls.
            </p>
          </div>
        </section>

        {/* Section 6 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              06
            </span>
            <h2>Website Use, Prohibited Conduct & Security</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>When accessing or using our website and API endpoints, you strictly agree NOT to:</p>
            <ul className="list-disc pl-5 space-y-1.5 text-slate-400 text-xs">
              <li>Manipulate client-side scripts, parameters, or payloads to bypass amount validation or security checks.</li>
              <li>Submit fraudulent, intercepted, or simulated PayFast ITN notifications or payment proofs.</li>
              <li>Engage in duplicate credit claims or ledger manipulation attacks.</li>
              <li>Attempt unauthorized access to administrator portals, backend databases, or server configurations.</li>
              <li>Use automated scrapers, bots, or DDoS techniques against platform infrastructure.</li>
            </ul>
            <p className="text-xs text-red-400/90">
              Violations will result in immediate permanent account termination, forfeiture of unverified claims, and reporting to law enforcement and regulatory authorities.
            </p>
          </div>
        </section>

        {/* Section 7 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              07
            </span>
            <h2>Customer Support & Complaints Procedure</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              We are committed to resolving customer inquiries and payment discrepancies efficiently. If you experience an issue with a deposit, transaction reference, or dashboard position:
            </p>
            <ol className="list-decimal pl-5 space-y-2 text-slate-400 text-xs">
              <li>
                <strong>Step 1 — Support Ticket:</strong> Submit a support ticket directly through your Customer Dashboard under the &quot;Support&quot; tab, specifying your transaction reference (e.g. GF-20261015-XXXXXXXX).
              </li>
              <li>
                <strong>Step 2 — Direct Email:</strong> Alternatively, contact our compliance desk via email at <span className="text-amber-300 font-mono">[compliance@globalfinancecryptomining.co.za]</span>.
              </li>
              <li>
                <strong>Step 3 — Resolution Timeframe:</strong> Our administrative and compliance team investigates all logged tickets within two (2) business days and communicates written resolution directly to your registered email.
              </li>
            </ol>
          </div>
        </section>

        {/* Section 8 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              08
            </span>
            <h2>Policy Updates & Governing Jurisdiction</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              <strong>Policy Revisions:</strong> We reserve the right to revise or amend these Terms & Conditions from time to time. When updates are published, the &quot;Effective Date&quot; at the top of this document will be updated. Continued use of the platform following notification constitutes acceptance of the modified terms.
            </p>
            <p>
              <strong>Governing Law & Legal Jurisdiction:</strong> These Terms & Conditions, and any non-contractual obligations arising out of or in connection with them, shall be governed by and construed in accordance with the laws of <strong>South Africa</strong> <em>[Jurisdiction: Republic of South Africa – Subject to formal statutory registration confirmation by company directors]</em>.
            </p>
            <p className="text-xs text-slate-500 italic">
              Notice: Global Finance Crypto Mining does not invent regulatory licences, financial registrations, or banking authorizations. Any statutory registrations required by competent authorities will be listed herein once formally confirmed.
            </p>
          </div>
        </section>
      </div>

      {/* Footer Navigation helper */}
      {onNavigate && (
        <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex flex-wrap gap-4 text-slate-400">
            <button onClick={() => onNavigate('refund-policy')} className="text-amber-400 hover:underline">
              View Refund Policy →
            </button>
            <button onClick={() => onNavigate('cancellation-policy')} className="text-amber-400 hover:underline">
              View Cancellation Policy →
            </button>
            <button onClick={() => onNavigate('delivery-policy')} className="text-amber-400 hover:underline">
              View Delivery & Fulfilment Policy →
            </button>
          </div>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="text-slate-400 hover:text-white"
          >
            ↑ Back to Top
          </button>
        </div>
      )}
    </div>
  );
};
