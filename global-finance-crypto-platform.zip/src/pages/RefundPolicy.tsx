import React from 'react';
import { ArrowLeft, RefreshCw, AlertCircle, CheckCircle2, Clock, ShieldCheck, CreditCard, Building2, HelpCircle } from 'lucide-react';

interface RefundPolicyProps {
  onNavigate?: (view: string) => void;
}

export const RefundPolicy: React.FC<RefundPolicyProps> = ({ onNavigate }) => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-12 text-slate-300">
      {/* Back button */}
      {onNavigate && (
        <button
          onClick={() => onNavigate('home')}
          className="inline-flex items-center space-x-2 text-xs text-amber-400 hover:text-amber-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </button>
      )}

      {/* Header */}
      <div className="space-y-4 border-b border-slate-800 pb-8">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-semibold">
          <RefreshCw className="w-3.5 h-3.5" />
          <span>FINANCIAL REVERSAL & REIMBURSEMENT STANDARDS</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-slate-100">
          Refund Policy
        </h1>
        <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400">
          <span><strong>Effective Date:</strong> October 15, 2026</span>
          <span>•</span>
          <span><strong>Governing Entity:</strong> Global Finance Crypto Mining</span>
          <span>•</span>
          <span><strong>Currency:</strong> South African Rand (ZAR)</span>
        </div>
      </div>

      {/* Overview Card */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 text-xs sm:text-sm space-y-3 leading-relaxed">
        <h3 className="font-semibold text-slate-200 text-base">Policy Statement</h3>
        <p className="text-slate-300">
          At Global Finance Crypto Mining, we are committed to maintaining transparent, fair, and auditable financial accounting. Because all transactions interact with our authoritative double-entry ledger and dedicated computational hardware clusters, this Refund Policy outlines the precise conditions, procedures, and timeframes under which refund requests are reviewed and disbursed.
        </p>
        <p className="text-slate-400 text-xs">
          This policy applies equally to payments made through the <strong>PayFast online payment gateway</strong> and direct <strong>manual electronic funds transfers (EFT)</strong> into our designated accounts.
        </p>
      </div>

      {/* Content Sections */}
      <div className="space-y-8 text-xs sm:text-sm leading-relaxed">
        {/* Section 1 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              01
            </span>
            <h2>Circumstances Where Refunds Are Considered or Granted</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Refunds are not arbitrary and are evaluated on an objective, auditable basis. Global Finance Crypto Mining will consider and process refunds under the following specific circumstances:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Duplicate or Accidental Overpayments</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  If an investor accidentally pays for the same pending transaction twice, or makes multiple transfers for a single allocation, the duplicated surplus amount will be fully refunded upon verification.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Unfulfilled Hardware Allocations</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  In the rare event that computational hardware capacity cannot be provisioned or activated within seventy-two (72) business hours of verified payment receipt, the customer is entitled to a 100% refund of the unallocated capital.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Pre-Activation Cancellation</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  If a cancellation request is submitted while a transaction is in &apos;PENDING&apos; status, or before the computational mining hash power has been assigned to the network, a full cancellation refund will be granted.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Payment Gateway Technical Discrepancies</span>
                </div>
                <p className="text-xs text-slate-400 leading-normal">
                  Where PayFast or banking gateway logs verify a billing discrepancy (e.g. incorrect amount charged vs selected permitted tier), the discrepancy will be immediately reconciled and refunded.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              02
            </span>
            <h2>Capital Guarantee & Contract Active Status</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Under our <strong>Investment Capital Guarantee</strong>, all allocated capital is safeguarded throughout the duration of the chosen investment tier (Starter, Growth, Professional, or Elite).
            </p>
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 text-xs space-y-2 text-amber-200">
              <span className="font-bold block">Important Distinction Between Refunds & Capital Redemptions:</span>
              <p>
                A <em>refund</em> applies to transaction errors, cancellations before service activation, or unfulfilled orders. Once your computational mining contract is activated and hash power is actively computing, your capital is protected under the <strong>Guaranteed Principal Terms</strong> and is redeemed at contract completion via our standard <em>Withdrawal Portal</em>, rather than through immediate transaction cancellation.
              </p>
            </div>
          </div>
        </section>

        {/* Section 3 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              03
            </span>
            <h2>How to Submit a Refund Request & Required Information</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>To request a refund, customers must submit an official request through one of our authorized channels:</p>
            <ol className="list-decimal pl-5 space-y-1.5 text-slate-400 text-xs">
              <li><strong>Option A:</strong> Log into your Customer Dashboard and open a ticket under the &quot;Support&quot; section with category &quot;Refund Request&quot;.</li>
              <li><strong>Option B:</strong> Send an email from your registered account email to <span className="text-amber-300 font-mono">[compliance@globalfinancecryptomining.co.za]</span>.</li>
            </ol>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 text-xs space-y-2 mt-2">
              <span className="font-semibold text-slate-200 block">Required Information Checklist:</span>
              <ul className="list-disc pl-5 space-y-1 text-slate-400 text-xs">
                <li>Your full legal name as registered on Global Finance Crypto Mining.</li>
                <li>Your unique platform transaction reference (e.g. <span className="font-mono text-amber-300">GF-20261015-XXXXXXXX</span>).</li>
                <li>The exact payment amount in ZAR and the date/time the payment was initiated.</li>
                <li>Payment method used (PayFast online or direct bank transfer).</li>
                <li>For PayFast: The PayFast payment ID or copy of the PayFast email confirmation.</li>
                <li>For Bank Transfer: Official bank payment confirmation (PDF) showing the transfer description and source bank details.</li>
                <li>A clear, concise explanation of the reason for the refund request.</li>
              </ul>
            </div>
          </div>
        </section>

        {/* Section 4 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              04
            </span>
            <h2>Refund Review & Processing Timeframes</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              Refund processing consists of two distinct stages: our internal compliance audit review, followed by the third-party payment provider settlement window.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-amber-300 font-bold">
                  <Clock className="w-4 h-4" />
                  <span>Stage 1: Internal Audit Review</span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Our compliance team reviews the submitted transaction against the database ledger and bank/PayFast logs within <strong>3 to 5 business days</strong>. Written confirmation of approval or rejection will be dispatched to your registered email address.
                </p>
              </div>

              <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-blue-400 font-bold">
                  <CreditCard className="w-4 h-4" />
                  <span>Stage 2: Provider Disbursement Timeframe</span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Once approved internally, the actual disbursement depends on the payment provider:
                </p>
                <ul className="list-disc pl-4 space-y-1 text-slate-400">
                  <li><strong>PayFast Gateway Reversals:</strong> Typically reflect on the customer&apos;s card or account within <strong>5 to 10 business days</strong>, depending on PayFast and your issuing bank.</li>
                  <li><strong>Direct Bank Transfers (EFT):</strong> Typically reflect within <strong>24 to 48 business hours</strong> via standard domestic South African clearing.</li>
                </ul>
              </div>
            </div>
            <p className="text-[11px] text-slate-400 italic">
              Important: Please note that third-party bank clearing schedules, public holidays, and banking settlement cutoff hours are outside of our direct operational control.
            </p>
          </div>
        </section>

        {/* Section 5 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              05
            </span>
            <h2>Handling by Payment Provider & Third-Party Deductions</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <ul className="list-disc pl-5 space-y-2 text-slate-400 text-xs">
              <li>
                <strong>PayFast Transactions:</strong> Approved refunds for payments initiated through PayFast will be credited directly back to the original funding instrument (credit card, debit card, or originating Instant EFT bank account) via PayFast&apos;s formal merchant reversal mechanism.
              </li>
              <li>
                <strong>Direct Bank Transfers:</strong> Refunds will only be disbursed into the verified South African bank account from which the funds originally came. Under South African anti-money laundering regulations, we cannot refund EFT deposits to unrelated third-party bank accounts.
              </li>
              <li>
                <strong>Lawful Deductions & Non-Refundable Charges:</strong> Where a refund is requested due to customer error rather than platform failure, non-recoverable third-party payment gateway transaction fees (such as PayFast merchant processing fees or interbank wire levies) may be deducted from the refund total where permitted by South African consumer protection law.
              </li>
            </ul>
          </div>
        </section>

        {/* Section 6 */}
        <section className="space-y-3 bg-slate-950/60 border border-slate-800/80 rounded-2xl p-6 sm:p-8">
          <div className="flex items-center space-x-3 text-amber-300 font-serif font-bold text-base sm:text-lg">
            <span className="w-7 h-7 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-xs text-amber-400 font-mono">
              06
            </span>
            <h2>Contacting Support Regarding a Refund</h2>
          </div>
          <div className="space-y-3 text-slate-300">
            <p>
              If your refund has been approved but has not reflected within the expected timeline, or if you need assistance submitting documentation, please contact our financial reconciliations team:
            </p>
            <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-1 text-xs">
              <div><strong>Email:</strong> <span className="text-amber-300 font-mono">[compliance@globalfinancecryptomining.co.za]</span></div>
              <div><strong>Subject Line:</strong> Refund Inquiry — [Your Transaction Reference]</div>
              <div><strong>Business Hours:</strong> Monday – Friday, 08:30 – 17:00 SAST</div>
            </div>
          </div>
        </section>
      </div>

      {/* Footer Navigation helper */}
      {onNavigate && (
        <div className="pt-6 border-t border-slate-800 flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex flex-wrap gap-4 text-slate-400">
            <button onClick={() => onNavigate('terms')} className="text-amber-400 hover:underline">
              ← View Terms & Conditions
            </button>
            <button onClick={() => onNavigate('cancellation-policy')} className="text-amber-400 hover:underline">
              View Cancellation Policy →
            </button>
            <button onClick={() => onNavigate('delivery-policy')} className="text-amber-400 hover:underline">
              View Delivery & Fulfilment Policy →
            </button>
          </div>
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="text-slate-400 hover:text-white"
          >
            ↑ Back to Top
          </button>
        </div>
      )}
    </div>
  );
};
