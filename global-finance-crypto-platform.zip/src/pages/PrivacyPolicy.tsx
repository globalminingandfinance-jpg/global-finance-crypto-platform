import React from 'react';
import { ShieldCheck } from 'lucide-react';

export const PrivacyPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-10 text-xs text-slate-300 leading-relaxed">
      <div className="space-y-3 border-b border-slate-800 pb-6">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
          Legal & Compliance
        </span>
        <h1 className="text-3xl font-serif font-bold text-slate-100">
          Privacy Policy (POPIA)
        </h1>
        <p className="text-slate-400 text-xs">
          Last updated: October 2026 • Prepared in alignment with the Protection of Personal Information Act (POPIA) of South Africa.
        </p>
      </div>

      <div className="space-y-6">
        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">1. Information We Collect</h2>
          <p>
            Global Finance Crypto Mining collects personal information necessary to maintain financial records, authenticate investor sessions, and execute payment processing. This includes:
          </p>
          <ul className="list-disc pl-5 space-y-1 text-slate-400">
            <li>Full legal first name and surname.</li>
            <li>Contact email address and phone number.</li>
            <li>Country of residence and IP address for session security.</li>
            <li>Transaction references, investment amounts, and payment provider identifiers.</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">2. Purpose of Processing</h2>
          <p>We process personal data solely for legitimate business and compliance objectives:</p>
          <ul className="list-disc pl-5 space-y-1 text-slate-400">
            <li>Facilitating secure online payments via PayFast (Pty) Ltd.</li>
            <li>Reconciling direct electronic funds transfers with official banking records.</li>
            <li>Maintaining an immutable, double-entry financial ledger of client allocations.</li>
            <li>Generating authorized receipts and satisfying statutory accounting requirements.</li>
          </ul>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">3. Data Minimization & Security</h2>
          <p>
            We strictly enforce the principle of least privilege. Sensitive financial secrets and payment credentials are kept exclusively on protected backend servers. We never collect or store raw payment card numbers, CVVs, or bank account PINs on our servers.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">4. Third-Party Disclosures</h2>
          <p>
            We do not sell, rent, or trade customer data. Transaction data is transmitted securely to PayFast (Pty) Ltd solely to process online payments initiated by the user.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-base font-bold text-slate-100">5. Customer Rights under POPIA</h2>
          <p>
            South African data subjects are entitled to request access to their personal records, request corrections of inaccurate data, or object to unlawful processing by contacting our designated Information Officer at <span className="text-amber-300 font-mono">[BUSINESS EMAIL: privacy@globalfinancecryptomining.co.za]</span>.
          </p>
        </section>
      </div>
    </div>
  );
};
