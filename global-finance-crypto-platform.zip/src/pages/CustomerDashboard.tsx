import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { FinancialSummary, Transaction, InvestmentAllocation, WithdrawalRecord, ReceiptData } from '../types/index.js';
import { ReceiptModal } from '../components/ReceiptModal.js';
import { NotificationCenter } from '../components/NotificationCenter.js';
import { CustomerSupportSection } from '../components/CustomerSupportSection.js';
import { SecurityCentre } from '../components/SecurityCentre.js';
import { InvestmentPerformanceDashboard } from '../components/InvestmentPerformanceDashboard.js';
import { CustomerFinancialOverview } from '../components/CustomerFinancialOverview.js';
import {
  LayoutDashboard,
  Wallet,
  Coins,
  History,
  CreditCard,
  ArrowDownToLine,
  User,
  ShieldCheck,
  HelpCircle,
  LifeBuoy,
  LogOut,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  Loader2,
  RefreshCw,
  PlusCircle,
  Bell,
  TrendingUp,
  Megaphone,
  X,
} from 'lucide-react';

interface CustomerDashboardProps {
  onOpenCheckout: () => void;
  onNavigateHome: () => void;
  initialTab?: string;
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  onOpenCheckout,
  onNavigateHome,
  initialTab,
}) => {
  const { user, token, logout } = useAuth();
  const [activeTab, setActiveTab] = useState<
    'overview' | 'financial-overview' | 'investment-dashboard' | 'investments' | 'transactions' | 'payments' | 'withdrawals' | 'profile' | 'security' | 'support'
  >((initialTab as any) || 'overview');

  const [isLoading, setIsLoading] = useState(true);
  const [summary, setSummary] = useState<FinancialSummary | null>(null);
  const [activeInvestments, setActiveInvestments] = useState<InvestmentAllocation[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [pendingPayments, setPendingPayments] = useState<Transaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRecord[]>([]);

  // Receipt modal state
  const [selectedReceipt, setSelectedReceipt] = useState<ReceiptData | null>(null);
  const [receiptLoading, setReceiptLoading] = useState(false);

  // Withdrawal form state
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawBank, setWithdrawBank] = useState('');
  const [withdrawAccount, setWithdrawAccount] = useState('');
  const [withdrawHolder, setWithdrawHolder] = useState(user ? `${user.firstName} ${user.lastName}` : '');
  const [withdrawBranch, setWithdrawBranch] = useState('');
  const [withdrawSubmitting, setWithdrawSubmitting] = useState(false);
  const [withdrawMessage, setWithdrawMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Support ticket form state
  const [supportSubject, setSupportSubject] = useState('');
  const [supportMessage, setSupportMessage] = useState('');
  const [supportSubmitting, setSupportSubmitting] = useState(false);
  const [supportFeedback, setSupportFeedback] = useState<string | null>(null);

  // Urgent Announcement Banner State
  const [urgentAnnouncement, setUrgentAnnouncement] = useState<any | null>(null);
  const [dismissedAnnouncements, setDismissedAnnouncements] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('gf_dismissed_announcements') || '[]');
    } catch {
      return [];
    }
  });

  const fetchDashboardData = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };

      // 1. Overview
      const ovRes = await fetch('/api/customer/overview', { headers });
      if (ovRes.ok) {
        const ovData = await ovRes.json();
        setSummary(ovData.financialSummary);
        setActiveInvestments(ovData.activeInvestments || []);
        setTransactions(ovData.recentTransactions || []);
        setPendingPayments(ovData.pendingPayments || []);
      }

      // 2. Withdrawals
      const wdRes = await fetch('/api/customer/withdrawals', { headers });
      if (wdRes.ok) {
        const wdData = await wdRes.json();
        setWithdrawals(wdData.withdrawals || []);
      }

      // 3. Urgent Announcements for Alert Banner
      const notifRes = await fetch('/api/customer/notifications', { headers });
      if (notifRes.ok) {
        const notifData = await notifRes.json();
        const urgentItems = (notifData.notifications || []).filter(
          (n: any) =>
            (n.type?.startsWith('ANNOUNCEMENT') || n.announcement_id) &&
            (n.priority === 'URGENT' || n.priority === 'CRITICAL' || n.priority === 'IMPORTANT')
        );
        const activeUnDismissed = urgentItems.find(
          (a: any) => !dismissedAnnouncements.includes(a.announcement_id || a.id)
        );
        setUrgentAnnouncement(activeUnDismissed || null);
      }
    } catch (err) {
      console.error('Failed to load customer dashboard data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [token]);

  const handleOpenReceipt = async (reference: string) => {
    setReceiptLoading(true);
    try {
      const res = await fetch(`/api/payments/receipt/${reference}`);
      const data = await res.json();
      if (res.ok) {
        setSelectedReceipt(data);
      } else {
        alert(data.error || 'Unable to load receipt.');
      }
    } catch {
      alert('Network error loading receipt.');
    } finally {
      setReceiptLoading(false);
    }
  };

  const handleWithdrawalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawMessage(null);
    setWithdrawSubmitting(true);

    try {
      const res = await fetch('/api/customer/withdrawals', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          amount: parseFloat(withdrawAmount),
          bankName: withdrawBank,
          accountNumber: withdrawAccount,
          accountHolder: withdrawHolder,
          branchCode: withdrawBranch,
        }),
      });

      const data = await res.json();
      setWithdrawSubmitting(false);

      if (res.ok) {
        setWithdrawMessage({ type: 'success', text: data.message });
        setWithdrawAmount('');
        fetchDashboardData();
      } else {
        setWithdrawMessage({ type: 'error', text: data.error || 'Failed to submit withdrawal.' });
      }
    } catch {
      setWithdrawSubmitting(false);
      setWithdrawMessage({ type: 'error', text: 'Network connection failed.' });
    }
  };

  const handleSupportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSupportFeedback(null);
    setSupportSubmitting(true);

    try {
      const res = await fetch('/api/customer/support', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: `${user?.firstName} ${user?.lastName}`,
          email: user?.email,
          subject: supportSubject,
          message: supportMessage,
        }),
      });

      const data = await res.json();
      setSupportSubmitting(false);

      if (res.ok) {
        setSupportFeedback(data.message);
        setSupportSubject('');
        setSupportMessage('');
      } else {
        setSupportFeedback(data.error || 'Unable to submit support ticket.');
      }
    } catch {
      setSupportSubmitting(false);
      setSupportFeedback('Network error sending message.');
    }
  };

  // Selected ticket for direct navigation from notification bell
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);

  const handleOpenTicketFromNotification = (ticketId: string) => {
    setSelectedTicketId(ticketId);
    setActiveTab('support');
  };

  // Purchase-Gated Investment Feature Visibility Check:
  // Customers without any activated or historical investment will NOT see the Investment Dashboard
  // or projection interfaces. The portal operates in standard retail mode.
  const hasPurchasedInvestment =
    activeInvestments.length > 0 ||
    ((summary?.allocatedCapital || 0) > 0) ||
    ((summary?.activeInvestmentsCount || 0) > 0);

  // Auto-redirect if non-investing client navigates to investment-dashboard
  useEffect(() => {
    if (!isLoading && !hasPurchasedInvestment && activeTab === 'investment-dashboard') {
      setActiveTab('overview');
    }
  }, [isLoading, hasPurchasedInvestment, activeTab]);

  const menuItems = [
    { id: 'overview', label: 'Overview', icon: LayoutDashboard },
    { id: 'financial-overview', label: 'Financial Overview', icon: FileText },
    ...(hasPurchasedInvestment
      ? [{ id: 'investment-dashboard', label: 'Investment Dashboard', icon: TrendingUp }]
      : []),
    { id: 'investments', label: 'My Investments', icon: Coins },
    { id: 'transactions', label: 'Transactions', icon: History },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'withdrawals', label: 'Withdrawals', icon: ArrowDownToLine },
    { id: 'support', label: 'Support & Complaints', icon: LifeBuoy },
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'security', label: 'Security & KYC', icon: ShieldCheck },
  ];

  return (
    <div className="min-h-screen bg-[#070b12] text-slate-100 flex flex-col md:flex-row">
      {/* Receipt Modal */}
      <ReceiptModal receipt={selectedReceipt} onClose={() => setSelectedReceipt(null)} />

      {/* Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-slate-950 border-r border-slate-800/80 flex flex-col shrink-0">
        <div className="p-6 border-b border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center space-x-3 cursor-pointer" onClick={onNavigateHome}>
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-600 to-yellow-400 p-[1px]">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center font-bold text-amber-400 text-xs">
                GF
              </div>
            </div>
            <div>
              <div className="font-serif font-bold text-sm tracking-wide text-slate-100">
                GLOBAL FINANCE
              </div>
              <div className="text-[10px] text-amber-400 uppercase tracking-widest">
                Client Portal
              </div>
            </div>
          </div>
        </div>

        {/* User Card */}
        <div className="p-4 mx-3 my-3 bg-slate-900/60 border border-slate-800 rounded-xl">
          <div className="text-xs font-semibold text-slate-200">
            {user?.firstName} {user?.lastName}
          </div>
          <div className="text-[11px] text-slate-400 font-mono truncate">{user?.email}</div>
          <div className="mt-2 flex items-center justify-between">
            <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
              Verified Client
            </span>
            <button
              onClick={fetchDashboardData}
              title="Refresh ledger"
              className="p-1 text-slate-400 hover:text-white"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Menu list */}
        <nav className="flex-1 px-3 space-y-1 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isSelected = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  isSelected
                    ? 'bg-amber-500 text-black font-bold shadow-md shadow-amber-500/20'
                    : 'text-slate-300 hover:bg-slate-900 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-black' : 'text-amber-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Footer actions */}
        <div className="p-4 border-t border-slate-800/80 space-y-2">
          <button
            onClick={onOpenCheckout}
            className="w-full flex items-center justify-center space-x-2 py-2.5 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Investment</span>
          </button>
          <button
            onClick={logout}
            className="w-full flex items-center justify-center space-x-2 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-red-400 hover:bg-slate-900 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-6 sm:p-8 lg:p-10 overflow-y-auto max-w-7xl">
        {/* Top Header Toolbar with Notification Bell */}
        <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-800/80">
          <div className="flex items-center space-x-2 text-xs text-slate-400">
            <span className="font-semibold text-slate-200 uppercase tracking-wider">
              {menuItems.find((m) => m.id === activeTab)?.label || 'Client Portal'}
            </span>
          </div>
          <div className="flex items-center space-x-3">
            <NotificationCenter
              token={token}
              onOpenTicket={handleOpenTicketFromNotification}
              onOpenCheckout={onOpenCheckout}
              onNavigate={(tab) => setActiveTab(tab as any)}
            />
          </div>
        </div>

        {/* Urgent Announcement Alert Banner */}
        {urgentAnnouncement && (
          <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-red-500/15 via-slate-900 to-amber-500/10 border border-red-500/30 flex items-start justify-between gap-4 shadow-lg shadow-red-500/5">
            <div className="flex items-start space-x-3.5">
              <div className="w-8 h-8 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400 shrink-0 mt-0.5">
                <Megaphone className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500/20 text-red-300 border border-red-500/40 uppercase">
                    {urgentAnnouncement.priority === 'URGENT' ? 'Urgent Alert' : 'Important Notice'}
                  </span>
                  <span className="text-xs font-bold text-slate-100">
                    {urgentAnnouncement.title}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-1 line-clamp-2">
                  {urgentAnnouncement.message}
                </p>
                {urgentAnnouncement.action_link && (
                  <div className="mt-2">
                    <button
                      onClick={() => {
                        if (urgentAnnouncement.action_link.startsWith('/')) {
                          setActiveTab(urgentAnnouncement.action_link.replace('/', '') as any);
                        }
                      }}
                      className="text-xs font-semibold text-amber-400 hover:text-amber-300 underline"
                    >
                      View Details & Action &rarr;
                    </button>
                  </div>
                )}
              </div>
            </div>
            <button
              onClick={() => {
                const targetId = urgentAnnouncement.announcement_id || urgentAnnouncement.id;
                const updated = [...dismissedAnnouncements, targetId];
                setDismissedAnnouncements(updated);
                try {
                  localStorage.setItem('gf_dismissed_announcements', JSON.stringify(updated));
                } catch {}
                setUrgentAnnouncement(null);
              }}
              className="p-1 text-slate-400 hover:text-slate-200 transition-colors shrink-0"
              title="Dismiss announcement banner"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* OVERVIEW TAB */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">Client Overview</h1>
              <p className="text-xs text-slate-400 mt-1">
                Real-time financial balances calculated directly from the immutable double-entry ledger.
              </p>
            </div>

            {/* Financial Ledger Metric Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* Confirmed Deposits */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-medium text-slate-400">Total Confirmed Deposits</span>
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold font-mono text-slate-100">
                  R {(summary?.confirmedDeposits || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-emerald-400/90 mt-1">
                  Verified payments received
                </div>
              </div>

              {/* Allocated Investment Capital */}
              <div className="bg-slate-900/80 border border-amber-500/30 rounded-2xl p-5 relative overflow-hidden shadow-lg shadow-amber-500/5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-medium text-amber-300">Allocated Investment Capital</span>
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                    <Coins className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold font-mono text-amber-300">
                  R {(summary?.allocatedCapital || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-slate-400 mt-1">
                  {summary?.activeInvestmentsCount || 0} active computing position(s)
                </div>
              </div>

              {/* Available Cash Balance */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-medium text-slate-400">Available Unallocated Balance</span>
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                    <Wallet className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold font-mono text-slate-100">
                  R {(summary?.availableBalance || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Available for withdrawal or re-allocation
                </div>
              </div>

              {/* Pending Withdrawals */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-medium text-slate-400">Pending Withdrawals</span>
                  <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center">
                    <Clock className="w-4 h-4" />
                  </div>
                </div>
                <div className="text-2xl font-bold font-mono text-slate-100">
                  R {(summary?.pendingWithdrawals || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                </div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Under administrative review
                </div>
              </div>
            </div>

            {/* Performance Dashboard shortcut for qualifying investors */}
            {hasPurchasedInvestment && (
              <div className="bg-gradient-to-r from-amber-500/10 via-slate-900 to-slate-900 border border-amber-500/30 rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-lg shadow-amber-500/5">
                <div className="flex items-center space-x-3.5">
                  <div className="p-2.5 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 shrink-0">
                    <TrendingUp className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
                      <span>Investment Performance Dashboard Active</span>
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        Live Tracking
                      </span>
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Monitor your contractual maturity schedule, projected returns, daily milestone records, and interactive charts.
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('investment-dashboard')}
                  className="self-start sm:self-center px-4 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10 shrink-0 whitespace-nowrap"
                >
                  View Performance Dashboard →
                </button>
              </div>
            )}

            {/* Pending Payments Alert if any */}
            {pendingPayments.length > 0 && (
              <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-amber-300 font-semibold text-sm">
                    <Clock className="w-4 h-4" />
                    <span>You have {pendingPayments.length} pending payment(s)</span>
                  </div>
                </div>
                <div className="divide-y divide-amber-500/20 text-xs">
                  {pendingPayments.map((p) => (
                    <div key={p.id} className="py-2.5 flex items-center justify-between">
                      <div>
                        <span className="font-mono font-bold text-amber-300">{p.reference}</span>
                        <span className="text-slate-400 ml-2">({p.productName})</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className="font-mono text-slate-200">R {p.amount.toLocaleString()}</span>
                        <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                          {p.paymentMethod === 'bank_transfer' ? 'EFT Pending Reconcile' : 'PayFast Pending'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Active Investments Grid */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-semibold text-slate-100">Active Investment Positions</h3>
                <button
                  onClick={onOpenCheckout}
                  className="text-xs text-amber-400 hover:text-amber-300 font-medium"
                >
                  + Add Investment
                </button>
              </div>

              {activeInvestments.length === 0 ? (
                <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-8 text-center text-xs text-slate-400 space-y-3">
                  <Coins className="w-10 h-10 text-slate-600 mx-auto" />
                  <p>You do not currently have any active investment allocations.</p>
                  <button
                    onClick={onOpenCheckout}
                    className="px-4 py-2 rounded-xl text-xs font-semibold text-black bg-amber-400 hover:bg-amber-300"
                  >
                    Start Your First Investment
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeInvestments.map((inv) => (
                    <div
                      key={inv.id}
                      className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 relative overflow-hidden"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-sm text-slate-100">{inv.productName}</span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          {inv.status}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 text-xs block">Allocated Capital</span>
                        <span className="text-xl font-mono font-bold text-amber-300">
                          R {inv.amountAllocated.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div className="pt-3 border-t border-slate-800/80 text-[11px] text-slate-500 flex justify-between">
                        <span>Date: {new Date(inv.createdAt).toLocaleDateString()}</span>
                        <span className="font-mono">Ref: {inv.transactionReference || 'SETTLED'}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Recent Transactions Table */}
            <div className="space-y-4">
              <h3 className="text-base font-semibold text-slate-100">Recent Transactions</h3>
              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                      <tr>
                        <th className="py-3 px-4 font-medium">Reference</th>
                        <th className="py-3 px-4 font-medium">Product</th>
                        <th className="py-3 px-4 font-medium">Amount</th>
                        <th className="py-3 px-4 font-medium">Method</th>
                        <th className="py-3 px-4 font-medium">Status</th>
                        <th className="py-3 px-4 font-medium">Date</th>
                        <th className="py-3 px-4 font-medium text-right">Receipt</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {transactions.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="py-8 text-center text-slate-500">
                            No transactions recorded in ledger.
                          </td>
                        </tr>
                      ) : (
                        transactions.map((tx) => (
                          <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors">
                            <td className="py-3 px-4 font-mono font-semibold text-slate-200">
                              {tx.reference}
                            </td>
                            <td className="py-3 px-4 text-slate-300">{tx.productName}</td>
                            <td className="py-3 px-4 font-mono font-medium text-slate-200">
                              R {tx.amount.toLocaleString()}
                            </td>
                            <td className="py-3 px-4 text-slate-400 uppercase text-[11px]">
                              {tx.paymentMethod === 'payfast' ? 'PayFast' : 'Bank EFT'}
                            </td>
                            <td className="py-3 px-4">
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  tx.status === 'SUCCESS'
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                    : tx.status === 'PENDING'
                                    ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                                    : 'bg-red-500/10 text-red-400 border border-red-500/30'
                                }`}
                              >
                                {tx.status}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-slate-400 text-[11px]">
                              {new Date(tx.createdAt).toLocaleDateString()}
                            </td>
                            <td className="py-3 px-4 text-right">
                              {tx.status === 'SUCCESS' ? (
                                <button
                                  onClick={() => handleOpenReceipt(tx.reference)}
                                  className="inline-flex items-center space-x-1 text-amber-400 hover:text-amber-300 font-medium text-xs"
                                >
                                  <FileText className="w-3.5 h-3.5" />
                                  <span>Receipt</span>
                                </button>
                              ) : (
                                <span className="text-[10px] text-slate-600">Pending</span>
                              )}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* MY INVESTMENTS TAB */}
        {activeTab === 'investments' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold font-serif text-slate-100">My Investment Positions</h1>
                <p className="text-xs text-slate-400 mt-1">
                  Authoritative record of computational hardware allocations and custody agreements.
                </p>
              </div>
              <button
                onClick={onOpenCheckout}
                className="px-4 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10"
              >
                + Explore Investments
              </button>
            </div>

            <div className="space-y-4">
              {activeInvestments.length === 0 ? (
                <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-10 text-center space-y-3">
                  <Coins className="w-12 h-12 text-slate-600 mx-auto" />
                  <h3 className="text-base font-semibold text-slate-200">No Active Allocations</h3>
                  <p className="text-xs text-slate-400 max-w-md mx-auto">
                    Start by selecting an investment plan (Starter, Growth, or Professional) and funding via PayFast or Bank Transfer.
                  </p>
                  <button
                    onClick={onOpenCheckout}
                    className="px-5 py-2.5 rounded-xl text-xs font-semibold text-black bg-amber-400"
                  >
                    Select an Investment Plan
                  </button>
                </div>
              ) : (
                activeInvestments.map((inv) => (
                  <div
                    key={inv.id}
                    className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-4">
                      <div>
                        <h3 className="text-lg font-bold text-amber-300 font-serif">
                          {inv.productName}
                        </h3>
                        <p className="text-xs text-slate-400">
                          Transaction Reference: <span className="font-mono text-slate-200">{inv.transactionReference}</span>
                        </p>
                      </div>
                      <span className="self-start sm:self-center text-xs font-bold px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                        Status: {inv.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                      <div>
                        <span className="text-slate-400 block mb-1">Capital Allocated</span>
                        <span className="text-xl font-mono font-bold text-slate-100">
                          R {inv.amountAllocated.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block mb-1">Allocation Timestamp</span>
                        <span className="text-slate-200">
                          {new Date(inv.createdAt).toLocaleString('en-ZA')}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block mb-1">Terms & Conditions</span>
                        <span className="text-slate-300 text-[11px] leading-tight block">
                          {inv.terms || 'Standard custody and hardware computational terms apply.'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TRANSACTIONS TAB */}
        {activeTab === 'transactions' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">Transaction History</h1>
              <p className="text-xs text-slate-400 mt-1">
                Auditable list of all payment events and gateway reconciliation statuses.
              </p>
            </div>

            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4 font-medium">Reference</th>
                      <th className="py-3 px-4 font-medium">Description</th>
                      <th className="py-3 px-4 font-medium">Amount (ZAR)</th>
                      <th className="py-3 px-4 font-medium">Payment Gateway</th>
                      <th className="py-3 px-4 font-medium">Status</th>
                      <th className="py-3 px-4 font-medium">Date</th>
                      <th className="py-3 px-4 font-medium text-right">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {transactions.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="py-8 text-center text-slate-500">
                          No transactions found.
                        </td>
                      </tr>
                    ) : (
                      transactions.map((tx) => (
                        <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="py-3 px-4 font-mono font-semibold text-slate-200">
                            {tx.reference}
                          </td>
                          <td className="py-3 px-4 text-slate-300">{tx.productName}</td>
                          <td className="py-3 px-4 font-mono font-medium text-slate-100">
                            R {tx.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-3 px-4 text-slate-400 uppercase text-[11px]">
                            {tx.paymentMethod === 'payfast' ? 'PayFast Online' : 'Manual EFT'}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                tx.status === 'SUCCESS'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                  : tx.status === 'PENDING'
                                  ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                                  : 'bg-red-500/10 text-red-400 border border-red-500/30'
                              }`}
                            >
                              {tx.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-400 text-[11px]">
                            {new Date(tx.createdAt).toLocaleString('en-ZA')}
                          </td>
                          <td className="py-3 px-4 text-right">
                            {tx.status === 'SUCCESS' ? (
                              <button
                                onClick={() => handleOpenReceipt(tx.reference)}
                                className="inline-flex items-center space-x-1 text-amber-400 hover:text-amber-300 font-medium"
                              >
                                <FileText className="w-3.5 h-3.5" />
                                <span>Receipt</span>
                              </button>
                            ) : (
                              <span className="text-[10px] text-slate-600">Pending</span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* PAYMENTS TAB */}
        {activeTab === 'payments' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">Payment Gateway Methods</h1>
              <p className="text-xs text-slate-400 mt-1">
                Authorized deposit and processing channels supported by Global Finance Crypto Mining.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* PayFast Card */}
              <div className="bg-slate-900/80 border border-amber-500/30 rounded-2xl p-6 space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                    <CreditCard className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-100">PayFast Online Gateway</h3>
                    <p className="text-xs text-emerald-400">Real-Time Instant Settlement</p>
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  PayFast is South Africa's premier digital payment provider, supporting Instant EFT (via Capitec, FNB, Nedbank, Standard Bank, Absa), Visa, Mastercard, and Masterpass.
                </p>
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-[11px] space-y-1.5 text-slate-400">
                  <div className="flex justify-between">
                    <span>Provider</span>
                    <span className="text-slate-200 font-medium">PayFast (Pty) Ltd</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Currencies</span>
                    <span className="text-slate-200 font-medium">ZAR (South African Rand)</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Security</span>
                    <span className="text-slate-200 font-medium">MD5 Signature & Server-Side ITN</span>
                  </div>
                </div>
                <button
                  onClick={onOpenCheckout}
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-black bg-amber-400 hover:bg-amber-300"
                >
                  Pay via PayFast
                </button>
              </div>

              {/* Bank Transfer Card */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
                    <History className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-100">Direct Electronic Bank Transfer</h3>
                    <p className="text-xs text-amber-300">Manual Administrator Reconciliation</p>
                  </div>
                </div>
                <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-xl text-xs text-amber-200 space-y-1">
                  <div className="font-bold flex items-center space-x-1.5 text-amber-300">
                    <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                    <span>BANKING APP ONLY REQUIREMENT</span>
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    This payment can <strong>ONLY be performed directly inside your official banking application</strong> (e.g. TymeBank / GoTymeBank app). Do NOT attempt payment at retail till points or cash deposit machines.
                  </p>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Direct EFT payments must be initiated using your <strong>unique pending transaction reference</strong> as the <strong>beneficiary transfer description</strong> for reconciliation by our compliance team.
                </p>
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 text-[11px] space-y-2 text-slate-300 font-mono">
                  <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                    <span className="text-slate-500 font-sans">Account Name:</span>
                    <span className="font-semibold text-slate-100">[BAHOLO CONSULTING]</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                    <span className="text-slate-500 font-sans">Bank:</span>
                    <span className="font-semibold text-slate-100">[TymeBank/GoTymeBank]</span>
                  </div>
                  <div className="flex justify-between border-b border-slate-800/80 pb-1.5">
                    <span className="text-slate-500 font-sans">Account Number:</span>
                    <span className="font-bold text-amber-400">[53002153808]</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-sans">Branch Code:</span>
                    <span className="font-semibold text-slate-100">[678910]</span>
                  </div>
                </div>
                <button
                  onClick={onOpenCheckout}
                  className="w-full py-2.5 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700"
                >
                  Initiate Bank Transfer Checkout
                </button>
              </div>
            </div>
          </div>
        )}

        {/* WITHDRAWALS TAB */}
        {activeTab === 'withdrawals' && (
          <div className="space-y-6">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">Funds & Withdrawals</h1>
              <p className="text-xs text-slate-400 mt-1">
                Audited withdrawal requests against unallocated cash balances.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Form */}
              <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                  <h3 className="font-semibold text-sm text-slate-100">Request Withdrawal</h3>
                  <div className="text-xs text-slate-400">
                    Available: <strong className="font-mono text-amber-300">R {(summary?.availableBalance || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}</strong>
                  </div>
                </div>

                <div className="bg-amber-500/5 border border-amber-500/20 p-3 rounded-xl text-[11px] text-slate-300 leading-relaxed">
                  <strong>Notice:</strong> Only unallocated cash balances in the financial ledger may be withdrawn. Capital allocated to active computational infrastructure plans cannot be withdrawn without formal contract closure review.
                </div>

                {withdrawMessage && (
                  <div
                    className={`p-3 rounded-xl text-xs flex items-center space-x-2 ${
                      withdrawMessage.type === 'success'
                        ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
                        : 'bg-red-500/10 border border-red-500/30 text-red-400'
                    }`}
                  >
                    {withdrawMessage.type === 'success' ? (
                      <CheckCircle2 className="w-4 h-4 shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 shrink-0" />
                    )}
                    <span>{withdrawMessage.text}</span>
                  </div>
                )}

                <form onSubmit={handleWithdrawalSubmit} className="space-y-4 text-xs">
                  <div>
                    <label className="block font-medium text-slate-300 mb-1">
                      Withdrawal Amount (ZAR)
                    </label>
                    <input
                      type="number"
                      step="any"
                      required
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(e.target.value)}
                      placeholder="e.g. 500"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 font-mono focus:outline-none focus:border-amber-500/60"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-medium text-slate-300 mb-1">Bank Name</label>
                      <input
                        type="text"
                        required
                        value={withdrawBank}
                        onChange={(e) => setWithdrawBank(e.target.value)}
                        placeholder="e.g. Standard Bank / FNB / Capitec"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500/60"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-slate-300 mb-1">Account Number</label>
                      <input
                        type="text"
                        required
                        value={withdrawAccount}
                        onChange={(e) => setWithdrawAccount(e.target.value)}
                        placeholder="Account number"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 font-mono focus:outline-none focus:border-amber-500/60"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-medium text-slate-300 mb-1">Account Holder Name</label>
                      <input
                        type="text"
                        required
                        value={withdrawHolder}
                        onChange={(e) => setWithdrawHolder(e.target.value)}
                        placeholder="Full account name"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500/60"
                      />
                    </div>
                    <div>
                      <label className="block font-medium text-slate-300 mb-1">Branch Code</label>
                      <input
                        type="text"
                        required
                        value={withdrawBranch}
                        onChange={(e) => setWithdrawBranch(e.target.value)}
                        placeholder="e.g. 250655"
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-100 font-mono focus:outline-none focus:border-amber-500/60"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={withdrawSubmitting || (summary?.availableBalance || 0) <= 0}
                    className="w-full py-3 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 disabled:opacity-50"
                  >
                    {withdrawSubmitting ? 'Submitting Request...' : 'Submit Withdrawal for Review'}
                  </button>
                </form>
              </div>

              {/* Status & Info Card */}
              <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
                <h4 className="font-semibold text-xs text-slate-200 uppercase tracking-wider">
                  Withdrawal Guidelines
                </h4>
                <ul className="text-xs text-slate-400 space-y-2.5">
                  <li className="flex items-start space-x-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>All payouts require administrative review to prevent unauthorized account tampering.</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Payouts are processed via domestic South African bank EFT.</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Bank account holder must match the registered customer identity.</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Withdrawal History Table */}
            <div className="space-y-4">
              <h3 className="text-base font-semibold text-slate-100">Withdrawal Requests</h3>
              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Amount</th>
                      <th className="py-3 px-4">Bank</th>
                      <th className="py-3 px-4">Account Number</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4">Requested Date</th>
                      <th className="py-3 px-4">Notes</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {withdrawals.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-slate-500">
                          No withdrawal requests found.
                        </td>
                      </tr>
                    ) : (
                      withdrawals.map((w) => (
                        <tr key={w.id}>
                          <td className="py-3 px-4 font-mono font-semibold text-slate-200">
                            R {w.amount.toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-slate-300">{w.bankName}</td>
                          <td className="py-3 px-4 font-mono text-slate-400">
                            •••• {w.accountNumber.slice(-4)}
                          </td>
                          <td className="py-3 px-4">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                w.status === 'COMPLETED'
                                  ? 'bg-emerald-500/10 text-emerald-400'
                                  : w.status === 'REJECTED'
                                  ? 'bg-red-500/10 text-red-400'
                                  : 'bg-amber-500/10 text-amber-300'
                              }`}
                            >
                              {w.status}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-400 text-[11px]">
                            {new Date(w.createdAt).toLocaleDateString()}
                          </td>
                          <td className="py-3 px-4 text-slate-500 text-[11px]">
                            {w.reviewNotes || 'Under standard review'}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* PROFILE TAB */}
        {activeTab === 'profile' && (
          <div className="space-y-6 max-w-2xl">
            <div>
              <h1 className="text-2xl font-bold font-serif text-slate-100">Customer Profile</h1>
              <p className="text-xs text-slate-400 mt-1">
                Your registered account details and verified identity context.
              </p>
            </div>

            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4 text-xs divide-y divide-slate-800/80">
              <div className="pb-3 flex justify-between items-center">
                <span className="text-slate-400">Full Name</span>
                <span className="font-semibold text-slate-100">{user?.firstName} {user?.lastName}</span>
              </div>
              <div className="py-3 flex justify-between items-center">
                <span className="text-slate-400">Email Address</span>
                <span className="font-mono text-slate-200">{user?.email}</span>
              </div>
              <div className="py-3 flex justify-between items-center">
                <span className="text-slate-400">Contact Number</span>
                <span className="text-slate-200">{user?.phone || 'Not provided'}</span>
              </div>
              <div className="py-3 flex justify-between items-center">
                <span className="text-slate-400">Country</span>
                <span className="text-slate-200">{user?.country || 'South Africa'}</span>
              </div>
              <div className="py-3 flex justify-between items-center">
                <span className="text-slate-400">Account Role</span>
                <span className="font-mono uppercase text-amber-400 font-semibold">{user?.role}</span>
              </div>
              <div className="pt-3 flex justify-between items-center">
                <span className="text-slate-400">Account Status</span>
                <span className="text-emerald-400 font-bold capitalize">{user?.status}</span>
              </div>
            </div>
          </div>
        )}

        {/* CUSTOMER FINANCIAL OVERVIEW TAB */}
        {activeTab === 'financial-overview' && (
          <CustomerFinancialOverview
            token={token}
            onOpenCheckout={onOpenCheckout}
          />
        )}

        {/* INVESTMENT PERFORMANCE DASHBOARD TAB */}
        {activeTab === 'investment-dashboard' && (
          <InvestmentPerformanceDashboard
            token={token}
            onOpenCheckout={onOpenCheckout}
            onViewReceipt={handleOpenReceipt}
          />
        )}

        {/* SECURITY & ACCOUNT PROTECTION CENTRE */}
        {activeTab === 'security' && (
          <SecurityCentre
            token={token}
            onNavigateSupportTicket={handleOpenTicketFromNotification}
          />
        )}

        {/* SUPPORT & COMPLAINTS TAB */}
        {activeTab === 'support' && (
          <CustomerSupportSection
            token={token}
            initialTicketId={selectedTicketId}
          />
        )}
      </main>
    </div>
  );
};
