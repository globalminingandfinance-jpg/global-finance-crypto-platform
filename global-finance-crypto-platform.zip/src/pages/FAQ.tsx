import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

export const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: '1. What is Global Finance Crypto Mining?',
      a: 'Global Finance Crypto Mining is a South African financial technology and digital infrastructure platform offering structured computational allocation plans with audited double-entry financial ledger accounting and secure PayFast payment gateway integration.',
    },
    {
      q: '2. How do I invest?',
      a: 'You can explore our three investment tiers (Starter min R500, Growth min R1,000, and Professional min R2,500). Select one of the permitted amounts (R500, R1,000, R2,500, or R5,000), provide your customer information, and fund your allocation via PayFast (Instant EFT/cards) or direct electronic bank transfer.',
    },
    {
      q: '3. How does PayFast work?',
      a: 'PayFast is South Africa’s leading regulated payment gateway. When checking out, our server generates a cryptographically signed payment request. You are redirected to PayFast’s secure checkout to complete payment via Instant EFT or Visa/Mastercard. PayFast then notifies our server via an Instant Transaction Notification (ITN) webhook.',
    },
    {
      q: '4. What happens after I make a payment?',
      a: 'Once your payment is independently verified by our backend through PayFast’s webhook or reconciled by an administrator for EFT transfers, your investment allocation is recorded in the financial ledger and an official transaction receipt is generated.',
    },
    {
      q: '5. How can I view my transactions?',
      a: 'You can view all your transactions, active investment positions, and balance histories by logging into your authenticated Client Portal and navigating to the "Transactions" or "Overview" tab.',
    },
    {
      q: '6. How do I contact support?',
      a: 'You can contact support directly through the "Contact" page or via the "Support" ticket form within your Client Portal. Inquiries are logged directly into our compliance and support queue.',
    },
    {
      q: '7. What verification may be required?',
      a: 'In accordance with South African regulatory guidelines, basic customer information (name, email, phone, and country) is verified during checkout. For larger corporate or high-tier allocations, standard FICA/KYC documentation may be requested.',
    },
    {
      q: '8. Are investments guaranteed?',
      a: 'No. Global Finance Crypto Mining does not advertise or promise guaranteed returns or risk-free profits. Digital asset computing and cryptocurrency markets involve financial and operational risks. Please review our Risk Disclosure notice.',
    },
    {
      q: '9. How can I make a bank transfer?',
      a: 'Select "Direct Bank Transfer" during checkout. The platform will generate your unique transaction reference (e.g. GF-20261014-XXXXXXXX) and display our official banking details: Account Name: [BAHOLO CONSULTING], Bank: [TymeBank/GoTymeBank], Account: [53002153808], Branch Code: [678910]. CRITICAL: This payment can ONLY be performed directly inside your banking mobile application. You must include your exact transaction reference in the transfer description/payment reference so our compliance team can verify and allocate your funds.',
    },
    {
      q: '10. What happens if my payment is pending?',
      a: 'If a payment shows as "PENDING", it means we are awaiting webhook confirmation from PayFast or statement verification for direct EFT. You can refresh your transaction status on the Payment Success page or inside your Client Dashboard.',
    },
    {
      q: '11. How can I obtain a receipt?',
      a: 'Official receipts are automatically generated for all confirmed (SUCCESS) transactions. You can view, print, or download your receipt directly from the Payment Success page or by clicking "Receipt" in your Client Portal transaction list.',
    },
    {
      q: '12. How do I request a withdrawal?',
      a: 'You can request a withdrawal from your available unallocated cash balance via the "Withdrawals" tab in your Client Portal. Provide your South African bank details. The request will be reviewed by an administrator and processed via domestic EFT.',
    },
    {
      q: '13. How do I protect my account?',
      a: 'Ensure you use a strong, unique password of at least 8 characters. Never share your credentials with anyone. Our platform uses Bcrypt password hashing, session expiration, and rate limiting to protect your account.',
    },
    {
      q: '14. How do I contact the administrator about an account issue?',
      a: 'You can submit a ticket through the Client Portal Support section or email our designated compliance team at the official contact address. Include your registered email and relevant transaction references.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16 space-y-12">
      <div className="text-center space-y-4">
        <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
          Knowledge Base
        </span>
        <h1 className="text-3xl sm:text-4xl font-serif font-bold text-slate-100">
          Frequently Asked Questions
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
          Find clear answers regarding payment verification, accounting rules, PayFast gateway procedures, and platform security.
        </p>
      </div>

      <div className="space-y-3">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden transition-colors"
            >
              <button
                type="button"
                onClick={() => setOpenIndex(isOpen ? null : idx)}
                className="w-full flex items-center justify-between p-5 text-left text-sm font-semibold text-slate-200 hover:text-amber-300 transition-colors"
              >
                <span>{faq.q}</span>
                <ChevronDown
                  className={`w-4 h-4 text-amber-400 shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs text-slate-400 leading-relaxed border-t border-slate-800/60">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
