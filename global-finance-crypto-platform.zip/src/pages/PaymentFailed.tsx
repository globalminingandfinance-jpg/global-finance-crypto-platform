import React from 'react';
import { XCircle, RefreshCw, ArrowLeft, HelpCircle } from 'lucide-react';

interface PaymentFailedProps {
  reference?: string;
  onRetry: () => void;
  onNavigateInvestments: () => void;
  onNavigateContact: () => void;
}

export const PaymentFailed: React.FC<PaymentFailedProps> = ({
  reference,
  onRetry,
  onNavigateInvestments,
  onNavigateContact,
}) => {
  return (
    <div className="min-h-[75vh] flex items-center justify-center p-4 bg-[#070b12]">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center justify-center mx-auto shadow-lg shadow-red-500/10">
          <XCircle className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-bold font-serif text-slate-100">Payment Unsuccessful</h1>
          <p className="text-sm text-slate-400">The payment could not be completed.</p>
        </div>

        {reference && (
          <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-xs text-slate-400">
            Transaction Reference: <span className="font-mono text-slate-200">{reference}</span>
          </div>
        )}

        <div className="text-xs text-slate-400 text-left bg-slate-950/60 border border-slate-800/80 p-4 rounded-xl space-y-2">
          <div className="font-semibold text-slate-300">Common reasons include:</div>
          <ul className="list-disc pl-5 space-y-1">
            <li>The checkout process was cancelled at the PayFast gateway.</li>
            <li>Insufficient funds or 3D Secure verification timeout.</li>
            <li>Bank card limit or international authorization block.</li>
          </ul>
        </div>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={onRetry}
            className="w-full sm:w-auto flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 transition-all shadow-md shadow-amber-500/10"
          >
            <RefreshCw className="w-4 h-4" />
            <span>Try Again</span>
          </button>
          <button
            onClick={onNavigateInvestments}
            className="w-full sm:w-auto flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Investments</span>
          </button>
          <button
            onClick={onNavigateContact}
            className="w-full sm:w-auto flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-medium text-slate-400 hover:text-white transition-colors"
          >
            <HelpCircle className="w-4 h-4" />
            <span>Contact Support</span>
          </button>
        </div>
      </div>
    </div>
  );
};
