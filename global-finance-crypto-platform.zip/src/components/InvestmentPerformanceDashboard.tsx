import React, { useState, useEffect, useMemo } from 'react';
import {
  TrendingUp,
  Coins,
  Clock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Calendar,
  FileText,
  ArrowUpRight,
  ArrowDownRight,
  RefreshCw,
  SlidersHorizontal,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Info,
  DollarSign,
  Layers,
  Sparkles,
} from 'lucide-react';
import {
  InvestmentPerformanceDashboardData,
  InvestmentPerformanceItem,
  InvestmentDailyRecord,
  InvestmentChartPoint,
} from '../types/index.js';

interface Props {
  token: string | null;
  onOpenCheckout?: () => void;
  onViewReceipt?: (reference: string) => void;
}

export const InvestmentPerformanceDashboard: React.FC<Props> = ({
  token,
  onOpenCheckout,
  onViewReceipt,
}) => {
  const [data, setData] = useState<InvestmentPerformanceDashboardData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Selected individual investment for drill-down view (or null for Portfolio aggregate)
  const [selectedInvestmentId, setSelectedInvestmentId] = useState<string | null>(null);

  // Timeframe filter for chart: 'all' | '30d' | '7d'
  const [chartTimeframe, setChartTimeframe] = useState<'all' | '30d' | '7d'>('all');

  // Chart tooltip hover state
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  // Paginated history table state
  const [historyPage, setHistoryPage] = useState(1);
  const historyPerPage = 8;

  // Live countdown state
  const [countdownRemaining, setCountdownRemaining] = useState<number | null>(null);

  // Fetch dashboard data from server
  const fetchDashboardData = async (isManualRefresh = false) => {
    if (!token) return;
    if (isManualRefresh) setIsRefreshing(true);
    else setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/investments/dashboard', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) {
        throw new Error('Failed to load authoritative investment performance data.');
      }

      const json: InvestmentPerformanceDashboardData = await res.json();
      setData(json);

      if (json.metrics.nextMaturityRemainingSeconds !== null) {
        setCountdownRemaining(json.metrics.nextMaturityRemainingSeconds);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An unexpected network error occurred.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [token]);

  // Live countdown ticker
  useEffect(() => {
    if (countdownRemaining === null || countdownRemaining <= 0) return;

    const interval = setInterval(() => {
      setCountdownRemaining((prev) => {
        if (prev === null || prev <= 1) {
          // Re-validate maturity on server when countdown reaches 0
          fetchDashboardData(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [countdownRemaining]);

  // Active selected investment detail
  const selectedInvestment = useMemo(() => {
    if (!data || !selectedInvestmentId) return null;
    return data.investments.find((i) => i.id === selectedInvestmentId) || null;
  }, [data, selectedInvestmentId]);

  // Active or filtered chart data
  const filteredChartData = useMemo(() => {
    if (!data || !data.chartData || data.chartData.length === 0) return [];

    let points = [...data.chartData];

    if (chartTimeframe === '7d') {
      points = points.slice(-7);
    } else if (chartTimeframe === '30d') {
      points = points.slice(-30);
    }

    return points;
  }, [data, chartTimeframe]);

  // Flattened daily history for history table
  const allHistoryRecords = useMemo(() => {
    if (!data) return [];
    // If an individual investment is selected, show records for it, else all
    const relevantInvestments = selectedInvestment
      ? [selectedInvestment]
      : data.investments;

    // Build synthesized milestone history rows from authoritative investment data
    const records: Array<{
      id: string;
      date: string;
      investmentRef: string;
      planName: string;
      openingValue: number;
      closingValue: number;
      dailyChange: number;
      dailyPercentage: number;
      cumulativeChange: number;
      projectedValue: number;
      classification: 'ACTUAL' | 'PROJECTED' | 'SETTLED' | 'ADJUSTED';
      dataSource: string;
      notes: string;
    }> = [];

    for (const inv of relevantInvestments) {
      // Day 1: Capital verified & allocated
      records.push({
        id: `dr_${inv.id}_start`,
        date: inv.activatedAt,
        investmentRef: inv.transactionReference,
        planName: inv.planName,
        openingValue: inv.investedCapital,
        closingValue: inv.investedCapital,
        dailyChange: 0,
        dailyPercentage: 0,
        cumulativeChange: 0,
        projectedValue: inv.investedCapital,
        classification: 'ACTUAL',
        dataSource: 'VERIFIED_PAYMENT_LEDGER',
        notes: `Capital allocated via ${inv.paymentMethod.toUpperCase()} (Ref: ${inv.transactionReference})`,
      });

      // Scheduled Contractual Maturity Milestone
      if (inv.status === 'SETTLED') {
        records.push({
          id: `dr_${inv.id}_settled`,
          date: inv.settlementDate || inv.maturityDate,
          investmentRef: inv.transactionReference,
          planName: inv.planName,
          openingValue: inv.currentValuation,
          closingValue: inv.settlementAmount || inv.projectedTotal,
          dailyChange: inv.realizedPnL,
          dailyPercentage: Math.round(inv.returnRate * 100),
          cumulativeChange: inv.realizedPnL,
          projectedValue: inv.projectedTotal,
          classification: 'SETTLED',
          dataSource: 'AUDITED_ADMIN_SETTLEMENT',
          notes: inv.settlementNotes || 'Authoritative maturity settlement credited to client cash balance.',
        });
      } else {
        records.push({
          id: `dr_${inv.id}_proj`,
          date: inv.maturityDate,
          investmentRef: inv.transactionReference,
          planName: inv.planName,
          openingValue: inv.currentValuation,
          closingValue: inv.projectedTotal,
          dailyChange: inv.projectedProfit,
          dailyPercentage: Math.round(inv.returnRate * 100),
          cumulativeChange: inv.projectedProfit,
          projectedValue: inv.projectedTotal,
          classification: 'PROJECTED',
          dataSource: `PLAN_TERMS_V${inv.termVersion}_CONTRACT`,
          notes: `Projected maturity target at ${Math.round(inv.returnRate * 100)}% return over ${inv.durationDays} days.`,
        });
      }
    }

    return records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [data, selectedInvestment]);

  // Paginated records
  const paginatedHistory = useMemo(() => {
    const start = (historyPage - 1) * historyPerPage;
    return allHistoryRecords.slice(start, start + historyPerPage);
  }, [allHistoryRecords, historyPage]);

  const totalHistoryPages = Math.ceil(allHistoryRecords.length / historyPerPage) || 1;

  // Format countdown string
  const formatCountdown = (seconds: number | null) => {
    if (seconds === null) return 'Unavailable';
    if (seconds <= 0) return 'Maturity Reached (Awaiting Settlement)';

    const days = Math.floor(seconds / (24 * 3600));
    const hours = Math.floor((seconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    parts.push(`${hours.toString().padStart(2, '0')}h`);
    parts.push(`${minutes.toString().padStart(2, '0')}m`);
    parts.push(`${secs.toString().padStart(2, '0')}s`);

    return parts.join(' : ');
  };

  // Helper currency formatter
  const formatZAR = (val: number | undefined | null) => {
    const num = Number(val || 0);
    return `R ${num.toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  if (isLoading) {
    return (
      <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center space-y-4">
        <RefreshCw className="w-8 h-8 text-amber-400 animate-spin mx-auto" />
        <h3 className="text-base font-semibold text-slate-100">Synchronizing Investment Ledger</h3>
        <p className="text-xs text-slate-400 max-w-sm mx-auto">
          Retrieving authoritative database records, verified payment allocations, and contractual maturity schedules...
        </p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-red-500/10 border border-red-500/30 rounded-3xl p-8 text-center space-y-3">
        <AlertCircle className="w-8 h-8 text-red-400 mx-auto" />
        <h3 className="text-base font-bold text-red-300">Unable to Load Dashboard</h3>
        <p className="text-xs text-red-400/90">{error || 'Failed to connect to backend service.'}</p>
        <button
          onClick={() => fetchDashboardData()}
          className="px-4 py-2 rounded-xl text-xs font-bold text-black bg-amber-400 hover:bg-amber-300"
        >
          Try Again
        </button>
      </div>
    );
  }

  const { zeroState, metrics, chartData, investments, pendingPurchases, disclosures } = data;

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* 1. TOP HEADER & REFRESH BAR */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-[10px] uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
              Verified Accounting Ledger
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-[11px] text-slate-400">
              Updated: {new Date(data.serverTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-100 mt-1">
            Investment Performance Dashboard
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl mt-0.5">
            Authoritative real-time tracking of computational capital, verified valuations, contractual maturity milestones, and audited historical payouts.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => fetchDashboardData(true)}
            disabled={isRefreshing}
            className="flex items-center space-x-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : 'text-slate-400'}`} />
            <span>{isRefreshing ? 'Refreshing...' : 'Sync Ledger'}</span>
          </button>

          {onOpenCheckout && (
            <button
              onClick={onOpenCheckout}
              className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10"
            >
              <Coins className="w-3.5 h-3.5" />
              <span>Explore Plans</span>
            </button>
          )}
        </div>
      </div>

      {/* 2. GENUINE ZERO STATE (When user has 0 active & 0 historical investments) */}
      {zeroState ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-8 sm:p-12 text-center space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center mx-auto text-amber-400">
            <Coins className="w-8 h-8" />
          </div>

          <div className="space-y-2 max-w-lg mx-auto">
            <h2 className="text-xl font-bold font-serif text-slate-100">
              No Active or Historical Investments
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              You don&apos;t have any active investments yet. Once an eligible investment purchase has been verified via PayFast or Bank Transfer, your investment performance will appear here.
            </p>
          </div>

          {/* Zero State Figures Summary */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto pt-2">
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl text-left">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Total Invested</span>
              <span className="text-base font-mono font-bold text-slate-300">R 0.00</span>
            </div>
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl text-left">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Current Valuation</span>
              <span className="text-base font-mono font-bold text-slate-300">R 0.00</span>
            </div>
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl text-left">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Realized Profit</span>
              <span className="text-base font-mono font-bold text-slate-300">R 0.00</span>
            </div>
            <div className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl text-left">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Projected Returns</span>
              <span className="text-base font-mono font-bold text-slate-300">R 0.00</span>
            </div>
          </div>

          {/* Flatline Zero Graph Illustration */}
          <div className="max-w-xl mx-auto bg-slate-950/90 border border-slate-800/80 rounded-2xl p-5 space-y-2">
            <div className="flex justify-between items-center text-[11px] text-slate-500">
              <span>Performance Baseline (Flat Zero)</span>
              <span>R 0.00</span>
            </div>
            <div className="h-14 w-full flex items-center justify-center relative">
              <div className="w-full h-[1px] bg-slate-800" />
              <div className="w-full h-[2px] bg-amber-500/40 absolute top-1/2 -translate-y-1/2" />
            </div>
            <p className="text-[10px] text-slate-500 italic">
              Interactive charts are unlocked as soon as your initial capital allocation is confirmed.
            </p>
          </div>

          <div className="pt-2">
            {onOpenCheckout ? (
              <button
                onClick={onOpenCheckout}
                className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl text-sm font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-lg shadow-amber-500/20 transition-all"
              >
                <Coins className="w-4 h-4" />
                <span>Explore Investment Plans</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
            ) : null}
          </div>
        </div>
      ) : (
        <>
          {/* 3. PERFORMANCE SUMMARY CARDS (6 CARDS AS PER SECTION 6) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* CARD A: Total Invested Capital */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Total Invested Capital</span>
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                  <Coins className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="text-2xl font-serif font-bold text-slate-100 font-mono">
                  {formatZAR(metrics.totalInvestedCapital)}
                </div>
                <div className="flex items-center space-x-1.5 mt-1 text-[11px] text-slate-400">
                  <span className="font-semibold text-slate-300">
                    {metrics.activeInvestmentsCount} active
                  </span>
                  <span>•</span>
                  <span>{metrics.maturedInvestmentsCount} historical/matured</span>
                </div>
              </div>
              <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2 flex items-center space-x-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                <span>Original principal recorded in immutable financial ledger.</span>
              </div>
            </div>

            {/* CARD B: Current Investment Value */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Current Investment Value</span>
                <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="text-2xl font-serif font-bold text-cyan-300 font-mono">
                  {formatZAR(metrics.currentInvestmentValue)}
                </div>
                <div className="mt-1 text-[11px] text-slate-400">
                  Latest recorded valuation of active capital.
                </div>
              </div>
              <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2 flex items-center space-x-1">
                <Info className="w-3 h-3 text-cyan-400 shrink-0" />
                <span>Distinguished from future maturity payout.</span>
              </div>
            </div>

            {/* CARD C: Projected Returns */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Projected Returns</span>
                <span className="text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/20">
                  Estimated
                </span>
              </div>
              <div>
                <div className="text-2xl font-serif font-bold text-amber-300 font-mono">
                  {metrics.projectedReturns > 0 ? formatZAR(metrics.projectedReturns) : 'R 0.00'}
                </div>
                <div className="mt-1 text-[11px] text-amber-400/90 flex items-center space-x-1">
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>Projected return — not yet realized</span>
                </div>
              </div>
              <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
                Calculated strictly from applicable contractual plan terms.
              </div>
            </div>

            {/* CARD D: Actual Realized Profit or Loss */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Realized Profit / Loss</span>
                <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                  <DollarSign className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="text-2xl font-serif font-bold text-emerald-400 font-mono">
                  {formatZAR(metrics.actualRealizedPnL)}
                </div>
                <div className="mt-1 text-[11px] text-slate-400">
                  Completed maturity settlements credited to ledger.
                </div>
              </div>
              <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2 flex items-center space-x-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                <span>Excludes unverified projections and pending settlements.</span>
              </div>
            </div>

            {/* CARD E: Daily Performance */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Daily Recorded Change</span>
                <div className="p-2 rounded-xl bg-slate-800 text-slate-300">
                  <Clock className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="text-2xl font-serif font-bold text-slate-200 font-mono flex items-center space-x-2">
                  <span>{formatZAR(metrics.dailyRecordedChange)}</span>
                  {metrics.dailyRecordedPercentage > 0 && (
                    <span className="text-xs text-emerald-400 font-sans font-bold flex items-center">
                      <ArrowUpRight className="w-3.5 h-3.5" />+{metrics.dailyRecordedPercentage}%
                    </span>
                  )}
                </div>
                <div className="mt-1 text-[11px] text-slate-400">
                  {metrics.dailyRecordedChange === 0
                    ? 'No recorded variance today (Contractual fixed-term)'
                    : 'Actual recorded ledger adjustments'}
                </div>
              </div>
              <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
                Based strictly on audited historical entries.
              </div>
            </div>

            {/* CARD F: Active Investments & Maturity Countdown */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-slate-400">Maturity Countdown</span>
                <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400">
                  <Calendar className="w-4 h-4" />
                </div>
              </div>
              <div>
                <div className="text-lg font-mono font-bold text-amber-300 truncate">
                  {formatCountdown(countdownRemaining)}
                </div>
                <div className="mt-1 text-[11px] text-slate-400">
                  {metrics.nextMaturityDate ? (
                    <>Target date: {new Date(metrics.nextMaturityDate).toLocaleDateString()}</>
                  ) : (
                    <>No active countdown schedule</>
                  )}
                </div>
              </div>
              <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
                Server-authoritative timestamp source of truth.
              </div>
            </div>
          </div>

          {/* 4. PENDING PURCHASES SEPARATE SECTION (Per Section 3 & 4) */}
          {pendingPurchases.length > 0 && (
            <div className="bg-amber-500/5 border border-amber-500/20 rounded-2xl p-5 space-y-3">
              <div className="flex items-center space-x-2 text-amber-300 font-semibold text-xs">
                <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>Pending Purchases & Awaiting Verification ({pendingPurchases.length})</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                The following purchase requests are awaiting banking or PayFast verification. Pending payments do not generate active performance or growth until server-side payment confirmation is finalized.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-1">
                {pendingPurchases.map((p) => (
                  <div
                    key={p.id}
                    className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl space-y-1.5 text-xs"
                  >
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-slate-200">{p.productName}</span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                        PENDING
                      </span>
                    </div>
                    <div className="text-amber-300 font-mono font-semibold">{formatZAR(p.amount)}</div>
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>Method: {p.paymentMethod === 'payfast' ? 'PayFast' : 'Bank Transfer'}</span>
                      <span className="font-mono">{p.reference}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. INTERACTIVE FINANCIAL CHART SECTION (Per Section 7) */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold font-serif text-slate-100 flex items-center space-x-2">
                  <TrendingUp className="w-4 h-4 text-amber-400" />
                  <span>
                    {selectedInvestment
                      ? `${selectedInvestment.planName} Valuation Trajectory`
                      : 'Portfolio Valuation & Performance Trajectory'}
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Distinguishing actual recorded valuations (solid line) from projected contract milestones (dashed line).
                </p>
              </div>

              {/* Chart Timeframe Controls */}
              <div className="flex items-center space-x-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto text-xs">
                {(['7d', '30d', 'all'] as const).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setChartTimeframe(tf)}
                    className={`px-3 py-1 rounded-lg font-medium transition-colors ${
                      chartTimeframe === tf
                        ? 'bg-amber-400 text-black font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {tf === '7d' ? '7 Days' : tf === '30d' ? '30 Days' : 'Full Term'}
                  </button>
                ))}
              </div>
            </div>

            {/* Chart Legend */}
            <div className="flex flex-wrap items-center gap-4 text-xs pt-1">
              <div className="flex items-center space-x-2">
                <div className="w-3.5 h-0.5 bg-amber-400" />
                <span className="text-slate-300">Actual Recorded Valuation</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3.5 h-0.5 border-t-2 border-dashed border-cyan-400" />
                <span className="text-slate-300">Projected Milestone Target (Unrealized)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3.5 h-0.5 border-t border-dotted border-slate-500" />
                <span className="text-slate-400">Principal Baseline Reference</span>
              </div>
            </div>

            {/* Custom Responsive High-Precision SVG Chart */}
            <div className="relative w-full h-72 sm:h-80 bg-slate-950/60 rounded-2xl border border-slate-800/80 p-4 select-none">
              {filteredChartData.length === 0 ? (
                <div className="h-full flex items-center justify-center text-xs text-slate-500">
                  No historical performance data recorded for this timeframe.
                </div>
              ) : (
                (() => {
                  const points = filteredChartData;
                  const maxVal = Math.max(
                    ...points.map((p) => Math.max(p.actualValue || 0, p.projectedValue || 0, p.principalBaseline)),
                    100
                  );
                  const minVal = 0;
                  const range = maxVal - minVal || 1;

                  const width = 800;
                  const height = 240;
                  const padding = { top: 20, right: 30, bottom: 30, left: 60 };
                  const chartW = width - padding.left - padding.right;
                  const chartH = height - padding.top - padding.bottom;

                  const getX = (i: number) => padding.left + (i / Math.max(1, points.length - 1)) * chartW;
                  const getY = (val: number) => padding.top + chartH - ((val - minVal) / range) * chartH;

                  // Baseline principal line
                  const baselineY = getY(points[0].principalBaseline);

                  // Actual points path (up to last actual)
                  const actualPoints = points
                    .map((p, i) => ({ x: getX(i), y: p.actualValue !== null ? getY(p.actualValue) : null }))
                    .filter((pt): pt is { x: number; y: number } => pt.y !== null);

                  const actualPath = actualPoints.length > 0
                    ? `M ${actualPoints.map((pt) => `${pt.x},${pt.y}`).join(' L ')}`
                    : '';

                  // Projected points path
                  const projPoints = points.map((p, i) => ({
                    x: getX(i),
                    y: getY(p.projectedValue !== null ? p.projectedValue : p.principalBaseline),
                  }));

                  const projPath = `M ${projPoints.map((pt) => `${pt.x},${pt.y}`).join(' L ')}`;

                  // Hover point coordinates
                  const activeHoverPoint = hoverIndex !== null && points[hoverIndex] ? points[hoverIndex] : null;
                  const hoverX = hoverIndex !== null ? getX(hoverIndex) : 0;

                  return (
                    <div className="w-full h-full relative">
                      <svg
                        viewBox={`0 0 ${width} ${height}`}
                        className="w-full h-full overflow-visible"
                        preserveAspectRatio="none"
                        onMouseLeave={() => setHoverIndex(null)}
                        onMouseMove={(e) => {
                          const rect = e.currentTarget.getBoundingClientRect();
                          const mouseX = e.clientX - rect.left;
                          const ratio = Math.max(0, Math.min(1, (mouseX - (padding.left / width) * rect.width) / ((chartW / width) * rect.width)));
                          const index = Math.round(ratio * (points.length - 1));
                          setHoverIndex(index);
                        }}
                      >
                        <defs>
                          <linearGradient id="actualGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.25" />
                            <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.0" />
                          </linearGradient>
                        </defs>

                        {/* Y-Axis Gridlines */}
                        {[0, 0.25, 0.5, 0.75, 1].map((pct) => {
                          const val = minVal + pct * range;
                          const y = getY(val);
                          return (
                            <g key={pct}>
                              <line
                                x1={padding.left}
                                y1={y}
                                x2={width - padding.right}
                                y2={y}
                                stroke="#1e293b"
                                strokeDasharray="3 3"
                              />
                              <text
                                x={padding.left - 8}
                                y={y + 4}
                                fill="#64748b"
                                fontSize="9"
                                textAnchor="end"
                                fontFamily="monospace"
                              >
                                R {Math.round(val).toLocaleString()}
                              </text>
                            </g>
                          );
                        })}

                        {/* Principal Baseline Line */}
                        <line
                          x1={padding.left}
                          y1={baselineY}
                          x2={width - padding.right}
                          y2={baselineY}
                          stroke="#64748b"
                          strokeDasharray="2 4"
                          strokeWidth="1.5"
                        />

                        {/* Projected Curve (Dashed Cyan/Gold) */}
                        <path
                          d={projPath}
                          fill="none"
                          stroke="#22d3ee"
                          strokeWidth="2"
                          strokeDasharray="5 5"
                        />

                        {/* Actual Curve (Solid Amber) */}
                        {actualPath && (
                          <path
                            d={actualPath}
                            fill="none"
                            stroke="#f59e0b"
                            strokeWidth="2.5"
                          />
                        )}

                        {/* Actual Area Fill */}
                        {actualPoints.length > 1 && (
                          <path
                            d={`${actualPath} L ${actualPoints[actualPoints.length - 1].x},${getY(0)} L ${actualPoints[0].x},${getY(0)} Z`}
                            fill="url(#actualGradient)"
                          />
                        )}

                        {/* Hover Crosshair */}
                        {hoverIndex !== null && (
                          <g>
                            <line
                              x1={hoverX}
                              y1={padding.top}
                              x2={hoverX}
                              y2={height - padding.bottom}
                              stroke="#e2e8f0"
                              strokeDasharray="2 2"
                              strokeWidth="1"
                            />
                            {activeHoverPoint?.actualValue !== null && (
                              <circle
                                cx={hoverX}
                                cy={getY(activeHoverPoint!.actualValue!)}
                                r="5"
                                fill="#f59e0b"
                                stroke="#070b12"
                                strokeWidth="2"
                              />
                            )}
                            {activeHoverPoint?.isProjectedOnly && activeHoverPoint.projectedValue !== null && (
                              <circle
                                cx={hoverX}
                                cy={getY(activeHoverPoint.projectedValue)}
                                r="4"
                                fill="#22d3ee"
                                stroke="#070b12"
                                strokeWidth="2"
                              />
                            )}
                          </g>
                        )}

                        {/* X-Axis Date Labels */}
                        {points.map((p, i) => {
                          if (points.length > 10 && i % Math.ceil(points.length / 6) !== 0 && i !== points.length - 1) {
                            return null;
                          }
                          return (
                            <text
                              key={p.date + i}
                              x={getX(i)}
                              y={height - 10}
                              fill="#64748b"
                              fontSize="9"
                              textAnchor="middle"
                            >
                              {p.label || p.date.slice(5)}
                            </text>
                          );
                        })}
                      </svg>

                      {/* Tooltip Popup on Hover */}
                      {hoverIndex !== null && activeHoverPoint && (
                        <div
                          style={{
                            left: `${Math.max(10, Math.min(85, (hoverX / width) * 100))}%`,
                            top: '15px',
                          }}
                          className="absolute z-20 pointer-events-none -translate-x-1/2 bg-slate-900 border border-slate-700/80 rounded-xl p-3 shadow-xl space-y-1 text-xs min-w-[200px]"
                        >
                          <div className="text-[11px] font-semibold text-slate-300 border-b border-slate-800 pb-1">
                            {new Date(activeHoverPoint.timestamp).toLocaleDateString('en-ZA', {
                              weekday: 'short',
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </div>
                          {activeHoverPoint.actualValue !== null ? (
                            <div className="flex justify-between items-center text-amber-300">
                              <span>Recorded Valuation:</span>
                              <span className="font-mono font-bold">{formatZAR(activeHoverPoint.actualValue)}</span>
                            </div>
                          ) : (
                            <div className="flex justify-between items-center text-slate-500 italic text-[11px]">
                              <span>Actual Recorded:</span>
                              <span>Not yet reached</span>
                            </div>
                          )}
                          <div className="flex justify-between items-center text-cyan-300">
                            <span>Projected Target:</span>
                            <span className="font-mono font-bold">{formatZAR(activeHoverPoint.projectedValue)}</span>
                          </div>
                          <div className="flex justify-between items-center text-slate-400 text-[10px]">
                            <span>Initial Principal:</span>
                            <span className="font-mono">{formatZAR(activeHoverPoint.principalBaseline)}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })()
              )}
            </div>

            <p className="text-[11px] text-slate-500 italic text-center">
              * The solid line depicts audited capital and recorded valuations. The dashed line visualizes the contractual target trajectory through scheduled maturity.
            </p>
          </div>

          {/* 6. INDIVIDUAL INVESTMENT SELECTOR & DRILL-DOWN (Per Section 8) */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-bold font-serif text-slate-100">
                  Individual Investment Positions ({investments.length})
                </h3>
                <p className="text-xs text-slate-400">
                  Select an individual position to inspect isolated charts, contract parameters, and countdown timers.
                </p>
              </div>

              {selectedInvestmentId && (
                <button
                  onClick={() => setSelectedInvestmentId(null)}
                  className="self-start sm:self-auto text-xs text-amber-400 hover:text-amber-300 font-semibold"
                >
                  ← Show Combined Portfolio View
                </button>
              )}
            </div>

            {/* Investment Position Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {investments.map((inv) => {
                const isSelected = selectedInvestmentId === inv.id;
                return (
                  <div
                    key={inv.id}
                    onClick={() => setSelectedInvestmentId(isSelected ? null : inv.id)}
                    className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/10 border-amber-500 shadow-md shadow-amber-500/10 ring-1 ring-amber-500'
                        : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center space-x-2">
                          <h4 className="font-bold text-sm text-slate-100 font-serif">{inv.planName}</h4>
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                            v{inv.termVersion}
                          </span>
                        </div>
                        <span className="text-[11px] font-mono text-slate-400">Ref: {inv.transactionReference}</span>
                      </div>

                      <span
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                          inv.status === 'ACTIVE'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : inv.status === 'MATURED'
                            ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                            : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                        }`}
                      >
                        {inv.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3 pt-3 mt-3 border-t border-slate-800/80 text-xs">
                      <div>
                        <span className="text-slate-500 block text-[10px]">Invested Capital</span>
                        <span className="font-mono font-bold text-slate-200">{formatZAR(inv.investedCapital)}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Contractual Return</span>
                        <span className="font-mono font-bold text-amber-400">
                          {Math.round(inv.returnRate * 100)}% ({inv.durationDays} days)
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Projected Profit</span>
                        <span className="font-mono font-bold text-emerald-400">{formatZAR(inv.projectedProfit)}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[10px]">Projected Payout</span>
                        <span className="font-mono font-bold text-cyan-300">{formatZAR(inv.projectedTotal)}</span>
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                      <span>Matures: {new Date(inv.maturityDate).toLocaleDateString()}</span>
                      {onViewReceipt && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onViewReceipt(inv.transactionReference);
                          }}
                          className="text-amber-400 hover:text-amber-300 font-medium inline-flex items-center space-x-1"
                        >
                          <FileText className="w-3 h-3" />
                          <span>Receipt</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 7. PAGINATED DAILY PERFORMANCE HISTORY TABLE (Per Section 9) */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-bold font-serif text-slate-100 flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>
                    {selectedInvestment
                      ? `${selectedInvestment.planName} History Ledger`
                      : 'Audited Performance & Milestone Ledger'}
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  Immutable record entries linked to payment verification, scheduled milestones, and actual accounting receipts.
                </p>
              </div>

              <span className="text-[11px] text-slate-400 font-mono">
                Showing {paginatedHistory.length} of {allHistoryRecords.length} records
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-3.5 font-medium">Date & Time</th>
                    <th className="py-3 px-3.5 font-medium">Investment Reference</th>
                    <th className="py-3 px-3.5 font-medium">Plan</th>
                    <th className="py-3 px-3.5 font-medium">Opening (ZAR)</th>
                    <th className="py-3 px-3.5 font-medium">Closing (ZAR)</th>
                    <th className="py-3 px-3.5 font-medium">Change</th>
                    <th className="py-3 px-3.5 font-medium">Classification</th>
                    <th className="py-3 px-3.5 font-medium">Source / Basis</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {paginatedHistory.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500">
                        No performance records recorded yet.
                      </td>
                    </tr>
                  ) : (
                    paginatedHistory.map((rec) => (
                      <tr key={rec.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-3 px-3.5 text-slate-300 font-mono text-[11px]">
                          {new Date(rec.date).toLocaleDateString()}{' '}
                          <span className="text-slate-500">{new Date(rec.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </td>
                        <td className="py-3 px-3.5 font-mono text-slate-200 text-[11px]">
                          {rec.investmentRef}
                        </td>
                        <td className="py-3 px-3.5 text-slate-300 font-medium">{rec.planName}</td>
                        <td className="py-3 px-3.5 font-mono text-slate-400">{formatZAR(rec.openingValue)}</td>
                        <td className="py-3 px-3.5 font-mono font-semibold text-slate-200">{formatZAR(rec.closingValue)}</td>
                        <td className="py-3 px-3.5 font-mono font-bold">
                          {rec.dailyChange > 0 ? (
                            <span className="text-emerald-400">+{formatZAR(rec.dailyChange)}</span>
                          ) : rec.dailyChange < 0 ? (
                            <span className="text-red-400">{formatZAR(rec.dailyChange)}</span>
                          ) : (
                            <span className="text-slate-500">R 0.00</span>
                          )}
                        </td>
                        <td className="py-3 px-3.5">
                          <span
                            className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                              rec.classification === 'ACTUAL'
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                                : rec.classification === 'SETTLED'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                : rec.classification === 'PROJECTED'
                                ? 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/30'
                                : 'bg-purple-500/10 text-purple-300 border border-purple-500/30'
                            }`}
                          >
                            {rec.classification}
                          </span>
                        </td>
                        <td className="py-3 px-3.5 text-[11px] text-slate-400 font-mono">
                          {rec.dataSource}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            {totalHistoryPages > 1 && (
              <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                <span className="text-xs text-slate-500">
                  Page {historyPage} of {totalHistoryPages}
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setHistoryPage((p) => Math.max(1, p - 1))}
                    disabled={historyPage === 1}
                    className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-white disabled:opacity-40"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setHistoryPage((p) => Math.min(totalHistoryPages, p + 1))}
                    disabled={historyPage === totalHistoryPages}
                    className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-white disabled:opacity-40"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </>
      )}

      {/* 8. REGULATORY & CONTRACTUAL FINANCIAL DISCLOSURES (Per Section 18) */}
      <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-5 space-y-3 text-xs text-slate-400 leading-relaxed">
        <div className="flex items-center space-x-2 text-slate-300 font-semibold text-xs">
          <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
          <span>Statutory Disclosures & Contractual Assumptions</span>
        </div>
        <p>
          <strong className="text-slate-300">Projected Returns Disclosure:</strong> {disclosures.projectionNotice}
        </p>
        <p>
          <strong className="text-slate-300">Capital Custody & Security:</strong> {disclosures.custodyNotice}
        </p>
        <p>
          <strong className="text-slate-300">Operational Notice:</strong> {disclosures.regulatoryNotice}
        </p>
      </div>
    </div>
  );
};
