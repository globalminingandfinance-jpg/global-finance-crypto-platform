import React, { useState, useEffect } from 'react';
import { Lock, CheckCircle2, AlertCircle, RefreshCw, X, Eye, EyeOff, ShieldCheck } from 'lucide-react';

interface ResetPasswordModalProps {
  token: string;
  onClose: () => void;
  onSuccess: (targetRole?: 'admin' | 'client') => void;
}

export const ResetPasswordModal: React.FC<ResetPasswordModalProps> = ({
  token,
  onClose,
  onSuccess,
}) => {
  const [isValidating, setIsValidating] = useState(true);
  const [isTokenValid, setIsTokenValid] = useState(false);
  const [userRole, setUserRole] = useState<'admin' | 'client'>('client');
  const [tokenError, setTokenError] = useState<string | null>(null);

  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Validate token on mount
  useEffect(() => {
    let isMounted = true;
    const verifyToken = async () => {
      try {
        const res = await fetch(`/api/auth/verify-reset-token?token=${encodeURIComponent(token)}`);
        const data = await res.json();
        if (isMounted) {
          if (res.ok && data.valid) {
            setIsTokenValid(true);
            if (data.role === 'admin') {
              setUserRole('admin');
            }
          } else {
            setIsTokenValid(false);
            setTokenError(data.error || 'Password reset link is invalid or expired.');
          }
        }
      } catch {
        if (isMounted) {
          setIsTokenValid(false);
          setTokenError('Network error while validating reset link.');
        }
      } finally {
        if (isMounted) setIsValidating(false);
      }
    };

    verifyToken();
    return () => {
      isMounted = false;
    };
  }, [token]);

  // Password strength checks
  const hasMinLength = newPassword.length >= 8;
  const hasUpper = /[A-Z]/.test(newPassword);
  const hasLower = /[a-z]/.test(newPassword);
  const hasNumberOrSymbol = /[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(newPassword);
  const isMatch = newPassword.length > 0 && newPassword === confirmPassword;
  const isStrengthValid = hasMinLength && hasUpper && hasLower && hasNumberOrSymbol;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!isStrengthValid) {
      setSubmitError('Please meet all password strength requirements.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setSubmitError('Passwords do not match.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token, newPassword }),
      });

      const data = await res.json();
      setIsSubmitting(false);

      if (res.ok) {
        setSubmitSuccess(true);
        setTimeout(() => {
          onSuccess(userRole);
        }, 1800);
      } else {
        setSubmitError(data.error || 'Failed to reset password.');
      }
    } catch {
      setIsSubmitting(false);
      setSubmitError('Network connection failure. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-md bg-slate-900 border border-amber-500/40 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-bold text-amber-400">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-100">Password Recovery</h3>
              <p className="text-[10px] text-amber-400/90 font-mono">Global Finance Secure Reset</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {isValidating ? (
            <div className="py-12 flex flex-col items-center justify-center space-y-3 text-center">
              <RefreshCw className="w-8 h-8 text-amber-400 animate-spin" />
              <p className="text-xs text-slate-300">Validating cryptographic security token...</p>
            </div>
          ) : !isTokenValid ? (
            <div className="space-y-4 py-4 text-center">
              <div className="w-12 h-12 mx-auto rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
                <AlertCircle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-100">Recovery Link Invalid or Expired</h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                {tokenError || 'This password reset link is invalid, has already been used, or has passed its 60-minute expiration window.'}
              </p>
              <div className="pt-2">
                <button
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl font-bold text-xs text-black bg-amber-400 hover:bg-amber-300 transition-colors"
                >
                  Return to Login
                </button>
              </div>
            </div>
          ) : submitSuccess ? (
            <div className="space-y-4 py-6 text-center animate-fadeIn">
              <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-slate-100">Password Reset Complete</h4>
              <p className="text-xs text-slate-300">
                Your password has been successfully updated. All other active sessions have been revoked. Redirecting you to sign in...
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <p className="text-slate-300">
                Please enter a strong new password for your Global Finance Crypto Mining account.
              </p>

              {submitError && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{submitError}</span>
                </div>
              )}

              <div>
                <label className="block text-slate-300 font-medium mb-1">New Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Confirm New Password</label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Re-type new password"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>

              {/* Password strength checklist */}
              <div className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl space-y-1.5 text-[11px]">
                <div className="text-slate-400 font-medium mb-1 flex items-center space-x-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>Security Requirements:</span>
                </div>
                <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                  <span className={hasMinLength ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                    ✓ Minimum 8 characters
                  </span>
                  <span className={hasUpper ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                    ✓ Uppercase letter
                  </span>
                  <span className={hasLower ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                    ✓ Lowercase letter
                  </span>
                  <span className={hasNumberOrSymbol ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                    ✓ Number or symbol
                  </span>
                </div>
                {confirmPassword && (
                  <div className={`pt-1 text-[10px] ${isMatch ? 'text-emerald-400 font-semibold' : 'text-amber-400'}`}>
                    {isMatch ? '✓ Passwords match' : '✗ Passwords do not match yet'}
                  </div>
                )}
              </div>

              <button
                type="submit"
                disabled={isSubmitting || !isStrengthValid || !isMatch}
                className="w-full py-3 rounded-xl font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 transition-all shadow-md shadow-amber-500/10 disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Updating Password...</span>
                  </>
                ) : (
                  <span>Commit Password Change</span>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
