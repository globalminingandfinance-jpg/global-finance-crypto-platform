import React, { useState, useEffect } from 'react';
import {
  LifeBuoy,
  PlusCircle,
  MessageSquare,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowLeft,
  Send,
  Paperclip,
  FileText,
  X,
  RefreshCw,
  Tag,
  ShieldCheck,
  User,
} from 'lucide-react';
import { SupportTicket, TicketMessage, TicketCategory } from '../types/index.js';

interface CustomerSupportSectionProps {
  token: string | null;
  initialTicketId?: string | null;
}

const CATEGORY_LABELS: Record<TicketCategory, string> = {
  general_support: 'General Support',
  complaints: 'Formal Complaints',
  deposits: 'Deposits & PayFast',
  withdrawals: 'Withdrawals & Payouts',
  account_verification: 'Account & KYC Verification',
  technical_problems: 'Technical Problems',
  other_enquiries: 'Other Enquiries',
};

const CATEGORY_COLORS: Record<TicketCategory, string> = {
  general_support: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
  complaints: 'bg-red-500/10 text-red-400 border-red-500/30',
  deposits: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  withdrawals: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
  account_verification: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  technical_problems: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
  other_enquiries: 'bg-slate-500/10 text-slate-400 border-slate-500/30',
};

export const CustomerSupportSection: React.FC<CustomerSupportSectionProps> = ({
  token,
  initialTicketId,
}) => {
  const [subView, setSubView] = useState<'tickets' | 'create' | 'detail'>('tickets');
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(initialTicketId || null);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [messages, setMessages] = useState<TicketMessage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  // Ticket creation form state
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState<TicketCategory>('general_support');
  const [description, setDescription] = useState('');
  const [attachment, setAttachment] = useState<{ name: string; data: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [createdTicketInfo, setCreatedTicketInfo] = useState<{ reference: string; id: string } | null>(
    null
  );

  // Reply state
  const [replyText, setReplyText] = useState('');
  const [replyAttachment, setReplyAttachment] = useState<{ name: string; data: string } | null>(null);
  const [isSendingReply, setIsSendingReply] = useState(false);
  const [replyError, setReplyError] = useState<string | null>(null);

  // Load customer tickets
  const fetchTickets = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/customer/tickets', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setTickets(data.tickets || []);
      }
    } catch (err) {
      console.error('Failed to fetch tickets:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, [token]);

  // Handle external selection (from notification click)
  useEffect(() => {
    if (initialTicketId) {
      openTicketDetails(initialTicketId);
    }
  }, [initialTicketId]);

  // Open specific ticket conversation
  const openTicketDetails = async (ticketId: string) => {
    if (!token) return;
    setSelectedTicketId(ticketId);
    setIsLoading(true);
    setSubView('detail');
    try {
      const res = await fetch(`/api/customer/tickets/${ticketId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedTicket(data.ticket);
        setMessages(data.messages || []);
      } else {
        alert('Unable to load ticket details.');
        setSubView('tickets');
      }
    } catch {
      alert('Network error loading ticket.');
      setSubView('tickets');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle File Upload (Client side base64 encoding with 2MB limit)
  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    isReply: boolean = false
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('File size exceeds 2MB limit. Please attach a smaller file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      if (isReply) {
        setReplyAttachment({ name: file.name, data: result });
      } else {
        setAttachment({ name: file.name, data: result });
      }
    };
    reader.readAsDataURL(file);
  };

  // Submit New Ticket
  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;

    setSubmitError(null);
    setCreatedTicketInfo(null);

    if (subject.trim().length < 3) {
      setSubmitError('Subject must be at least 3 characters.');
      return;
    }
    if (description.trim().length < 5) {
      setSubmitError('Please describe your issue in at least 5 characters.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/customer/tickets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          subject: subject.trim(),
          category,
          description: description.trim(),
          attachmentName: attachment?.name,
          attachmentData: attachment?.data,
        }),
      });

      const data = await res.json();
      setIsSubmitting(false);

      if (res.ok && data.success) {
        setCreatedTicketInfo({
          reference: data.ticket.reference,
          id: data.ticket.id,
        });
        // Reset form
        setSubject('');
        setDescription('');
        setAttachment(null);
        fetchTickets();
      } else {
        setSubmitError(data.error || 'Failed to submit ticket.');
      }
    } catch {
      setIsSubmitting(false);
      setSubmitError('Network error submitting ticket. Please check connection.');
    }
  };

  // Send Follow-up Reply
  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !selectedTicketId) return;

    if (!replyText.trim()) {
      setReplyError('Message cannot be empty.');
      return;
    }

    setReplyError(null);
    setIsSendingReply(true);

    try {
      const res = await fetch(`/api/customer/tickets/${selectedTicketId}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          message: replyText.trim(),
          attachmentName: replyAttachment?.name,
          attachmentData: replyAttachment?.data,
        }),
      });

      const data = await res.json();
      setIsSendingReply(false);

      if (res.ok && data.success) {
        setMessages((prev) => [...prev, data.message]);
        if (selectedTicket) {
          setSelectedTicket({
            ...selectedTicket,
            status: data.updatedStatus,
            last_activity_at: new Date().toISOString(),
          });
        }
        setReplyText('');
        setReplyAttachment(null);
        fetchTickets();
      } else {
        setReplyError(data.error || 'Failed to send reply.');
      }
    } catch {
      setIsSendingReply(false);
      setReplyError('Network error sending message.');
    }
  };

  // Filtered tickets
  const filteredTickets = tickets.filter((t) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchRef = t.reference.toLowerCase().includes(q);
      const matchSub = t.subject.toLowerCase().includes(q);
      if (!matchRef && !matchSub) return false;
    }
    if (categoryFilter && t.category !== categoryFilter) return false;
    if (statusFilter && t.status !== statusFilter) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header & Sub-Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="flex items-center space-x-2">
            <h1 className="text-2xl font-bold font-serif text-slate-100">
              Support & Complaints Centre
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Submit formal enquiries, lodge transaction complaints, and track verified administrator replies.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          {subView !== 'tickets' ? (
            <button
              onClick={() => {
                setSubView('tickets');
                setSelectedTicketId(null);
                setCreatedTicketInfo(null);
              }}
              className="flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-semibold bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back to Tickets</span>
            </button>
          ) : (
            <button
              onClick={() => {
                setSubView('create');
                setCreatedTicketInfo(null);
                setSubmitError(null);
              }}
              className="flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10 transition-all"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Submit New Ticket</span>
            </button>
          )}

          <button
            onClick={fetchTickets}
            title="Refresh tickets"
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* ======================================================================= */}
      {/* 1. TICKETS LIST VIEW */}
      {/* ======================================================================= */}
      {subView === 'tickets' && (
        <div className="space-y-6">
          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
              <span className="text-[11px] text-slate-400">Total Enquiries</span>
              <div className="text-xl font-bold font-mono text-slate-100 mt-1">
                {tickets.length}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/60 border border-amber-500/20">
              <span className="text-[11px] text-amber-400">Open & Active</span>
              <div className="text-xl font-bold font-mono text-amber-300 mt-1">
                {tickets.filter((t) => t.status === 'OPEN' || t.status === 'IN_PROGRESS').length}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/60 border border-blue-500/20">
              <span className="text-[11px] text-blue-400">Awaiting Your Reply</span>
              <div className="text-xl font-bold font-mono text-blue-300 mt-1">
                {tickets.filter((t) => t.status === 'AWAITING_CUSTOMER').length}
              </div>
            </div>
            <div className="p-4 rounded-xl bg-slate-900/60 border border-emerald-500/20">
              <span className="text-[11px] text-emerald-400">Resolved</span>
              <div className="text-xl font-bold font-mono text-emerald-300 mt-1">
                {tickets.filter((t) => t.status === 'RESOLVED' || t.status === 'CLOSED').length}
              </div>
            </div>
          </div>

          {/* Search & Filters */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by ticket reference (e.g. GF-2026-00001) or subject..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60"
              />
            </div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500/60"
            >
              <option value="">All Categories</option>
              {Object.entries(CATEGORY_LABELS).map(([k, label]) => (
                <option key={k} value={k}>
                  {label}
                </option>
              ))}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500/60"
            >
              <option value="">All Statuses</option>
              <option value="OPEN">Open</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="AWAITING_CUSTOMER">Awaiting Your Reply</option>
              <option value="RESOLVED">Resolved</option>
              <option value="CLOSED">Closed</option>
            </select>
          </div>

          {/* Tickets Table / List */}
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-medium">
                  <tr>
                    <th className="py-3 px-4">Reference</th>
                    <th className="py-3 px-4">Subject</th>
                    <th className="py-3 px-4">Category</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Last Activity</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {filteredTickets.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-slate-500">
                        <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-30 text-slate-400" />
                        <p>No support tickets found.</p>
                        <p className="text-[11px] text-slate-600 mt-1">
                          Have an issue with a transaction or deposit? Click &ldquo;Submit New Ticket&rdquo; above.
                        </p>
                      </td>
                    </tr>
                  ) : (
                    filteredTickets.map((t) => {
                      const isAwaitingClient = t.status === 'AWAITING_CUSTOMER';
                      return (
                        <tr
                          key={t.id}
                          className="hover:bg-slate-850/50 transition-colors cursor-pointer"
                          onClick={() => openTicketDetails(t.id)}
                        >
                          <td className="py-3.5 px-4 font-mono font-semibold text-amber-400">
                            {t.reference}
                          </td>
                          <td className="py-3.5 px-4 font-medium text-slate-200">
                            <div className="max-w-xs truncate">{t.subject}</div>
                            {t.message_count && t.message_count > 1 && (
                              <span className="text-[10px] text-slate-500">
                                {t.message_count} messages
                              </span>
                            )}
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${
                                CATEGORY_COLORS[t.category] || 'bg-slate-800 text-slate-300'
                              }`}
                            >
                              {CATEGORY_LABELS[t.category] || t.category}
                            </span>
                          </td>
                          <td className="py-3.5 px-4">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                t.status === 'RESOLVED' || t.status === 'CLOSED'
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : isAwaitingClient
                                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30 animate-pulse'
                                  : t.status === 'IN_PROGRESS'
                                  ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                  : 'bg-slate-800 text-slate-300 border border-slate-700'
                              }`}
                            >
                              {isAwaitingClient ? 'Awaiting Your Response' : t.status.replace('_', ' ')}
                            </span>
                          </td>
                          <td className="py-3.5 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                            {new Date(t.last_activity_at || t.created_at).toLocaleString()}
                          </td>
                          <td className="py-3.5 px-4 text-right">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                openTicketDetails(t.id);
                              }}
                              className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-amber-500 hover:text-black text-slate-200 transition-colors"
                            >
                              View Ticket
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================================= */}
      {/* 2. CREATE TICKET FORM */}
      {/* ======================================================================= */}
      {subView === 'create' && (
        <div className="max-w-2xl space-y-6">
          {createdTicketInfo ? (
            <div className="p-6 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-slate-100 space-y-4">
              <div className="flex items-center space-x-3 text-emerald-400">
                <CheckCircle2 className="w-6 h-6 shrink-0" />
                <h3 className="text-lg font-bold">Support Ticket Successfully Created</h3>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Your enquiry has been logged in our compliance database and assigned official reference:
              </p>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl font-mono text-sm text-amber-400 font-bold flex items-center justify-between">
                <span>{createdTicketInfo.reference}</span>
                <span className="text-[10px] text-slate-400 font-sans uppercase">Confirmed & Saved</span>
              </div>
              <p className="text-xs text-slate-400">
                A confirmation has been sent to your email and saved in your notification centre. Our team will review and reply promptly.
              </p>
              <div className="pt-2 flex items-center space-x-3">
                <button
                  onClick={() => openTicketDetails(createdTicketInfo.id)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400"
                >
                  Open Ticket Conversation
                </button>
                <button
                  onClick={() => {
                    setCreatedTicketInfo(null);
                    setSubView('tickets');
                  }}
                  className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
                >
                  View All Tickets
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleCreateTicket} className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-5 text-xs">
              <div className="border-b border-slate-800 pb-4">
                <h2 className="text-base font-bold text-slate-100">Submit a Support Enquiry or Complaint</h2>
                <p className="text-slate-400 text-xs mt-1">
                  Please provide clear details regarding your issue or transaction reference.
                </p>
              </div>

              {submitError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded-xl flex items-center space-x-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{submitError}</span>
                </div>
              )}

              <div>
                <label className="block font-medium text-slate-300 mb-1.5">
                  Category <span className="text-amber-400">*</span>
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as TicketCategory)}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-amber-500/60"
                >
                  {Object.entries(CATEGORY_LABELS).map(([k, label]) => (
                    <option key={k} value={k}>
                      {label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-300 mb-1.5">
                  Subject / Summary <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Deposit confirmation inquiry for PayFast reference PF-12345"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>

              <div>
                <label className="block font-medium text-slate-300 mb-1.5">
                  Detailed Description <span className="text-amber-400">*</span>
                </label>
                <textarea
                  required
                  rows={5}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide complete context, amounts, transaction dates, or specific questions..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-sm text-slate-100 focus:outline-none focus:border-amber-500/60 resize-none leading-relaxed"
                />
              </div>

              {/* Secure Attachment Support */}
              <div>
                <label className="block font-medium text-slate-300 mb-1.5">
                  Optional Attachment (Proof of Payment, Screenshot, PDF — max 2MB)
                </label>
                {attachment ? (
                  <div className="flex items-center justify-between p-3 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="flex items-center space-x-2 text-slate-200">
                      <FileText className="w-4 h-4 text-amber-400" />
                      <span className="truncate max-w-xs">{attachment.name}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setAttachment(null)}
                      className="p-1 text-slate-500 hover:text-red-400"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <label className="flex items-center justify-center space-x-2 border border-dashed border-slate-800 hover:border-amber-500/50 rounded-xl p-4 cursor-pointer bg-slate-950/50 hover:bg-slate-950 transition-colors">
                    <Paperclip className="w-4 h-4 text-slate-400" />
                    <span className="text-xs text-slate-400">Attach file or payment proof</span>
                    <input
                      type="file"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, false)}
                      accept="image/*,.pdf,.doc,.docx"
                    />
                  </label>
                )}
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 disabled:opacity-50 transition-all flex items-center justify-center space-x-2 shadow-lg shadow-amber-500/10"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Submitting to Compliance Database...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Submit Ticket & Receive Reference</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          )}
        </div>
      )}

      {/* ======================================================================= */}
      {/* 3. TICKET CONVERSATION VIEW */}
      {/* ======================================================================= */}
      {subView === 'detail' && selectedTicket && (
        <div className="space-y-6 max-w-4xl">
          {/* Ticket Header Card */}
          <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-mono font-bold text-sm text-amber-400">
                    {selectedTicket.reference}
                  </span>
                  <span
                    className={`text-[10px] font-semibold px-2 py-0.5 rounded-full border ${
                      CATEGORY_COLORS[selectedTicket.category] || 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {CATEGORY_LABELS[selectedTicket.category] || selectedTicket.category}
                  </span>
                </div>
                <h2 className="text-lg font-bold text-slate-100 mt-1">{selectedTicket.subject}</h2>
              </div>

              <div className="flex items-center space-x-2">
                <span
                  className={`text-xs font-bold px-3 py-1 rounded-full ${
                    selectedTicket.status === 'RESOLVED' || selectedTicket.status === 'CLOSED'
                      ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                      : selectedTicket.status === 'AWAITING_CUSTOMER'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                  }`}
                >
                  Status: {selectedTicket.status.replace('_', ' ')}
                </span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 text-slate-400 text-[11px]">
              <div>
                <span className="text-slate-500">Created:</span>{' '}
                <span className="text-slate-300">{new Date(selectedTicket.created_at).toLocaleString()}</span>
              </div>
              <div>
                <span className="text-slate-500">Last Activity:</span>{' '}
                <span className="text-slate-300">{new Date(selectedTicket.last_activity_at).toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Messages Chronological Stream */}
          <div className="space-y-4">
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
              Conversation History
            </h3>

            {messages.map((m) => {
              const isAdmin = m.sender_role === 'admin';
              return (
                <div
                  key={m.id}
                  className={`p-5 rounded-2xl border text-xs leading-relaxed space-y-2.5 transition-all ${
                    isAdmin
                      ? 'bg-amber-500/5 border-amber-500/20 ml-0 sm:ml-4'
                      : 'bg-slate-900/60 border-slate-800 mr-0 sm:mr-4'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-slate-800/60 pb-2">
                    <div className="flex items-center space-x-2">
                      <div
                        className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-[10px] ${
                          isAdmin
                            ? 'bg-amber-500 text-black'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {isAdmin ? <ShieldCheck className="w-3.5 h-3.5" /> : <User className="w-3.5 h-3.5" />}
                      </div>
                      <span className="font-semibold text-slate-200">
                        {isAdmin ? 'Global Finance Support (Official Admin)' : 'You (Account Holder)'}
                      </span>
                      {isAdmin && (
                        <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded font-bold">
                          Verified Support
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-500">
                      {new Date(m.created_at).toLocaleString()}
                    </span>
                  </div>

                  <p className="text-slate-300 whitespace-pre-wrap">{m.message}</p>

                  {m.attachment_name && m.attachment_data && (
                    <div className="pt-2">
                      <a
                        href={m.attachment_data}
                        download={m.attachment_name}
                        className="inline-flex items-center space-x-2 p-2 bg-slate-950 border border-slate-800 rounded-xl text-amber-400 hover:text-amber-300"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span className="underline">{m.attachment_name}</span>
                      </a>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Follow-Up Reply Composer */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h4 className="font-semibold text-xs text-slate-200 uppercase tracking-wider">
              Send Follow-up Message
            </h4>

            {replyError && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 rounded-xl text-xs flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{replyError}</span>
              </div>
            )}

            <form onSubmit={handleSendReply} className="space-y-4 text-xs">
              <textarea
                rows={4}
                required
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder="Type your follow-up reply or question for our team..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-sm text-slate-100 focus:outline-none focus:border-amber-500/60 resize-none"
              />

              {/* Optional Attachment */}
              <div>
                {replyAttachment ? (
                  <div className="flex items-center justify-between p-2.5 bg-slate-950 border border-slate-800 rounded-xl">
                    <div className="flex items-center space-x-2 text-slate-200">
                      <FileText className="w-4 h-4 text-amber-400" />
                      <span className="truncate max-w-xs">{replyAttachment.name}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setReplyAttachment(null)}
                      className="p-1 text-slate-500 hover:text-red-400"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ) : (
                  <label className="inline-flex items-center space-x-2 px-3 py-1.5 border border-slate-800 hover:border-slate-700 rounded-xl cursor-pointer bg-slate-950 text-slate-400 hover:text-white transition-colors">
                    <Paperclip className="w-3.5 h-3.5" />
                    <span>Attach document</span>
                    <input
                      type="file"
                      className="hidden"
                      onChange={(e) => handleFileUpload(e, true)}
                      accept="image/*,.pdf,.doc,.docx"
                    />
                  </label>
                )}
              </div>

              <button
                type="submit"
                disabled={isSendingReply}
                className="px-6 py-2.5 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 disabled:opacity-50 transition-all flex items-center space-x-2"
              >
                {isSendingReply ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Sending...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Reply</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
