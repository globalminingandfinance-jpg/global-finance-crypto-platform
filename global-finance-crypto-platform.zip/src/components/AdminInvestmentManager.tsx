import React, { useState, useEffect } from 'react';
import {
  Coins,
  TrendingUp,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  Calendar,
  DollarSign,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
  FileText,
  SlidersHorizontal,
  X,
  History,
  ShieldAlert,
  ArrowUpRight,
  Info,
} from 'lucide-react';

interface Props {
  token: string | null;
}

export const AdminInvestmentManager: React.FC<Props> = ({ token }) => {
  const [investments, setInvestments] = useState<any[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // Selected investment for detail / audit modal
  const [inspectModalOpen, setInspectModalOpen] = useState(false);
  const [inspectingInvestment, setInspectingInvestment] = useState<any | null>(null);
  const [inspectLoading, setInspectLoading] = useState(false);
  const [dailyRecords, setDailyRecords] = useState<any[]>([]);
  const [auditLogs, setAuditLogs] = useState<any[]>([]);

  // Settle modal state
  const [settleModalOpen, setSettleModalOpen] = useState(false);
  const [settleInvestmentId, setSettleInvestmentId] = useState<string | null>(null);
  const [settleNotes, setSettleNotes] = useState('');
  const [isSettling, setIsSettling] = useState(false);
  const [settleFeedback, setSettleFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Valuation adjustment modal state
  const [valuationModalOpen, setValuationModalOpen] = useState(false);
  const [valInvestmentId, setValInvestmentId] = useState<string | null>(null);
  const [newValuation, setNewValuation] = useState('');
  const [valReason, setValReason] = useState('');
  const [isAdjustingVal, setIsAdjustingVal] = useState(false);
  const [valFeedback, setValFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Plans & Versions modal
  const [plansModalOpen, setPlansModalOpen] = useState(false);
  const [plans, setPlans] = useState<any[]>([]);
  const [planVersions, setPlanVersions] = useState<any[]>([]);
  const [plansLoading, setPlansLoading] = useState(false);

  // Edit plan modal
  const [selectedPlanToEdit, setSelectedPlanToEdit] = useState<any | null>(null);
  const [editReturnRate, setEditReturnRate] = useState('');
  const [editDurationDays, setEditDurationDays] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [isSavingPlan, setIsSavingPlan] = useState(false);

  const fetchInvestments = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const q = new URLSearchParams();
      if (statusFilter !== 'ALL') q.set('status', statusFilter);
      if (searchQuery.trim()) q.set('q', searchQuery.trim());
      q.set('page', String(page));
      q.set('limit', '15');

      const res = await fetch(`/api/admin/investments?${q.toString()}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setInvestments(data.investments || []);
        setMetrics(data.metrics || null);
        setTotalPages(data.pagination?.totalPages || 1);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchInvestments();
  }, [token, statusFilter, page]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchInvestments();
  };

  // Inspect detail
  const handleOpenInspect = async (id: string) => {
    if (!token) return;
    setInspectModalOpen(true);
    setInspectLoading(true);
    try {
      const res = await fetch(`/api/admin/investments/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setInspectingInvestment(data.investment);
        setDailyRecords(data.dailyRecords || []);
        setAuditLogs(data.auditLogs || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setInspectLoading(false);
    }
  };

  // Settle matured investment
  const handleSettleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settleInvestmentId || !token) return;
    setIsSettling(true);
    setSettleFeedback(null);

    try {
      const res = await fetch(`/api/admin/investments/${settleInvestmentId}/settle`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ notes: settleNotes }),
      });
      const data = await res.json();
      if (res.ok) {
        setSettleFeedback({ type: 'success', text: data.message });
        setTimeout(() => {
          setSettleModalOpen(false);
          setSettleInvestmentId(null);
          setSettleNotes('');
          fetchInvestments();
        }, 1200);
      } else {
        setSettleFeedback({ type: 'error', text: data.error || 'Failed to process settlement.' });
      }
    } catch {
      setSettleFeedback({ type: 'error', text: 'Network connection error.' });
    } finally {
      setIsSettling(false);
    }
  };

  // Record valuation adjustment
  const handleValuationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!valInvestmentId || !token) return;
    setIsAdjustingVal(true);
    setValFeedback(null);

    try {
      const res = await fetch(`/api/admin/investments/${valInvestmentId}/record-valuation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          newValuation: parseFloat(newValuation),
          reason: valReason,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setValFeedback({ type: 'success', text: data.message });
        setTimeout(() => {
          setValuationModalOpen(false);
          setValInvestmentId(null);
          setNewValuation('');
          setValReason('');
          fetchInvestments();
        }, 1200);
      } else {
        setValFeedback({ type: 'error', text: data.error || 'Failed to update valuation.' });
      }
    } catch {
      setValFeedback({ type: 'error', text: 'Network connection error.' });
    } finally {
      setIsAdjustingVal(false);
    }
  };

  // Fetch plan versions
  const handleOpenPlans = async () => {
    if (!token) return;
    setPlansModalOpen(true);
    setPlansLoading(true);
    try {
      const res = await fetch('/api/admin/investments-plans', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setPlans(data.products || []);
        setPlanVersions(data.versions || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setPlansLoading(false);
    }
  };

  // Save updated plan terms
  const handleSavePlanSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlanToEdit || !token) return;
    setIsSavingPlan(true);

    try {
      const res = await fetch(`/api/admin/investments-plans/${selectedPlanToEdit.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          returnRate: parseFloat(editReturnRate),
          durationDays: parseInt(editDurationDays, 10),
          notes: editNotes,
        }),
      });
      if (res.ok) {
        setSelectedPlanToEdit(null);
        handleOpenPlans();
        fetchInvestments();
      } else {
        const d = await res.json();
        alert(d.error || 'Failed to update plan.');
      }
    } catch {
      alert('Network error.');
    } finally {
      setIsSavingPlan(false);
    }
  };

  const formatZAR = (val: number | null | undefined) => {
    return `R ${Number(val || 0).toLocaleString('en-ZA', { minimumFractionDigits: 2 })}`;
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-serif font-bold text-slate-100 flex items-center space-x-2">
            <Coins className="w-5 h-5 text-amber-400" />
            <span>Investment Management & Settlement Console</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative lifecycle monitoring of client capital allocations, contractual maturity dates, and audited payout settlements.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={handleOpenPlans}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 transition-colors"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-400" />
            <span>Plan Terms & Versions</span>
          </button>
          <button
            onClick={() => fetchInvestments()}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-white"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Summary Cards */}
      {metrics && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Active Capital</span>
            <div className="text-lg font-mono font-bold text-amber-300">{formatZAR(metrics.activeCapital)}</div>
            <span className="text-[10px] text-slate-400">{metrics.activeCount} active positions</span>
          </div>
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Projected Return Obligations</span>
            <div className="text-lg font-mono font-bold text-cyan-300">{formatZAR(metrics.activeProjectedProfit)}</div>
            <span className="text-[10px] text-slate-400">At maturity schedule</span>
          </div>
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Matured Awaiting Settlement</span>
            <div className="text-lg font-mono font-bold text-amber-400">{metrics.maturedCount} positions</div>
            <span className="text-[10px] text-slate-400">{formatZAR(metrics.maturedCapital)} capital</span>
          </div>
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-2xl">
            <span className="text-[10px] text-slate-500 uppercase font-semibold block">Total Settled Payouts</span>
            <div className="text-lg font-mono font-bold text-emerald-400">{formatZAR(metrics.settledAmount)}</div>
            <span className="text-[10px] text-slate-400">{metrics.settledCount} completed settlements</span>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-950 p-3 rounded-2xl border border-slate-800">
        <div className="flex items-center space-x-1 w-full sm:w-auto overflow-x-auto text-xs">
          {['ALL', 'ACTIVE', 'MATURED', 'SETTLED', 'CANCELLED'].map((st) => (
            <button
              key={st}
              onClick={() => {
                setStatusFilter(st);
                setPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${
                statusFilter === st
                  ? 'bg-amber-400 text-black font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>

        <form onSubmit={handleSearchSubmit} className="flex items-center space-x-2 w-full sm:w-80">
          <div className="relative w-full">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search ref, email, client..."
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/60"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200"
          >
            Find
          </button>
        </form>
      </div>

      {/* Investments Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4 font-medium">Reference</th>
                <th className="py-3 px-4 font-medium">Client</th>
                <th className="py-3 px-4 font-medium">Plan</th>
                <th className="py-3 px-4 font-medium">Capital</th>
                <th className="py-3 px-4 font-medium">Rate / Term</th>
                <th className="py-3 px-4 font-medium">Maturity Date</th>
                <th className="py-3 px-4 font-medium">Status</th>
                <th className="py-3 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {isLoading ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    Loading investments...
                  </td>
                </tr>
              ) : investments.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500">
                    No investment records matching the specified criteria.
                  </td>
                </tr>
              ) : (
                investments.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-3 px-4 font-mono font-semibold text-slate-200">
                      {inv.transaction_reference}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-200">
                        {inv.customer_first_name} {inv.customer_last_name}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">{inv.customer_email}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-300 font-medium">
                      {inv.plan_name || inv.product_name}{' '}
                      <span className="text-[10px] text-slate-500 font-mono">v{inv.term_version}</span>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-amber-300">
                      {formatZAR(inv.amount_allocated)}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-300">
                      {Math.round((inv.return_rate || 0.75) * 100)}% ({inv.duration_days || 5}d)
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {new Date(inv.maturity_date).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          inv.status === 'ACTIVE'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : inv.status === 'MATURED'
                            ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                            : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                        }`}
                      >
                        {inv.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        onClick={() => handleOpenInspect(inv.id)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium"
                      >
                        Inspect
                      </button>

                      {inv.status === 'MATURED' && inv.settlement_status !== 'SETTLED' && (
                        <button
                          onClick={() => {
                            setSettleInvestmentId(inv.id);
                            setSettleModalOpen(true);
                          }}
                          className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-black text-[11px] font-bold shadow-sm"
                        >
                          Settle Payout
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setValInvestmentId(inv.id);
                          setNewValuation(String(inv.current_valuation || inv.amount_allocated));
                          setValuationModalOpen(true);
                        }}
                        className="px-2 py-1 rounded-lg bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-300 text-[11px]"
                      >
                        Adjust
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between p-4 border-t border-slate-800 text-xs text-slate-400">
            <span>
              Page {page} of {totalPages}
            </span>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page === 1}
                className="p-1 rounded-lg bg-slate-950 border border-slate-800 disabled:opacity-40"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="p-1 rounded-lg bg-slate-950 border border-slate-800 disabled:opacity-40"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* INSPECT MODAL */}
      {inspectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-slate-100 font-serif">
                  Investment Position Inspection
                </h3>
                <span className="text-xs text-slate-400 font-mono">
                  ID: {inspectingInvestment?.id}
                </span>
              </div>
              <button
                onClick={() => setInspectModalOpen(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {inspectLoading ? (
              <div className="py-12 text-center text-xs text-slate-400">Loading details...</div>
            ) : inspectingInvestment ? (
              <div className="space-y-6 text-xs">
                {/* Overview Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 bg-slate-950 rounded-2xl border border-slate-800/80">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Client</span>
                    <span className="font-semibold text-slate-200">
                      {inspectingInvestment.customer_first_name} {inspectingInvestment.customer_last_name}
                    </span>
                    <span className="text-slate-400 block font-mono text-[10px]">
                      {inspectingInvestment.customer_email}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Plan Name & Version</span>
                    <span className="font-semibold text-slate-200">
                      {inspectingInvestment.plan_name || inspectingInvestment.product_name}
                    </span>
                    <span className="text-slate-400 block font-mono text-[10px]">
                      Term Version {inspectingInvestment.term_version}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Invested Capital</span>
                    <span className="font-mono font-bold text-amber-300">
                      {formatZAR(inspectingInvestment.amount_allocated)}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Return Target</span>
                    <span className="font-mono text-slate-200">
                      {Math.round((inspectingInvestment.return_rate || 0.75) * 100)}% ({inspectingInvestment.duration_days} days)
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Projected Maturity Total</span>
                    <span className="font-mono font-bold text-cyan-300">
                      {formatZAR(inspectingInvestment.projected_total)}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Settlement Status</span>
                    <span className="font-bold text-emerald-400">
                      {inspectingInvestment.settlement_status || 'UNSETTLED'}
                    </span>
                  </div>
                </div>

                {/* Audit Trail */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-slate-200 text-xs">Audit Event Logs</h4>
                  <div className="bg-slate-950 rounded-2xl border border-slate-800 p-3 max-h-48 overflow-y-auto space-y-2">
                    {auditLogs.length === 0 ? (
                      <span className="text-slate-500 text-[11px]">No audit logs recorded.</span>
                    ) : (
                      auditLogs.map((a, i) => (
                        <div key={i} className="p-2 bg-slate-900/60 rounded-xl border border-slate-800 text-[11px] space-y-0.5">
                          <div className="flex justify-between font-mono text-slate-400">
                            <span className="font-semibold text-amber-400">{a.action}</span>
                            <span>{new Date(a.created_at).toLocaleString()}</span>
                          </div>
                          <div className="text-slate-300 font-mono text-[10px] break-all">{a.reason}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* SETTLE MODAL */}
      {settleModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-amber-500/30 rounded-3xl p-6 space-y-4">
            <h3 className="font-bold text-base text-slate-100 font-serif">
              Authorize Maturity Settlement
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              This action credits the client&apos;s available cash ledger balance with the full capital and contractual return. It updates the position status to SETTLED and cannot be reversed.
            </p>

            {settleFeedback && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center space-x-2 ${
                  settleFeedback.type === 'success'
                    ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
                    : 'bg-red-500/10 border border-red-500/30 text-red-400'
                }`}
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{settleFeedback.text}</span>
              </div>
            )}

            <form onSubmit={handleSettleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Administrative Notes (Required for Audit)</label>
                <textarea
                  rows={3}
                  required
                  value={settleNotes}
                  onChange={(e) => setSettleNotes(e.target.value)}
                  placeholder="State the justification, reconciliation reference, or approval note..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 focus:outline-none focus:border-amber-500/60 resize-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSettleModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSettling}
                  className="px-5 py-2 rounded-xl font-bold text-black bg-amber-400 hover:bg-amber-300 disabled:opacity-50"
                >
                  {isSettling ? 'Processing...' : 'Confirm Settlement'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* RECORD VALUATION MODAL */}
      {valuationModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-4">
            <h3 className="font-bold text-base text-slate-100 font-serif">
              Record Audited Valuation Adjustment
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Record an authoritative valuation adjustment (e.g., hardware performance bonus, mining pool distribution, or yield variance). Silent changes are strictly prohibited.
            </p>

            {valFeedback && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center space-x-2 ${
                  valFeedback.type === 'success'
                    ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
                    : 'bg-red-500/10 border border-red-500/30 text-red-400'
                }`}
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{valFeedback.text}</span>
              </div>
            )}

            <form onSubmit={handleValuationSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">New Valuation Amount (ZAR)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={newValuation}
                  onChange={(e) => setNewValuation(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Authoritative Reason (Mandatory Audit Trail)</label>
                <textarea
                  rows={3}
                  required
                  value={valReason}
                  onChange={(e) => setValReason(e.target.value)}
                  placeholder="Specify hardware telemetry log, pool distribution hash, or variance justification..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 focus:outline-none focus:border-amber-500/60 resize-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setValuationModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isAdjustingVal}
                  className="px-5 py-2 rounded-xl font-bold text-black bg-amber-400 hover:bg-amber-300 disabled:opacity-50"
                >
                  {isAdjustingVal ? 'Updating...' : 'Save Valuation'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PLAN TERMS & VERSIONS MODAL */}
      {plansModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="w-full max-w-3xl bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-slate-100 font-serif">
                  Plan Terms & Version Governance
                </h3>
                <p className="text-xs text-slate-400">
                  Plan terms are immutable to existing investments. Updates create a new version for future purchases.
                </p>
              </div>
              <button
                onClick={() => setPlansModalOpen(false)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {plansLoading ? (
              <div className="py-8 text-center text-xs text-slate-400">Loading plan versions...</div>
            ) : (
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {plans.map((p) => (
                    <div key={p.id} className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 text-xs">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-slate-100 font-serif">{p.name}</span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/20">
                          v{p.term_version}
                        </span>
                      </div>
                      <div className="text-slate-400 text-[11px]">{p.description}</div>
                      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 text-[11px] font-mono">
                        <div>
                          <span className="text-slate-500 block text-[9px]">Return Rate:</span>
                          <span className="text-amber-400 font-bold">{Math.round((p.return_rate || 0.75) * 100)}%</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[9px]">Duration:</span>
                          <span className="text-slate-200">{p.duration_days} days</span>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setSelectedPlanToEdit(p);
                          setEditReturnRate(String(p.return_rate));
                          setEditDurationDays(String(p.duration_days));
                          setEditNotes('');
                        }}
                        className="w-full mt-2 py-1.5 rounded-xl bg-slate-900 border border-slate-700 hover:bg-slate-800 text-slate-200 text-xs font-semibold"
                      >
                        Create New Term Version
                      </button>
                    </div>
                  ))}
                </div>

                {/* Edit form inline */}
                {selectedPlanToEdit && (
                  <form onSubmit={handleSavePlanSubmit} className="p-4 bg-amber-500/5 border border-amber-500/30 rounded-2xl space-y-3 text-xs">
                    <div className="font-bold text-amber-300">
                      Update Terms for {selectedPlanToEdit.name} (Increments to v{(selectedPlanToEdit.term_version || 1) + 1})
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-300 mb-1">Return Rate (e.g. 0.85 for 85%)</label>
                        <input
                          type="number"
                          step="0.01"
                          required
                          value={editReturnRate}
                          onChange={(e) => setEditReturnRate(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-300 mb-1">Duration (Days)</label>
                        <input
                          type="number"
                          step="1"
                          required
                          value={editDurationDays}
                          onChange={(e) => setEditDurationDays(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-slate-300 mb-1">Version Update Justification (Audit Note)</label>
                      <input
                        type="text"
                        required
                        value={editNotes}
                        onChange={(e) => setEditNotes(e.target.value)}
                        placeholder="Reason for modifying contractual parameters..."
                        className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                      />
                    </div>
                    <div className="flex justify-end space-x-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setSelectedPlanToEdit(null)}
                        className="px-3 py-1.5 text-slate-400 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isSavingPlan}
                        className="px-4 py-1.5 rounded-xl font-bold text-black bg-amber-400 hover:bg-amber-300 disabled:opacity-50"
                      >
                        {isSavingPlan ? 'Saving...' : 'Publish Version'}
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
