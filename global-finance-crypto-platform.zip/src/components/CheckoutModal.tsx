import React, { useState } from 'react';
import { InvestmentProduct } from '../types/index.js';
import { useAuth } from '../context/AuthContext.js';
import { ShieldCheck, ArrowRight, ArrowLeft, CreditCard, Building2, Check, AlertCircle, Loader2, X } from 'lucide-react';

interface CheckoutModalProps {
  initialProduct: InvestmentProduct | null;
  onClose: () => void;
  onSuccess?: (reference: string) => void;
}

const STANDARD_AMOUNTS = [500, 1000, 2500, 5000];
const ELITE_AMOUNTS = [10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2000000];
const ALL_PERMITTED_AMOUNTS = [...STANDARD_AMOUNTS, ...ELITE_AMOUNTS];

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  initialProduct,
  onClose,
  onSuccess,
}) => {
  const { user } = useAuth();

  // Step state
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);

  // Form states
  const [firstName, setFirstName] = useState(user?.firstName || '');
  const [lastName, setLastName] = useState(user?.lastName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [phone, setPhone] = useState(user?.phone || '');
  const [country, setCountry] = useState(user?.country || 'South Africa');

  const [selectedProduct, setSelectedProduct] = useState<InvestmentProduct | null>(initialProduct);
  const [selectedAmount, setSelectedAmount] = useState<number>(() => {
    if (initialProduct) {
      if (initialProduct.slug === 'elite' || initialProduct.minAmount >= 10000) {
        return 10000;
      }
      const match = STANDARD_AMOUNTS.find((a) => a >= initialProduct.minAmount);
      return match || 1000;
    }
    return 1000;
  });
  const [paymentMethod, setPaymentMethod] = useState<'payfast' | 'bank_transfer'>('payfast');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Result state for bank transfer or PayFast form submission
  const [bankResult, setBankResult] = useState<{
    reference: string;
    amount: number;
    currency: string;
    bankingDetails: {
      accountName: string;
      bankName: string;
      accountNumber: string;
      branchCode: string;
      instructions: string;
    };
  } | null>(null);

  // Validation for Step 1
  const validateStep1 = () => {
    setErrorMessage(null);
    if (!firstName.trim()) {
      setErrorMessage('Please enter your first name.');
      return false;
    }
    if (!lastName.trim()) {
      setErrorMessage('Please enter your surname.');
      return false;
    }
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setErrorMessage('Please enter a valid email address.');
      return false;
    }
    return true;
  };

  // Validation for Step 2
  const validateStep2 = () => {
    setErrorMessage(null);
    if (!selectedProduct) {
      setErrorMessage('Please select an investment product.');
      return false;
    }
    if (!ALL_PERMITTED_AMOUNTS.includes(selectedAmount)) {
      setErrorMessage('Please select one of the permitted investment amounts.');
      return false;
    }
    if (selectedAmount < selectedProduct.minAmount) {
      setErrorMessage(
        `The selected amount (R${selectedAmount.toLocaleString()}) is below the minimum required for ${selectedProduct.name} (R${selectedProduct.minAmount.toLocaleString()}).`
      );
      return false;
    }
    return true;
  };

  const handleNextFrom1 = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateStep1()) {
      setStep(2);
    }
  };

  const handleNextFrom2 = () => {
    if (validateStep2()) {
      setStep(3);
    }
  };

  // Step 3 submission to backend initialization endpoint
  const handleProceedToPayment = async () => {
    if (!selectedProduct) return;
    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      const res = await fetch('/api/payments/initialize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productId: selectedProduct.id,
          amount: selectedAmount,
          paymentMethod,
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          email: email.trim(),
          phone: phone.trim(),
          country: country.trim(),
          userId: user?.id,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setErrorMessage(data.error || 'Unable to initialize payment transaction.');
        setIsSubmitting(false);
        return;
      }

      if (paymentMethod === 'payfast') {
        // Build and dynamically submit the official PayFast HTML form
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = data.processUrl;

        Object.entries(data.payfastPayload).forEach(([key, val]) => {
          const input = document.createElement('input');
          input.type = 'hidden';
          input.name = key;
          input.value = String(val);
          form.appendChild(input);
        });

        document.body.appendChild(form);
        form.submit();
      } else {
        // Bank transfer instructions
        setBankResult({
          reference: data.reference,
          amount: data.amount,
          currency: data.currency,
          bankingDetails: data.bankingDetails,
        });
        setStep(4);
        if (onSuccess) onSuccess(data.reference);
      }
    } catch (err) {
      setErrorMessage('Network connection error. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-xl bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[95vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/70">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-xs">
              GF
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-100">
                {step === 4 ? 'Bank Transfer Instructions' : 'Investment Checkout'}
              </h2>
              <p className="text-xs text-slate-400">Global Finance Crypto Mining</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress Indicator (Steps 1 to 3) */}
        {step < 4 && (
          <div className="grid grid-cols-3 border-b border-slate-800 text-xs text-center font-medium">
            <div
              className={`py-2.5 transition-colors ${
                step === 1
                  ? 'bg-amber-500/10 text-amber-300 border-b-2 border-amber-500'
                  : step > 1
                  ? 'text-emerald-400'
                  : 'text-slate-500'
              }`}
            >
              1. Customer Details
            </div>
            <div
              className={`py-2.5 transition-colors ${
                step === 2
                  ? 'bg-amber-500/10 text-amber-300 border-b-2 border-amber-500'
                  : step > 2
                  ? 'text-emerald-400'
                  : 'text-slate-500'
              }`}
            >
              2. Investment & Method
            </div>
            <div
              className={`py-2.5 transition-colors ${
                step === 3
                  ? 'bg-amber-500/10 text-amber-300 border-b-2 border-amber-500'
                  : 'text-slate-500'
              }`}
            >
              3. Review & Pay
            </div>
          </div>
        )}

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {errorMessage && (
            <div className="flex items-center space-x-2.5 bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-xl text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* STEP 1: CUSTOMER DETAILS */}
          {step === 1 && (
            <form onSubmit={handleNextFrom1} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    First Name <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="e.g. John"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/60 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Surname <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="e.g. Smith"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/60 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Email Address <span className="text-amber-400">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/60 transition-colors"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Payment confirmation receipts and transaction ledger updates will be delivered to this email.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Contact Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. +27 82 123 4567"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/60 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Country of Residence
                  </label>
                  <input
                    type="text"
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    placeholder="South Africa"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/60 transition-colors"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="flex items-center space-x-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 transition-all shadow-md shadow-amber-500/10"
                >
                  <span>Continue to Investment</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: INVESTMENT SELECTION & PAYMENT METHOD */}
          {step === 2 && (
            <div className="space-y-5">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  1. Select Investment Product
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    {
                      id: 'prod_starter',
                      slug: 'starter',
                      name: 'Starter Investment',
                      min: 500,
                    },
                    {
                      id: 'prod_growth',
                      slug: 'growth',
                      name: 'Growth Investment',
                      min: 1000,
                    },
                    {
                      id: 'prod_professional',
                      slug: 'professional',
                      name: 'Professional Investment',
                      min: 2500,
                    },
                    {
                      id: 'prod_elite',
                      slug: 'elite',
                      name: 'Elite Investment',
                      min: 10000,
                      isElite: true,
                    },
                  ].map((p) => {
                    const isSelected = selectedProduct?.name === p.name;
                    return (
                      <button
                        type="button"
                        key={p.id}
                        onClick={() => {
                          setSelectedProduct({
                            id: p.id,
                            slug: p.slug,
                            name: p.name,
                            description: '',
                            minAmount: p.min,
                            features: [],
                            currency: 'ZAR',
                          });
                          if (p.slug === 'elite') {
                            if (selectedAmount < 10000) setSelectedAmount(10000);
                          } else {
                            if (selectedAmount > 5000 || selectedAmount < p.min) {
                              const newMin = STANDARD_AMOUNTS.find((a) => a >= p.min) || p.min;
                              setSelectedAmount(newMin);
                            }
                          }
                        }}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSelected
                            ? p.isElite
                              ? 'bg-amber-500/20 border-amber-400 shadow-md shadow-amber-500/30'
                              : 'bg-amber-500/10 border-amber-500/60 shadow-sm shadow-amber-500/20'
                            : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className={`font-semibold text-xs ${p.isElite ? 'text-amber-300' : 'text-slate-200'}`}>
                            {p.name}
                          </span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400 font-mono">Min: R{p.min.toLocaleString()}</span>
                          {p.isElite && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300">
                              HIGH TIER
                            </span>
                          )}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-xs font-medium text-slate-300">
                    2. Select Permitted Investment Amount (ZAR)
                  </label>
                  {selectedProduct?.slug === 'elite' ? (
                    <span className="text-[11px] text-amber-300 font-mono font-medium">
                      Elite Range: R10,000 – R2,000,000
                    </span>
                  ) : (
                    <span className="text-[11px] text-slate-400 font-mono">
                      Standard Range: R500 – R5,000
                    </span>
                  )}
                </div>

                {selectedProduct?.slug === 'elite' ? (
                  <div className="space-y-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {ELITE_AMOUNTS.map((amt) => {
                        const isSelected = selectedAmount === amt;
                        return (
                          <button
                            type="button"
                            key={amt}
                            onClick={() => setSelectedAmount(amt)}
                            className={`py-3 px-2 rounded-xl border font-mono text-center transition-all ${
                              isSelected
                                ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-black font-bold border-amber-300 shadow-md shadow-amber-500/30'
                                : 'bg-slate-950 border-slate-800 text-slate-200 hover:border-amber-500/40'
                            }`}
                          >
                            <div className="text-sm font-semibold">
                              R {amt >= 1000000 ? `${amt / 1000000}M` : amt >= 1000 ? `${amt / 1000}k` : amt.toLocaleString()}
                            </div>
                            <div className="text-[10px] text-slate-400 opacity-80">
                              R {amt.toLocaleString()}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {STANDARD_AMOUNTS.map((amt) => {
                      const isBelowMin = selectedProduct && amt < selectedProduct.minAmount;
                      const isSelected = selectedAmount === amt;
                      return (
                        <button
                          type="button"
                          key={amt}
                          disabled={Boolean(isBelowMin)}
                          onClick={() => setSelectedAmount(amt)}
                          className={`py-3 px-2 rounded-xl border font-mono text-center transition-all ${
                            isBelowMin
                              ? 'opacity-40 cursor-not-allowed bg-slate-950 border-slate-800 text-slate-500'
                              : isSelected
                              ? 'bg-amber-500 text-black font-bold border-amber-400 shadow-md shadow-amber-500/20'
                              : 'bg-slate-950 border-slate-800 text-slate-200 hover:border-slate-700'
                          }`}
                        >
                          <div className="text-sm font-semibold">R {amt.toLocaleString()}</div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-2">
                  3. Select Payment Method
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('payfast')}
                    className={`p-3.5 rounded-xl border text-left flex items-start space-x-3 transition-all ${
                      paymentMethod === 'payfast'
                        ? 'bg-amber-500/10 border-amber-500/60 shadow-sm shadow-amber-500/20'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <CreditCard className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-xs text-slate-200">
                        PayFast Online Gateway
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Credit/Debit Card, Instant EFT, Masterpass. Real-time verification.
                      </div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('bank_transfer')}
                    className={`p-3.5 rounded-xl border text-left flex items-start space-x-3 transition-all ${
                      paymentMethod === 'bank_transfer'
                        ? 'bg-amber-500/10 border-amber-500/60 shadow-sm shadow-amber-500/20'
                        : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <Building2 className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-xs text-slate-200">
                        Direct Bank Transfer
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        Electronic Funds Transfer. Reconciled by administrator upon receipt.
                      </div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  onClick={handleNextFrom2}
                  className="flex items-center space-x-2 px-5 py-2.5 rounded-xl text-sm font-semibold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 transition-all shadow-md shadow-amber-500/10"
                >
                  <span>Review Order</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: PAYMENT REVIEW */}
          {step === 3 && (
            <div className="space-y-4">
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 divide-y divide-slate-800/80 text-xs">
                <div className="pb-3 flex justify-between items-center">
                  <span className="text-slate-400">Investor</span>
                  <span className="font-medium text-slate-200">{firstName} {lastName}</span>
                </div>
                <div className="py-2.5 flex justify-between items-center">
                  <span className="text-slate-400">Email Address</span>
                  <span className="text-slate-200">{email}</span>
                </div>
                <div className="py-2.5 flex justify-between items-center">
                  <span className="text-slate-400">Selected Product</span>
                  <span className="font-semibold text-amber-300">{selectedProduct?.name}</span>
                </div>
                <div className="py-2.5 flex justify-between items-center">
                  <span className="text-slate-400">Payment Method</span>
                  <span className="text-slate-200">
                    {paymentMethod === 'payfast' ? 'PayFast Online Payment' : 'Direct Electronic Bank Transfer'}
                  </span>
                </div>
                <div className="py-2.5 flex justify-between items-center">
                  <span className="text-slate-400">Platform Processing Fee</span>
                  <span className="font-mono text-emerald-400">R 0.00 (Zero Fee)</span>
                </div>
                <div className="pt-3 flex justify-between items-center font-bold">
                  <span className="text-slate-200 text-sm">Total Payable</span>
                  <span className="text-lg font-mono text-amber-400">
                    R {selectedAmount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                  </span>
                </div>
              </div>

              <div className="flex items-start space-x-2.5 bg-amber-500/5 border border-amber-500/20 p-3 rounded-xl text-[11px] text-slate-300">
                <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  A pending transaction reference will be created in the authoritative financial ledger on submission. Balances and investment capital are recorded upon server-side verification.
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={() => setStep(2)}
                  className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:text-white transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Back</span>
                </button>
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={handleProceedToPayment}
                  className="flex items-center space-x-2 px-6 py-3 rounded-xl text-sm font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 transition-all shadow-lg shadow-amber-500/20 disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Initializing Secure Gateway...</span>
                    </>
                  ) : (
                    <>
                      <span>Proceed to Secure Payment</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: BANK TRANSFER CONFIRMATION */}
          {step === 4 && bankResult && (
            <div className="space-y-4">
              <div className="bg-emerald-500/10 border border-emerald-500/30 p-4 rounded-xl text-xs text-emerald-300 flex items-center space-x-3">
                <Check className="w-5 h-5 shrink-0" />
                <div>
                  <div className="font-bold text-sm">Pending Transaction Created</div>
                  <div>Your unique transaction reference is ready for transfer reconciliation.</div>
                </div>
              </div>

              {/* CRITICAL BANKING APP REQUIREMENT BANNER */}
              <div className="bg-amber-500/15 border-2 border-amber-500/60 p-4 rounded-xl text-xs text-amber-200 space-y-2 shadow-lg shadow-amber-500/10">
                <div className="flex items-center space-x-2 text-amber-300 font-bold text-sm">
                  <AlertCircle className="w-5 h-5 shrink-0 text-amber-400" />
                  <span>CRITICAL REQUIREMENT: BANKING APP ONLY</span>
                </div>
                <p className="leading-relaxed text-amber-100">
                  This payment can <strong>ONLY be performed directly inside your official banking application</strong> (e.g. TymeBank / GoTymeBank app or your South African banking mobile app).
                </p>
                <p className="text-[11px] text-amber-200/80">
                  ⚠️ <strong>Do NOT</strong> attempt payment at retail store tills, supermarket checkouts, or cash deposit machines, as these channels do not record your unique reference.
                </p>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 space-y-3.5 text-xs">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-slate-400 font-medium">Your Unique Transaction Reference</span>
                    <span className="text-[10px] text-amber-400 uppercase font-semibold">Transfer Description</span>
                  </div>
                  <div className="bg-slate-900 border border-amber-500/40 p-3 rounded-lg flex items-center justify-between">
                    <span className="font-mono text-base font-bold text-amber-400 tracking-wider">
                      {bankResult.reference}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText(bankResult.reference);
                        alert('Transaction reference copied to clipboard!');
                      }}
                      className="px-2.5 py-1 text-[11px] rounded bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 transition-colors font-medium"
                    >
                      Copy Reference
                    </button>
                  </div>
                  <div className="bg-amber-500/10 border border-amber-500/30 p-2 rounded-lg mt-2 text-[11px] text-amber-300 leading-snug">
                    📌 <strong>IMPORTANT:</strong> You MUST include this exact reference (<strong>{bankResult.reference}</strong>) in the <strong>payment description / beneficiary reference</strong> field in your banking app so we can identify and allocate your investment.
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 grid grid-cols-2 gap-3.5">
                  <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80">
                    <span className="text-slate-500 block text-[11px]">Account Name / Beneficiary</span>
                    <span className="font-semibold text-slate-100 text-xs mt-0.5 block">{bankResult.bankingDetails.accountName || '[BAHOLO CONSULTING]'}</span>
                  </div>
                  <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80">
                    <span className="text-slate-500 block text-[11px]">Bank</span>
                    <span className="font-semibold text-slate-100 text-xs mt-0.5 block">{bankResult.bankingDetails.bankName || '[TymeBank/GoTymeBank]'}</span>
                  </div>
                  <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 text-[11px]">Account Number</span>
                      <button
                        type="button"
                        onClick={() => {
                          const acc = (bankResult.bankingDetails.accountNumber || '').replace(/[[\]]/g, '');
                          navigator.clipboard?.writeText(acc);
                          alert('Account number copied to clipboard!');
                        }}
                        className="text-[10px] text-amber-400 hover:underline"
                      >
                        Copy
                      </button>
                    </div>
                    <span className="font-mono font-bold text-amber-300 text-sm mt-0.5 block">{bankResult.bankingDetails.accountNumber || '[53002153808]'}</span>
                  </div>
                  <div className="bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/80">
                    <span className="text-slate-500 block text-[11px]">Branch Code</span>
                    <span className="font-mono text-slate-200 text-xs mt-0.5 block">{bankResult.bankingDetails.branchCode || '[678910]'}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-slate-400">Exact Transfer Amount:</span>
                  <div className="text-lg font-bold font-mono text-amber-400">
                    R {bankResult.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                  </div>
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-xl text-xs font-semibold text-black bg-gradient-to-r from-amber-400 to-yellow-300 hover:from-amber-300 hover:to-yellow-200 transition-colors shadow-md shadow-amber-500/10"
                >
                  Understood & Close
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
