import React, { useState, useEffect } from 'react';
import {
  FolderLock,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Eye,
  AlertCircle,
  RefreshCw,
  FileText,
  User,
  ShieldCheck,
  ShieldAlert,
  Download,
  X,
  History,
} from 'lucide-react';
import { ClientDocument, DocumentReviewLog } from '../types/index.js';

interface AdminDocumentVaultProps {
  token: string | null;
}

export const AdminDocumentVault: React.FC<AdminDocumentVaultProps> = ({ token }) => {
  const [stats, setStats] = useState<{
    total: number;
    pending: number;
    underReview: number;
    approved: number;
    rejected: number;
  }>({
    total: 0,
    pending: 0,
    underReview: 0,
    approved: 0,
    rejected: 0,
  });

  const [documents, setDocuments] = useState<ClientDocument[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  // Selected document for detailed review
  const [selectedDoc, setSelectedDoc] = useState<ClientDocument | null>(null);
  const [reviewLogs, setReviewLogs] = useState<DocumentReviewLog[]>([]);
  const [reviewLoading, setReviewLoading] = useState(false);

  // Review decision form
  const [reviewAction, setReviewAction] = useState<'APPROVE' | 'REJECT' | 'UNDER_REVIEW'>('APPROVE');
  const [rejectionReason, setRejectionReason] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchStats = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/documents/stats', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStats(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchDocuments = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (statusFilter !== 'ALL') params.set('status', statusFilter);
      if (categoryFilter !== 'ALL') params.set('category', categoryFilter);
      if (search.trim()) params.set('search', search.trim());

      const res = await fetch(`/api/admin/documents?${params.toString()}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setDocuments(data.documents || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    fetchDocuments();
  }, [token, statusFilter, categoryFilter]);

  const handleOpenDocDetails = async (doc: ClientDocument) => {
    setSelectedDoc(doc);
    setReviewLoading(true);
    setRejectionReason('');
    setReviewAction('APPROVE');
    try {
      const res = await fetch(`/api/admin/documents/${doc.id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedDoc(data.document);
        setReviewLogs(data.reviewLogs || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setReviewLoading(false);
    }
  };

  const handleSubmitReviewDecision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !selectedDoc) return;

    if (reviewAction === 'REJECT' && !rejectionReason.trim()) {
      alert('Please provide an administrative explanation/reason for rejecting this document.');
      return;
    }

    setIsSubmittingReview(true);
    setFeedback(null);

    try {
      const res = await fetch(`/api/admin/documents/${selectedDoc.id}/review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: reviewAction,
          notes: rejectionReason,
        }),
      });

      const data = await res.json();
      setIsSubmittingReview(false);

      if (res.ok) {
        setFeedback({
          type: 'success',
          text: `Document review saved: marked as ${reviewAction}. Client notified.`,
        });
        setSelectedDoc(null);
        fetchStats();
        fetchDocuments();
      } else {
        setFeedback({
          type: 'error',
          text: data.error || 'Failed to submit review decision.',
        });
      }
    } catch {
      setIsSubmittingReview(false);
      setFeedback({ type: 'error', text: 'Network connection error.' });
    }
  };

  return (
    <div className="space-y-6 max-w-7xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <FolderLock className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-100">
              Compliance Document Vault & KYC Verification
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Audited document inspection queue, KYC identity verification, and proof of payment approvals.
          </p>
        </div>

        <button
          onClick={() => {
            fetchStats();
            fetchDocuments();
          }}
          className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Queue</span>
        </button>
      </div>

      {/* Feedback Banner */}
      {feedback && (
        <div
          className={`p-3.5 rounded-2xl text-xs flex items-center justify-between space-x-3 animate-fadeIn ${
            feedback.type === 'success'
              ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
              : 'bg-red-500/10 border border-red-500/30 text-red-400'
          }`}
        >
          <div className="flex items-center space-x-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            )}
            <span>{feedback.text}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
        <div
          onClick={() => setStatusFilter('ALL')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            statusFilter === 'ALL'
              ? 'bg-slate-900 border-amber-500/40 shadow-lg shadow-amber-500/5'
              : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900/60'
          }`}
        >
          <div className="text-[11px] text-slate-400 font-medium">Total Vault Files</div>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">{stats.total}</div>
        </div>

        <div
          onClick={() => setStatusFilter('PENDING')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            statusFilter === 'PENDING'
              ? 'bg-slate-900 border-amber-400 shadow-lg shadow-amber-500/5'
              : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900/60'
          }`}
        >
          <div className="text-[11px] text-amber-400 font-medium">Pending Review</div>
          <div className="text-xl font-bold font-mono text-amber-300 mt-1">{stats.pending}</div>
        </div>

        <div
          onClick={() => setStatusFilter('UNDER_REVIEW')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            statusFilter === 'UNDER_REVIEW'
              ? 'bg-slate-900 border-blue-400 shadow-lg shadow-blue-500/5'
              : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900/60'
          }`}
        >
          <div className="text-[11px] text-blue-400 font-medium">Under Review</div>
          <div className="text-xl font-bold font-mono text-blue-300 mt-1">{stats.underReview}</div>
        </div>

        <div
          onClick={() => setStatusFilter('APPROVED')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            statusFilter === 'APPROVED'
              ? 'bg-slate-900 border-emerald-400 shadow-lg shadow-emerald-500/5'
              : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900/60'
          }`}
        >
          <div className="text-[11px] text-emerald-400 font-medium">Approved</div>
          <div className="text-xl font-bold font-mono text-emerald-300 mt-1">{stats.approved}</div>
        </div>

        <div
          onClick={() => setStatusFilter('REJECTED')}
          className={`cursor-pointer p-4 rounded-2xl border transition-all ${
            statusFilter === 'REJECTED'
              ? 'bg-slate-900 border-red-400 shadow-lg shadow-red-500/5'
              : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-900/60'
          }`}
        >
          <div className="text-[11px] text-red-400 font-medium">Rejected</div>
          <div className="text-xl font-bold font-mono text-red-400 mt-1">{stats.rejected}</div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchDocuments()}
            placeholder="Search by customer name, email, or document title..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-10 pr-3 py-2 text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-amber-500/60"
          />
        </div>

        <div className="flex items-center space-x-2">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="ALL">All Categories</option>
            <option value="ID_DOCUMENT">Identity / Passport</option>
            <option value="PROOF_OF_PAYMENT">Proof of Payment</option>
            <option value="ADDRESS_VERIFICATION">Address Proof</option>
            <option value="SUPPORTING_DOC">Supporting Documents</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
          >
            <option value="ALL">All Statuses</option>
            <option value="PENDING">Pending Review</option>
            <option value="UNDER_REVIEW">Under Review</option>
            <option value="APPROVED">Approved</option>
            <option value="REJECTED">Rejected</option>
          </select>
        </div>
      </div>

      {/* Documents Table */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
        {isLoading ? (
          <div className="p-12 text-center text-xs text-slate-400 flex items-center justify-center space-x-2">
            <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
            <span>Loading document compliance queue...</span>
          </div>
        ) : documents.length === 0 ? (
          <div className="p-12 text-center text-xs text-slate-500">
            No compliance documents matched the selected filters.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Document Title</th>
                  <th className="py-3 px-4">Category</th>
                  <th className="py-3 px-4">Customer</th>
                  <th className="py-3 px-4">Size</th>
                  <th className="py-3 px-4">Submitted</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Review Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {documents.map((doc) => {
                  const sizeInKb = (doc.file_size / 1024).toFixed(1);
                  return (
                    <tr key={doc.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3.5 px-4 font-semibold text-slate-100 flex items-center space-x-2">
                        <FileText className="w-4 h-4 text-amber-400 shrink-0" />
                        <span className="truncate max-w-[200px]">{doc.name}</span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-300 text-[11px]">
                        {doc.category.replace(/_/g, ' ')}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-200">
                          {doc.customer_first_name} {doc.customer_last_name}
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {doc.customer_email}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-slate-400 font-mono text-[11px]">
                        {sizeInKb} KB
                      </td>
                      <td className="py-3.5 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                        {new Date(doc.created_at).toLocaleDateString()}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            doc.status === 'APPROVED'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : doc.status === 'REJECTED'
                              ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                              : doc.status === 'UNDER_REVIEW'
                              ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                              : 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                          }`}
                        >
                          {doc.status.replace(/_/g, ' ')}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => handleOpenDocDetails(doc)}
                          className="px-3 py-1.5 rounded-xl font-bold text-xs bg-amber-400 text-black hover:bg-amber-300 transition-colors"
                        >
                          Inspect & Review
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODAL: DOCUMENT REVIEW & INSPECTION DRAWER */}
      {/* ========================================================================= */}
      {selectedDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-2xl shadow-2xl p-6 sm:p-7 space-y-5 max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-100">Document Compliance Inspection</h3>
                  <p className="text-[10px] text-slate-400 font-mono">
                    ID: {selectedDoc.id} • Audited Access
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedDoc(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document and Customer Metadata */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-400 block text-[11px]">Customer Profile</span>
                <span className="font-semibold text-slate-100 text-sm">
                  {selectedDoc.customer_first_name} {selectedDoc.customer_last_name}
                </span>
                <span className="text-slate-400 block font-mono text-[11px] mt-0.5">
                  {selectedDoc.customer_email}
                </span>
                <span className="text-slate-400 block text-[11px]">
                  Phone: {selectedDoc.customer_phone || 'Unverified'}
                </span>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px]">Document Details</span>
                <span className="font-semibold text-slate-100 text-sm">{selectedDoc.name}</span>
                <span className="text-amber-300 block text-[11px] font-medium mt-0.5">
                  Category: {selectedDoc.category.replace(/_/g, ' ')}
                </span>
                <span className="text-slate-400 block font-mono text-[11px]">
                  Size: {(selectedDoc.file_size / 1024).toFixed(1)} KB • Type: {selectedDoc.file_type}
                </span>
              </div>
            </div>

            {/* Audited Secure View Button */}
            <div className="p-4 rounded-xl bg-amber-500/5 border border-amber-500/20 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs">
              <div>
                <h4 className="font-semibold text-slate-200">Secure Document Stream</h4>
                <p className="text-[11px] text-slate-400">
                  Opening document streams file directly from private vault; this action is recorded in the immutable audit log.
                </p>
              </div>
              <a
                href={`/api/admin/documents/${selectedDoc.id}/view`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-xl font-bold text-xs bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/30 transition-colors flex items-center space-x-1.5 shrink-0"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>Open in Audited Viewer</span>
              </a>
            </div>

            {/* Audit Review Logs */}
            {reviewLogs.length > 0 && (
              <div className="space-y-2 text-xs">
                <span className="font-semibold text-slate-300 flex items-center space-x-1.5">
                  <History className="w-3.5 h-3.5 text-amber-400" />
                  <span>Document Audit Trail:</span>
                </span>
                <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 divide-y divide-slate-800/80 max-h-36 overflow-y-auto">
                  {reviewLogs.map((log) => (
                    <div key={log.id} className="py-2 text-[11px] first:pt-0 last:pb-0">
                      <div className="flex justify-between text-slate-400">
                        <span className="font-mono text-amber-400 font-bold uppercase">{log.action}</span>
                        <span>{new Date(log.created_at).toLocaleString()}</span>
                      </div>
                      <div className="text-slate-300 mt-0.5">{log.notes || 'No review notes'}</div>
                      <div className="text-slate-500 text-[10px]">Staff: {log.admin_email}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Review Decision Form */}
            <form onSubmit={handleSubmitReviewDecision} className="space-y-4 text-xs pt-2 border-t border-slate-800">
              <h4 className="font-bold text-slate-100 text-sm">Submit Review Decision</h4>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Decision</label>
                <select
                  value={reviewAction}
                  onChange={(e) => setReviewAction(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-semibold"
                >
                  <option value="APPROVE">APPROVE (Verified & Compliant)</option>
                  <option value="REJECT">REJECT (Unreadable / Incomplete / Mismatch)</option>
                  <option value="UNDER_REVIEW">UNDER REVIEW (Pending Secondary Inspection)</option>
                </select>
              </div>

              {reviewAction === 'APPROVE' && selectedDoc.category === 'ID_DOCUMENT' && (
                <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-emerald-300 text-[11px] flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>
                    Approving this National ID will automatically elevate customer account KYC status to <strong>Tier 1 Verified</strong>.
                  </span>
                </div>
              )}

              {reviewAction === 'REJECT' && (
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Administrative Rejection Reason (Visible to Client & Audited) <span className="text-red-400">*</span>
                  </label>
                  <textarea
                    rows={3}
                    required
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    placeholder="State clear reasons why the document is rejected (e.g. Document edges cropped, expired passport, unreadable blurred scan)..."
                    className="w-full bg-slate-950 border border-red-500/40 rounded-xl p-3 text-slate-100 focus:outline-none focus:border-red-400 resize-none"
                  />
                </div>
              )}

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedDoc(null)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Close
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingReview}
                  className={`px-6 py-2.5 rounded-xl font-bold text-xs transition-all flex items-center space-x-2 disabled:opacity-50 ${
                    reviewAction === 'APPROVE'
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-black'
                      : reviewAction === 'REJECT'
                      ? 'bg-red-500 hover:bg-red-400 text-white'
                      : 'bg-blue-500 hover:bg-blue-400 text-white'
                  }`}
                >
                  {isSubmittingReview ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Saving Decision...</span>
                    </>
                  ) : (
                    <span>Commit Review Decision</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
