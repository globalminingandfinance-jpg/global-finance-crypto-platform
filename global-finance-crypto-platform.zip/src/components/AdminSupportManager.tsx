import React, { useState, useEffect } from 'react';
import {
  LifeBuoy,
  Search,
  Filter,
  CheckCircle2,
  AlertCircle,
  Clock,
  ArrowLeft,
  Send,
  Paperclip,
  FileText,
  X,
  RefreshCw,
  Lock,
  MessageSquare,
  ShieldAlert,
  ShieldCheck,
  User,
  ChevronLeft,
  ChevronRight,
  AlertTriangle,
} from 'lucide-react';
import { SupportTicket, TicketMessage, TicketCategory, TicketPriority, TicketStatus } from '../types/index.js';

interface AdminSupportManagerProps {
  token: string | null;
}

const CATEGORY_LABELS: Record<string, string> = {
  general_support: 'General Support',
  complaints: 'Formal Complaints',
  deposits: 'Deposits & PayFast',
  withdrawals: 'Withdrawals & Payouts',
  account_verification: 'Account & KYC Verification',
  technical_problems: 'Technical Problems',
  other_enquiries: 'Other Enquiries',
};

export const AdminSupportManager: React.FC<AdminSupportManagerProps> = ({ token }) => {
  const [stats, setStats] = useState<any>(null);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 25, total: 0, totalPages: 1 });
  const [isLoading, setIsLoading] = useState(false);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  // Selected ticket for modal / drawer
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [conversation, setConversation] = useState<TicketMessage[]>([]);
  const [loadingConversation, setLoadingConversation] = useState(false);

  // Composer state
  const [replyText, setReplyText] = useState('');
  const [isInternalNote, setIsInternalNote] = useState(false);
  const [statusUpdateOption, setStatusUpdateOption] = useState<string>('AWAITING_CUSTOMER');
  const [priorityUpdateOption, setPriorityUpdateOption] = useState<string>('');
  const [composerAttachment, setComposerAttachment] = useState<{ name: string; data: string } | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [composerFeedback, setComposerFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Fetch KPI statistics
  const fetchStats = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/admin/tickets/stats', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setStats(await res.json());
      }
    } catch (err) {
      console.error('Failed to load ticket stats:', err);
    }
  };

  // Fetch Tickets List
  const fetchTickets = async (page = 1) => {
    if (!token) return;
    setIsLoading(true);
    try {
      let url = `/api/admin/tickets?page=${page}&limit=25`;
      if (searchQuery.trim()) url += `&q=${encodeURIComponent(searchQuery.trim())}`;
      if (categoryFilter) url += `&category=${encodeURIComponent(categoryFilter)}`;
      if (priorityFilter) url += `&priority=${encodeURIComponent(priorityFilter)}`;
      if (statusFilter) url += `&status=${encodeURIComponent(statusFilter)}`;

      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setTickets(data.tickets || []);
        if (data.pagination) setPagination(data.pagination);
      }
    } catch (err) {
      console.error('Failed to load admin tickets:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    fetchTickets(1);
  }, [token, categoryFilter, priorityFilter, statusFilter]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchTickets(1);
  };

  // Load detailed ticket conversation
  const openTicket = async (ticketId: string) => {
    if (!token) return;
    setSelectedTicketId(ticketId);
    setLoadingConversation(true);
    setComposerFeedback(null);
    setReplyText('');
    setComposerAttachment(null);
    setIsInternalNote(false);

    try {
      const res = await fetch(`/api/admin/tickets/${ticketId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSelectedTicket(data.ticket);
        setConversation(data.messages || []);
        setStatusUpdateOption(data.ticket.status);
        setPriorityUpdateOption(data.ticket.priority);
      } else {
        alert('Failed to load ticket details.');
        setSelectedTicketId(null);
      }
    } catch {
      alert('Network error loading ticket details.');
      setSelectedTicketId(null);
    } finally {
      setLoadingConversation(false);
    }
  };

  // File Upload Handling
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      alert('File size exceeds 2MB limit.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setComposerAttachment({ name: file.name, data: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  // Submit Admin Reply or Internal Note
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !selectedTicketId) return;

    if (!replyText.trim()) {
      setComposerFeedback({ type: 'error', text: 'Message or note text cannot be empty.' });
      return;
    }

    setIsSending(true);
    setComposerFeedback(null);

    try {
      const res = await fetch(`/api/admin/tickets/${selectedTicketId}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          message: replyText.trim(),
          isInternalNote,
          statusUpdate: statusUpdateOption,
          attachmentName: composerAttachment?.name,
          attachmentData: composerAttachment?.data,
        }),
      });

      const data = await res.json();
      setIsSending(false);

      if (res.ok && data.success) {
        setConversation((prev) => [...prev, data.message]);
        if (selectedTicket) {
          setSelectedTicket({
            ...selectedTicket,
            status: data.updatedStatus as TicketStatus,
            last_activity_at: new Date().toISOString(),
          });
        }
        setReplyText('');
        setComposerAttachment(null);
        setComposerFeedback({
          type: 'success',
          text: isInternalNote
            ? 'Internal note saved securely. Never visible to customer.'
            : 'Reply sent to customer. Email and in-app notifications dispatched.',
        });
        fetchStats();
        fetchTickets(pagination.page);
      } else {
        setComposerFeedback({ type: 'error', text: data.error || 'Failed to submit response.' });
      }
    } catch {
      setIsSending(false);
      setComposerFeedback({ type: 'error', text: 'Network error submitting response.' });
    }
  };

  // Quick Status or Priority Change
  const handleQuickStatusChange = async (newStatus: TicketStatus) => {
    if (!token || !selectedTicketId) return;
    try {
      const res = await fetch(`/api/admin/tickets/${selectedTicketId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        setSelectedTicket((prev) => (prev ? { ...prev, status: newStatus } : null));
        setStatusUpdateOption(newStatus);
        fetchStats();
        fetchTickets(pagination.page);
      }
    } catch (err) {
      console.error('Failed to change status:', err);
    }
  };

  const handleQuickPriorityChange = async (newPriority: TicketPriority) => {
    if (!token || !selectedTicketId) return;
    try {
      const res = await fetch(`/api/admin/tickets/${selectedTicketId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ priority: newPriority }),
      });
      if (res.ok) {
        setSelectedTicket((prev) => (prev ? { ...prev, priority: newPriority } : null));
        setPriorityUpdateOption(newPriority);
        fetchTickets(pagination.page);
      }
    } catch (err) {
      console.error('Failed to change priority:', err);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-serif text-slate-100">
            Support & Complaints Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Review customer enquiries, manage escalated complaints, send official replies, and maintain internal notes.
          </p>
        </div>
        <button
          onClick={() => {
            fetchStats();
            fetchTickets(pagination.page);
          }}
          className="flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh</span>
        </button>
      </div>

      {/* KPI Dashboard Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
          <span className="text-[11px] text-slate-400">Total Enquiries</span>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">
            {stats?.total ?? 0}
          </div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-blue-500/30">
          <span className="text-[11px] text-blue-400">New / Unassigned</span>
          <div className="text-xl font-bold font-mono text-blue-300 mt-1">
            {stats?.new ?? 0}
          </div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-amber-500/30">
          <span className="text-[11px] text-amber-400">In Progress</span>
          <div className="text-xl font-bold font-mono text-amber-300 mt-1">
            {stats?.inProgress ?? 0}
          </div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-purple-500/30">
          <span className="text-[11px] text-purple-400">Awaiting Customer</span>
          <div className="text-xl font-bold font-mono text-purple-300 mt-1">
            {stats?.awaitingCustomer ?? 0}
          </div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/60 border border-emerald-500/30">
          <span className="text-[11px] text-emerald-400">Resolved / Closed</span>
          <div className="text-xl font-bold font-mono text-emerald-300 mt-1">
            {stats?.resolved ?? 0}
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 space-y-3">
        <form onSubmit={handleSearchSubmit} className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search reference (GF-2026-00001), subject, customer email or name..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-amber-500/60"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500/60"
          >
            <option value="">All Categories</option>
            {Object.entries(CATEGORY_LABELS).map(([k, label]) => (
              <option key={k} value={k}>
                {label}
              </option>
            ))}
          </select>

          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500/60"
          >
            <option value="">All Priorities</option>
            <option value="LOW">Low</option>
            <option value="NORMAL">Normal</option>
            <option value="HIGH">High</option>
            <option value="URGENT">Urgent</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:outline-none focus:border-amber-500/60"
          >
            <option value="">All Statuses</option>
            <option value="OPEN">Open (New)</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="AWAITING_CUSTOMER">Awaiting Customer</option>
            <option value="RESOLVED">Resolved</option>
            <option value="CLOSED">Closed</option>
          </select>

          <button
            type="submit"
            className="px-4 py-2 rounded-xl text-xs font-semibold bg-amber-500 text-black hover:bg-amber-400"
          >
            Search
          </button>
        </form>
      </div>

      {/* Tickets Table */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 font-medium">
              <tr>
                <th className="py-3 px-4">Reference</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Subject</th>
                <th className="py-3 px-4">Priority</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Last Activity</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {tickets.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    <LifeBuoy className="w-8 h-8 mx-auto mb-2 opacity-30 text-slate-400" />
                    <p>No support tickets found matching current filters.</p>
                  </td>
                </tr>
              ) : (
                tickets.map((t) => {
                  return (
                    <tr
                      key={t.id}
                      className="hover:bg-slate-850/50 transition-colors cursor-pointer"
                      onClick={() => openTicket(t.id)}
                    >
                      <td className="py-3.5 px-4 font-mono font-bold text-amber-400 whitespace-nowrap">
                        {t.reference}
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-200">
                          {t.customer_first_name} {t.customer_last_name}
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono truncate max-w-[180px]">
                          {t.customer_email}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                          {CATEGORY_LABELS[t.category] || t.category}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-medium text-slate-200">
                        <div className="max-w-xs truncate">{t.subject}</div>
                        {t.total_messages && (
                          <div className="text-[10px] text-slate-500">
                            {t.total_messages} message(s)
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            t.priority === 'URGENT'
                              ? 'bg-red-500/20 text-red-300 border border-red-500/30 animate-pulse'
                              : t.priority === 'HIGH'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : t.priority === 'LOW'
                              ? 'bg-slate-800 text-slate-400'
                              : 'bg-blue-500/10 text-blue-300 border border-blue-500/20'
                          }`}
                        >
                          {t.priority}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            t.status === 'RESOLVED' || t.status === 'CLOSED'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                              : t.status === 'AWAITING_CUSTOMER'
                              ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                              : t.status === 'IN_PROGRESS'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          }`}
                        >
                          {t.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                        {new Date(t.last_activity_at || t.created_at).toLocaleString()}
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            openTicket(t.id);
                          }}
                          className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-amber-500 hover:text-black text-slate-200 transition-colors"
                        >
                          Manage & Reply
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>
              Showing {tickets.length} of {pagination.total} tickets (Page {pagination.page} of {pagination.totalPages})
            </span>
            <div className="flex items-center space-x-2">
              <button
                disabled={pagination.page <= 1}
                onClick={() => fetchTickets(pagination.page - 1)}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 disabled:opacity-30"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                disabled={pagination.page >= pagination.totalPages}
                onClick={() => fetchTickets(pagination.page + 1)}
                className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 disabled:opacity-30"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ======================================================================= */}
      {/* DETAILED TICKET MANAGEMENT DRAWER / MODAL */}
      {/* ======================================================================= */}
      {selectedTicketId && selectedTicket && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end">
          <div className="w-full max-w-3xl bg-slate-950 border-l border-slate-800 h-full flex flex-col shadow-2xl overflow-hidden">
            {/* Drawer Header */}
            <div className="p-6 border-b border-slate-800 bg-slate-900/70 flex items-center justify-between shrink-0">
              <div className="flex items-center space-x-3">
                <span className="font-mono font-bold text-amber-400 text-sm">
                  {selectedTicket.reference}
                </span>
                <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {CATEGORY_LABELS[selectedTicket.category] || selectedTicket.category}
                </span>
              </div>
              <button
                onClick={() => setSelectedTicketId(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Customer Account Identity Details */}
              <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-4 text-xs space-y-2">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-sm text-slate-100">{selectedTicket.subject}</h3>
                    <div className="text-slate-400 mt-0.5">
                      Customer: <strong className="text-slate-200">{selectedTicket.customer_first_name} {selectedTicket.customer_last_name}</strong> •{' '}
                      <span className="font-mono">{selectedTicket.customer_email}</span>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-500">
                    Opened {new Date(selectedTicket.created_at).toLocaleDateString()}
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center gap-4 text-[11px] text-slate-400">
                  <span>Phone: <strong className="text-slate-300">{selectedTicket.customer_phone || 'None'}</strong></span>
                  <span>Country: <strong className="text-slate-300">{selectedTicket.customer_country || 'South Africa'}</strong></span>
                  <span>KYC: <strong className="text-emerald-400 capitalize">{selectedTicket.customer_kyc_status || 'retail'}</strong></span>
                  <span>Account: <strong className="text-slate-200 capitalize">{selectedTicket.customer_account_status || 'active'}</strong></span>
                </div>
              </div>

              {/* Status & Priority Controls Toolbar */}
              <div className="p-4 bg-slate-900/40 border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center space-x-2">
                  <span className="text-slate-400">Current Status:</span>
                  <select
                    value={selectedTicket.status}
                    onChange={(e) => handleQuickStatusChange(e.target.value as TicketStatus)}
                    className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-slate-200 font-bold focus:outline-none"
                  >
                    <option value="OPEN">OPEN (New)</option>
                    <option value="IN_PROGRESS">IN PROGRESS</option>
                    <option value="AWAITING_CUSTOMER">AWAITING CUSTOMER</option>
                    <option value="RESOLVED">RESOLVED</option>
                    <option value="CLOSED">CLOSED</option>
                  </select>
                </div>

                <div className="flex items-center space-x-2">
                  <span className="text-slate-400">Priority:</span>
                  <select
                    value={selectedTicket.priority}
                    onChange={(e) => handleQuickPriorityChange(e.target.value as TicketPriority)}
                    className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-slate-200 font-bold focus:outline-none"
                  >
                    <option value="LOW">LOW</option>
                    <option value="NORMAL">NORMAL</option>
                    <option value="HIGH">HIGH</option>
                    <option value="URGENT">URGENT</option>
                  </select>
                </div>
              </div>

              {/* Chronological Messages Stream */}
              <div className="space-y-4">
                <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  Complete Ticket History & Internal Notes
                </h4>

                {conversation.map((m) => {
                  const isNote = m.is_internal_note === 1;
                  const isAdmin = m.sender_role === 'admin';

                  return (
                    <div
                      key={m.id}
                      className={`p-4 rounded-2xl border text-xs leading-relaxed space-y-2 ${
                        isNote
                          ? 'bg-amber-950/20 border-amber-500/40 text-amber-100 shadow-sm'
                          : isAdmin
                          ? 'bg-slate-900 border-slate-700 ml-4'
                          : 'bg-slate-950 border-slate-800 mr-4'
                      }`}
                    >
                      <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                        <div className="flex items-center space-x-2">
                          {isNote ? (
                            <>
                              <div className="w-5 h-5 rounded bg-amber-500 text-black flex items-center justify-center font-bold">
                                <Lock className="w-3 h-3" />
                              </div>
                              <span className="font-bold text-amber-400 uppercase tracking-wider text-[11px]">
                                Private Internal Note (Hidden from Customer)
                              </span>
                            </>
                          ) : isAdmin ? (
                            <>
                              <div className="w-5 h-5 rounded bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                                <ShieldCheck className="w-3 h-3" />
                              </div>
                              <span className="font-semibold text-slate-200">
                                Administrator Public Reply
                              </span>
                            </>
                          ) : (
                            <>
                              <div className="w-5 h-5 rounded bg-slate-800 text-slate-300 flex items-center justify-center font-bold">
                                <User className="w-3 h-3" />
                              </div>
                              <span className="font-semibold text-slate-200">
                                Customer ({selectedTicket.customer_first_name})
                              </span>
                            </>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-500">
                          {new Date(m.created_at).toLocaleString()}
                        </span>
                      </div>

                      <p className="whitespace-pre-wrap">{m.message}</p>

                      {m.attachment_name && m.attachment_data && (
                        <div className="pt-2">
                          <a
                            href={m.attachment_data}
                            download={m.attachment_name}
                            className="inline-flex items-center space-x-1.5 p-1.5 rounded-lg bg-black/40 border border-slate-800 text-amber-400 hover:text-amber-300"
                          >
                            <FileText className="w-3 h-3" />
                            <span className="underline">{m.attachment_name}</span>
                          </a>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Composer Footer */}
            <div className="p-6 border-t border-slate-800 bg-slate-900/90 shrink-0 space-y-4">
              {/* Toggle: Customer Reply vs Internal Note */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setIsInternalNote(false)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      !isInternalNote
                        ? 'bg-amber-500 text-black shadow-sm font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Public Customer Reply
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsInternalNote(true)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center space-x-1.5 ${
                      isInternalNote
                        ? 'bg-amber-400 text-black shadow-sm font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Lock className="w-3 h-3" />
                    <span>Private Internal Note</span>
                  </button>
                </div>

                {!isInternalNote && (
                  <div className="flex items-center space-x-2 text-xs">
                    <span className="text-slate-400">After reply set status:</span>
                    <select
                      value={statusUpdateOption}
                      onChange={(e) => setStatusUpdateOption(e.target.value)}
                      className="bg-slate-950 border border-slate-800 rounded-lg px-2 py-1 text-slate-200 text-xs"
                    >
                      <option value="AWAITING_CUSTOMER">Awaiting Customer</option>
                      <option value="IN_PROGRESS">In Progress</option>
                      <option value="RESOLVED">Resolved</option>
                      <option value="CLOSED">Closed</option>
                    </select>
                  </div>
                )}
              </div>

              {isInternalNote && (
                <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[11px] text-amber-300 flex items-center space-x-2">
                  <Lock className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    <strong>Internal Staff Note:</strong> This note will be recorded in the audit ledger and viewable only by administrators. The customer will NOT receive any notification or email.
                  </span>
                </div>
              )}

              {composerFeedback && (
                <div
                  className={`p-3 rounded-xl text-xs flex items-center space-x-2 ${
                    composerFeedback.type === 'success'
                      ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
                      : 'bg-red-500/10 border border-red-500/30 text-red-400'
                  }`}
                >
                  {composerFeedback.type === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 shrink-0" />
                  )}
                  <span>{composerFeedback.text}</span>
                </div>
              )}

              <form onSubmit={handleSendMessage} className="space-y-3">
                <textarea
                  rows={3}
                  required
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder={
                    isInternalNote
                      ? 'Add private administrative notes, customer risk observations, investigation details...'
                      : `Write official response to ${selectedTicket.customer_first_name} (will trigger email & notification)...`
                  }
                  className={`w-full bg-slate-950 border rounded-xl p-3 text-xs text-slate-100 focus:outline-none resize-none ${
                    isInternalNote
                      ? 'border-amber-500/50 focus:border-amber-400'
                      : 'border-slate-800 focus:border-amber-500/60'
                  }`}
                />

                <div className="flex items-center justify-between">
                  <div>
                    {composerAttachment ? (
                      <div className="flex items-center space-x-2 p-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200">
                        <FileText className="w-3.5 h-3.5 text-amber-400" />
                        <span className="truncate max-w-[200px]">{composerAttachment.name}</span>
                        <button
                          type="button"
                          onClick={() => setComposerAttachment(null)}
                          className="text-slate-500 hover:text-red-400"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <label className="inline-flex items-center space-x-1.5 px-2.5 py-1.5 border border-slate-800 hover:border-slate-700 rounded-lg cursor-pointer bg-slate-950 text-slate-400 hover:text-white text-xs transition-colors">
                        <Paperclip className="w-3 h-3" />
                        <span>Attach File</span>
                        <input
                          type="file"
                          className="hidden"
                          onChange={handleFileUpload}
                          accept="image/*,.pdf,.doc,.docx"
                        />
                      </label>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={isSending}
                    className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
                      isInternalNote
                        ? 'bg-amber-400 text-black hover:bg-amber-300'
                        : 'bg-gradient-to-r from-amber-500 to-yellow-400 text-black hover:from-amber-400'
                    } disabled:opacity-50`}
                  >
                    {isSending ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Saving...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-3.5 h-3.5" />
                        <span>{isInternalNote ? 'Save Internal Note' : 'Send Customer Response'}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
