import React, { useState, useEffect } from 'react';
import {
  Wallet,
  Coins,
  TrendingUp,
  Download,
  Calendar,
  Layers,
  CheckCircle2,
  Clock,
  Shield,
  RefreshCw,
  AlertCircle,
  FileText,
  PieChart,
  ArrowUpRight,
  ArrowDownRight,
  Info,
} from 'lucide-react';

interface Props {
  token: string | null;
  onOpenCheckout?: () => void;
}

interface ValuedCryptoHolding {
  id: string;
  symbol: string;
  network: string;
  quantity: number;
  custodyType: string;
  currentPriceZar: number;
  currentPriceUsd: number;
  valuationZar: number;
  valuationUsd: number;
  lastVerifiedAt: string;
}

interface CustomerFinancialData {
  currency: string;
  summary: {
    confirmedDeposits: number;
    allocatedCapital: number;
    availableCash: number;
    pendingDeposits: number;
    pendingWithdrawals: number;
    activeInvestmentsCount: number;
  };
  cryptoHoldings: ValuedCryptoHolding[];
  totalCryptoValuationZar: number;
  totalPortfolioValuationZar: number;
  assetAllocation: {
    cashPercent: number;
    computingPercent: number;
    cryptoPercent: number;
  };
  recentLedgerActivity: Array<{
    id: string;
    transaction_id: string;
    entry_type: string;
    debit: number;
    credit: number;
    balance_after: number;
    description: string;
    created_at: string;
  }>;
  asOf: string;
  disclosures: string[];
}

export const CustomerFinancialOverview: React.FC<Props> = ({ token, onOpenCheckout }) => {
  const [data, setData] = useState<CustomerFinancialData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchFinancialOverview = async (isManual = false) => {
    if (!token) return;
    if (isManual) setIsRefreshing(true);
    else setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/customer/financial-overview', {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) throw new Error('Unable to retrieve customer financial overview.');
      const json = await res.json();
      setData(json);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error communicating with financial service.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchFinancialOverview();
  }, [token]);

  const formatZAR = (val: number | undefined | null) => {
    const num = Number(val || 0);
    return `R ${num.toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const handleDownloadStatement = () => {
    window.location.href = `/api/customer/statement/download`;
  };

  if (isLoading) {
    return (
      <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center space-y-4">
        <RefreshCw className="w-8 h-8 text-amber-400 animate-spin mx-auto" />
        <h3 className="text-base font-semibold text-slate-100">Synchronizing Personal Financial Overview</h3>
        <p className="text-xs text-slate-400 max-w-sm mx-auto">
          Reconciling authoritative ledger balances, verified custodial holdings, and live spot valuations...
        </p>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-red-500/10 border border-red-500/30 rounded-3xl p-8 text-center space-y-3">
        <AlertCircle className="w-8 h-8 text-red-400 mx-auto" />
        <h3 className="text-base font-bold text-red-300">Unable to Load Financial Overview</h3>
        <p className="text-xs text-red-400/90">{error || 'Server connection failed.'}</p>
        <button
          onClick={() => fetchFinancialOverview()}
          className="px-4 py-2 rounded-xl text-xs font-bold text-black bg-amber-400 hover:bg-amber-300"
        >
          Try Again
        </button>
      </div>
    );
  }

  const { summary, cryptoHoldings, totalCryptoValuationZar, totalPortfolioValuationZar, assetAllocation, recentLedgerActivity, disclosures } = data;

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* 1. TOP HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-[10px] uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
              Personal Financial Overview
            </span>
            <span className="text-slate-600">•</span>
            <span className="text-[11px] text-slate-400">Double-Entry Ledger Verified</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-100 mt-1">
            Account Financial Overview & Statements
          </h1>
          <p className="text-xs text-slate-400 max-w-2xl mt-0.5">
            Transparent breakdown of your verified cash balances, active computational capital allocations, verified cryptocurrency outputs, and official downloadable statements.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => fetchFinancialOverview(true)}
            disabled={isRefreshing}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-xs text-slate-300 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : 'text-slate-400'}`} />
            <span>{isRefreshing ? 'Syncing...' : 'Sync Balance'}</span>
          </button>

          <button
            onClick={handleDownloadStatement}
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Statement (CSV)</span>
          </button>
        </div>
      </div>

      {/* 2. TOTAL COMBINED PORTFOLIO VALUATION BANNER */}
      <div className="bg-gradient-to-r from-amber-500/10 via-slate-900 to-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block mb-1">
              Total Combined Portfolio Valuation
            </span>
            <div className="text-3xl sm:text-4xl font-serif font-bold text-slate-100 font-mono">
              {formatZAR(totalPortfolioValuationZar)}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Evaluated in South African Rand (ZAR) using live spot prices for digital holdings.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl text-left">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Available Cash</span>
              <span className="text-base font-mono font-bold text-blue-300">{formatZAR(summary.availableCash)}</span>
            </div>
            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl text-left">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Computing Capital</span>
              <span className="text-base font-mono font-bold text-amber-300">{formatZAR(summary.allocatedCapital)}</span>
            </div>
            <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-2xl text-left">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Digital Assets</span>
              <span className="text-base font-mono font-bold text-emerald-300">{formatZAR(totalCryptoValuationZar)}</span>
            </div>
          </div>
        </div>

        {/* Portfolio Allocation Progress Bar */}
        <div className="space-y-2 pt-2 border-t border-slate-800/80">
          <div className="flex justify-between items-center text-xs">
            <span className="text-slate-400 font-medium">Asset Allocation Distribution</span>
            <span className="text-slate-500 text-[11px]">100% Fully Backed</span>
          </div>
          <div className="h-3 w-full bg-slate-950 rounded-full overflow-hidden flex p-0.5 border border-slate-800">
            <div
              style={{ width: `${Math.max(5, assetAllocation.cashPercent)}%` }}
              title={`Available Cash: ${assetAllocation.cashPercent}%`}
              className="bg-blue-400 h-full rounded-l-full"
            />
            <div
              style={{ width: `${Math.max(5, assetAllocation.computingPercent)}%` }}
              title={`Allocated Computing: ${assetAllocation.computingPercent}%`}
              className="bg-amber-400 h-full"
            />
            <div
              style={{ width: `${Math.max(5, assetAllocation.cryptoPercent)}%` }}
              title={`Digital Assets: ${assetAllocation.cryptoPercent}%`}
              className="bg-emerald-400 h-full rounded-r-full"
            />
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs pt-1">
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-400" />
              <span className="text-slate-300">Available Cash: {assetAllocation.cashPercent}%</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <span className="text-slate-300">Computing Capital: {assetAllocation.computingPercent}%</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
              <span className="text-slate-300">Digital Holdings: {assetAllocation.cryptoPercent}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* 3. VERIFIED DIGITAL ASSET HOLDINGS */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center space-x-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>Verified Cryptocurrency Output Holdings</span>
            </h3>
            <p className="text-xs text-slate-400">
              Computational mining outputs and digital asset custody verified on our infrastructure.
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 font-bold">
            Total Crypto: {formatZAR(totalCryptoValuationZar)}
          </span>
        </div>

        {cryptoHoldings.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-8 text-center space-y-3">
            <Coins className="w-10 h-10 text-slate-600 mx-auto" />
            <h4 className="text-sm font-semibold text-slate-300">No Direct Crypto Output Holdings</h4>
            <p className="text-xs text-slate-400 max-w-md mx-auto">
              Your account balance is currently denominated in Rand (ZAR) via our double-entry ledger. Verified crypto output distributions from completed mining contracts will appear here upon distribution.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {cryptoHoldings.map((h) => (
              <div key={h.id} className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2.5">
                    <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-bold text-amber-400 font-mono text-xs">
                      {h.symbol}
                    </div>
                    <div>
                      <span className="font-bold text-slate-100 text-sm block">{h.symbol}</span>
                      <span className="text-[10px] text-slate-400 uppercase">{h.network} Network</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Verified
                  </span>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Holding Quantity</span>
                    <span className="font-mono font-bold text-slate-200">{h.quantity} {h.symbol}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">Current Spot Price</span>
                    <span className="font-mono text-slate-300">{formatZAR(h.currentPriceZar)}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800 flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-medium">Spot Valuation</span>
                  <span className="font-mono font-bold text-emerald-400 text-sm">{formatZAR(h.valuationZar)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 4. FINANCIAL STATEMENT LEDGER TABLE */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center space-x-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <span>Official Account Financial Statement</span>
            </h3>
            <p className="text-xs text-slate-400">
              Auditable record of all deposits, capital allocations, payouts, and balance adjustments.
            </p>
          </div>

          <button
            onClick={handleDownloadStatement}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-xl text-xs font-semibold bg-slate-900 border border-amber-500/30 text-amber-300 hover:bg-amber-500/10 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4 font-medium">Timestamp</th>
                  <th className="py-3 px-4 font-medium">Entry ID</th>
                  <th className="py-3 px-4 font-medium">Type</th>
                  <th className="py-3 px-4 font-medium">Debit (ZAR)</th>
                  <th className="py-3 px-4 font-medium">Credit (ZAR)</th>
                  <th className="py-3 px-4 font-medium">Balance After</th>
                  <th className="py-3 px-4 font-medium">Description</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {recentLedgerActivity.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-10 text-center text-slate-500">
                      No financial transactions recorded on ledger yet.
                    </td>
                  </tr>
                ) : (
                  recentLedgerActivity.map((entry) => (
                    <tr key={entry.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">
                        {new Date(entry.created_at).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-300">{entry.id}</td>
                      <td className="py-3 px-4">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            entry.entry_type === 'DEPOSIT'
                              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                              : entry.entry_type === 'ALLOCATION'
                              ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                              : entry.entry_type === 'PAYOUT'
                              ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                              : 'bg-purple-500/10 text-purple-400 border border-purple-500/30'
                          }`}
                        >
                          {entry.entry_type}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-rose-400">
                        {entry.debit > 0 ? `-${formatZAR(entry.debit)}` : '—'}
                      </td>
                      <td className="py-3 px-4 font-mono text-emerald-400">
                        {entry.credit > 0 ? `+${formatZAR(entry.credit)}` : '—'}
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-100">
                        {formatZAR(entry.balance_after)}
                      </td>
                      <td className="py-3 px-4 text-slate-300 max-w-sm truncate" title={entry.description}>
                        {entry.description}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 5. REGULATORY DISCLOSURES */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 text-xs text-slate-400 space-y-2">
        <div className="flex items-center space-x-2 text-slate-200 font-semibold">
          <Shield className="w-4 h-4 text-amber-400" />
          <span>Accounting Standard & Regulatory Protection Notice</span>
        </div>
        <div className="space-y-1 leading-relaxed">
          {disclosures.map((d, i) => (
            <p key={i}>• {d}</p>
          ))}
        </div>
      </div>
    </div>
  );
};
