import React, { useRef } from 'react';
import { ReceiptData } from '../types/index.js';
import { Printer, Download, X, CheckCircle2, ShieldCheck } from 'lucide-react';

interface ReceiptModalProps {
  receipt: ReceiptData | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ receipt, onClose }) => {
  const receiptRef = useRef<HTMLDivElement>(null);

  if (!receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadText = () => {
    const textContent = `
============================================================
              GLOBAL FINANCE CRYPTO MINING
               OFFICIAL TRANSACTION RECEIPT
============================================================

Receipt Number:        ${receipt.receiptNumber}
Transaction Reference: ${receipt.transactionReference}
Date:                  ${new Date(receipt.transactionDate).toUTCString()}
Status:                ${receipt.paymentStatus} (VERIFIED)

------------------------------------------------------------
CUSTOMER DETAILS
------------------------------------------------------------
Customer Name:         ${receipt.customerName}
Customer Email:        ${receipt.customerEmail}

------------------------------------------------------------
INVESTMENT & PAYMENT DETAILS
------------------------------------------------------------
Investment Product:    ${receipt.investmentProduct}
Amount Paid:           R ${receipt.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
Currency:              ${receipt.currency}
Platform Fee:          R ${receipt.fee.toFixed(2)}
Payment Provider:      ${receipt.paymentProvider}
Payment Method:        ${receipt.paymentMethod === 'payfast' ? 'PayFast Online Gateway' : 'Direct Electronic Bank Transfer'}

------------------------------------------------------------
${receipt.closingMessage}
============================================================
This receipt represents an immutable and verified record from 
Global Finance Crypto Mining's financial ledger.
    `.trim();

    const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Receipt-${receipt.transactionReference}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-xl bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <span className="font-semibold text-slate-100 text-sm tracking-wide">
              Official Transaction Receipt
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Receipt Content */}
        <div
          ref={receiptRef}
          className="p-6 md:p-8 overflow-y-auto space-y-6 bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 print:bg-white print:text-black"
        >
          {/* Logo / Brand */}
          <div className="text-center pb-6 border-b border-slate-800/80">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-600 to-yellow-400 text-black font-bold text-xl mb-3 shadow-lg shadow-amber-500/20">
              GF
            </div>
            <h2 className="text-xl md:text-2xl font-bold tracking-wider text-amber-300 font-serif">
              {receipt.businessName}
            </h2>
            <p className="text-xs text-slate-400 mt-1 uppercase tracking-widest">
              Digital Investment & Mining Infrastructure
            </p>
          </div>

          {/* Status Badge */}
          <div className="flex items-center justify-between bg-emerald-500/10 border border-emerald-500/30 rounded-xl px-4 py-3">
            <div className="flex items-center space-x-2 text-emerald-400">
              <CheckCircle2 className="w-5 h-5" />
              <span className="text-sm font-medium">Payment Verified & Settled</span>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-300 tracking-wider">
              {receipt.receiptNumber}
            </span>
          </div>

          {/* Transaction Metadata */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div>
              <span className="text-slate-400 block mb-0.5">Transaction Reference</span>
              <span className="font-mono font-semibold text-slate-200 text-sm">
                {receipt.transactionReference}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Date & Time</span>
              <span className="text-slate-200">
                {new Date(receipt.transactionDate).toLocaleString('en-ZA')}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Customer</span>
              <span className="font-medium text-slate-200">{receipt.customerName}</span>
            </div>
            <div>
              <span className="text-slate-400 block mb-0.5">Customer Email</span>
              <span className="text-slate-200">{receipt.customerEmail}</span>
            </div>
          </div>

          {/* Product & Payment Table */}
          <div className="border border-slate-800 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-950/70 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Description</th>
                  <th className="py-2.5 px-4 text-right">Amount (ZAR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                <tr>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-slate-200">{receipt.investmentProduct}</div>
                    <div className="text-[11px] text-slate-400">
                      Payment Provider: {receipt.paymentProvider} ({receipt.paymentMethod})
                    </div>
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-semibold text-slate-200">
                    R {receipt.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
                <tr>
                  <td className="py-2.5 px-4 text-slate-400">Processing & Platform Fee</td>
                  <td className="py-2.5 px-4 text-right font-mono text-slate-400">
                    R {receipt.fee.toFixed(2)}
                  </td>
                </tr>
                <tr className="bg-amber-500/5 font-bold">
                  <td className="py-3 px-4 text-amber-300">Total Confirmed & Settled</td>
                  <td className="py-3 px-4 text-right font-mono text-base text-amber-400">
                    R {receipt.amount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Closing Message */}
          <div className="text-center pt-2 text-xs text-slate-400">
            <p className="text-slate-300 font-medium mb-1">{receipt.closingMessage}</p>
            <p className="text-[10px] text-slate-500">
              This receipt confirms that client funds have been securely recorded in the immutable double-entry financial ledger.
            </p>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end space-x-3 px-6 py-4 border-t border-slate-800 bg-slate-950/80">
          <button
            onClick={handleDownloadText}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-medium text-slate-200 bg-slate-800 hover:bg-slate-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Download</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center space-x-2 px-4 py-2 rounded-xl text-xs font-semibold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 transition-colors shadow-md shadow-amber-500/10"
          >
            <Printer className="w-4 h-4" />
            <span>Print Receipt</span>
          </button>
        </div>
      </div>
    </div>
  );
};
