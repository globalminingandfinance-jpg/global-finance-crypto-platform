import React, { useState, useEffect } from 'react';
import {
  Megaphone,
  Sparkles,
  Send,
  Calendar,
  Clock,
  Eye,
  CheckCircle2,
  AlertTriangle,
  X,
  RefreshCw,
  Search,
  Filter,
  FileText,
  History,
  Layers,
  ArrowRight,
  RotateCcw,
  SlidersHorizontal,
  ChevronDown,
  ChevronUp,
  Archive,
  Trash2,
  ExternalLink,
  Users,
  ShieldAlert,
  Bot,
  Activity,
  Check,
} from 'lucide-react';
import {
  GlobalAnnouncement,
  AnnouncementAnalytics,
  AnnouncementCategory,
  AnnouncementPriority,
  StructuredAnnouncementDetails,
  AudienceCriteria,
  AIWritingStyle,
  AIAssistantAction,
  AnnouncementRevision,
} from '../types/index.js';

interface AdminAnnouncementsCentreProps {
  token: string | null;
}

export const AdminAnnouncementsCentre: React.FC<AdminAnnouncementsCentreProps> = ({ token }) => {
  const [activeSubTab, setActiveSubTab] = useState<'overview' | 'create' | 'drafts' | 'history'>('overview');
  const [analytics, setAnalytics] = useState<AnnouncementAnalytics | null>(null);
  const [announcements, setAnnouncements] = useState<GlobalAnnouncement[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<AnnouncementCategory>('GENERAL_ANNOUNCEMENT');
  const [priority, setPriority] = useState<AnnouncementPriority>('INFORMATIONAL');
  const [message, setMessage] = useState('');
  const [previousMessageDraft, setPreviousMessageDraft] = useState('');
  const [actionLink, setActionLink] = useState('');
  const [publishTiming, setPublishTiming] = useState<'IMMEDIATE' | 'SCHEDULED'>('IMMEDIATE');
  const [scheduledFor, setScheduledFor] = useState('');
  const [recurrencePattern, setRecurrencePattern] = useState<'NONE' | 'DAILY' | 'WEEKLY' | 'MONTHLY'>('NONE');
  const [recurrenceEndDate, setRecurrenceEndDate] = useState('');

  // Structured Details for AI Context
  const [showStructuredDetails, setShowStructuredDetails] = useState(false);
  const [structuredDetails, setStructuredDetails] = useState<StructuredAnnouncementDetails>({
    whatHappened: '',
    whyItMatters: '',
    effectiveDate: '',
    duration: '',
    affectedServices: '',
    requiredAction: '',
    factualNotes: '',
  });

  // AI Assistant State
  const [writingStyle, setWritingStyle] = useState<AIWritingStyle>('professional_reassuring');
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);

  // Audience Filtering State
  const [audienceCriteria, setAudienceCriteria] = useState<AudienceCriteria>({
    general: 'ALL_CLIENTS',
    selectedUserIds: [],
    plans: [],
    kycStatuses: [],
    paymentStatuses: [],
    investmentActivity: 'ALL',
  });

  // Client search for individual selection
  const [clientSearchQuery, setClientSearchQuery] = useState('');
  const [availableClients, setAvailableClients] = useState<any[]>([]);
  const [isSearchingClients, setIsSearchingClients] = useState(false);

  // Recipient Count Preview
  const [recipientPreview, setRecipientPreview] = useState<{
    totalCount: number;
    sampleRecipients: any[];
  } | null>(null);
  const [isPreviewingRecipients, setIsPreviewingRecipients] = useState(false);

  // Modals
  const [confirmationModal, setConfirmationModal] = useState<boolean>(false);
  const [clientPreviewModal, setClientPreviewModal] = useState<boolean>(false);
  const [inspectAnnouncement, setInspectAnnouncement] = useState<{
    announcement: GlobalAnnouncement;
    revisions: AnnouncementRevision[];
    deliveries: any[];
  } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchOverview = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/admin/announcements/overview', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setAnalytics(data.analytics);
        setAnnouncements(data.announcements || []);
      }
    } catch (err) {
      console.error('Failed to load announcements overview:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOverview();
  }, [token]);

  // Search clients for manual selection
  useEffect(() => {
    if (audienceCriteria.general !== 'INDIVIDUAL_CLIENTS') return;
    const searchTimer = setTimeout(async () => {
      setIsSearchingClients(true);
      try {
        const res = await fetch(`/api/admin/announcements/clients?q=${encodeURIComponent(clientSearchQuery)}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data = await res.json();
          setAvailableClients(data.clients || []);
        }
      } catch {
      } finally {
        setIsSearchingClients(false);
      }
    }, 300);
    return () => clearTimeout(searchTimer);
  }, [clientSearchQuery, audienceCriteria.general, token]);

  // Recalculate recipient count whenever criteria change
  useEffect(() => {
    const fetchRecipientCount = async () => {
      if (!token) return;
      setIsPreviewingRecipients(true);
      try {
        const res = await fetch('/api/admin/announcements/preview-recipients', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({ criteria: audienceCriteria }),
        });
        if (res.ok) {
          const data = await res.json();
          setRecipientPreview(data);
        }
      } catch {
      } finally {
        setIsPreviewingRecipients(false);
      }
    };
    fetchRecipientCount();
  }, [audienceCriteria, token]);

  // AI Message Generation Handler
  const handleAIAssistant = async (action: AIAssistantAction) => {
    if (!title.trim()) {
      setFeedback({ type: 'error', text: 'Please enter an Announcement Title first to give the AI context.' });
      return;
    }
    if (!token) return;

    if (message) {
      setPreviousMessageDraft(message);
    }

    setIsGeneratingAI(true);
    setFeedback(null);

    try {
      const res = await fetch('/api/admin/announcements/ai-generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title,
          category,
          priority,
          structuredDetails: showStructuredDetails ? structuredDetails : undefined,
          audienceSummary:
            audienceCriteria.general === 'INDIVIDUAL_CLIENTS'
              ? 'Selected Specific Clients'
              : 'Targeted Client Cohort',
          writingStyle,
          action,
          currentMessage: message,
        }),
      });

      const data = await res.json();
      if (res.ok && data.message) {
        setMessage(data.message);
        setFeedback({
          type: 'success',
          text: 'AI generated announcement message. Review and make any manual adjustments before publishing.',
        });
      } else {
        setFeedback({
          type: 'error',
          text: data.error || 'AI generation failed. You may write your message manually.',
        });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed during AI generation.' });
    } finally {
      setIsGeneratingAI(false);
    }
  };

  const handleRestoreDraft = () => {
    if (previousMessageDraft) {
      setMessage(previousMessageDraft);
      setPreviousMessageDraft('');
      setFeedback({ type: 'success', text: 'Restored previous draft.' });
    }
  };

  // Submit announcement
  const handleSubmitAnnouncement = async (requestedStatus: 'DRAFT' | 'SCHEDULED' | 'PUBLISHED') => {
    if (!title.trim() || !message.trim()) {
      setFeedback({ type: 'error', text: 'Title and Message Body are required.' });
      return;
    }
    if (!token) return;

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/admin/announcements', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title,
          category,
          priority,
          message,
          structuredDetails: showStructuredDetails ? structuredDetails : undefined,
          audienceCriteria,
          status: requestedStatus,
          scheduledFor: requestedStatus === 'SCHEDULED' ? scheduledFor : null,
          recurrencePattern,
          recurrenceEndDate: recurrenceEndDate || null,
          actionLink: actionLink || null,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: data.message });
        setConfirmationModal(false);
        // Reset form
        setTitle('');
        setMessage('');
        setActionLink('');
        setScheduledFor('');
        fetchOverview();
        setActiveSubTab(requestedStatus === 'PUBLISHED' ? 'overview' : 'drafts');
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to save announcement.' });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Immediate publish for draft or scheduled item
  const handlePublishNow = async (id: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/announcements/${id}/publish`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: data.message });
        fetchOverview();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to publish.' });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // Cancel scheduled announcement
  const handleCancelScheduled = async (id: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/announcements/${id}/cancel`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: data.message });
        fetchOverview();
      } else {
        setFeedback({ type: 'error', text: data.error });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // Archive published announcement
  const handleArchive = async (id: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/announcements/${id}/archive`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: data.message });
        fetchOverview();
      } else {
        setFeedback({ type: 'error', text: data.error });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // Inspect announcement details & recipient read list
  const handleInspect = async (id: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/announcements/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setInspectAnnouncement(data);
      }
    } catch {
      setFeedback({ type: 'error', text: 'Failed to inspect announcement.' });
    }
  };

  // Category labels helper
  const getCategoryLabel = (cat: string) => {
    const map: Record<string, string> = {
      SYSTEM_MAINTENANCE: 'System Maintenance',
      COMPANY_NEWS: 'Company News',
      KYC_VERIFICATION: 'Account Verification / KYC',
      PAYMENTS_WITHDRAWALS: 'Payments & Withdrawals',
      INVESTMENT_INFO: 'Investment Information',
      SECURITY_ALERTS: 'Security Alerts',
      SERVICE_AVAILABILITY: 'Service Availability',
      GENERAL_ANNOUNCEMENT: 'General Announcement',
      OTHER: 'Other Announcement',
    };
    return map[cat] || cat;
  };

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Megaphone className="w-4 h-4" />
            </div>
            <h1 className="text-xl font-bold font-serif text-slate-100">
              Global Announcements Centre
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            Enterprise broadcasting system for client communications with AI-assisted drafting, real database audience targeting, scheduled execution, and verifiable read tracking.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setActiveSubTab('create')}
            className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-black font-bold rounded-xl text-xs flex items-center space-x-1.5 shadow-md shadow-amber-500/10 transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span>New Announcement</span>
          </button>
          <button
            onClick={fetchOverview}
            disabled={isLoading}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition-colors"
            title="Refresh announcements"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center justify-between ${
            feedback.type === 'success'
              ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
              : 'bg-red-500/10 border border-red-500/30 text-red-400'
          }`}
        >
          <div className="flex items-center space-x-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 shrink-0" />
            )}
            <span>{feedback.text}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-500 hover:text-slate-300 ml-4">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Sub-Navigation Tabs */}
      <div className="flex border-b border-slate-800 space-x-4 text-xs font-medium">
        <button
          onClick={() => setActiveSubTab('overview')}
          className={`pb-3 border-b-2 transition-all flex items-center space-x-2 ${
            activeSubTab === 'overview'
              ? 'border-amber-500 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Overview & Published ({announcements.filter((a) => a.status === 'PUBLISHED').length})</span>
        </button>

        <button
          onClick={() => setActiveSubTab('create')}
          className={`pb-3 border-b-2 transition-all flex items-center space-x-2 ${
            activeSubTab === 'create'
              ? 'border-amber-500 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bot className="w-4 h-4" />
          <span>Create Announcement & AI Assistant</span>
        </button>

        <button
          onClick={() => setActiveSubTab('drafts')}
          className={`pb-3 border-b-2 transition-all flex items-center space-x-2 ${
            activeSubTab === 'drafts'
              ? 'border-amber-500 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span>
            Drafts & Scheduled ({announcements.filter((a) => ['DRAFT', 'SCHEDULED'].includes(a.status)).length})
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('history')}
          className={`pb-3 border-b-2 transition-all flex items-center space-x-2 ${
            activeSubTab === 'history'
              ? 'border-amber-500 text-amber-400 font-bold'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <History className="w-4 h-4" />
          <span>Audit Records & History</span>
        </button>
      </div>

      {/* SECTION 1: OVERVIEW & PUBLISHED ANNOUNCEMENTS */}
      {activeSubTab === 'overview' && (
        <div className="space-y-6">
          {/* Analytics Cards */}
          {analytics && (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Total Announcements</span>
                <div className="text-xl font-bold font-mono text-slate-100 mt-1">{analytics.totalAnnouncements}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Database records</div>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
                <span className="text-[10px] text-emerald-400 uppercase tracking-wider block">Published Active</span>
                <div className="text-xl font-bold font-mono text-emerald-300 mt-1">{analytics.publishedAnnouncements}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Live in client bell</div>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
                <span className="text-[10px] text-amber-400 uppercase tracking-wider block">Scheduled</span>
                <div className="text-xl font-bold font-mono text-amber-300 mt-1">{analytics.scheduledAnnouncements}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">Awaiting trigger</div>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Clients Reached</span>
                <div className="text-xl font-bold font-mono text-slate-200 mt-1">{analytics.totalRecipientsReached}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">In-app notifications</div>
              </div>

              <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-4">
                <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Verified Reads</span>
                <div className="text-xl font-bold font-mono text-slate-100 mt-1">{analytics.totalRead}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">{analytics.totalUnread} Unread</div>
              </div>

              <div className="bg-slate-900/80 border border-amber-500/30 rounded-xl p-4 shadow-sm shadow-amber-500/5">
                <span className="text-[10px] text-amber-300 uppercase tracking-wider block font-semibold">Overall Read Rate</span>
                <div className="text-xl font-bold font-mono text-amber-300 mt-1">{analytics.overallReadRate}%</div>
                <div className="text-[10px] text-emerald-400 mt-0.5">Authoritative status</div>
              </div>
            </div>
          )}

          {/* Published Announcements List */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <h3 className="font-bold text-xs text-slate-200 uppercase tracking-wider flex items-center space-x-2">
                <Megaphone className="w-3.5 h-3.5 text-amber-400" />
                <span>Live Published Announcements</span>
              </h3>
            </div>

            {announcements.filter((a) => a.status === 'PUBLISHED').length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                <Megaphone className="w-8 h-8 mx-auto mb-2 opacity-30 text-slate-400" />
                <p>No published announcements yet.</p>
                <p className="text-[11px] text-slate-600 mt-1">
                  Create and publish an announcement to broadcast important updates to your clients.
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider">
                      <th className="p-3.5">Announcement</th>
                      <th className="p-3.5">Category</th>
                      <th className="p-3.5">Priority</th>
                      <th className="p-3.5">Recipients</th>
                      <th className="p-3.5">Reads / Rate</th>
                      <th className="p-3.5">Published (SAST)</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {announcements
                      .filter((a) => a.status === 'PUBLISHED')
                      .map((a) => (
                        <tr key={a.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="p-3.5">
                            <div className="font-bold text-slate-100">{a.title}</div>
                            <div className="text-[11px] text-slate-400 line-clamp-1 max-w-sm mt-0.5">
                              {a.message}
                            </div>
                          </td>
                          <td className="p-3.5 text-[11px] text-slate-300">
                            {getCategoryLabel(a.category)}
                          </td>
                          <td className="p-3.5">
                            <span
                              className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase border ${
                                a.priority === 'URGENT'
                                  ? 'bg-red-500/20 text-red-300 border-red-500/40'
                                  : a.priority === 'IMPORTANT'
                                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                  : 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                              }`}
                            >
                              {a.priority}
                            </span>
                          </td>
                          <td className="p-3.5 font-mono text-slate-200">{a.delivered_count || a.recipient_count}</td>
                          <td className="p-3.5">
                            <div className="font-mono text-emerald-400 font-semibold text-xs">
                              {a.read_count || 0} reads
                            </div>
                            <div className="text-[10px] text-slate-500 font-mono">
                              {a.read_rate !== undefined ? `${a.read_rate}% rate` : 'Tracking'}
                            </div>
                          </td>
                          <td className="p-3.5 text-slate-400 text-[11px]">
                            {a.published_at ? new Date(a.published_at).toLocaleString() : '—'}
                          </td>
                          <td className="p-3.5 text-right space-x-2">
                            <button
                              onClick={() => handleInspect(a.id)}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[10px] font-medium transition-colors"
                            >
                              Inspect Reads
                            </button>
                            <button
                              onClick={() => handleArchive(a.id)}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-300 rounded-lg text-[10px] font-medium transition-colors"
                              title="Archive Announcement"
                            >
                              Archive
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 2: CREATE ANNOUNCEMENT FORM & AI ASSISTANT */}
      {activeSubTab === 'create' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Announcement Details Form */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-2">
                <FileText className="w-4 h-4 text-amber-400" />
                <span>1. Announcement Content</span>
              </h2>

              {/* Title */}
              <div>
                <label className="block text-slate-300 text-xs font-medium mb-1">
                  Announcement Title <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Scheduled System Maintenance / Important Account Verification Notice"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Category & Priority */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 text-xs font-medium mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200"
                  >
                    <option value="GENERAL_ANNOUNCEMENT">General Announcement</option>
                    <option value="SYSTEM_MAINTENANCE">System Maintenance</option>
                    <option value="COMPANY_NEWS">Company News</option>
                    <option value="KYC_VERIFICATION">Account Verification / KYC</option>
                    <option value="PAYMENTS_WITHDRAWALS">Payments and Withdrawals</option>
                    <option value="INVESTMENT_INFO">Investment Information</option>
                    <option value="SECURITY_ALERTS">Security Alerts</option>
                    <option value="SERVICE_AVAILABILITY">Service Availability</option>
                    <option value="OTHER">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 text-xs font-medium mb-1">Priority</label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 font-semibold"
                  >
                    <option value="INFORMATIONAL">Informational (Standard bell update)</option>
                    <option value="IMPORTANT">Important (Highlighted banner badge)</option>
                    <option value="URGENT">Urgent (Immediate operational or security alert)</option>
                  </select>
                </div>
              </div>

              {/* Action Link (Optional) */}
              <div>
                <label className="block text-slate-300 text-xs font-medium mb-1">
                  Optional In-App Destination Link
                </label>
                <input
                  type="text"
                  value={actionLink}
                  onChange={(e) => setActionLink(e.target.value)}
                  placeholder="e.g. /deposit, /investments, /profile, /support"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2 text-xs text-slate-200 font-mono"
                />
              </div>

              {/* Collapsible Structured Facts for AI Assistant */}
              <div className="pt-2 border-t border-slate-800/80">
                <button
                  type="button"
                  onClick={() => setShowStructuredDetails(!showStructuredDetails)}
                  className="flex items-center justify-between w-full text-xs text-amber-400 font-medium py-1"
                >
                  <span className="flex items-center space-x-1.5">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Provide Structured Facts for AI Generation (Optional but Recommended)</span>
                  </span>
                  {showStructuredDetails ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {showStructuredDetails && (
                  <div className="mt-3 p-4 bg-slate-950/70 border border-slate-800 rounded-xl space-y-3 text-xs">
                    <div>
                      <label className="block text-slate-400 text-[11px] mb-1">What happened or what is changing?</label>
                      <input
                        type="text"
                        value={structuredDetails.whatHappened}
                        onChange={(e) => setStructuredDetails({ ...structuredDetails, whatHappened: e.target.value })}
                        placeholder="e.g. Scheduled database maintenance and core network upgrades"
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1">Effective Date & Time</label>
                        <input
                          type="text"
                          value={structuredDetails.effectiveDate}
                          onChange={(e) => setStructuredDetails({ ...structuredDetails, effectiveDate: e.target.value })}
                          placeholder="e.g. Saturday, 24 October at 02:00 SAST"
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1">Expected Duration</label>
                        <input
                          type="text"
                          value={structuredDetails.duration}
                          onChange={(e) => setStructuredDetails({ ...structuredDetails, duration: e.target.value })}
                          placeholder="e.g. 90 minutes"
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1">Affected Services</label>
                        <input
                          type="text"
                          value={structuredDetails.affectedServices}
                          onChange={(e) => setStructuredDetails({ ...structuredDetails, affectedServices: e.target.value })}
                          placeholder="e.g. Client Portal logins and PayFast EFT deposits"
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 text-[11px] mb-1">Required Action From Clients</label>
                        <input
                          type="text"
                          value={structuredDetails.requiredAction}
                          onChange={(e) => setStructuredDetails({ ...structuredDetails, requiredAction: e.target.value })}
                          placeholder="e.g. None required / Please log out prior to maintenance"
                          className="w-full bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-slate-400 text-[11px] mb-1">Additional Factual Details / Why Clients Need to Know</label>
                      <textarea
                        rows={2}
                        value={structuredDetails.whyItMatters}
                        onChange={(e) => setStructuredDetails({ ...structuredDetails, whyItMatters: e.target.value })}
                        placeholder="State any specific reasons or instructions..."
                        className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs text-slate-200"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Message Body Field */}
              <div className="pt-2">
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-slate-300 text-xs font-medium">
                    Announcement Final Message Body <span className="text-red-400">*</span>
                  </label>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {message.length} characters (Editable)
                  </span>
                </div>
                <textarea
                  required
                  rows={6}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your announcement directly or use the AI Assistant on the right to draft a complete message from your supplied facts..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-100 focus:outline-none focus:border-amber-500 leading-relaxed font-sans"
                />
              </div>
            </div>

            {/* Audience Filtering Panel */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-2">
                  <Filter className="w-4 h-4 text-amber-400" />
                  <span>2. Client Audience & Cohort Filters</span>
                </h2>
                {recipientPreview && (
                  <span className="text-xs font-bold font-mono px-3 py-1 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                    Matches: {recipientPreview.totalCount} Clients
                  </span>
                )}
              </div>

              {/* General Audience Radio */}
              <div className="flex items-center space-x-4 text-xs">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="generalAudience"
                    checked={audienceCriteria.general === 'ALL_CLIENTS'}
                    onChange={() => setAudienceCriteria({ ...audienceCriteria, general: 'ALL_CLIENTS' })}
                    className="text-amber-500"
                  />
                  <span className="text-slate-200 font-medium">Filter by Criteria / All Eligible Clients</span>
                </label>

                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="generalAudience"
                    checked={audienceCriteria.general === 'INDIVIDUAL_CLIENTS'}
                    onChange={() => setAudienceCriteria({ ...audienceCriteria, general: 'INDIVIDUAL_CLIENTS' })}
                    className="text-amber-500"
                  />
                  <span className="text-slate-200 font-medium">Selected Individual Clients</span>
                </label>
              </div>

              {/* Individual Client Search if selected */}
              {audienceCriteria.general === 'INDIVIDUAL_CLIENTS' ? (
                <div className="space-y-3 pt-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-500" />
                    <input
                      type="text"
                      value={clientSearchQuery}
                      onChange={(e) => setClientSearchQuery(e.target.value)}
                      placeholder="Search clients by email, first name, or last name..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3.5 py-2 text-xs text-slate-200"
                    />
                  </div>

                  <div className="max-h-48 overflow-y-auto border border-slate-800 rounded-xl divide-y divide-slate-800 bg-slate-950/60">
                    {availableClients.map((client) => {
                      const isSelected = audienceCriteria.selectedUserIds?.includes(client.id);
                      return (
                        <div
                          key={client.id}
                          onClick={() => {
                            const current = audienceCriteria.selectedUserIds || [];
                            setAudienceCriteria({
                              ...audienceCriteria,
                              selectedUserIds: isSelected
                                ? current.filter((id) => id !== client.id)
                                : [...current, client.id],
                            });
                          }}
                          className={`p-2.5 text-xs flex items-center justify-between cursor-pointer transition-colors ${
                            isSelected ? 'bg-amber-500/10' : 'hover:bg-slate-900'
                          }`}
                        >
                          <div>
                            <div className="font-semibold text-slate-200">
                              {client.first_name} {client.last_name}
                            </div>
                            <div className="text-[11px] text-slate-400 font-mono">{client.email}</div>
                          </div>
                          <input type="checkbox" checked={isSelected} readOnly className="rounded text-amber-500" />
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                /* Criteria Filters (Plans, KYC, Payments, Activity) */
                <div className="space-y-4 pt-2">
                  {/* Investment Plan Filter */}
                  <div>
                    <label className="block text-slate-400 text-[11px] font-semibold uppercase tracking-wider mb-1.5">
                      Investment Plan Audience (Holders of active/matured plans)
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {(['STARTER', 'GROWTH', 'PROFESSIONAL', 'ELITE'] as const).map((plan) => {
                        const isChecked = audienceCriteria.plans?.includes(plan);
                        return (
                          <label
                            key={plan}
                            className={`p-2 rounded-xl border text-xs cursor-pointer flex items-center space-x-2 transition-all ${
                              isChecked
                                ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 font-semibold'
                                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                const cur = audienceCriteria.plans || [];
                                setAudienceCriteria({
                                  ...audienceCriteria,
                                  plans: e.target.checked ? [...cur, plan] : cur.filter((p) => p !== plan),
                                });
                              }}
                              className="rounded text-amber-500"
                            />
                            <span>{plan}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {/* KYC Verification Filter */}
                  <div>
                    <label className="block text-slate-400 text-[11px] font-semibold uppercase tracking-wider mb-1.5">
                      Account KYC Status
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'verified', label: 'KYC Verified' },
                        { id: 'unverified', label: 'Unverified' },
                        { id: 'pending_review', label: 'Pending Review' },
                        { id: 'rejected', label: 'KYC Rejected' },
                      ].map((item) => {
                        const isChecked = audienceCriteria.kycStatuses?.includes(item.id as any);
                        return (
                          <label
                            key={item.id}
                            className={`p-2 rounded-xl border text-xs cursor-pointer flex items-center space-x-2 transition-all ${
                              isChecked
                                ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 font-semibold'
                                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                const cur = audienceCriteria.kycStatuses || [];
                                setAudienceCriteria({
                                  ...audienceCriteria,
                                  kycStatuses: e.target.checked
                                    ? [...cur, item.id as any]
                                    : cur.filter((k) => k !== item.id),
                                });
                              }}
                              className="rounded text-amber-500"
                            />
                            <span>{item.label}</span>
                          </label>
                        );
                      })}
                    </div>
                  </div>

                  {/* Investment Activity */}
                  <div>
                    <label className="block text-slate-400 text-[11px] font-semibold uppercase tracking-wider mb-1.5">
                      Investment Activity Cohort
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {[
                        { id: 'ALL', label: 'All Clients' },
                        { id: 'ACTIVE_ONLY', label: 'Active Capital Only' },
                        { id: 'NO_ACTIVE', label: 'Zero Active Allocations' },
                        { id: 'APPROACHING_MATURITY', label: 'Maturity < 7 Days' },
                      ].map((item) => {
                        const isSelected = (audienceCriteria.investmentActivity || 'ALL') === item.id;
                        return (
                          <button
                            type="button"
                            key={item.id}
                            onClick={() =>
                              setAudienceCriteria({ ...audienceCriteria, investmentActivity: item.id as any })
                            }
                            className={`p-2 rounded-xl border text-xs text-left transition-all ${
                              isSelected
                                ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 font-bold'
                                : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            {item.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Sample masked recipient preview */}
              {recipientPreview && recipientPreview.sampleRecipients.length > 0 && (
                <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl text-xs space-y-1.5">
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">
                    Sample Masked Recipients Preview (First {recipientPreview.sampleRecipients.length}):
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {recipientPreview.sampleRecipients.map((s, idx) => (
                      <span
                        key={idx}
                        className="px-2 py-0.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] text-slate-300 font-mono"
                      >
                        {s.name} ({s.maskedEmail})
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: AI Writing Assistant & Scheduling Controls */}
          <div className="lg:col-span-5 space-y-6">
            {/* AI Assistant Panel */}
            <div className="bg-slate-900/80 border border-amber-500/30 rounded-2xl p-6 space-y-4 shadow-lg shadow-amber-500/5">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Bot className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-100">AI Message Assistant</h3>
                  <p className="text-[10px] text-amber-400/90 font-mono">Gemini 3.8 Flash • Strict Fact Guardrails</p>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                Drafts compliant, professional announcements from your title and supplied facts. Never invents unverified dates, payments, or regulatory claims.
              </p>

              {/* Style Selector */}
              <div>
                <label className="block text-slate-400 text-xs font-medium mb-1">Tone & Communication Style</label>
                <select
                  value={writingStyle}
                  onChange={(e) => setWritingStyle(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200"
                >
                  <option value="professional_reassuring">Professional and Reassuring</option>
                  <option value="formal_corporate">Formal Corporate Executive</option>
                  <option value="simple_clear">Simple and Easy to Understand</option>
                  <option value="urgent_operational">Urgent Operational Notice</option>
                  <option value="friendly_customer">Friendly Customer Update</option>
                </select>
              </div>

              {/* Primary AI Actions */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={() => handleAIAssistant('GENERATE')}
                  disabled={isGeneratingAI}
                  className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 text-black font-bold rounded-xl text-xs flex items-center justify-center space-x-2 shadow-md shadow-amber-500/10 transition-all disabled:opacity-50"
                >
                  <Sparkles className={`w-3.5 h-3.5 ${isGeneratingAI ? 'animate-spin' : ''}`} />
                  <span>{isGeneratingAI ? 'Generating with Gemini...' : 'Generate Announcement Draft'}</span>
                </button>

                {message && (
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => handleAIAssistant('MAKE_SHORTER')}
                      disabled={isGeneratingAI}
                      className="py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-[11px] text-slate-300 font-medium transition-colors"
                    >
                      Make Shorter
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAIAssistant('MAKE_FORMAL')}
                      disabled={isGeneratingAI}
                      className="py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-[11px] text-slate-300 font-medium transition-colors"
                    >
                      Make More Formal
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAIAssistant('SIMPLIFY')}
                      disabled={isGeneratingAI}
                      className="py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-[11px] text-slate-300 font-medium transition-colors"
                    >
                      Simplify Language
                    </button>
                    <button
                      type="button"
                      onClick={() => handleAIAssistant('IMPROVE_CLARITY')}
                      disabled={isGeneratingAI}
                      className="py-1.5 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-[11px] text-slate-300 font-medium transition-colors"
                    >
                      Improve Clarity
                    </button>
                  </div>
                )}

                {previousMessageDraft && (
                  <button
                    type="button"
                    onClick={handleRestoreDraft}
                    className="w-full py-1.5 bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg text-[11px] flex items-center justify-center space-x-1"
                  >
                    <RotateCcw className="w-3 h-3" />
                    <span>Restore Previous Draft</span>
                  </button>
                )}
              </div>
            </div>

            {/* Publishing & Scheduling Controls */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
              <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-amber-400" />
                <span>3. Publication & Scheduling</span>
              </h3>

              {/* Timing selector */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setPublishTiming('IMMEDIATE')}
                  className={`py-2 px-3 rounded-xl border text-left transition-all ${
                    publishTiming === 'IMMEDIATE'
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  Publish Immediately
                </button>
                <button
                  type="button"
                  onClick={() => setPublishTiming('SCHEDULED')}
                  className={`py-2 px-3 rounded-xl border text-left transition-all ${
                    publishTiming === 'SCHEDULED'
                      ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  Schedule for Future
                </button>
              </div>

              {publishTiming === 'SCHEDULED' && (
                <div className="space-y-3 pt-2 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">Schedule Date & Time (ISO / SAST)</label>
                    <input
                      type="datetime-local"
                      value={scheduledFor}
                      onChange={(e) => setScheduledFor(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">Recurrence Pattern</label>
                    <select
                      value={recurrencePattern}
                      onChange={(e) => setRecurrencePattern(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
                    >
                      <option value="NONE">None (One-time broadcast)</option>
                      <option value="DAILY">Daily at scheduled time</option>
                      <option value="WEEKLY">Weekly</option>
                      <option value="MONTHLY">Monthly</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-4 border-t border-slate-800 space-y-2">
                <button
                  type="button"
                  onClick={() => setClientPreviewModal(true)}
                  disabled={!title.trim() || !message.trim()}
                  className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center space-x-1.5 transition-colors disabled:opacity-40"
                >
                  <Eye className="w-3.5 h-3.5 text-amber-400" />
                  <span>Preview in Client Notification Bell</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => handleSubmitAnnouncement('DRAFT')}
                    disabled={isSubmitting || !title.trim() || !message.trim()}
                    className="py-2.5 bg-slate-950 hover:bg-slate-800 border border-slate-700 text-slate-300 font-bold rounded-xl text-xs transition-colors disabled:opacity-40"
                  >
                    Save Draft
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (publishTiming === 'SCHEDULED') {
                        handleSubmitAnnouncement('SCHEDULED');
                      } else {
                        setConfirmationModal(true);
                      }
                    }}
                    disabled={isSubmitting || !title.trim() || !message.trim()}
                    className="py-2.5 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl text-xs transition-all shadow-md shadow-amber-500/20 disabled:opacity-40"
                  >
                    {publishTiming === 'SCHEDULED' ? 'Schedule Announcement' : 'Review & Publish'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 3: DRAFTS & SCHEDULED ANNOUNCEMENTS */}
      {activeSubTab === 'drafts' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-xs text-slate-200 uppercase tracking-wider flex items-center space-x-2">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Drafts & Pending Scheduled Broadcasts</span>
            </h3>
          </div>

          {announcements.filter((a) => ['DRAFT', 'SCHEDULED'].includes(a.status)).length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              <Clock className="w-8 h-8 mx-auto mb-2 opacity-30 text-slate-400" />
              <p>No drafts or scheduled announcements.</p>
              <p className="text-[11px] text-slate-600 mt-1">
                Saved drafts or upcoming scheduled notices will appear here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider">
                    <th className="p-3.5">Announcement Title</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Priority</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Scheduled For (SAST)</th>
                    <th className="p-3.5">Recurrence</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {announcements
                    .filter((a) => ['DRAFT', 'SCHEDULED'].includes(a.status))
                    .map((a) => (
                      <tr key={a.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="p-3.5 font-bold text-slate-100">{a.title}</td>
                        <td className="p-3.5 text-slate-300">{getCategoryLabel(a.category)}</td>
                        <td className="p-3.5">
                          <span
                            className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase border ${
                              a.priority === 'URGENT'
                                ? 'bg-red-500/20 text-red-300 border-red-500/40'
                                : a.priority === 'IMPORTANT'
                                ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                                : 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                            }`}
                          >
                            {a.priority}
                          </span>
                        </td>
                        <td className="p-3.5">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              a.status === 'SCHEDULED'
                                ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {a.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-400 font-mono text-[11px]">
                          {a.scheduled_for ? new Date(a.scheduled_for).toLocaleString() : '—'}
                        </td>
                        <td className="p-3.5 text-slate-400 font-mono text-[10px]">{a.recurrence_pattern}</td>
                        <td className="p-3.5 text-right space-x-2">
                          <button
                            onClick={() => handlePublishNow(a.id)}
                            className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-lg text-[10px] transition-colors"
                          >
                            Publish Now
                          </button>
                          {a.status === 'SCHEDULED' && (
                            <button
                              onClick={() => handleCancelScheduled(a.id)}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white rounded-lg text-[10px] transition-colors"
                            >
                              Cancel
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* SECTION 4: AUDIT RECORDS & HISTORY */}
      {activeSubTab === 'history' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 flex items-center justify-between">
            <h3 className="font-bold text-xs text-slate-200 uppercase tracking-wider flex items-center space-x-2">
              <History className="w-3.5 h-3.5 text-amber-400" />
              <span>Announcement Lifecycle & Audit Trail</span>
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider">
                  <th className="p-3.5">Title</th>
                  <th className="p-3.5">Category</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Created By</th>
                  <th className="p-3.5">Created At</th>
                  <th className="p-3.5">Published At</th>
                  <th className="p-3.5 text-right">Audit</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {announcements.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="p-3.5 font-bold text-slate-200">{a.title}</td>
                    <td className="p-3.5 text-slate-300">{getCategoryLabel(a.category)}</td>
                    <td className="p-3.5">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {a.status}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-400 text-[11px] font-mono">{a.created_by_admin}</td>
                    <td className="p-3.5 text-slate-400 text-[11px]">{new Date(a.created_at).toLocaleDateString()}</td>
                    <td className="p-3.5 text-slate-400 text-[11px]">
                      {a.published_at ? new Date(a.published_at).toLocaleDateString() : '—'}
                    </td>
                    <td className="p-3.5 text-right">
                      <button
                        onClick={() => handleInspect(a.id)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-lg text-[10px] font-medium"
                      >
                        Inspect History
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL 1: CLIENT PREVIEW MODAL */}
      {clientPreviewModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>Client Bell Dropdown Preview</span>
              </span>
              <button onClick={() => setClientPreviewModal(false)} className="text-slate-500 hover:text-slate-300">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 p-4 rounded-xl bg-slate-900/90 border border-amber-500/30 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span
                  className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border ${
                    priority === 'URGENT'
                      ? 'bg-red-500/20 text-red-300 border-red-500/40'
                      : priority === 'IMPORTANT'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                  }`}
                >
                  {priority === 'URGENT' ? 'Urgent Announcement' : priority === 'IMPORTANT' ? 'Important Notice' : 'Announcement'}
                </span>
                <span className="text-[10px] text-slate-500">Just now</span>
              </div>

              <div className="font-bold text-slate-100 text-sm">{title}</div>
              <p className="text-slate-300 text-[11px] leading-relaxed whitespace-pre-line">{message}</p>

              {actionLink && (
                <div className="pt-2 border-t border-slate-800">
                  <span className="inline-flex items-center space-x-1 px-3 py-1 bg-amber-500 text-black font-bold rounded-lg text-[10px]">
                    <span>View Destination Link</span>
                    <ArrowRight className="w-2.5 h-2.5" />
                  </span>
                </div>
              )}
            </div>

            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setClientPreviewModal(false)}
                className="px-4 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: CONFIRM IMMEDIATE PUBLICATION */}
      {confirmationModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center space-x-2 text-amber-400 mb-2">
              <Send className="w-5 h-5" />
              <h3 className="font-bold text-slate-100 text-sm">Confirm Global Announcement Publication</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to publish <strong className="text-amber-300">"{title}"</strong> immediately?
            </p>

            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-xs space-y-1.5 my-4">
              <div>
                Category: <strong className="text-slate-200">{getCategoryLabel(category)}</strong>
              </div>
              <div>
                Priority: <strong className="text-slate-200">{priority}</strong>
              </div>
              <div>
                Target Recipients:{' '}
                <strong className="text-amber-300 font-mono">
                  {recipientPreview?.totalCount ?? 'Calculating...'} Clients
                </strong>
              </div>
              {priority === 'URGENT' && (
                <div className="text-red-400 font-semibold text-[11px] pt-1">
                  ⚠️ Urgent priority will highlight this notification prominently in all recipient notification panels.
                </div>
              )}
            </div>

            <div className="flex items-center justify-end space-x-3">
              <button
                type="button"
                onClick={() => setConfirmationModal(false)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs font-medium"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleSubmitAnnouncement('PUBLISHED')}
                disabled={isSubmitting}
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl text-xs transition-all shadow-md shadow-amber-500/20"
              >
                {isSubmitting ? 'Publishing...' : 'Confirm & Publish Now'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: INSPECT ANNOUNCEMENT & READ RECIPIENT LIST */}
      {inspectAnnouncement && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[85vh] overflow-y-auto p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="font-bold text-sm text-slate-100 flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-amber-400" />
                  <span>Announcement Delivery & Revision Audit</span>
                </h3>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5">{inspectAnnouncement.announcement.id}</p>
              </div>
              <button onClick={() => setInspectAnnouncement(null)} className="text-slate-500 hover:text-slate-300">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content summary */}
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-xs my-4 space-y-1">
              <div className="font-bold text-slate-100">{inspectAnnouncement.announcement.title}</div>
              <p className="text-slate-400 text-[11px] whitespace-pre-line">{inspectAnnouncement.announcement.message}</p>
            </div>

            {/* Revisions history */}
            <div className="mb-4">
              <h4 className="font-bold text-xs text-slate-300 uppercase tracking-wider mb-2">Revision History</h4>
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {inspectAnnouncement.revisions.map((rev) => (
                  <div key={rev.id} className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-[11px] flex justify-between">
                    <div>
                      <span className="font-bold text-amber-400 mr-2">Rev {rev.revision_number}</span>
                      <span className="text-slate-300">{rev.change_reason || 'Edited'}</span>
                    </div>
                    <span className="text-slate-500 font-mono">{new Date(rev.created_at).toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Delivery & Read details */}
            <div>
              <h4 className="font-bold text-xs text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Client Delivery & Read Tracking</span>
                <span className="text-slate-500 text-[10px] font-normal">
                  Showing first {inspectAnnouncement.deliveries.length} delivered
                </span>
              </h4>

              <div className="max-h-48 overflow-y-auto border border-slate-800 rounded-xl divide-y divide-slate-800 bg-slate-900/50">
                {inspectAnnouncement.deliveries.length === 0 ? (
                  <div className="p-4 text-center text-slate-500 text-xs">No client delivery records recorded yet.</div>
                ) : (
                  inspectAnnouncement.deliveries.map((del) => (
                    <div key={del.id} className="p-2.5 text-xs flex items-center justify-between">
                      <div>
                        <div className="font-medium text-slate-200">{del.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono">{del.maskedEmail}</div>
                      </div>
                      <div className="text-right">
                        <span
                          className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                            del.isRead
                              ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {del.isRead ? 'READ' : 'DELIVERED (UNREAD)'}
                        </span>
                        <div className="text-[9px] text-slate-500 mt-0.5">{new Date(del.deliveredAt).toLocaleTimeString()}</div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setInspectAnnouncement(null)}
                className="px-4 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
