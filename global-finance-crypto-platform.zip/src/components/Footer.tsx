import React from 'react';
import { Shield, Lock, CreditCard, ExternalLink } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#04070d] border-t border-slate-800/80 text-slate-400 text-xs mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand Column */}
          <div className="space-y-4 md:col-span-1">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-600 to-yellow-400 p-[1px]">
                <div className="w-full h-full bg-slate-950 rounded-[7px] flex items-center justify-center font-serif font-black text-amber-400 text-xs">
                  GF
                </div>
              </div>
              <span className="font-serif font-bold text-slate-100 tracking-wider text-sm">
                GLOBAL FINANCE
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Global Finance Crypto Mining provides structured digital computational allocation plans with audited financial records, PayFast gateway integration, and segregated accounts.
            </p>
            <div className="pt-2 flex items-center space-x-2 text-slate-500 text-[11px]">
              <Shield className="w-4 h-4 text-amber-400" />
              <span>TLS 1.3 Encrypted & Immutable Financial Ledger</span>
            </div>
          </div>

          {/* Platform Links */}
          <div className="space-y-3">
            <h4 className="text-slate-200 font-semibold uppercase tracking-wider text-xs">
              Platform
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigate('investments')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Investment Plans
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('how-it-works')}
                  className="hover:text-amber-300 transition-colors"
                >
                  How It Works
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('security')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Security Architecture
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-amber-300 transition-colors"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('faq')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Frequently Asked Questions
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Compliance */}
          <div className="space-y-3">
            <h4 className="text-slate-200 font-semibold uppercase tracking-wider text-xs">
              Legal & Compliance
            </h4>
            <ul className="space-y-2">
              <li>
                <button
                  onClick={() => onNavigate('terms')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Terms & Conditions
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('refund-policy')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Refund Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('cancellation-policy')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Cancellation Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('delivery-policy')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Delivery & Fulfilment Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('privacy-policy')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Privacy Policy (POPIA)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('risk-disclosure')}
                  className="text-amber-400/90 hover:text-amber-300 font-medium transition-colors"
                >
                  Risk Disclosure Notice
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('contact')}
                  className="hover:text-amber-300 transition-colors"
                >
                  Contact & Support
                </button>
              </li>
            </ul>
          </div>

          {/* Payment & Security Disclosures */}
          <div className="space-y-3">
            <h4 className="text-slate-200 font-semibold uppercase tracking-wider text-xs">
              Payment Gateway
            </h4>
            <div className="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl space-y-2">
              <div className="flex items-center space-x-2 text-slate-200 font-medium">
                <CreditCard className="w-4 h-4 text-amber-400" />
                <span>PayFast (Pty) Ltd</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-normal">
                Online South African transactions are securely processed via PayFast using real-time signature verification. Direct bank transfers are manually reconciled.
              </p>
            </div>
            <div className="pt-2">
              <button
                onClick={() => onNavigate('admin-login')}
                className="flex items-center space-x-1.5 text-[11px] text-slate-500 hover:text-amber-400 transition-colors"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Administrator Access Portal</span>
              </button>
            </div>
          </div>
        </div>

        {/* Regulatory Risk Disclaimer Banner */}
        <div className="mt-12 pt-6 border-t border-slate-800/80 text-[11px] text-slate-500 leading-relaxed space-y-2">
          <p>
            <strong className="text-slate-400">FINANCIAL & CRYPTOCURRENCY RISK NOTICE:</strong> Digital asset computational allocations and cryptocurrency mining infrastructure involve significant financial and technological risks. Past performance and operational output are not indicative of future results. Global Finance Crypto Mining does not provide guaranteed returns, speculative promises, or debt guarantees. All transactions are subject to identity verification where required by applicable regulations.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-between text-slate-500 pt-3">
            <span>&copy; {new Date().getFullYear()} Global Finance Crypto Mining. All rights reserved.</span>
            <span className="mt-2 sm:mt-0 font-mono text-[10px]">South Africa (ZAR) Operations</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
