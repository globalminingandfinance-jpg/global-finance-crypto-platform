import React, { useState, useEffect } from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  KeyRound,
  HelpCircle,
  Smartphone,
  FolderLock,
  History,
  Laptop,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Eye,
  EyeOff,
  UploadCloud,
  FileText,
  FileCheck,
  FileX,
  Trash2,
  Download,
  AlertTriangle,
  Lock,
  X,
  Plus,
} from 'lucide-react';
import {
  ClientDocument,
  DocumentCategory,
  SecurityEvent,
  UserSession,
  SecurityOverviewData,
} from '../types/index.js';

interface SecurityCentreProps {
  token: string | null;
  onNavigateSupportTicket?: (ticketId: string) => void;
}

export const SecurityCentre: React.FC<SecurityCentreProps> = ({
  token,
  onNavigateSupportTicket,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<
    'overview' | 'password' | 'security-question' | 'contact' | 'vault' | 'activity' | 'sessions'
  >('overview');

  const [isLoading, setIsLoading] = useState(true);
  const [overview, setOverview] = useState<SecurityOverviewData | null>(null);

  // General feedback banner
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // 1. CHANGE PASSWORD STATE
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [signOutOtherSessions, setSignOutOtherSessions] = useState(true);
  const [isChangingPassword, setIsChangingPassword] = useState(false);

  // 2. SECURITY QUESTION STATE
  const [secQuestionConfigured, setSecQuestionConfigured] = useState(false);
  const [currentSecQuestion, setCurrentSecQuestion] = useState<string | null>(null);
  const [standardQuestions, setStandardQuestions] = useState<string[]>([]);
  const [selectedQuestion, setSelectedQuestion] = useState('');
  const [customQuestion, setCustomQuestion] = useState('');
  const [secAnswer, setSecAnswer] = useState('');
  const [secAnswerConfirm, setSecAnswerConfirm] = useState('');
  const [secPasswordConfirm, setSecPasswordConfirm] = useState('');
  const [isSavingSecQuestion, setIsSavingSecQuestion] = useState(false);

  // 3. PHONE & CONTACT STATE
  const [currentPhone, setCurrentPhone] = useState('');
  const [isPhoneVerified, setIsPhoneVerified] = useState(false);
  const [newPhone, setNewPhone] = useState('');
  const [phoneReauthPassword, setPhoneReauthPassword] = useState('');
  const [phoneStep, setPhoneStep] = useState<'request' | 'verify'>('request');
  const [otpCode, setOtpCode] = useState('');
  const [isRequestingOtp, setIsRequestingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [simulatedPreviewCode, setSimulatedPreviewCode] = useState<string | null>(null);
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [isUpdatingPersonal, setIsUpdatingPersonal] = useState(false);

  // 4. DOCUMENT VAULT STATE
  const [documents, setDocuments] = useState<ClientDocument[]>([]);
  const [docCategoryFilter, setDocCategoryFilter] = useState<string>('ALL');
  const [isUploadingDoc, setIsUploadingDoc] = useState(false);
  const [uploadModalOpen, setUploadModalOpen] = useState(false);
  const [uploadDocName, setUploadDocName] = useState('');
  const [uploadCategory, setUploadCategory] = useState<DocumentCategory>('ID_DOCUMENT');
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    type: string;
    size: number;
    base64: string;
  } | null>(null);

  // 5. SECURITY ACTIVITY STATE
  const [activityLogs, setActivityLogs] = useState<SecurityEvent[]>([]);
  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [reportDetails, setReportDetails] = useState('');
  const [selectedReportEvent, setSelectedReportEvent] = useState<SecurityEvent | null>(null);
  const [isReporting, setIsReporting] = useState(false);

  // 6. SESSIONS STATE
  const [sessions, setSessions] = useState<UserSession[]>([]);
  const [isRevokingSession, setIsRevokingSession] = useState(false);

  // Fetch overview & data
  const fetchOverview = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/security/overview', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data: SecurityOverviewData = await res.json();
        setOverview(data);
        setCurrentPhone(data.phone || '');
        setIsPhoneVerified(data.isPhoneVerified);
        setCity(data.city || '');
        setAddress(data.address || '');
        setSecQuestionConfigured(data.hasSecurityQuestion);
        setCurrentSecQuestion(data.securityQuestion);
      }
    } catch (err) {
      console.error('Failed to load security overview:', err);
    }
  };

  const fetchSecurityQuestionData = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/security/security-question', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setStandardQuestions(data.standardQuestions || []);
        if (data.standardQuestions?.length > 0 && !selectedQuestion) {
          setSelectedQuestion(data.standardQuestions[0]);
        }
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchDocuments = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/security/documents', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setDocuments(data.documents || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchActivity = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/security/activity', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setActivityLogs(data.events || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchSessions = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/security/sessions', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setSessions(data.sessions || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    const loadAll = async () => {
      setIsLoading(true);
      await Promise.all([
        fetchOverview(),
        fetchSecurityQuestionData(),
        fetchDocuments(),
        fetchActivity(),
        fetchSessions(),
      ]);
      setIsLoading(false);
    };
    loadAll();
  }, [token]);

  // Clear feedback after 6 seconds
  useEffect(() => {
    if (feedback) {
      const timer = setTimeout(() => setFeedback(null), 6000);
      return () => clearTimeout(timer);
    }
  }, [feedback]);

  // Password Strength Validations
  const pwdMinLength = newPassword.length >= 8;
  const pwdUpper = /[A-Z]/.test(newPassword);
  const pwdLower = /[a-z]/.test(newPassword);
  const pwdNumOrSym = /[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(newPassword);
  const pwdMatches = newPassword.length > 0 && newPassword === confirmPassword;
  const isPwdStrengthOk = pwdMinLength && pwdUpper && pwdLower && pwdNumOrSym;

  // HANDLER: CHANGE PASSWORD
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setFeedback(null);

    if (!isPwdStrengthOk) {
      setFeedback({ type: 'error', text: 'New password does not fulfill all required strength criteria.' });
      return;
    }
    if (newPassword !== confirmPassword) {
      setFeedback({ type: 'error', text: 'New password and confirmation do not match.' });
      return;
    }

    setIsChangingPassword(true);
    try {
      const res = await fetch('/api/security/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          currentPassword,
          newPassword,
          confirmPassword,
          signOutOtherSessions,
        }),
      });

      const data = await res.json();
      setIsChangingPassword(false);

      if (res.ok) {
        setFeedback({ type: 'success', text: data.message || 'Password changed successfully.' });
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        fetchOverview();
        fetchActivity();
        fetchSessions();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to change password.' });
      }
    } catch {
      setIsChangingPassword(false);
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // HANDLER: SAVE SECURITY QUESTION
  const handleSaveSecurityQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setFeedback(null);

    const questionToSave = selectedQuestion === 'CUSTOM' ? customQuestion : selectedQuestion;
    if (!questionToSave || questionToSave.trim().length < 5) {
      setFeedback({ type: 'error', text: 'Please choose or enter a valid security question.' });
      return;
    }

    if (secAnswer.trim().toLowerCase() !== secAnswerConfirm.trim().toLowerCase()) {
      setFeedback({ type: 'error', text: 'Your security question answers do not match.' });
      return;
    }

    setIsSavingSecQuestion(true);
    try {
      const res = await fetch('/api/security/security-question', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          currentPassword: secPasswordConfirm,
          question: questionToSave,
          answer: secAnswer,
        }),
      });

      const data = await res.json();
      setIsSavingSecQuestion(false);

      if (res.ok) {
        setFeedback({ type: 'success', text: data.message || 'Security question saved.' });
        setSecAnswer('');
        setSecAnswerConfirm('');
        setSecPasswordConfirm('');
        setCustomQuestion('');
        fetchOverview();
        fetchActivity();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to save security question.' });
      }
    } catch {
      setIsSavingSecQuestion(false);
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // HANDLER: PHONE REQUEST OTP
  const handleRequestPhoneOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setFeedback(null);
    setIsRequestingOtp(true);

    try {
      const res = await fetch('/api/security/phone/request-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          newPhone,
          currentPassword: phoneReauthPassword,
        }),
      });

      const data = await res.json();
      setIsRequestingOtp(false);

      if (res.ok) {
        setPhoneStep('verify');
        setSimulatedPreviewCode(data.previewCode || null);
        setFeedback({
          type: 'success',
          text: data.message || 'Verification code dispatched.',
        });
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to request OTP.' });
      }
    } catch {
      setIsRequestingOtp(false);
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // HANDLER: PHONE VERIFY OTP
  const handleVerifyPhoneOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setFeedback(null);
    setIsVerifyingOtp(true);

    try {
      const res = await fetch('/api/security/phone/verify-otp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          newPhone,
          otpCode,
        }),
      });

      const data = await res.json();
      setIsVerifyingOtp(false);

      if (res.ok) {
        setFeedback({ type: 'success', text: data.message || 'Phone number verified and updated!' });
        setCurrentPhone(data.phone);
        setIsPhoneVerified(true);
        setPhoneStep('request');
        setNewPhone('');
        setPhoneReauthPassword('');
        setOtpCode('');
        setSimulatedPreviewCode(null);
        fetchOverview();
        fetchActivity();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Verification code incorrect or expired.' });
      }
    } catch {
      setIsVerifyingOtp(false);
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // HANDLER: UPDATE PERSONAL DETAILS
  const handleUpdatePersonalDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsUpdatingPersonal(true);

    try {
      const res = await fetch('/api/security/personal-details', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ city, address }),
      });

      const data = await res.json();
      setIsUpdatingPersonal(false);

      if (res.ok) {
        setFeedback({ type: 'success', text: data.message || 'Personal details updated.' });
        fetchOverview();
        fetchActivity();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to update details.' });
      }
    } catch {
      setIsUpdatingPersonal(false);
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // HANDLER: FILE INPUT FOR VAULT
  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setFeedback({ type: 'error', text: 'Selected file exceeds the maximum 5 MB limit.' });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedFile({
        name: file.name,
        type: file.type || 'application/pdf',
        size: file.size,
        base64: reader.result as string,
      });
      if (!uploadDocName) {
        setUploadDocName(file.name.replace(/\.[^/.]+$/, ''));
      }
    };
    reader.readAsDataURL(file);
  };

  // HANDLER: UPLOAD DOCUMENT
  const handleUploadDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !selectedFile) return;

    setIsUploadingDoc(true);
    setFeedback(null);

    try {
      const res = await fetch('/api/security/documents/upload', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          name: uploadDocName,
          category: uploadCategory,
          fileType: selectedFile.type,
          fileData: selectedFile.base64,
          fileSize: selectedFile.size,
        }),
      });

      const data = await res.json();
      setIsUploadingDoc(false);

      if (res.ok) {
        setFeedback({ type: 'success', text: data.message || 'Document uploaded successfully!' });
        setUploadModalOpen(false);
        setSelectedFile(null);
        setUploadDocName('');
        fetchDocuments();
        fetchOverview();
        fetchActivity();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to upload document.' });
      }
    } catch {
      setIsUploadingDoc(false);
      setFeedback({ type: 'error', text: 'Network connection failed during document upload.' });
    }
  };

  // HANDLER: DELETE DOCUMENT
  const handleDeleteDocument = async (docId: string, docName: string) => {
    if (!token) return;
    if (!confirm(`Are you sure you want to securely remove "${docName}" from your vault?`)) {
      return;
    }

    try {
      const res = await fetch(`/api/security/documents/${docId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: data.message || 'Document removed.' });
        fetchDocuments();
        fetchOverview();
        fetchActivity();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to delete document.' });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network error deleting document.' });
    }
  };

  // HANDLER: REPORT SUSPICIOUS ACTIVITY
  const handleReportSuspicious = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsReporting(true);

    try {
      const res = await fetch('/api/security/report-suspicious', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          eventId: selectedReportEvent?.id,
          details: reportDetails,
        }),
      });

      const data = await res.json();
      setIsReporting(false);

      if (res.ok) {
        setFeedback({
          type: 'success',
          text: `Urgent security report lodged (Ref: ${data.reference}). Our security operations team has been alerted.`,
        });
        setReportModalOpen(false);
        setReportDetails('');
        setSelectedReportEvent(null);
        fetchActivity();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to lodge report.' });
      }
    } catch {
      setIsReporting(false);
      setFeedback({ type: 'error', text: 'Network connection failure.' });
    }
  };

  // HANDLER: REVOKE SESSION
  const handleRevokeSession = async (sessionId?: string, revokeAllOthers?: boolean) => {
    if (!token) return;
    if (
      revokeAllOthers &&
      !confirm('Are you sure you want to sign out of all other active sessions across devices?')
    ) {
      return;
    }

    setIsRevokingSession(true);
    try {
      const res = await fetch('/api/security/sessions/revoke', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ sessionId, revokeAllOthers }),
      });
      const data = await res.json();
      setIsRevokingSession(false);

      if (res.ok) {
        setFeedback({ type: 'success', text: data.message || 'Session(s) revoked.' });
        fetchSessions();
        fetchOverview();
        fetchActivity();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to revoke session.' });
      }
    } catch {
      setIsRevokingSession(false);
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  // Filtered documents
  const filteredDocs = documents.filter((d) => {
    if (docCategoryFilter === 'ALL') return true;
    return d.category === docCategoryFilter;
  });

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Title & Introduction */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-800/80">
        <div>
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <h1 className="text-xl sm:text-2xl font-bold font-serif text-slate-100">
              Security & Account Protection Centre
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Enterprise cryptographic safeguards, multi-factor verification, private document custody, and real-time activity auditing.
          </p>
        </div>

        {/* Quick indicator badge */}
        <div className="flex items-center space-x-2">
          <span className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-[11px] font-semibold bg-emerald-500/10 border border-emerald-500/30 text-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Client Vault Active</span>
          </span>
        </div>
      </div>

      {/* Global Feedback Banner */}
      {feedback && (
        <div
          className={`p-3.5 rounded-2xl text-xs flex items-center justify-between space-x-3 animate-fadeIn ${
            feedback.type === 'success'
              ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
              : 'bg-red-500/10 border border-red-500/30 text-red-400'
          }`}
        >
          <div className="flex items-center space-x-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            ) : (
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            )}
            <span>{feedback.text}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Security Navigation Sub-tabs */}
      <div className="flex items-center space-x-1 border-b border-slate-800 overflow-x-auto pb-1 scrollbar-none">
        {[
          { id: 'overview', label: 'Security Overview', icon: Shield },
          { id: 'password', label: 'Change Password', icon: KeyRound },
          { id: 'security-question', label: 'Security Question', icon: HelpCircle },
          { id: 'contact', label: 'Contact & Details', icon: Smartphone },
          { id: 'vault', label: 'Secure Document Vault', icon: FolderLock },
          { id: 'activity', label: 'Security Activity', icon: History },
          { id: 'sessions', label: 'Active Sessions', icon: Laptop },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center space-x-2 px-3.5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================================= */}
      {/* SUBTAB 1: SECURITY OVERVIEW */}
      {/* ========================================================================= */}
      {activeSubTab === 'overview' && (
        <div className="space-y-6">
          {/* Key Security Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* Password Health */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-slate-400">Account Password</span>
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                  <KeyRound className="w-4 h-4" />
                </div>
              </div>
              <div className="text-base font-bold text-slate-100 flex items-center space-x-2">
                <span className="text-emerald-400">Protected & Salted</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Bcrypt 12-round cryptographic hash enforcement</p>
              <button
                onClick={() => setActiveSubTab('password')}
                className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center space-x-1"
              >
                <span>Update Password →</span>
              </button>
            </div>

            {/* Security Question Status */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-slate-400">Personal Security Question</span>
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    secQuestionConfigured
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : 'bg-amber-500/10 text-amber-400'
                  }`}
                >
                  <HelpCircle className="w-4 h-4" />
                </div>
              </div>
              <div className="text-base font-bold text-slate-100">
                {secQuestionConfigured ? (
                  <span className="text-emerald-400">Configured & Masked</span>
                ) : (
                  <span className="text-amber-400">Action Recommended</span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">
                {secQuestionConfigured
                  ? 'Salted one-way hash stored for secondary recovery verification'
                  : 'Add a personal recovery question to protect your account'}
              </p>
              <button
                onClick={() => setActiveSubTab('security-question')}
                className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center space-x-1"
              >
                <span>{secQuestionConfigured ? 'Modify Question →' : 'Set Up Question →'}</span>
              </button>
            </div>

            {/* Phone Verification */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-slate-400">Contact Number Verification</span>
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    isPhoneVerified
                      ? 'bg-emerald-500/10 text-emerald-400'
                      : 'bg-amber-500/10 text-amber-400'
                  }`}
                >
                  <Smartphone className="w-4 h-4" />
                </div>
              </div>
              <div className="text-base font-bold text-slate-100">
                {isPhoneVerified ? (
                  <span className="text-emerald-400">Verified Contact</span>
                ) : (
                  <span className="text-amber-400">Unverified Phone</span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-1 font-mono">
                {currentPhone || 'No registered phone number'}
              </p>
              <button
                onClick={() => setActiveSubTab('contact')}
                className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center space-x-1"
              >
                <span>{isPhoneVerified ? 'Change Phone →' : 'Verify Phone via OTP →'}</span>
              </button>
            </div>

            {/* Document Vault Summary */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-slate-400">Private Document Vault</span>
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                  <FolderLock className="w-4 h-4" />
                </div>
              </div>
              <div className="text-xl font-bold font-mono text-slate-100">
                {overview?.documentsSummary.total || 0} Documents
              </div>
              <div className="text-[11px] text-slate-400 mt-1 flex space-x-3">
                <span className="text-emerald-400 font-semibold">
                  {overview?.documentsSummary.approved || 0} Approved
                </span>
                <span className="text-amber-400 font-semibold">
                  {overview?.documentsSummary.pending || 0} Pending
                </span>
                {overview?.documentsSummary.rejected ? (
                  <span className="text-red-400 font-semibold">
                    {overview.documentsSummary.rejected} Rejected
                  </span>
                ) : null}
              </div>
              <button
                onClick={() => setActiveSubTab('vault')}
                className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center space-x-1"
              >
                <span>Open Document Vault →</span>
              </button>
            </div>

            {/* Active Sessions */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-slate-400">Active Login Sessions</span>
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                  <Laptop className="w-4 h-4" />
                </div>
              </div>
              <div className="text-xl font-bold font-mono text-slate-100">
                {overview?.activeSessionsCount || 1} Device(s)
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Review authenticated devices and sessions</p>
              <button
                onClick={() => setActiveSubTab('sessions')}
                className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center space-x-1"
              >
                <span>Manage Sessions →</span>
              </button>
            </div>

            {/* Security Audit Trail */}
            <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-medium text-slate-400">Recent Security Events</span>
                <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
                  <History className="w-4 h-4" />
                </div>
              </div>
              <div className="text-xl font-bold font-mono text-slate-100">
                {activityLogs.length} Logged
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Real-time immutable security activity record</p>
              <button
                onClick={() => setActiveSubTab('activity')}
                className="mt-3 text-xs text-amber-400 hover:text-amber-300 font-semibold flex items-center space-x-1"
              >
                <span>View Full Audit Log →</span>
              </button>
            </div>
          </div>

          {/* Compliance & Regulatory Notice */}
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 space-y-2">
            <h3 className="font-bold text-slate-100 flex items-center space-x-2">
              <Shield className="w-4 h-4 text-amber-400" />
              <span>Global Finance Security Framework & POPIA Compliance</span>
            </h3>
            <p className="leading-relaxed">
              Global Finance Crypto Mining implements end-to-end security architectures to safeguard investor capital and private records. In compliance with South Africa's Protection of Personal Information Act (POPIA) and Financial Intelligence Centre Act (FICA), all uploaded documents are stored in segregated private disk vaults and are never exposed to public indexing or third-party web crawlers.
            </p>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBTAB 2: CHANGE PASSWORD */}
      {/* ========================================================================= */}
      {activeSubTab === 'password' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 max-w-2xl">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
              <KeyRound className="w-5 h-5 text-amber-400" />
              <span>Change Account Password</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Update your account password with cryptographic verification. Your new password will be hashed using Bcrypt with 12 computational rounds.
            </p>
          </div>

          <form onSubmit={handleChangePassword} className="space-y-4 text-xs">
            {/* Current Password */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Current Password <span className="text-amber-400">*</span>
              </label>
              <div className="relative">
                <input
                  type={showCurrentPassword ? 'text' : 'password'}
                  required
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Enter your current password"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
                >
                  {showCurrentPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* New Password */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                New Password <span className="text-amber-400">*</span>
              </label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Create a strong new password"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-2.5 text-slate-500 hover:text-slate-300"
                >
                  {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Confirm New Password */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Confirm New Password <span className="text-amber-400">*</span>
              </label>
              <input
                type={showNewPassword ? 'text' : 'password'}
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Re-enter your new password"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60"
              />
            </div>

            {/* Strength checklist */}
            <div className="p-3.5 bg-slate-950/70 border border-slate-800 rounded-xl space-y-1.5 text-[11px]">
              <div className="text-slate-400 font-medium mb-1 flex items-center space-x-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Password Strength Requirements:</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                <span className={pwdMinLength ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                  ✓ Minimum 8 characters
                </span>
                <span className={pwdUpper ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                  ✓ At least 1 uppercase letter
                </span>
                <span className={pwdLower ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                  ✓ At least 1 lowercase letter
                </span>
                <span className={pwdNumOrSym ? 'text-emerald-400 font-semibold' : 'text-slate-500'}>
                  ✓ At least 1 number or symbol
                </span>
              </div>
              {confirmPassword && (
                <div className={`pt-1 text-[10px] ${pwdMatches ? 'text-emerald-400 font-semibold' : 'text-amber-400'}`}>
                  {pwdMatches ? '✓ Passwords match' : '✗ Passwords do not match'}
                </div>
              )}
            </div>

            {/* Sign out other sessions checkbox */}
            <label className="flex items-center space-x-2.5 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={signOutOtherSessions}
                onChange={(e) => setSignOutOtherSessions(e.target.checked)}
                className="rounded border-slate-700 text-amber-500 focus:ring-amber-400 bg-slate-950"
              />
              <span className="text-slate-300 text-xs">
                Sign out of all other active sessions and devices after saving
              </span>
            </label>

            <button
              type="submit"
              disabled={isChangingPassword || !isPwdStrengthOk || !pwdMatches}
              className="px-6 py-2.5 rounded-xl font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 transition-all shadow-md shadow-amber-500/10 disabled:opacity-50 flex items-center space-x-2"
            >
              {isChangingPassword ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Updating Password...</span>
                </>
              ) : (
                <span>Update Password</span>
              )}
            </button>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBTAB 3: PERSONAL SECURITY QUESTION */}
      {/* ========================================================================= */}
      {activeSubTab === 'security-question' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 max-w-2xl">
          <div>
            <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
              <HelpCircle className="w-5 h-5 text-amber-400" />
              <span>Personal Security Question</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Configuring a personal security question provides an extra layer of verification for sensitive account recovery. Your answer is normalized and hashed with a cryptographic salt; plaintext answers are never stored or displayed.
            </p>
          </div>

          {secQuestionConfigured && (
            <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-start space-x-2.5">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
              <div>
                <p className="font-semibold">Security Question Configured</p>
                <p className="text-[11px] text-emerald-400/90 mt-0.5">
                  Current Question: &ldquo;{currentSecQuestion}&rdquo;
                </p>
                <p className="text-[10px] text-slate-400 mt-1">
                  You can update your security question anytime below by re-entering your current password.
                </p>
              </div>
            </div>
          )}

          <form onSubmit={handleSaveSecurityQuestion} className="space-y-4 text-xs">
            {/* Select question */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Choose Security Question <span className="text-amber-400">*</span>
              </label>
              <select
                value={selectedQuestion}
                onChange={(e) => setSelectedQuestion(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60"
              >
                {standardQuestions.map((q) => (
                  <option key={q} value={q}>
                    {q}
                  </option>
                ))}
                <option value="CUSTOM">-- Write my own custom security question --</option>
              </select>
            </div>

            {/* Custom Question input if selected */}
            {selectedQuestion === 'CUSTOM' && (
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Custom Security Question <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={customQuestion}
                  onChange={(e) => setCustomQuestion(e.target.value)}
                  placeholder="e.g. What is the title of your favourite book from childhood?"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>
            )}

            {/* Secret Answer */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Your Answer <span className="text-amber-400">*</span>
              </label>
              <input
                type="password"
                required
                value={secAnswer}
                onChange={(e) => setSecAnswer(e.target.value)}
                placeholder="Enter secret answer (not case-sensitive)"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60 font-mono"
              />
              <span className="text-[10px] text-slate-500 block mt-1">
                Answers are normalized (lowercase and trimmed) and stored using a one-way cryptographic hash.
              </span>
            </div>

            {/* Confirm Secret Answer */}
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Confirm Your Answer <span className="text-amber-400">*</span>
              </label>
              <input
                type="password"
                required
                value={secAnswerConfirm}
                onChange={(e) => setSecAnswerConfirm(e.target.value)}
                placeholder="Confirm secret answer"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60 font-mono"
              />
            </div>

            {/* Current Password Re-auth */}
            <div className="pt-2 border-t border-slate-800/80">
              <label className="block text-slate-300 font-medium mb-1">
                Confirm Current Password (Required for Authentication) <span className="text-amber-400">*</span>
              </label>
              <input
                type="password"
                required
                value={secPasswordConfirm}
                onChange={(e) => setSecPasswordConfirm(e.target.value)}
                placeholder="Enter current password to authorize change"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60"
              />
            </div>

            <button
              type="submit"
              disabled={isSavingSecQuestion || !secAnswer || !secPasswordConfirm}
              className="px-6 py-2.5 rounded-xl font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 transition-all shadow-md shadow-amber-500/10 disabled:opacity-50 flex items-center space-x-2"
            >
              {isSavingSecQuestion ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Securing Question...</span>
                </>
              ) : (
                <span>Save Security Question</span>
              )}
            </button>
          </form>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBTAB 4: PHONE NUMBER & CONTACT DETAILS */}
      {/* ========================================================================= */}
      {activeSubTab === 'contact' && (
        <div className="space-y-6 max-w-2xl">
          {/* Phone verification card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <span>Verified Phone Number</span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                To prevent unauthorized takeover, changing your registered phone number requires password re-authentication and a one-time OTP verification code.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Current Registered Phone</span>
                <span className="text-sm font-mono font-bold text-slate-100">
                  {currentPhone || 'No phone number configured'}
                </span>
              </div>
              <span
                className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                  isPhoneVerified
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                    : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                }`}
              >
                {isPhoneVerified ? '✓ OTP Verified' : '! Verification Required'}
              </span>
            </div>

            {/* OTP Flow */}
            {phoneStep === 'request' ? (
              <form onSubmit={handleRequestPhoneOtp} className="space-y-4 text-xs pt-2">
                <h3 className="font-semibold text-slate-200">Update Phone Number</h3>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    New Phone Number (with Country Code) <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="e.g. +27 82 123 4567"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 font-mono focus:outline-none focus:border-amber-500/60"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    Current Password (Re-authentication) <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="password"
                    required
                    value={phoneReauthPassword}
                    onChange={(e) => setPhoneReauthPassword(e.target.value)}
                    placeholder="Enter current password"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isRequestingOtp || !newPhone || !phoneReauthPassword}
                  className="px-6 py-2.5 rounded-xl font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 transition-all shadow-md shadow-amber-500/10 disabled:opacity-50 flex items-center space-x-2"
                >
                  {isRequestingOtp ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Sending Verification Code...</span>
                    </>
                  ) : (
                    <span>Request Verification Code</span>
                  )}
                </button>
              </form>
            ) : (
              <form onSubmit={handleVerifyPhoneOtp} className="space-y-4 text-xs pt-2 animate-fadeIn">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-slate-200">Enter Verification Code</h3>
                  <button
                    type="button"
                    onClick={() => setPhoneStep('request')}
                    className="text-amber-400 hover:underline text-[11px]"
                  >
                    Change Number
                  </button>
                </div>
                <p className="text-slate-300">
                  A 6-digit OTP code has been dispatched for phone number{' '}
                  <strong className="text-amber-300 font-mono">{newPhone}</strong>.
                </p>

                {simulatedPreviewCode && (
                  <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-[11px] flex items-center justify-between">
                    <span>
                      <strong>OTP Notification:</strong> Code sent to your device:
                    </span>
                    <span className="font-mono font-bold text-base tracking-widest text-white bg-slate-950 px-2 py-0.5 rounded border border-amber-500/40">
                      {simulatedPreviewCode}
                    </span>
                  </div>
                )}

                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    6-Digit Verification Code <span className="text-amber-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value)}
                    placeholder="123456"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-center text-lg font-mono tracking-widest text-slate-100 focus:outline-none focus:border-amber-500/60"
                  />
                </div>

                <div className="flex space-x-3">
                  <button
                    type="submit"
                    disabled={isVerifyingOtp || otpCode.length < 6}
                    className="px-6 py-2.5 rounded-xl font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 transition-all shadow-md shadow-amber-500/10 disabled:opacity-50 flex items-center space-x-2"
                  >
                    {isVerifyingOtp ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Verifying...</span>
                      </>
                    ) : (
                      <span>Confirm & Update Phone</span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPhoneStep('request')}
                    className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Residential Address / City Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-4">
            <h3 className="font-bold text-slate-100 text-sm">Residential & Profile Details</h3>
            <p className="text-xs text-slate-400">
              Provide permitted location details for FICA / AML compliance alignment.
            </p>

            <form onSubmit={handleUpdatePersonalDetails} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">City / Municipality</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="e.g. Johannesburg, Cape Town, Durban"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Residential Street Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="e.g. 14 Sandton Boulevard, Sandhurst"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>

              <button
                type="submit"
                disabled={isUpdatingPersonal}
                className="px-6 py-2.5 rounded-xl font-bold text-black bg-amber-400 hover:bg-amber-300 transition-colors disabled:opacity-50 flex items-center space-x-2"
              >
                {isUpdatingPersonal ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Saving...</span>
                  </>
                ) : (
                  <span>Save Profile Details</span>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBTAB 5: SECURE DOCUMENT VAULT */}
      {/* ========================================================================= */}
      {activeSubTab === 'vault' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                <FolderLock className="w-5 h-5 text-amber-400" />
                <span>Private Document Vault</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Upload and manage identity credentials, proof of payment, and address verification in segregated encrypted storage.
              </p>
            </div>
            <button
              onClick={() => setUploadModalOpen(true)}
              className="px-4 py-2.5 rounded-xl font-bold text-xs text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 transition-all flex items-center space-x-2 shadow-md shadow-amber-500/10 shrink-0"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Upload Document</span>
            </button>
          </div>

          {/* Privacy & Storage Safeguard Banner */}
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 space-y-1">
            <div className="font-semibold text-slate-200 flex items-center space-x-2">
              <Lock className="w-3.5 h-3.5 text-amber-400" />
              <span>Custody Safeguard Protocol:</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Files are stored on isolated, non-public file storage with randomly generated UUID paths. All requests require valid JWT session verification and ownership validation. Only authorized compliance officers may review documents through an audited process.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs">
            {[
              { id: 'ALL', label: 'All Documents' },
              { id: 'ID_DOCUMENT', label: 'Identity / Passport' },
              { id: 'PROOF_OF_PAYMENT', label: 'Proof of Payment' },
              { id: 'ADDRESS_VERIFICATION', label: 'Address Proof' },
              { id: 'SUPPORTING_DOC', label: 'Supporting Documents' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setDocCategoryFilter(cat.id)}
                className={`px-3 py-1.5 rounded-xl font-medium transition-colors whitespace-nowrap ${
                  docCategoryFilter === cat.id
                    ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300 font-semibold'
                    : 'bg-slate-900/60 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Document List */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
            {filteredDocs.length === 0 ? (
              <div className="p-12 text-center space-y-3">
                <div className="w-12 h-12 mx-auto rounded-full bg-slate-800/80 flex items-center justify-center text-slate-500">
                  <FolderLock className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-semibold text-slate-300">No Documents Uploaded Yet</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {docCategoryFilter === 'ALL'
                    ? 'You have not uploaded any compliance documents to your private vault yet. Click "Upload Document" to begin.'
                    : `No documents found in category "${docCategoryFilter.replace(/_/g, ' ')}".`}
                </p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Document Name</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Size</th>
                      <th className="py-3 px-4">Upload Date</th>
                      <th className="py-3 px-4">Review Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {filteredDocs.map((doc) => {
                      const sizeInKb = (doc.file_size / 1024).toFixed(1);
                      const isPending = doc.status === 'PENDING';
                      const isApproved = doc.status === 'APPROVED';
                      const isRejected = doc.status === 'REJECTED';
                      const isUnderReview = doc.status === 'UNDER_REVIEW';

                      return (
                        <React.Fragment key={doc.id}>
                          <tr className="hover:bg-slate-800/30 transition-colors">
                            <td className="py-3.5 px-4 font-semibold text-slate-100 flex items-center space-x-2">
                              <FileText className="w-4 h-4 text-amber-400 shrink-0" />
                              <span className="truncate max-w-[200px]">{doc.name}</span>
                            </td>
                            <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                              {doc.category.replace(/_/g, ' ')}
                            </td>
                            <td className="py-3.5 px-4 text-slate-400 font-mono text-[11px]">
                              {sizeInKb} KB
                            </td>
                            <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                              {new Date(doc.created_at).toLocaleDateString()}
                            </td>
                            <td className="py-3.5 px-4">
                              <span
                                className={`inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                                  isApproved
                                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                    : isRejected
                                    ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                                    : isUnderReview
                                    ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                                    : 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                                }`}
                              >
                                <span>{doc.status.replace(/_/g, ' ')}</span>
                              </span>
                            </td>
                            <td className="py-3.5 px-4 text-right space-x-2">
                              <a
                                href={`/api/security/documents/${doc.id}/download`}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
                              >
                                <Download className="w-3 h-3" />
                                <span>View</span>
                              </a>

                              {(!isApproved || doc.status === 'REJECTED') && (
                                <button
                                  onClick={() => handleDeleteDocument(doc.id, doc.name)}
                                  className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs transition-colors"
                                  title="Delete document"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              )}
                            </td>
                          </tr>

                          {/* Rejection Notice Banner */}
                          {isRejected && doc.rejection_reason && (
                            <tr className="bg-red-500/5">
                              <td colSpan={6} className="py-2.5 px-4 text-xs text-red-400 border-b border-red-500/20">
                                <div className="flex items-start space-x-2">
                                  <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
                                  <div>
                                    <strong className="font-semibold text-red-300">
                                      Compliance Review Explanation:
                                    </strong>{' '}
                                    <span>{doc.rejection_reason}</span>
                                    <p className="text-[10px] text-slate-400 mt-0.5">
                                      Please upload a replacement document addressing the reviewer&apos;s feedback.
                                    </p>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBTAB 6: SECURITY ACTIVITY AUDIT */}
      {/* ========================================================================= */}
      {activeSubTab === 'activity' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                <History className="w-5 h-5 text-amber-400" />
                <span>Security Activity & Audit Trail</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Real-time chronological events recorded for your account, including sign-ins, credential changes, and document submissions.
              </p>
            </div>
            <button
              onClick={() => {
                setSelectedReportEvent(null);
                setReportModalOpen(true);
              }}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 transition-colors flex items-center space-x-1.5 shrink-0"
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Report Suspicious Activity</span>
            </button>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
            {activityLogs.length === 0 ? (
              <div className="p-10 text-center text-xs text-slate-500">
                No recent security activity logged yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="py-3 px-4">Event Type</th>
                      <th className="py-3 px-4">Description</th>
                      <th className="py-3 px-4">Device & IP</th>
                      <th className="py-3 px-4">Timestamp</th>
                      <th className="py-3 px-4 text-right">Report</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {activityLogs.map((log) => {
                      const isDanger =
                        log.event_type.includes('FAIL') ||
                        log.event_type.includes('SUSPICIOUS');
                      const isSuccess =
                        log.event_type.includes('SUCCESS') ||
                        log.event_type.includes('VERIFIED');

                      return (
                        <tr key={log.id} className="hover:bg-slate-800/30 transition-colors">
                          <td className="py-3 px-4">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                isDanger
                                  ? 'bg-red-500/10 text-red-400 border border-red-500/20'
                                  : isSuccess
                                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                  : 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                              }`}
                            >
                              {log.event_type}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-slate-200 text-xs">
                            {log.description}
                          </td>
                          <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                            <div>{log.user_agent || 'Standard Client'}</div>
                            <div className="text-slate-500 text-[10px]">{log.displayIp || '127.0.0.1'}</div>
                          </td>
                          <td className="py-3 px-4 text-slate-400 text-[11px] whitespace-nowrap">
                            {new Date(log.created_at).toLocaleString()}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <button
                              onClick={() => {
                                setSelectedReportEvent(log);
                                setReportModalOpen(true);
                              }}
                              className="text-slate-500 hover:text-red-400 text-[11px]"
                              title="Flag unrecognized activity"
                            >
                              Flag
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUBTAB 7: ACTIVE SESSIONS */}
      {/* ========================================================================= */}
      {activeSubTab === 'sessions' && (
        <div className="space-y-6 max-w-3xl">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
                <Laptop className="w-5 h-5 text-amber-400" />
                <span>Active Login Sessions</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Manage all devices currently authenticated to your Global Finance account. Revoking a session immediately invalidates its token.
              </p>
            </div>
            <button
              onClick={() => handleRevokeSession(undefined, true)}
              disabled={isRevokingSession}
              className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-500/10 border border-red-500/30 text-red-400 hover:bg-red-500/20 transition-colors disabled:opacity-50 shrink-0"
            >
              Sign Out All Other Sessions
            </button>
          </div>

          <div className="space-y-3">
            {sessions.map((sess) => (
              <div
                key={sess.id}
                className={`p-4 rounded-2xl border flex items-center justify-between text-xs transition-colors ${
                  sess.isRevoked
                    ? 'bg-slate-950/40 border-slate-900 opacity-60'
                    : sess.isCurrent
                    ? 'bg-slate-900/90 border-amber-500/40'
                    : 'bg-slate-900/60 border-slate-800'
                }`}
              >
                <div className="flex items-center space-x-3.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                      sess.isCurrent
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    <Laptop className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="font-semibold text-slate-200 flex items-center space-x-2">
                      <span>{sess.deviceInfo}</span>
                      {sess.isCurrent && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          Current Device
                        </span>
                      )}
                      {sess.isRevoked && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-500">
                          Revoked
                        </span>
                      )}
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                      IP: {sess.displayIp} • Last Active: {new Date(sess.lastActiveAt).toLocaleString()}
                    </div>
                  </div>
                </div>

                {!sess.isRevoked && !sess.isCurrent && (
                  <button
                    onClick={() => handleRevokeSession(sess.id)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold text-red-400 hover:bg-red-500/10 transition-colors"
                  >
                    Sign Out
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: UPLOAD COMPLIANCE DOCUMENT */}
      {/* ========================================================================= */}
      {uploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-lg bg-slate-900 border border-amber-500/30 rounded-2xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2">
                <FolderLock className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm text-slate-100">Upload to Private Vault</h3>
              </div>
              <button
                onClick={() => setUploadModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUploadDocument} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Document Category <span className="text-amber-400">*</span>
                </label>
                <select
                  value={uploadCategory}
                  onChange={(e) => setUploadCategory(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500/60"
                >
                  <option value="ID_DOCUMENT">National ID / Passport / Driver License</option>
                  <option value="PROOF_OF_PAYMENT">Proof of Payment / Bank Confirmation Receipt</option>
                  <option value="ADDRESS_VERIFICATION">Proof of Residential Address (Utility Bill / Statement)</option>
                  <option value="SUPPORTING_DOC">Supporting Document / Customer Support Attachment</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Document Title <span className="text-amber-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={uploadDocName}
                  onChange={(e) => setUploadDocName(e.target.value)}
                  placeholder="e.g. South African Smart ID Card (Front & Back)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none focus:border-amber-500/60"
                />
              </div>

              {/* File Drop Area */}
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Choose File (PDF, PNG, JPG - max 5 MB) <span className="text-amber-400">*</span>
                </label>
                <div className="border-2 border-dashed border-slate-800 hover:border-amber-500/50 rounded-2xl p-6 text-center bg-slate-950/60 transition-colors cursor-pointer relative">
                  <input
                    type="file"
                    required
                    onChange={handleFileInput}
                    accept="application/pdf,image/png,image/jpeg,image/webp"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  {selectedFile ? (
                    <div className="flex items-center justify-center space-x-2 text-emerald-400">
                      <FileCheck className="w-6 h-6" />
                      <div className="text-left">
                        <p className="font-semibold text-slate-200">{selectedFile.name}</p>
                        <p className="text-[10px] text-slate-400">
                          {(selectedFile.size / 1024).toFixed(1)} KB • Ready to commit
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      <UploadCloud className="w-8 h-8 text-amber-400 mx-auto" />
                      <p className="text-slate-300 font-medium">Click or drag file to upload</p>
                      <p className="text-[10px] text-slate-500">
                        Accepted: PDF, PNG, JPEG, WebP • Maximum size: 5 MB
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl text-[11px] text-slate-400 space-y-1">
                <p>• Documents are kept in encrypted private custody and never publicly accessible.</p>
                <p>• Only compliance officers with audited permissions can review your submission.</p>
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setUploadModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploadingDoc || !selectedFile}
                  className="px-6 py-2.5 rounded-xl font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 transition-all shadow-md shadow-amber-500/10 disabled:opacity-50 flex items-center space-x-2"
                >
                  {isUploadingDoc ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Encrypting & Storing...</span>
                    </>
                  ) : (
                    <span>Commit Document to Vault</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL: REPORT SUSPICIOUS ACTIVITY */}
      {/* ========================================================================= */}
      {reportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="relative w-full max-w-md bg-slate-900 border border-red-500/40 rounded-2xl shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-2 text-red-400">
                <AlertTriangle className="w-5 h-5" />
                <h3 className="font-bold text-sm text-slate-100">Report Unrecognized Activity</h3>
              </div>
              <button
                onClick={() => setReportModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              If you suspect an unauthorized sign-in or transaction attempt, notify our 24/7 security desk immediately. This creates an urgent security investigation ticket.
            </p>

            {selectedReportEvent && (
              <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-xs space-y-1">
                <span className="font-semibold text-red-300 block">Flagged Event:</span>
                <p className="text-slate-200">
                  [{selectedReportEvent.event_type}] {selectedReportEvent.description}
                </p>
                <span className="text-[10px] text-slate-400 font-mono">
                  {new Date(selectedReportEvent.created_at).toLocaleString()} • IP: {selectedReportEvent.displayIp}
                </span>
              </div>
            )}

            <form onSubmit={handleReportSuspicious} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">
                  Incident Details & Observations <span className="text-amber-400">*</span>
                </label>
                <textarea
                  rows={4}
                  required
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="Explain why you suspect this activity is unauthorized (e.g. I did not log in from this location or change my settings)..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-slate-100 focus:outline-none focus:border-red-500/60 resize-none"
                />
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button
                  type="button"
                  onClick={() => setReportModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isReporting || !reportDetails.trim()}
                  className="px-5 py-2.5 rounded-xl font-bold text-white bg-red-600 hover:bg-red-500 transition-colors disabled:opacity-50 flex items-center space-x-2"
                >
                  {isReporting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Submitting Alert...</span>
                    </>
                  ) : (
                    <span>Lodge Security Emergency Alert</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
