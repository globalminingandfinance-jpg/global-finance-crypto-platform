import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  Menu,
  X,
  Shield,
  User as UserIcon,
  LogOut,
  ChevronRight,
  LayoutDashboard,
  Lock,
  TrendingUp,
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  onOpenCheckout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenAuth,
  onOpenCheckout,
}) => {
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'investments', label: 'Investments' },
    { id: 'how-it-works', label: 'How It Works' },
    { id: 'security', label: 'Security' },
    { id: 'about', label: 'About' },
    { id: 'faq', label: 'FAQ' },
    { id: 'contact', label: 'Contact' },
  ];

  const handleLinkClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <nav className="sticky top-0 z-40 bg-[#070b12]/90 backdrop-blur-md border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Brand Logo */}
          <div
            onClick={() => onNavigate('home')}
            className="flex items-center space-x-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 via-amber-500 to-yellow-400 p-[1.5px] shadow-lg shadow-amber-500/20 group-hover:shadow-amber-500/30 transition-shadow">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center font-serif font-black text-amber-400 text-base">
                GF
              </div>
            </div>
            <div>
              <div className="font-serif font-bold text-base md:text-lg tracking-wider text-slate-100 flex items-center gap-1.5">
                <span>GLOBAL FINANCE</span>
              </div>
              <div className="text-[10px] tracking-[0.25em] font-semibold text-amber-400/90 uppercase">
                Crypto Mining
              </div>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden lg:flex items-center space-x-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`px-3.5 py-2 rounded-lg text-xs font-medium tracking-wide transition-colors ${
                  currentView === link.id
                    ? 'text-amber-300 bg-amber-500/10 font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                {link.label}
              </button>
            ))}

            {/* Financial Intelligence Dropdown */}
            <div className="relative group">
              <button
                className={`flex items-center space-x-1 px-3.5 py-2 rounded-lg text-xs font-medium tracking-wide transition-colors ${
                  currentView === 'crypto-intelligence' || currentView === 'financial-reports'
                    ? 'text-amber-300 bg-amber-500/10 font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <span>Financial Intelligence</span>
                <ChevronRight className="w-3.5 h-3.5 rotate-90 text-slate-400 group-hover:text-amber-400 transition-transform" />
              </button>

              {/* Dropdown Menu */}
              <div className="absolute top-full left-0 mt-1 w-72 bg-[#0b101b] border border-slate-800 rounded-2xl p-2 shadow-2xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-150 z-50">
                <button
                  onClick={() => handleLinkClick('crypto-intelligence')}
                  className="w-full text-left p-2.5 rounded-xl hover:bg-slate-900 transition-colors flex items-start space-x-3 group/item"
                >
                  <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20 shrink-0">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-200 block group-hover/item:text-amber-300">
                      Crypto Intelligence Centre
                    </span>
                    <span className="text-[11px] text-slate-400 leading-tight block">
                      Live market prices, 24h charts, volatility & news
                    </span>
                  </div>
                </button>

                <button
                  onClick={() => {
                    if (user) {
                      onNavigate('customer-financial-overview');
                    } else {
                      onOpenAuth('login');
                    }
                  }}
                  className="w-full text-left p-2.5 rounded-xl hover:bg-slate-900 transition-colors flex items-start space-x-3 group/item"
                >
                  <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400 border border-blue-500/20 shrink-0">
                    <UserIcon className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-200 block group-hover/item:text-blue-300">
                      Customer Financial Overview
                    </span>
                    <span className="text-[11px] text-slate-400 leading-tight block">
                      Personal ledger balances, crypto holdings & statements
                    </span>
                  </div>
                </button>

                <button
                  onClick={() => {
                    if (user?.role === 'admin') {
                      onNavigate('admin-business-finance');
                    } else {
                      onNavigate('admin-login');
                    }
                  }}
                  className="w-full text-left p-2.5 rounded-xl hover:bg-slate-900 transition-colors flex items-start space-x-3 group/item"
                >
                  <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                    <Shield className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="text-xs font-bold text-slate-200 group-hover/item:text-emerald-300">
                        Business Finance Centre
                      </span>
                      <span className="text-[9px] uppercase font-bold px-1.5 py-0.2 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20">
                        Admin
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 leading-tight block">
                      Corporate P&L, balance sheet, cash & expenses
                    </span>
                  </div>
                </button>

                <button
                  onClick={() => {
                    if (user?.role === 'admin') {
                      onNavigate('admin-business-finance');
                    } else if (user) {
                      onNavigate('customer-financial-overview');
                    } else {
                      onOpenAuth('login');
                    }
                  }}
                  className="w-full text-left p-2.5 rounded-xl hover:bg-slate-900 transition-colors flex items-start space-x-3 group/item"
                >
                  <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20 shrink-0">
                    <LayoutDashboard className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-200 block group-hover/item:text-purple-300">
                      Financial Reports
                    </span>
                    <span className="text-[11px] text-slate-400 leading-tight block">
                      Audited statements and downloadable CSV reports
                    </span>
                  </div>
                </button>

                {user?.role === 'admin' && (
                  <button
                    onClick={() => onNavigate('admin-data-sources')}
                    className="w-full text-left p-2.5 rounded-xl hover:bg-slate-900 transition-colors flex items-start space-x-3 group/item border-t border-slate-800/80 mt-1"
                  >
                    <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shrink-0">
                      <Lock className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="text-xs font-bold text-slate-200 block group-hover/item:text-cyan-300">
                        Data Sources & Status
                      </span>
                      <span className="text-[11px] text-slate-400 leading-tight block">
                        API provider health, latency, & ledger integrity
                      </span>
                    </div>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* Desktop Auth / Action Area */}
          <div className="hidden lg:flex items-center space-x-3">
            {user ? (
              <div className="flex items-center space-x-2">
                {user.role === 'admin' && (
                  <button
                    onClick={() => onNavigate('admin-dashboard')}
                    className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all ${
                      currentView === 'admin-dashboard'
                        ? 'bg-amber-500 text-black border-amber-400'
                        : 'text-amber-400 border-amber-500/40 hover:bg-amber-500/10'
                    }`}
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Admin Portal</span>
                  </button>
                )}
                <button
                  onClick={() => onNavigate('customer-dashboard')}
                  className={`flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                    currentView === 'customer-dashboard'
                      ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                      : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
                  }`}
                >
                  <LayoutDashboard className="w-3.5 h-3.5 text-amber-400" />
                  <span>Dashboard</span>
                </button>
                <button
                  onClick={logout}
                  title="Log out"
                  className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-xl transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-2.5">
                <button
                  onClick={() => onOpenAuth('login')}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-200 hover:text-white hover:bg-slate-800/80 transition-colors"
                >
                  Client Login
                </button>
                <button
                  onClick={onOpenCheckout}
                  className="flex items-center space-x-1 px-4 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 transition-all shadow-md shadow-amber-500/20"
                >
                  <span>Explore Investments</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>

          {/* Mobile Hamburger Button */}
          <div className="lg:hidden flex items-center space-x-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition-colors"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-800 bg-[#070b12] px-4 pt-3 pb-6 space-y-3 shadow-2xl animate-fadeIn">
          <div className="space-y-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  currentView === link.id
                    ? 'text-amber-300 bg-amber-500/10 font-semibold'
                    : 'text-slate-300 hover:bg-slate-800/50'
                }`}
              >
                {link.label}
              </button>
            ))}

            {/* Mobile Financial Intelligence Section */}
            <div className="pt-2 pb-1 border-t border-slate-800/80">
              <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest px-4 block mb-1">
                Financial Intelligence
              </span>
              <button
                onClick={() => handleLinkClick('crypto-intelligence')}
                className="w-full text-left px-4 py-2 rounded-xl text-sm font-medium text-slate-300 hover:bg-slate-800/50 flex items-center justify-between"
              >
                <span>Crypto Intelligence Centre</span>
                <TrendingUp className="w-4 h-4 text-amber-400" />
              </button>
              <button
                onClick={() => {
                  if (user) {
                    onNavigate('customer-financial-overview');
                  } else {
                    onOpenAuth('login');
                  }
                  setMobileMenuOpen(false);
                }}
                className="w-full text-left px-4 py-2 rounded-xl text-sm font-medium text-slate-300 hover:bg-slate-800/50 flex items-center justify-between"
              >
                <span>Customer Financial Overview</span>
                <UserIcon className="w-4 h-4 text-blue-400" />
              </button>
              {user?.role === 'admin' && (
                <>
                  <button
                    onClick={() => {
                      onNavigate('admin-business-finance');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 rounded-xl text-sm font-medium text-slate-300 hover:bg-slate-800/50 flex items-center justify-between"
                  >
                    <span>Business Finance Centre</span>
                    <Shield className="w-4 h-4 text-emerald-400" />
                  </button>
                  <button
                    onClick={() => {
                      onNavigate('admin-data-sources');
                      setMobileMenuOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 rounded-xl text-sm font-medium text-slate-300 hover:bg-slate-800/50 flex items-center justify-between"
                  >
                    <span>Data Sources & Status</span>
                    <Lock className="w-4 h-4 text-cyan-400" />
                  </button>
                </>
              )}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80 space-y-2">
            {user ? (
              <>
                <button
                  onClick={() => handleLinkClick('customer-dashboard')}
                  className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-sm font-semibold"
                >
                  <span>Client Dashboard ({user.firstName})</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
                {user.role === 'admin' && (
                  <button
                    onClick={() => handleLinkClick('admin-dashboard')}
                    className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl bg-slate-900 border border-amber-500/40 text-amber-400 text-sm font-semibold"
                  >
                    <span>Administrator Portal</span>
                    <Lock className="w-4 h-4" />
                  </button>
                )}
                <button
                  onClick={() => {
                    logout();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center space-x-2 px-4 py-2.5 rounded-xl text-red-400 hover:bg-red-500/10 text-sm font-medium"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Log Out</span>
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    onOpenAuth('login');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl text-xs font-semibold text-slate-200 bg-slate-900 border border-slate-800"
                >
                  Client Login
                </button>
                <button
                  onClick={() => {
                    onOpenAuth('register');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400"
                >
                  Register
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};
