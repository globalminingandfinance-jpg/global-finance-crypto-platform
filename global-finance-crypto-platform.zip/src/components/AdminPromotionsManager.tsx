import React, { useState, useEffect } from 'react';
import {
  Tag,
  Clock,
  Calendar,
  Send,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Eye,
  RefreshCw,
  Gift,
  Coins,
  Percent,
  Sparkles,
  ShieldAlert,
  Users,
  Power,
  ArrowRight,
  Check,
  X,
  FileCheck,
} from 'lucide-react';
import {
  PromotionalOfferTemplate,
  PromotionalOfferRun,
  PromotionalRewardClaim,
  PromotionTargetAudience,
  PromotionDiscountType,
} from '../types/index.js';

interface AdminPromotionsManagerProps {
  token: string | null;
}

export const AdminPromotionsManager: React.FC<AdminPromotionsManagerProps> = ({ token }) => {
  const [templates, setTemplates] = useState<PromotionalOfferTemplate[]>([]);
  const [recentRuns, setRecentRuns] = useState<PromotionalOfferRun[]>([]);
  const [claims, setClaims] = useState<PromotionalRewardClaim[]>([]);
  const [upcomingSchedule, setUpcomingSchedule] = useState<any[]>([]);
  const [sastTime, setSastTime] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<PromotionalOfferTemplate | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [previewTemplate, setPreviewTemplate] = useState<PromotionalOfferTemplate | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Kill switch modal state
  const [killingRun, setKillingRun] = useState<PromotionalOfferRun | null>(null);
  const [isKilling, setIsKilling] = useState(false);

  // Manual trigger state
  const [triggeringTemplate, setTriggeringTemplate] = useState<PromotionalOfferTemplate | null>(null);
  const [isTriggering, setIsTriggering] = useState(false);

  // Claim review state
  const [reviewingClaim, setReviewingClaim] = useState<{ claim: PromotionalRewardClaim; action: 'APPROVE' | 'REJECT' } | null>(null);
  const [reviewNotes, setReviewNotes] = useState('');
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  const fetchOverview = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const res = await fetch('/api/admin/promotions/overview', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setTemplates(data.templates || []);
        setRecentRuns(data.recentRuns || []);
        setUpcomingSchedule(data.upcomingSchedule || []);
        if (data.currentSAST) {
          setSastTime(data.currentSAST.sastFormatted || '');
        }
      }

      const claimsRes = await fetch('/api/admin/promotions/claims', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (claimsRes.ok) {
        const cData = await claimsRes.json();
        setClaims(cData.claims || []);
      }
    } catch (err) {
      console.error('Failed to load promotions overview:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOverview();
    const interval = setInterval(fetchOverview, 30000);
    return () => clearInterval(interval);
  }, [token]);

  const handleToggleTemplate = async (template: PromotionalOfferTemplate) => {
    if (!token) return;
    const newStatus = template.is_enabled === 1 ? 0 : 1;
    try {
      const res = await fetch(`/api/admin/promotions/templates/${template.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ is_enabled: newStatus }),
      });
      if (res.ok) {
        setTemplates((prev) =>
          prev.map((t) => (t.id === template.id ? { ...t, is_enabled: newStatus } : t))
        );
        setFeedback({
          type: 'success',
          text: `Recurring slot ${template.slot_key} is now ${newStatus === 1 ? 'ENABLED' : 'DISABLED'}.`,
        });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    }
  };

  const handleSaveTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !editingTemplate) return;
    setIsSaving(true);
    try {
      const res = await fetch(`/api/admin/promotions/templates/${editingTemplate.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(editingTemplate),
      });
      const data = await res.json();
      if (res.ok) {
        setTemplates((prev) =>
          prev.map((t) => (t.id === editingTemplate.id ? data.template : t))
        );
        setEditingTemplate(null);
        setFeedback({ type: 'success', text: 'Promotional offer template updated successfully.' });
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to update template.' });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleTriggerBroadcast = async (templateId: string, isTest: boolean) => {
    if (!token) return;
    setIsTriggering(true);
    try {
      const res = await fetch(`/api/admin/promotions/templates/${templateId}/trigger`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ isTest }),
      });
      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: data.message });
        setTriggeringTemplate(null);
        fetchOverview();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to dispatch offer.' });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    } finally {
      setIsTriggering(false);
    }
  };

  const handleKillRun = async () => {
    if (!token || !killingRun) return;
    setIsKilling(true);
    try {
      const res = await fetch(`/api/admin/promotions/runs/${killingRun.id}/kill`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: data.message });
        setKillingRun(null);
        fetchOverview();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to engage kill switch.' });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    } finally {
      setIsKilling(false);
    }
  };

  const handleReviewClaim = async () => {
    if (!token || !reviewingClaim) return;
    setIsSubmittingReview(true);
    try {
      const res = await fetch(`/api/admin/promotions/claims/${reviewingClaim.claim.id}/review`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: reviewingClaim.action,
          notes: reviewNotes,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setFeedback({ type: 'success', text: data.message });
        setReviewingClaim(null);
        setReviewNotes('');
        fetchOverview();
      } else {
        setFeedback({ type: 'error', text: data.error || 'Failed to review claim.' });
      }
    } catch {
      setFeedback({ type: 'error', text: 'Network connection failed.' });
    } finally {
      setIsSubmittingReview(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Title & Timezone Status Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/60 border border-slate-800 rounded-2xl p-6">
        <div>
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <Tag className="w-4 h-4" />
            </div>
            <h1 className="text-xl font-bold font-serif text-slate-100">
              Automated Money Offers Manager
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
            Automates the monthly publication of 4 scheduled, money-focused promotional offers. Runs independently in the background strictly synchronized to South Africa Standard Time (Africa/Johannesburg, 09:00 SAST).
          </p>
        </div>

        <div className="flex items-center space-x-4">
          <div className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-right">
            <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold flex items-center justify-end space-x-1">
              <Clock className="w-3 h-3 text-amber-400" />
              <span>Official SAST Engine Clock</span>
            </div>
            <div className="font-mono text-xs text-amber-300 font-bold mt-0.5">
              {sastTime || 'Synchronizing with SAST...'}
            </div>
          </div>

          <button
            onClick={fetchOverview}
            disabled={isLoading}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition-colors"
            title="Refresh schedule & claims"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {feedback && (
        <div
          className={`p-4 rounded-xl text-xs flex items-center justify-between ${
            feedback.type === 'success'
              ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300'
              : 'bg-red-500/10 border border-red-500/30 text-red-400'
          }`}
        >
          <div className="flex items-center space-x-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 shrink-0" />
            )}
            <span>{feedback.text}</span>
          </div>
          <button
            onClick={() => setFeedback(null)}
            className="text-slate-500 hover:text-slate-300 ml-4"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* SECTION 1: UPCOMING MONTHLY SCHEDULE TIMELINE */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              <span>Recurring Monthly Calendar (Africa/Johannesburg 09:00 SAST)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Unique monthly idempotency keys guarantee zero duplicate publication across server restarts.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {upcomingSchedule.map((slot) => {
            const template = templates.find((t) => t.slot_key === slot.slotKey);
            const isEnabled = template?.is_enabled === 1;

            return (
              <div
                key={slot.slotKey}
                className={`bg-slate-900/80 border rounded-2xl p-4 transition-all ${
                  isEnabled ? 'border-slate-800 hover:border-amber-500/40' : 'border-slate-800/40 opacity-70'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                    {slot.dayOfMonth} of month
                  </span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      isEnabled
                        ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                        : 'bg-slate-800 text-slate-400 border border-slate-700'
                    }`}
                  >
                    {isEnabled ? 'ARMED' : 'PAUSED'}
                  </span>
                </div>

                <div className="font-bold text-slate-200 text-sm mb-1">{slot.name}</div>
                <div className="text-[11px] text-slate-400 line-clamp-2 mb-3">
                  {template?.title || 'Configured offer template'}
                </div>

                <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
                  <span>Next scheduled:</span>
                  <span className="font-mono text-amber-300 font-semibold">{slot.nextScheduledSAST}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 2: CONFIGURE OFFER TEMPLATES */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Monthly Recurring Promotional Templates (4 Slots)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Customize financial terms, target audiences, and legal disclosures for each monthly slot.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {templates.map((tpl) => {
            const isEnabled = tpl.is_enabled === 1;

            return (
              <div
                key={tpl.id}
                className={`bg-slate-900/80 border rounded-2xl p-5 flex flex-col justify-between transition-all ${
                  isEnabled ? 'border-slate-800' : 'border-slate-800/40 opacity-75'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-2">
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        {tpl.slot_key}
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 border border-amber-500/30">
                        Day {tpl.schedule_day === -1 ? 'Final' : tpl.schedule_day} @ {tpl.schedule_time_sast} SAST
                      </span>
                    </div>

                    {/* Master Switch */}
                    <button
                      onClick={() => handleToggleTemplate(tpl)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center space-x-1.5 transition-colors border ${
                        isEnabled
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/25'
                          : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                      }`}
                      title={isEnabled ? 'Click to disable slot' : 'Click to enable slot'}
                    >
                      <Power className="w-3 h-3" />
                      <span>{isEnabled ? 'Active' : 'Disabled'}</span>
                    </button>
                  </div>

                  <h3 className="font-bold text-slate-100 text-sm mb-1">{tpl.title}</h3>
                  <p className="text-xs text-slate-400 leading-relaxed mb-4">{tpl.description}</p>

                  {/* Financial terms breakdown */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-[11px] mb-4">
                    {tpl.category === 'FEE_DISCOUNT' && (
                      <>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Normal Fee</span>
                          <span className="font-mono text-slate-300">R {tpl.normal_fee_amount?.toFixed(2)}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Discount Value</span>
                          <span className="font-mono text-emerald-400 font-bold">
                            {tpl.discount_type === 'PERCENTAGE' ? `${tpl.discount_value}%` : `R ${tpl.discount_value}`}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Min Allocation</span>
                          <span className="font-mono text-slate-300">R {tpl.min_deposit_amount?.toLocaleString('en-ZA')}</span>
                        </div>
                      </>
                    )}

                    {tpl.category === 'CASH_REWARD' && (
                      <>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Cash Reward</span>
                          <span className="font-mono text-amber-300 font-bold">R {tpl.reward_amount?.toFixed(2)}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Min Qualifying</span>
                          <span className="font-mono text-slate-300">R {tpl.min_deposit_amount?.toLocaleString('en-ZA')}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Workflow</span>
                          <span className="text-slate-300">Pending Review</span>
                        </div>
                      </>
                    )}

                    {tpl.category === 'SPECIAL_OFFER' && (
                      <>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Surcharge Waived</span>
                          <span className="font-mono text-emerald-400 font-bold">R {tpl.discount_value?.toFixed(2)}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Min Commitment</span>
                          <span className="font-mono text-slate-300">R {tpl.min_deposit_amount?.toLocaleString('en-ZA')}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Eligible Product</span>
                          <span className="text-slate-300 truncate">{tpl.product_name || 'Enterprise'}</span>
                        </div>
                      </>
                    )}

                    {tpl.category === 'MONTH_END' && (
                      <>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Bonus Hash Power</span>
                          <span className="font-mono text-purple-300 font-bold">+{tpl.discount_value}% Allocation</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Timing Window</span>
                          <span className="text-slate-300">Final Day Until 23:59</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Target Audience</span>
                          <span className="text-slate-300">{tpl.target_audience}</span>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* Card Actions Toolbar */}
                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setPreviewTemplate(tpl)}
                      className="px-3 py-1.5 rounded-lg text-[11px] font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors flex items-center space-x-1"
                    >
                      <Eye className="w-3.5 h-3.5 text-amber-400" />
                      <span>Client Preview</span>
                    </button>
                    <button
                      onClick={() => setEditingTemplate(tpl)}
                      className="px-3 py-1.5 rounded-lg text-[11px] font-medium text-amber-300 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 transition-colors"
                    >
                      Edit Offer
                    </button>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleTriggerBroadcast(tpl.id, true)}
                      disabled={isTriggering}
                      className="px-2.5 py-1.5 rounded-lg text-[10px] font-medium text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors"
                      title="Send a sample notification strictly to your administrator account"
                    >
                      Test Send to Admin
                    </button>
                    <button
                      onClick={() => setTriggeringTemplate(tpl)}
                      className="px-3 py-1.5 rounded-lg text-[11px] font-bold text-black bg-amber-500 hover:bg-amber-400 transition-colors flex items-center space-x-1 shadow-sm shadow-amber-500/10"
                    >
                      <Send className="w-3 h-3" />
                      <span>Trigger Now</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 3: PENDING CASH-VALUE REWARD CLAIMS */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-2">
              <Gift className="w-4 h-4 text-amber-400" />
              <span>Pending Cash-Value Reward Claims (16th Monthly Vouchers)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Client claims require explicit administrator verification before capital is safely credited to the double-entry ledger.
            </p>
          </div>
          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-800 text-amber-400 border border-slate-700">
            {claims.filter((c) => c.status === 'PENDING_APPROVAL').length} Pending
          </span>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
          {claims.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              <FileCheck className="w-8 h-8 mx-auto mb-2 opacity-30 text-slate-400" />
              <p>No reward voucher claims submitted yet.</p>
              <p className="text-[11px] text-slate-600 mt-1">
                When clients click "Claim Reward" on the 16th Cash-Value Reward notification, submissions appear here for review.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider">
                    <th className="p-3.5">Client</th>
                    <th className="p-3.5">Voucher Amount</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Claimed At</th>
                    <th className="p-3.5">Notes</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {claims.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-900/50 transition-colors">
                      <td className="p-3.5">
                        <div className="font-semibold text-slate-200">{c.user_email}</div>
                        <div className="text-[10px] text-slate-500 font-mono">ID: {c.user_id}</div>
                      </td>
                      <td className="p-3.5 font-mono text-amber-300 font-bold">
                        R {Number(c.reward_amount).toFixed(2)}
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            c.status === 'APPROVED'
                              ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                              : c.status === 'REJECTED'
                              ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                              : 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {c.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-400 text-[11px]">
                        {new Date(c.created_at).toLocaleString()}
                      </td>
                      <td className="p-3.5 text-slate-400 text-[11px] max-w-xs truncate">
                        {c.admin_notes || c.claim_notes || '—'}
                      </td>
                      <td className="p-3.5 text-right">
                        {c.status === 'PENDING_APPROVAL' ? (
                          <div className="flex items-center justify-end space-x-2">
                            <button
                              onClick={() => setReviewingClaim({ claim: c, action: 'APPROVE' })}
                              className="px-2.5 py-1 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 rounded-lg font-bold text-[10px] transition-colors"
                            >
                              Approve & Credit
                            </button>
                            <button
                              onClick={() => setReviewingClaim({ claim: c, action: 'REJECT' })}
                              className="px-2.5 py-1 bg-red-500/15 hover:bg-red-500/25 text-red-400 border border-red-500/30 rounded-lg font-bold text-[10px] transition-colors"
                            >
                              Reject
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-500 font-mono">
                            {c.reviewed_by ? `By ${c.reviewed_by}` : 'Reviewed'}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* SECTION 4: PUBLICATION RUNS & EMERGENCY KILL SWITCH */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center space-x-2">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>Publication History & Active Runs (Emergency Kill Switch)</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Live record of all scheduled and manual broadcasts. Emergency Kill Switch instantly revokes active campaigns.
            </p>
          </div>
        </div>

        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden">
          {recentRuns.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              <Clock className="w-8 h-8 mx-auto mb-2 opacity-30 text-slate-400" />
              <p>No promotional broadcasts recorded yet.</p>
              <p className="text-[11px] text-slate-600 mt-1">
                Runs will appear automatically as the monthly scheduler triggers on the 6th, 16th, 26th, and final calendar day.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 uppercase text-[10px] tracking-wider">
                    <th className="p-3.5">Offer Title</th>
                    <th className="p-3.5">Slot / Idempotency Key</th>
                    <th className="p-3.5">Trigger</th>
                    <th className="p-3.5">Published (SAST)</th>
                    <th className="p-3.5">Expires</th>
                    <th className="p-3.5">Clients</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Kill Switch</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {recentRuns.map((r) => {
                    const isActive = r.status === 'ACTIVE' && new Date(r.expires_at).getTime() > Date.now();

                    return (
                      <tr key={r.id} className="hover:bg-slate-900/50 transition-colors">
                        <td className="p-3.5 font-semibold text-slate-200 max-w-xs truncate">
                          {r.offer_title}
                        </td>
                        <td className="p-3.5 font-mono text-[10px] text-slate-400">
                          {r.idempotency_key}
                        </td>
                        <td className="p-3.5">
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                            {r.trigger_type}
                          </span>
                        </td>
                        <td className="p-3.5 text-slate-400 text-[11px]">
                          {new Date(r.published_at).toLocaleString()}
                        </td>
                        <td className="p-3.5 text-slate-400 text-[11px]">
                          {new Date(r.expires_at).toLocaleString()}
                        </td>
                        <td className="p-3.5 font-mono text-slate-300">
                          {r.recipient_count}
                        </td>
                        <td className="p-3.5">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              r.status === 'CANCELLED_KILL_SWITCH'
                                ? 'bg-red-500/15 text-red-400 border border-red-500/30'
                                : isActive
                                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                                : 'bg-slate-800 text-slate-400 border border-slate-700'
                            }`}
                          >
                            {r.status === 'CANCELLED_KILL_SWITCH' ? 'REVOKED' : isActive ? 'ACTIVE' : 'EXPIRED'}
                          </span>
                        </td>
                        <td className="p-3.5 text-right">
                          {isActive && (
                            <button
                              onClick={() => setKillingRun(r)}
                              className="px-2.5 py-1 bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 rounded-lg text-[10px] font-bold transition-colors flex items-center space-x-1 ml-auto"
                            >
                              <AlertTriangle className="w-3 h-3 text-red-400" />
                              <span>Emergency Kill</span>
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* MODAL 1: EDIT TEMPLATE */}
      {editingTemplate && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="text-base font-bold text-slate-100 flex items-center space-x-2">
                <Tag className="w-4 h-4 text-amber-400" />
                <span>Edit Offer Template: {editingTemplate.slot_key}</span>
              </h3>
              <button
                onClick={() => setEditingTemplate(null)}
                className="text-slate-500 hover:text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveTemplate} className="space-y-4 mt-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-medium">Offer Title Headline</label>
                <input
                  type="text"
                  required
                  value={editingTemplate.title}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, title: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Description & Promotional Copy</label>
                <textarea
                  required
                  rows={3}
                  value={editingTemplate.description}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, description: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-100 focus:outline-none focus:border-amber-500 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Target Audience</label>
                  <select
                    value={editingTemplate.target_audience}
                    onChange={(e) =>
                      setEditingTemplate({
                        ...editingTemplate,
                        target_audience: e.target.value as PromotionTargetAudience,
                      })
                    }
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
                  >
                    <option value="ALL_CLIENTS">All Active Clients</option>
                    <option value="VERIFIED_KYC_ONLY">Verified KYC Only</option>
                    <option value="ACTIVE_INVESTORS">Active Investors Only</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Discount Type</label>
                  <select
                    value={editingTemplate.discount_type}
                    onChange={(e) =>
                      setEditingTemplate({
                        ...editingTemplate,
                        discount_type: e.target.value as PromotionDiscountType,
                      })
                    }
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-200"
                  >
                    <option value="PERCENTAGE">Percentage (%)</option>
                    <option value="FIXED_AMOUNT">Fixed Amount (ZAR)</option>
                    <option value="NONE">None</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Discount Value</label>
                  <input
                    type="number"
                    step="any"
                    value={editingTemplate.discount_value}
                    onChange={(e) =>
                      setEditingTemplate({ ...editingTemplate, discount_value: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Normal Fee (ZAR)</label>
                  <input
                    type="number"
                    step="any"
                    value={editingTemplate.normal_fee_amount}
                    onChange={(e) =>
                      setEditingTemplate({ ...editingTemplate, normal_fee_amount: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Min Deposit (ZAR)</label>
                  <input
                    type="number"
                    step="any"
                    value={editingTemplate.min_deposit_amount}
                    onChange={(e) =>
                      setEditingTemplate({ ...editingTemplate, min_deposit_amount: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Cash Reward (ZAR)</label>
                  <input
                    type="number"
                    step="any"
                    value={editingTemplate.reward_amount}
                    onChange={(e) =>
                      setEditingTemplate({ ...editingTemplate, reward_amount: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Validity Duration (Hours)</label>
                  <input
                    type="number"
                    min="1"
                    max="168"
                    value={editingTemplate.validity_hours}
                    onChange={(e) =>
                      setEditingTemplate({ ...editingTemplate, validity_hours: parseInt(e.target.value, 10) || 48 })
                    }
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Button Label</label>
                  <input
                    type="text"
                    value={editingTemplate.cta_label}
                    onChange={(e) => setEditingTemplate({ ...editingTemplate, cta_label: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">Target Route</label>
                  <input
                    type="text"
                    value={editingTemplate.cta_route}
                    onChange={(e) => setEditingTemplate({ ...editingTemplate, cta_route: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">Mandatory Risk & Regulatory Disclaimer</label>
                <textarea
                  required
                  rows={2}
                  value={editingTemplate.disclaimer}
                  onChange={(e) => setEditingTemplate({ ...editingTemplate, disclaimer: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-300 focus:outline-none focus:border-amber-500 leading-normal font-mono text-[11px]"
                />
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setEditingTemplate(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-black rounded-xl font-bold transition-all shadow-md shadow-amber-500/20"
                >
                  {isSaving ? 'Saving Changes...' : 'Save Template'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: CLIENT PREVIEW */}
      {previewTemplate && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>Client Notification Center Preview</span>
              </span>
              <button
                onClick={() => setPreviewTemplate(null)}
                className="text-slate-500 hover:text-slate-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4 p-4 rounded-xl bg-slate-900/90 border border-amber-500/30 text-xs">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">
                  {previewTemplate.category}
                </span>
                <span className="text-[10px] text-amber-400 font-mono flex items-center space-x-1">
                  <Clock className="w-3 h-3 inline" />
                  <span>{previewTemplate.validity_hours}h left</span>
                </span>
              </div>

              <div className="font-bold text-slate-100 text-sm mb-1">{previewTemplate.title}</div>
              <p className="text-slate-300 text-[11px] leading-relaxed mb-3">{previewTemplate.description}</p>

              <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-[11px] space-y-1 mb-3">
                {previewTemplate.category === 'FEE_DISCOUNT' && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Normal Fee: R {previewTemplate.normal_fee_amount}</span>
                    <span className="text-emerald-400 font-bold">
                      Save {previewTemplate.discount_value}%
                    </span>
                  </div>
                )}
                {previewTemplate.category === 'CASH_REWARD' && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Voucher Value:</span>
                    <span className="text-amber-300 font-bold">R {previewTemplate.reward_amount.toFixed(2)}</span>
                  </div>
                )}
                <div className="text-[10px] text-slate-500">
                  Target Audience: {previewTemplate.target_audience}
                </div>
              </div>

              <button className="w-full py-2 bg-amber-500 text-black font-bold rounded-lg text-xs flex items-center justify-center space-x-1">
                <span>{previewTemplate.cta_label}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="mt-2 text-[9px] text-slate-500 border-t border-slate-800 pt-2 leading-tight">
                {previewTemplate.disclaimer}
              </div>
            </div>

            <div className="mt-4 flex justify-end">
              <button
                onClick={() => setPreviewTemplate(null)}
                className="px-4 py-1.5 bg-slate-800 text-slate-300 rounded-lg text-xs"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: CONFIRM TRIGGER BROADCAST */}
      {triggeringTemplate && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center space-x-2 text-amber-400 mb-2">
              <Send className="w-5 h-5" />
              <h3 className="font-bold text-slate-100 text-sm">Confirm Immediate Broadcast</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to publish an immediate broadcast of{' '}
              <strong className="text-amber-300">{triggeringTemplate.title}</strong> to qualifying clients?
            </p>
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-[11px] text-slate-400 my-4 space-y-1">
              <div>Target Audience: <span className="text-slate-200 font-medium">{triggeringTemplate.target_audience}</span></div>
              <div>Validity: <span className="text-slate-200 font-medium">{triggeringTemplate.validity_hours} Hours from dispatch</span></div>
            </div>

            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => setTriggeringTemplate(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => handleTriggerBroadcast(triggeringTemplate.id, false)}
                disabled={isTriggering}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-xl text-xs transition-colors"
              >
                {isTriggering ? 'Dispatching...' : 'Confirm & Dispatch Broadcast'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: EMERGENCY KILL SWITCH CONFIRMATION */}
      {killingRun && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-red-500/50 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center space-x-2 text-red-400 mb-2">
              <AlertTriangle className="w-5 h-5" />
              <h3 className="font-bold text-slate-100 text-sm">Emergency Kill Switch Confirmation</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              You are about to permanently revoke active promotion{' '}
              <strong className="text-red-300">{killingRun.offer_title}</strong> (ID: {killingRun.id}).
            </p>
            <p className="text-[11px] text-slate-400 mt-2">
              This action immediately terminates offer validity, rejects pending claim submissions, and marks the campaign as revoked in all customer notifications.
            </p>

            <div className="flex items-center justify-end space-x-3 mt-6">
              <button
                onClick={() => setKillingRun(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleKillRun}
                disabled={isKilling}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-xl text-xs transition-colors shadow-lg shadow-red-600/30"
              >
                {isKilling ? 'Revoking...' : 'Engage Emergency Kill Switch'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 5: CLAIM REVIEW (APPROVE OR REJECT) */}
      {reviewingClaim && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-950 border border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <h3 className="font-bold text-slate-100 text-sm mb-2 flex items-center space-x-2">
              <Gift className="w-4 h-4 text-amber-400" />
              <span>
                {reviewingClaim.action === 'APPROVE'
                  ? 'Approve Reward Claim & Credit Balance'
                  : 'Reject Reward Claim'}
              </span>
            </h3>

            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 my-3 space-y-1">
              <div>Client: <strong className="text-white">{reviewingClaim.claim.user_email}</strong></div>
              <div>Voucher Amount: <strong className="text-amber-300 font-mono">R {Number(reviewingClaim.claim.reward_amount).toFixed(2)}</strong></div>
              {reviewingClaim.action === 'APPROVE' && (
                <div className="text-emerald-400 text-[11px] mt-1">
                  ✓ Will apply double-entry credit to client financial ledger automatically.
                </div>
              )}
            </div>

            <div className="mb-4">
              <label className="block text-slate-400 text-xs mb-1">Administrator Review Notes</label>
              <textarea
                rows={2}
                value={reviewNotes}
                onChange={(e) => setReviewNotes(e.target.value)}
                placeholder={
                  reviewingClaim.action === 'APPROVE'
                    ? 'e.g. Allocation verified, reward voucher credited.'
                    : 'e.g. Ineligible: Did not meet minimum R2,500 deposit requirement.'
                }
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-2.5 text-xs text-slate-200 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div className="flex items-center justify-end space-x-3">
              <button
                onClick={() => setReviewingClaim(null)}
                className="px-4 py-2 bg-slate-800 text-slate-300 rounded-xl text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleReviewClaim}
                disabled={isSubmittingReview}
                className={`px-4 py-2 font-bold rounded-xl text-xs transition-colors ${
                  reviewingClaim.action === 'APPROVE'
                    ? 'bg-emerald-500 hover:bg-emerald-400 text-black'
                    : 'bg-red-600 hover:bg-red-500 text-white'
                }`}
              >
                {isSubmittingReview
                  ? 'Processing...'
                  : reviewingClaim.action === 'APPROVE'
                  ? 'Confirm Approval & Credit'
                  : 'Confirm Rejection'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
