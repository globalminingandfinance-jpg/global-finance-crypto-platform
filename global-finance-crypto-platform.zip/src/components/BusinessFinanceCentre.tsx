import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Building2,
  FileText,
  Download,
  Calendar,
  Layers,
  CheckCircle2,
  AlertCircle,
  Clock,
  Search,
  Plus,
  SlidersHorizontal,
  RefreshCw,
  ShieldCheck,
  X,
  ChevronLeft,
  ChevronRight,
  Info,
} from 'lucide-react';

interface Props {
  token: string | null;
}

interface FinancialRecord {
  id: string;
  recordType: 'REVENUE' | 'EXPENSE' | 'ASSET' | 'LIABILITY';
  category: string;
  categoryName?: string;
  amount: number;
  currency: string;
  reference: string;
  reportingPeriod: string;
  recordDate: string;
  description: string;
  supportingDoc?: string;
  reconciliationStatus: string;
  authorizedBy: string;
  notes?: string;
  createdAt: string;
}

interface BusinessMetrics {
  totalRevenue: number;
  totalExpenses: number;
  netOperatingIncome: number;
  operatingMarginPercent: number;
  availableBusinessCash: number;
  totalBusinessAssets: number;
  totalBusinessLiabilities: number;
  netCorporateEquity: number;
  currentReportingPeriod: string;
  segregationNotice: string;
}

export const BusinessFinanceCentre: React.FC<Props> = ({ token }) => {
  const [metrics, setMetrics] = useState<BusinessMetrics | null>(null);
  const [records, setRecords] = useState<FinancialRecord[]>([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [categories, setCategories] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Active Tab: 'overview' | 'ledger' | 'reports' | 'budgets'
  const [activeTab, setActiveTab] = useState<'overview' | 'ledger' | 'reports' | 'budgets'>('overview');

  // Reporting period filter
  const [selectedPeriod, setSelectedPeriod] = useState<string>('2026-Q3');

  // Ledger Filter states
  const [recordTypeFilter, setRecordTypeFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 15;

  // Reports state
  const [reportType, setReportType] = useState<'income' | 'balance' | 'cashflow' | 'budget'>('income');
  const [reportData, setReportData] = useState<any | null>(null);
  const [reportLoading, setReportLoading] = useState(false);

  // Budgets state
  const [budgets, setBudgets] = useState<any[]>([]);

  // Modals state
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [newType, setNewType] = useState<'REVENUE' | 'EXPENSE' | 'ASSET' | 'LIABILITY'>('REVENUE');
  const [newCategory, setNewCategory] = useState('');
  const [newAmount, setNewAmount] = useState('');
  const [newReference, setNewReference] = useState('');
  const [newDate, setNewDate] = useState(new Date().toISOString().slice(0, 10));
  const [newPeriod, setNewPeriod] = useState('2026-Q3');
  const [newDescription, setNewDescription] = useState('');
  const [newDoc, setNewDoc] = useState('');
  const [isSubmittingRecord, setIsSubmittingRecord] = useState(false);
  const [createFeedback, setCreateFeedback] = useState<string | null>(null);

  // Adjustment Modal
  const [adjustModalOpen, setAdjustModalOpen] = useState(false);
  const [adjustingRecord, setAdjustingRecord] = useState<FinancialRecord | null>(null);
  const [adjustAmount, setAdjustAmount] = useState('');
  const [adjustReason, setAdjustReason] = useState('');
  const [isAdjusting, setIsAdjusting] = useState(false);
  const [adjustFeedback, setAdjustFeedback] = useState<string | null>(null);

  const fetchOverview = async (isManual = false) => {
    if (!token) return;
    if (isManual) setIsRefreshing(true);
    else setIsLoading(true);
    setError(null);

    try {
      const headers = { Authorization: `Bearer ${token}` };
      const [resOv, resCats] = await Promise.all([
        fetch(`/api/business-finance/overview?period=${selectedPeriod}`, { headers }),
        fetch('/api/business-finance/categories', { headers }),
      ]);

      if (!resOv.ok) throw new Error('Unable to retrieve corporate financial overview.');
      const dataOv = await resOv.json();
      setMetrics(dataOv);

      if (resCats.ok) {
        const dataCats = await resCats.json();
        setCategories(dataCats.categories || []);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Error communicating with corporate finance backend.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  const fetchLedgerRecords = async () => {
    if (!token) return;
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const params = new URLSearchParams();
      if (recordTypeFilter !== 'ALL') params.set('type', recordTypeFilter);
      if (categoryFilter !== 'ALL') params.set('category', categoryFilter);
      if (selectedPeriod !== 'ALL') params.set('period', selectedPeriod);
      params.set('limit', String(pageSize));
      params.set('offset', String((page - 1) * pageSize));

      const res = await fetch(`/api/business-finance/records?${params.toString()}`, { headers });
      if (res.ok) {
        const data = await res.json();
        setRecords(data.records || []);
        setTotalRecords(data.totalCount || 0);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const fetchReport = async (type: 'income' | 'balance' | 'cashflow' | 'budget') => {
    if (!token) return;
    setReportLoading(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const res = await fetch(`/api/business-finance/reports/${type}?period=${selectedPeriod}`, { headers });
      if (res.ok) {
        const data = await res.json();
        setReportData(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setReportLoading(false);
    }
  };

  const fetchBudgets = async () => {
    if (!token) return;
    try {
      const headers = { Authorization: `Bearer ${token}` };
      const res = await fetch(`/api/business-finance/budgets?period=${selectedPeriod}`, { headers });
      if (res.ok) {
        const data = await res.json();
        setBudgets(data.comparisons || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchOverview();
  }, [token, selectedPeriod]);

  useEffect(() => {
    if (activeTab === 'ledger') fetchLedgerRecords();
    if (activeTab === 'reports') fetchReport(reportType);
    if (activeTab === 'budgets') fetchBudgets();
  }, [activeTab, recordTypeFilter, categoryFilter, selectedPeriod, page, reportType]);

  // Handle Create Record Submit
  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsSubmittingRecord(true);
    setCreateFeedback(null);

    try {
      const res = await fetch('/api/business-finance/records', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          recordType: newType,
          category: newCategory || (categories.find((c) => c.type === newType)?.code || 'REV_MINING'),
          amount: parseFloat(newAmount),
          reference: newReference.trim(),
          reportingPeriod: newPeriod,
          recordDate: newDate,
          description: newDescription,
          supportingDoc: newDoc || undefined,
        }),
      });

      const data = await res.json();
      setIsSubmittingRecord(false);

      if (res.ok && data.success) {
        setCreateFeedback('Corporate financial entry recorded successfully.');
        setTimeout(() => {
          setCreateModalOpen(false);
          setNewAmount('');
          setNewReference('');
          setNewDescription('');
          fetchOverview();
          fetchLedgerRecords();
        }, 1500);
      } else {
        setCreateFeedback(data.error || 'Failed to record entry.');
      }
    } catch {
      setIsSubmittingRecord(false);
      setCreateFeedback('Network failure recording financial entry.');
    }
  };

  // Handle Adjustment Submit
  const handleAdjustSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingRecord || !token) return;
    setIsAdjusting(true);
    setAdjustFeedback(null);

    try {
      const res = await fetch(`/api/business-finance/records/${adjustingRecord.id}/adjust`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          newAmount: parseFloat(adjustAmount),
          reason: adjustReason,
        }),
      });

      const data = await res.json();
      setIsAdjusting(false);

      if (res.ok && data.success) {
        setAdjustFeedback('Audited adjustment logged successfully.');
        setTimeout(() => {
          setAdjustModalOpen(false);
          fetchOverview();
          fetchLedgerRecords();
        }, 1500);
      } else {
        setAdjustFeedback(data.error || 'Failed to adjust record.');
      }
    } catch {
      setIsAdjusting(false);
      setAdjustFeedback('Network error while recording adjustment.');
    }
  };

  // Helper Currency Formatter
  const formatZAR = (val: number | undefined | null) => {
    const num = Number(val || 0);
    return `R ${num.toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  // Download CSV report
  const handleDownloadCsv = (type: string) => {
    window.location.href = `/api/business-finance/export/${type}?period=${selectedPeriod}`;
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* 1. HEADER & SEGREGATION NOTICE */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-[10px] uppercase font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
                Corporate Finance & Accounting
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-[11px] text-slate-400">Strictly Segregated from Customer Accounts</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-slate-100 mt-1">
              Business Finance Centre
            </h1>
            <p className="text-xs text-slate-400 max-w-2xl mt-0.5">
              Comprehensive corporate financial management, profit & loss statements, corporate balance sheets, operational expenditure tracking, and audited general ledger accounting.
            </p>
          </div>

          <div className="flex items-center space-x-3 self-start md:self-auto">
            {/* Period Selector */}
            <div className="flex items-center space-x-1.5 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-300">
              <Calendar className="w-3.5 h-3.5 text-amber-400" />
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="bg-transparent font-medium focus:outline-none"
              >
                <option value="2026-Q3">2026 - Q3 (Jul - Sep)</option>
                <option value="2026-10">2026 - October (M-T-D)</option>
                <option value="2026-Q4">2026 - Q4 (Oct - Dec)</option>
              </select>
            </div>

            <button
              onClick={() => fetchOverview(true)}
              disabled={isRefreshing}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 transition-colors disabled:opacity-50"
              title="Refresh financial ledger"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-amber-400' : 'text-slate-400'}`} />
            </button>

            <button
              onClick={() => {
                setNewPeriod(selectedPeriod);
                setNewReference(`GF-${selectedPeriod.replace('-', '')}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`);
                setCreateFeedback(null);
                setCreateModalOpen(true);
              }}
              className="flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record Entry</span>
            </button>
          </div>
        </div>

        {/* Regulatory Segregation Notice */}
        <div className="p-4 bg-amber-500/10 border border-amber-500/30 rounded-2xl flex items-start space-x-3 text-xs text-amber-300/90 leading-relaxed">
          <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold text-amber-300 block mb-0.5">
              Strict Legal & Accounting Segregation of Funds
            </span>
            <span>
              All financial metrics and statements in this module reflect the corporate operating books of Global Finance Crypto Mining. Customer investment capital and customer deposits are held under trust and recorded exclusively on the segregated double-entry customer ledger. Customer funds are never classified as company operating revenue.
            </span>
          </div>
        </div>
      </div>

      {/* 2. CORPORATE PERFORMANCE SUMMARY CARDS (6 CARDS) */}
      {metrics && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Card 1: Total Corporate Revenue */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Total Business Revenue ({selectedPeriod})</span>
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div>
              <div className="text-2xl font-serif font-bold text-emerald-400 font-mono">
                {formatZAR(metrics.totalRevenue)}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Mining pool yield fees & capacity leasing
              </div>
            </div>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
              Verified corporate operating inflows.
            </div>
          </div>

          {/* Card 2: Operating Expenses */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Operating Expenses ({selectedPeriod})</span>
              <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400">
                <TrendingDown className="w-4 h-4" />
              </div>
            </div>
            <div>
              <div className="text-2xl font-serif font-bold text-rose-400 font-mono">
                {formatZAR(metrics.totalExpenses)}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Data centre power, maintenance, colocation
              </div>
            </div>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
              Audited operational costs incurred.
            </div>
          </div>

          {/* Card 3: Net Operating Income */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Net Operating Income (EBITDA)</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/10 text-amber-300 font-mono">
                {metrics.operatingMarginPercent}% Margin
              </span>
            </div>
            <div>
              <div className="text-2xl font-serif font-bold text-amber-300 font-mono">
                {formatZAR(metrics.netOperatingIncome)}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Gross operating surplus before tax
              </div>
            </div>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
              Revenue minus operational expenditures.
            </div>
          </div>

          {/* Card 4: Corporate Cash in Bank */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Corporate Bank Cash Reserve</span>
              <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400">
                <Building2 className="w-4 h-4" />
              </div>
            </div>
            <div>
              <div className="text-2xl font-serif font-bold text-cyan-300 font-mono">
                {formatZAR(metrics.availableBusinessCash)}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                TymeBank Corporate Account (#53002153808)
              </div>
            </div>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
              Available company working capital.
            </div>
          </div>

          {/* Card 5: Total Business Assets */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Total Business Assets</span>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-blue-500/10 text-blue-300">
                Hardware & Infra
              </span>
            </div>
            <div>
              <div className="text-2xl font-serif font-bold text-blue-300 font-mono">
                {formatZAR(metrics.totalBusinessAssets)}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                ASIC Rigs, Cooling & Transformers
              </div>
            </div>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
              Evaluated fixed computational infrastructure.
            </div>
          </div>

          {/* Card 6: Corporate Liabilities & Equity */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">Net Corporate Equity</span>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-purple-500/10 text-purple-300">
                Assets - Liabilities
              </span>
            </div>
            <div>
              <div className="text-2xl font-serif font-bold text-purple-300 font-mono">
                {formatZAR(metrics.netCorporateEquity)}
              </div>
              <div className="text-[11px] text-slate-400 mt-1">
                Liabilities: {formatZAR(metrics.totalBusinessLiabilities)}
              </div>
            </div>
            <div className="text-[10px] text-slate-500 border-t border-slate-800/80 pt-2">
              Net balance sheet value of the business.
            </div>
          </div>
        </div>
      )}

      {/* 3. NAVIGATION TABS */}
      <div className="border-b border-slate-800 flex flex-wrap items-center justify-between gap-4 pb-2">
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'overview'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Overview & Breakdown
          </button>
          <button
            onClick={() => setActiveTab('ledger')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'ledger'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            General Ledger Entries ({totalRecords || '...'})
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'reports'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Financial Reports (P&L, Balance Sheet, Cash Flow)
          </button>
          <button
            onClick={() => setActiveTab('budgets')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'budgets'
                ? 'bg-amber-500 text-black shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            Budgets & Variance
          </button>
        </div>
      </div>

      {/* 4. TAB CONTENT */}
      {/* TAB A: OVERVIEW BREAKDOWN */}
      {activeTab === 'overview' && metrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Revenue Breakdown */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center justify-between">
              <span>Revenue Streams ({selectedPeriod})</span>
              <span className="text-emerald-400 font-mono font-bold text-sm">
                {formatZAR(metrics.totalRevenue)}
              </span>
            </h3>
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex justify-between items-center">
                <div>
                  <span className="font-semibold text-slate-200 block">Mining Infrastructure Yield Fee</span>
                  <span className="text-[11px] text-slate-500">Block reward commissions</span>
                </div>
                <span className="font-mono text-emerald-400 font-bold">R 1,420,000.00</span>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex justify-between items-center">
                <div>
                  <span className="font-semibold text-slate-200 block">Computational Hash Allocation Fee</span>
                  <span className="text-[11px] text-slate-500">Capacity hosting contracts</span>
                </div>
                <span className="font-mono text-emerald-400 font-bold">R 780,000.00</span>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex justify-between items-center">
                <div>
                  <span className="font-semibold text-slate-200 block">Custody & Compliance Administration</span>
                  <span className="text-[11px] text-slate-500">Institutional FICA verification</span>
                </div>
                <span className="font-mono text-emerald-400 font-bold">R 195,000.00</span>
              </div>
            </div>
          </div>

          {/* Operating Expense Breakdown */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-100 flex items-center justify-between">
              <span>Operating Costs ({selectedPeriod})</span>
              <span className="text-rose-400 font-mono font-bold text-sm">
                {formatZAR(metrics.totalExpenses)}
              </span>
            </h3>
            <div className="space-y-3 text-xs">
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex justify-between items-center">
                <div>
                  <span className="font-semibold text-slate-200 block">Data Centre Primary Grid Electricity</span>
                  <span className="text-[11px] text-slate-500">11kV high-density power tariffs</span>
                </div>
                <span className="font-mono text-rose-400 font-bold">R 890,000.00</span>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex justify-between items-center">
                <div>
                  <span className="font-semibold text-slate-200 block">Hardware Maintenance & Parts</span>
                  <span className="text-[11px] text-slate-500">Hashboard & cooling servicing</span>
                </div>
                <span className="font-mono text-rose-400 font-bold">R 210,000.00</span>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex justify-between items-center">
                <div>
                  <span className="font-semibold text-slate-200 block">Secure Tier-3 Rack Co-location</span>
                  <span className="text-[11px] text-slate-500">Facility rental and cooling</span>
                </div>
                <span className="font-mono text-rose-400 font-bold">R 180,000.00</span>
              </div>
              <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl flex justify-between items-center">
                <div>
                  <span className="font-semibold text-slate-200 block">Regulatory Compliance & Legal Audit</span>
                  <span className="text-[11px] text-slate-500">Independent legal oversight</span>
                </div>
                <span className="font-mono text-rose-400 font-bold">R 95,000.00</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB B: GENERAL LEDGER ENTRIES */}
      {activeTab === 'ledger' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-4 border border-slate-800 rounded-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-400 font-medium">Record Type:</span>
              {(['ALL', 'REVENUE', 'EXPENSE', 'ASSET', 'LIABILITY'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => {
                    setRecordTypeFilter(t);
                    setPage(1);
                  }}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors ${
                    recordTypeFilter === t
                      ? 'bg-slate-800 text-amber-300 border border-amber-500/30'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            <span className="text-xs text-slate-400 font-mono">
              Showing {records.length} of {totalRecords} entries
            </span>
          </div>

          {/* Ledger Table */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4 font-medium">Date</th>
                    <th className="py-3 px-4 font-medium">Reference</th>
                    <th className="py-3 px-4 font-medium">Type</th>
                    <th className="py-3 px-4 font-medium">Category</th>
                    <th className="py-3 px-4 font-medium">Amount (ZAR)</th>
                    <th className="py-3 px-4 font-medium">Description</th>
                    <th className="py-3 px-4 font-medium">Status</th>
                    <th className="py-3 px-4 text-right font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {records.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-10 text-center text-slate-500">
                        No financial records found matching criteria.
                      </td>
                    </tr>
                  ) : (
                    records.map((r) => (
                      <tr key={r.id} className="hover:bg-slate-800/30 transition-colors">
                        <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">{r.recordDate}</td>
                        <td className="py-3 px-4 font-mono font-bold text-amber-300">{r.reference}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              r.recordType === 'REVENUE'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                                : r.recordType === 'EXPENSE'
                                ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                                : r.recordType === 'ASSET'
                                ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30'
                                : 'bg-purple-500/10 text-purple-400 border border-purple-500/30'
                            }`}
                          >
                            {r.recordType}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-slate-300">{r.categoryName || r.category}</td>
                        <td className="py-3 px-4 font-mono font-bold text-slate-100">
                          {formatZAR(r.amount)}
                        </td>
                        <td className="py-3 px-4 text-slate-300 max-w-xs truncate" title={r.description}>
                          {r.description}
                        </td>
                        <td className="py-3 px-4">
                          <span className="text-[10px] font-semibold text-emerald-400 flex items-center space-x-1">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>{r.reconciliationStatus}</span>
                          </span>
                        </td>
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => {
                              setAdjustingRecord(r);
                              setAdjustAmount(String(r.amount));
                              setAdjustReason('');
                              setAdjustFeedback(null);
                              setAdjustModalOpen(true);
                            }}
                            className="px-2.5 py-1 rounded-lg text-[11px] font-medium text-slate-400 hover:text-amber-300 hover:bg-slate-800 transition-colors"
                          >
                            Audit Adjust
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalRecords > pageSize && (
              <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-400">
                  Page {page} of {Math.ceil(totalRecords / pageSize)}
                </span>
                <div className="flex items-center space-x-2">
                  <button
                    disabled={page <= 1}
                    onClick={() => setPage((p) => p - 1)}
                    className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-40"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    disabled={page >= Math.ceil(totalRecords / pageSize)}
                    onClick={() => setPage((p) => p + 1)}
                    className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white disabled:opacity-40"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB C: FINANCIAL REPORTS */}
      {activeTab === 'reports' && (
        <div className="space-y-6">
          {/* Report Sub-tabs & Download Action */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-900/60 p-4 border border-slate-800 rounded-2xl">
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setReportType('income')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  reportType === 'income' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'
                }`}
              >
                Income Statement (P&L)
              </button>
              <button
                onClick={() => setReportType('balance')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  reportType === 'balance' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'
                }`}
              >
                Balance Sheet
              </button>
              <button
                onClick={() => setReportType('cashflow')}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  reportType === 'cashflow' ? 'bg-amber-500 text-black' : 'text-slate-400 hover:text-white'
                }`}
              >
                Cash Flow Statement
              </button>
            </div>

            <button
              onClick={() => handleDownloadCsv(reportType)}
              className="flex items-center space-x-1.5 px-4 py-2 rounded-xl text-xs font-bold text-amber-400 bg-slate-900 border border-amber-500/30 hover:bg-amber-500/10 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download CSV Statement</span>
            </button>
          </div>

          {/* Report Display Container */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
            {reportLoading ? (
              <div className="py-16 text-center space-y-2 text-xs text-amber-400">
                <RefreshCw className="w-5 h-5 animate-spin mx-auto" />
                <span>Generating certified financial report...</span>
              </div>
            ) : reportType === 'income' && reportData ? (
              <div className="space-y-6 text-xs">
                <div className="border-b border-slate-800 pb-4">
                  <h3 className="text-xl font-serif font-bold text-slate-100">Income Statement (Profit & Loss)</h3>
                  <p className="text-slate-400 mt-0.5">
                    For Reporting Period: <span className="font-semibold text-slate-200">{reportData.reportingPeriod}</span> (All figures in ZAR)
                  </p>
                </div>

                {/* Revenue Section */}
                <div className="space-y-2">
                  <div className="flex justify-between font-bold text-sm text-emerald-400 border-b border-slate-800 pb-1">
                    <span>OPERATING REVENUES</span>
                    <span className="font-mono">{formatZAR(reportData.revenue.total)}</span>
                  </div>
                  {reportData.revenue.items.map((i: any) => (
                    <div key={i.category} className="flex justify-between py-1 text-slate-300">
                      <span>{i.categoryName}</span>
                      <span className="font-mono">{formatZAR(i.amount)}</span>
                    </div>
                  ))}
                </div>

                {/* Expenses Section */}
                <div className="space-y-2 pt-4">
                  <div className="flex justify-between font-bold text-sm text-rose-400 border-b border-slate-800 pb-1">
                    <span>OPERATING EXPENSES</span>
                    <span className="font-mono">{formatZAR(reportData.expenses.total)}</span>
                  </div>
                  {reportData.expenses.items.map((i: any) => (
                    <div key={i.category} className="flex justify-between py-1 text-slate-300">
                      <span>{i.categoryName}</span>
                      <span className="font-mono">{formatZAR(i.amount)}</span>
                    </div>
                  ))}
                </div>

                {/* Net Income Summary */}
                <div className="pt-4 border-t-2 border-slate-700 space-y-2 bg-slate-950/60 p-4 rounded-xl">
                  <div className="flex justify-between text-sm font-bold text-slate-100">
                    <span>NET OPERATING INCOME (EBITDA)</span>
                    <span className="font-mono text-amber-300 text-base">{formatZAR(reportData.netOperatingIncome)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Operating Profit Margin</span>
                    <span className="font-mono font-bold text-slate-200">{reportData.netMarginPercent}%</span>
                  </div>
                </div>

                {/* Notes */}
                <div className="pt-2 text-[11px] text-slate-500 space-y-1">
                  {reportData.notes?.map((n: string, i: number) => (
                    <div key={i}>• {n}</div>
                  ))}
                </div>
              </div>
            ) : reportType === 'balance' && reportData ? (
              <div className="space-y-6 text-xs">
                <div className="border-b border-slate-800 pb-4">
                  <h3 className="text-xl font-serif font-bold text-slate-100">Statement of Financial Position (Balance Sheet)</h3>
                  <p className="text-slate-400 mt-0.5">
                    As of: <span className="font-semibold text-slate-200">{reportData.asOfDate}</span> (All figures in ZAR)
                  </p>
                </div>

                {/* Assets */}
                <div className="space-y-2">
                  <div className="flex justify-between font-bold text-sm text-blue-400 border-b border-slate-800 pb-1">
                    <span>ASSETS</span>
                    <span className="font-mono">{formatZAR(reportData.assets.totalAssets)}</span>
                  </div>
                  <span className="text-[11px] font-semibold text-slate-400 block pt-1">Current Assets:</span>
                  {reportData.assets.currentAssets.map((a: any) => (
                    <div key={a.category} className="flex justify-between py-1 pl-4 text-slate-300">
                      <span>{a.name}</span>
                      <span className="font-mono">{formatZAR(a.amount)}</span>
                    </div>
                  ))}
                  <span className="text-[11px] font-semibold text-slate-400 block pt-2">Non-Current Infrastructure Assets:</span>
                  {reportData.assets.nonCurrentAssets.map((a: any) => (
                    <div key={a.category} className="flex justify-between py-1 pl-4 text-slate-300">
                      <span>{a.name}</span>
                      <span className="font-mono">{formatZAR(a.amount)}</span>
                    </div>
                  ))}
                </div>

                {/* Liabilities */}
                <div className="space-y-2 pt-4">
                  <div className="flex justify-between font-bold text-sm text-purple-400 border-b border-slate-800 pb-1">
                    <span>LIABILITIES</span>
                    <span className="font-mono">{formatZAR(reportData.liabilities.totalLiabilities)}</span>
                  </div>
                  {reportData.liabilities.currentLiabilities.map((l: any) => (
                    <div key={l.category} className="flex justify-between py-1 pl-4 text-slate-300">
                      <span>{l.name}</span>
                      <span className="font-mono">{formatZAR(l.amount)}</span>
                    </div>
                  ))}
                  {reportData.liabilities.longTermLiabilities.map((l: any) => (
                    <div key={l.category} className="flex justify-between py-1 pl-4 text-slate-300">
                      <span>{l.name}</span>
                      <span className="font-mono">{formatZAR(l.amount)}</span>
                    </div>
                  ))}
                </div>

                {/* Equity */}
                <div className="pt-4 border-t-2 border-slate-700 bg-slate-950/60 p-4 rounded-xl flex justify-between font-bold text-sm text-slate-100">
                  <span>TOTAL CORPORATE EQUITY (RETAINED SURPLUS)</span>
                  <span className="font-mono text-purple-300 text-base">{formatZAR(reportData.equity.totalEquity)}</span>
                </div>
              </div>
            ) : reportType === 'cashflow' && reportData ? (
              <div className="space-y-6 text-xs">
                <div className="border-b border-slate-800 pb-4">
                  <h3 className="text-xl font-serif font-bold text-slate-100">Statement of Cash Flows</h3>
                  <p className="text-slate-400 mt-0.5">
                    Period: <span className="font-semibold text-slate-200">{reportData.reportingPeriod}</span>
                  </p>
                </div>

                <div className="space-y-3">
                  {reportData.details.map((d: any, i: number) => (
                    <div key={i} className="flex justify-between p-3 bg-slate-950 rounded-xl border border-slate-800">
                      <span className="text-slate-300">{d.activity}</span>
                      <span className={`font-mono font-bold ${d.type === 'INFLOW' ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {d.type === 'INFLOW' ? '+' : '-'}{formatZAR(d.amount)}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="p-4 bg-slate-950 border border-slate-700 rounded-xl space-y-2">
                  <div className="flex justify-between text-slate-400">
                    <span>Net Change in Operating Cash</span>
                    <span className="font-mono font-bold text-slate-200">{formatZAR(reportData.netCashFlow)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-slate-100 border-t border-slate-800 pt-2">
                    <span>Ending Treasury Cash Balance</span>
                    <span className="font-mono text-cyan-300 text-base">{formatZAR(reportData.endingCash)}</span>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* TAB D: BUDGETS & VARIANCE ANALYSIS */}
      {activeTab === 'budgets' && (
        <div className="space-y-4">
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-2xl flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-100">Budget vs Actual Operational Variance</h3>
              <p className="text-xs text-slate-400">Planned fiscal allocations compared to verified ledger entries.</p>
            </div>
            <span className="text-xs font-mono text-amber-300 font-bold">Reporting: {selectedPeriod}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {budgets.map((b) => (
              <div key={b.category} className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-200 text-sm">{b.categoryName}</span>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      b.status === 'FAVORABLE'
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    {b.status}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-xs pt-1">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Budgeted</span>
                    <span className="font-mono text-slate-300 font-medium">{formatZAR(b.budgeted)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Actual</span>
                    <span className="font-mono text-slate-100 font-bold">{formatZAR(b.actual)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">Variance</span>
                    <span className={`font-mono font-bold ${b.varianceAmount >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {formatZAR(b.varianceAmount)} ({b.variancePercent}%)
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className={`h-full ${b.status === 'FAVORABLE' ? 'bg-emerald-400' : 'bg-rose-400'}`}
                    style={{ width: `${Math.min(100, b.budgeted > 0 ? (b.actual / b.budgeted) * 100 : 0)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. RECORD ENTRY MODAL */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b101b] border border-slate-800 rounded-3xl w-full max-w-lg p-6 sm:p-8 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <h3 className="text-base font-serif font-bold text-slate-100 flex items-center space-x-2">
                <Plus className="w-4 h-4 text-amber-400" />
                <span>Record Authorized Financial Entry</span>
              </h3>
              <button onClick={() => setCreateModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Entry Type</label>
                  <select
                    value={newType}
                    onChange={(e) => {
                      const t = e.target.value as any;
                      setNewType(t);
                      const def = categories.find((c) => c.type === t);
                      if (def) setNewCategory(def.code);
                    }}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    <option value="REVENUE">Corporate Revenue</option>
                    <option value="EXPENSE">Operating Expense</option>
                    <option value="ASSET">Corporate Asset</option>
                    <option value="LIABILITY">Corporate Liability</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Accounting Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100"
                  >
                    {categories
                      .filter((c) => c.type === newType)
                      .map((c) => (
                        <option key={c.code} value={c.code}>
                          {c.name}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Amount in ZAR (R)</label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="e.g. 150000.00"
                    value={newAmount}
                    onChange={(e) => setNewAmount(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Audit Reference</label>
                  <input
                    type="text"
                    required
                    value={newReference}
                    onChange={(e) => setNewReference(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Record Date</label>
                  <input
                    type="date"
                    required
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>

                <div>
                  <label className="text-slate-300 font-semibold block mb-1">Reporting Period</label>
                  <input
                    type="text"
                    required
                    value={newPeriod}
                    onChange={(e) => setNewPeriod(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">Description & Purpose</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Detailed description of the transaction..."
                  value={newDescription}
                  onChange={(e) => setNewDescription(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-slate-100 placeholder-slate-600"
                />
              </div>

              {createFeedback && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300">
                  {createFeedback}
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingRecord}
                  className="px-5 py-2 rounded-xl font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10 disabled:opacity-50"
                >
                  {isSubmittingRecord ? 'Saving...' : 'Record Entry'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 6. AUDIT ADJUSTMENT MODAL */}
      {adjustModalOpen && adjustingRecord && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0b101b] border border-slate-800 rounded-3xl w-full max-w-md p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-serif font-bold text-slate-100">
                Audited Adjustment: {adjustingRecord.reference}
              </h3>
              <button onClick={() => setAdjustModalOpen(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAdjustSubmit} className="space-y-4 text-xs">
              <div>
                <span className="text-slate-400 block mb-1">Current Recorded Amount:</span>
                <span className="font-mono font-bold text-slate-200 text-sm">
                  {formatZAR(adjustingRecord.amount)}
                </span>
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">New Adjusted Amount (ZAR)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2 text-slate-100 font-mono text-sm"
                />
              </div>

              <div>
                <label className="text-slate-300 font-semibold block mb-1">
                  Audit Justification Reason (Mandatory)
                </label>
                <textarea
                  required
                  rows={3}
                  placeholder="Explain why this adjustment is authorized..."
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-slate-100 placeholder-slate-600"
                />
              </div>

              {adjustFeedback && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300">
                  {adjustFeedback}
                </div>
              )}

              <div className="flex justify-end space-x-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setAdjustModalOpen(false)}
                  className="px-4 py-2 rounded-xl text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isAdjusting}
                  className="px-5 py-2 rounded-xl font-bold text-black bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 shadow-md shadow-amber-500/10 disabled:opacity-50"
                >
                  {isAdjusting ? 'Recording...' : 'Commit Adjustment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
