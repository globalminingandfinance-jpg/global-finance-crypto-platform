import React, { useState, useEffect, useRef } from 'react';
import {
  Bell,
  Check,
  Trash2,
  MessageSquare,
  ArrowRight,
  X,
  Clock,
  Gift,
  Tag,
  Sparkles,
  ShieldAlert,
  Coins,
  ChevronDown,
  ChevronUp,
  Percent,
  Megaphone,
  AlertTriangle,
} from 'lucide-react';
import { CustomerNotification, PromoNotificationData } from '../types/index.js';

interface NotificationCenterProps {
  token: string | null;
  onOpenTicket?: (ticketId: string) => void;
  onOpenCheckout?: () => void;
  onNavigate?: (tab: string) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  token,
  onOpenTicket,
  onOpenCheckout,
  onNavigate,
}) => {
  const [notifications, setNotifications] = useState<CustomerNotification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [claimingRunId, setClaimingRunId] = useState<string | null>(null);
  const [expandedDisclaimers, setExpandedDisclaimers] = useState<Record<string, boolean>>({});
  const panelRef = useRef<HTMLDivElement>(null);

  const fetchNotifications = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/customer/notifications', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications || []);
        setUnreadCount(data.unreadCount || 0);
      }
    } catch (err) {
      console.error('Failed to load notifications:', err);
    }
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 15000); // Poll notifications every 15s
    return () => clearInterval(interval);
  }, [token]);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const handleMarkAsRead = async (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (!token) return;
    try {
      await fetch(`/api/customer/notifications/${id}/read`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` },
      });
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, is_read: 1 } : n))
      );
      setUnreadCount((prev) => Math.max(0, prev - 1));
    } catch (err) {
      console.error('Failed to mark notification as read:', err);
    }
  };

  const handleMarkAllAsRead = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      await fetch('/api/customer/notifications/mark-all-read', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      });
      setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
      setUnreadCount(0);
    } catch (err) {
      console.error('Failed to mark all as read:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!token) return;
    try {
      await fetch(`/api/customer/notifications/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      const target = notifications.find((n) => n.id === id);
      if (target && !target.is_read) {
        setUnreadCount((prev) => Math.max(0, prev - 1));
      }
      setNotifications((prev) => prev.filter((n) => n.id !== id));
    } catch (err) {
      console.error('Failed to delete notification:', err);
    }
  };

  const handleClaimReward = async (runId: string, notifId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!token || !runId) return;
    setClaimingRunId(runId);
    try {
      const res = await fetch('/api/customer/promotions/claim-reward', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ runId }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotifications((prev) =>
          prev.map((n) =>
            n.promo_run_id === runId
              ? { ...n, promo_claim_status: 'PENDING_APPROVAL', is_read: 1 }
              : n
          )
        );
      } else {
        alert(data.error || 'Failed to submit reward claim.');
      }
    } catch {
      alert('Network error submitting claim.');
    } finally {
      setClaimingRunId(null);
    }
  };

  const toggleDisclaimer = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedDisclaimers((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const parsePromoData = (data?: string | PromoNotificationData): PromoNotificationData | null => {
    if (!data) return null;
    if (typeof data === 'object') return data;
    try {
      return JSON.parse(data);
    } catch {
      return null;
    }
  };

  const formatTimestamp = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 1) return 'Just now';
      if (diffMins < 60) return `${diffMins}m ago`;
      if (diffHours < 24) return `${diffHours}h ago`;
      if (diffDays < 7) return `${diffDays}d ago`;
      return date.toLocaleDateString();
    } catch {
      return dateStr;
    }
  };

  const formatTimeRemaining = (expiryStr?: string) => {
    if (!expiryStr) return null;
    try {
      const expiry = new Date(expiryStr).getTime();
      const now = Date.now();
      const diff = expiry - now;
      if (diff <= 0) return 'Expired';
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      if (hours > 24) {
        const days = Math.floor(hours / 24);
        const remHours = hours % 24;
        return `${days}d ${remHours}h left`;
      }
      return `${hours}h ${minutes}m left`;
    } catch {
      return null;
    }
  };

  return (
    <div className="relative" ref={panelRef}>
      {/* Bell Trigger Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-amber-500/50 transition-all focus:outline-none"
        title="Customer Notifications"
        aria-label="Customer Notifications"
      >
        <Bell className="w-4 h-4" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-amber-500 text-[10px] font-bold text-black shadow-lg shadow-amber-500/40 animate-pulse">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown Panel */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-84 sm:w-[440px] bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl z-50 overflow-hidden flex flex-col max-h-[560px]">
          {/* Header */}
          <div className="p-4 border-b border-slate-800/80 flex items-center justify-between bg-slate-900/60">
            <div className="flex items-center space-x-2">
              <span className="font-semibold text-xs text-slate-100 uppercase tracking-wider">
                Notification Center
              </span>
              {unreadCount > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  {unreadCount} new
                </span>
              )}
            </div>
            <div className="flex items-center space-x-2">
              {unreadCount > 0 && (
                <button
                  onClick={handleMarkAllAsRead}
                  disabled={isLoading}
                  className="text-[11px] text-amber-400 hover:text-amber-300 font-medium flex items-center space-x-1"
                >
                  <Check className="w-3 h-3" />
                  <span>Mark all read</span>
                </button>
              )}
              <button
                onClick={() => setIsOpen(false)}
                className="text-slate-500 hover:text-slate-300 p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Notifications List */}
          <div className="overflow-y-auto divide-y divide-slate-800/60 flex-1">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                <Bell className="w-8 h-8 mx-auto mb-2 opacity-30 text-slate-400" />
                <p>No notifications yet</p>
                <p className="text-[11px] text-slate-600 mt-1">
                  Automated money offers, ticket replies, and account updates will appear here.
                </p>
              </div>
            ) : (
              notifications.map((n) => {
                const isPromo =
                  Boolean(n.promo_run_id) ||
                  n.type?.startsWith('PROMOTION_') ||
                  Boolean(n.promo_category);
                const isAnnouncement =
                  Boolean(n.announcement_id) ||
                  n.type === 'ANNOUNCEMENT' ||
                  n.type === 'ANNOUNCEMENT_URGENT';

                const promo = isPromo ? parsePromoData(n.promo_data) : null;
                const timeRemaining = isPromo
                  ? formatTimeRemaining(n.promo_expiry || promo?.expires_at)
                  : null;
                const isDisclaimerOpen = Boolean(expandedDisclaimers[n.id]);

                // Promotional Badge & Category Info
                let promoBadge = {
                  label: 'Special Offer',
                  bgColor: 'bg-amber-500/10 text-amber-300 border-amber-500/30',
                  icon: Sparkles,
                };

                const cat = n.promo_category || promo?.category;
                if (cat === 'FEE_DISCOUNT' || n.type === 'PROMOTION_DISCOUNT') {
                  promoBadge = {
                    label: 'Flash Fee Discount',
                    bgColor: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
                    icon: Percent,
                  };
                } else if (cat === 'CASH_REWARD' || n.type === 'PROMOTION_REWARD') {
                  promoBadge = {
                    label: 'Cash-Value Reward',
                    bgColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
                    icon: Gift,
                  };
                } else if (cat === 'SPECIAL_OFFER' || n.type === 'PROMOTION_INVESTMENT') {
                  promoBadge = {
                    label: 'Enterprise Special',
                    bgColor: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
                    icon: Coins,
                  };
                } else if (cat === 'MONTH_END' || n.type === 'PROMOTION_MONTH_END') {
                  promoBadge = {
                    label: 'Month-End Special',
                    bgColor: 'bg-purple-500/15 text-purple-300 border-purple-500/30',
                    icon: Sparkles,
                  };
                }

                // Announcement Badge
                let announcementBadge = {
                  label: 'Announcement',
                  bgColor: 'bg-blue-500/15 text-blue-300 border-blue-500/30',
                  icon: Megaphone,
                };
                if (n.priority === 'URGENT' || n.type === 'ANNOUNCEMENT_URGENT') {
                  announcementBadge = {
                    label: 'Urgent Announcement',
                    bgColor: 'bg-red-500/20 text-red-300 border-red-500/40',
                    icon: AlertTriangle,
                  };
                } else if (n.priority === 'IMPORTANT') {
                  announcementBadge = {
                    label: 'Important Notice',
                    bgColor: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
                    icon: Sparkles,
                  };
                }

                const BadgeIcon = isAnnouncement
                  ? announcementBadge.icon
                  : promoBadge.icon;

                return (
                  <div
                    key={n.id}
                    onClick={() => {
                      if (!n.is_read) handleMarkAsRead(n.id);
                    }}
                    className={`p-4 text-xs transition-colors flex items-start space-x-3 ${
                      !n.is_read
                        ? isAnnouncement && (n.priority === 'URGENT' || n.type === 'ANNOUNCEMENT_URGENT')
                          ? 'bg-red-500/5 hover:bg-red-500/10 border-l-2 border-red-500'
                          : 'bg-amber-500/5 hover:bg-amber-500/10 border-l-2 border-amber-500'
                        : 'hover:bg-slate-900/60'
                    }`}
                  >
                    {/* Left Icon */}
                    <div
                      className={`mt-0.5 w-7 h-7 rounded-xl flex items-center justify-center shrink-0 border ${
                        isAnnouncement && (n.priority === 'URGENT' || n.type === 'ANNOUNCEMENT_URGENT')
                          ? 'bg-red-500/15 text-red-400 border-red-500/30'
                          : isAnnouncement
                          ? 'bg-blue-500/15 text-blue-400 border-blue-500/30'
                          : isPromo
                          ? 'bg-amber-500/10 text-amber-400 border-amber-500/30'
                          : !n.is_read
                          ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                    >
                      {isAnnouncement ? (
                        <BadgeIcon className="w-3.5 h-3.5" />
                      ) : isPromo ? (
                        <BadgeIcon className="w-3.5 h-3.5" />
                      ) : (
                        <MessageSquare className="w-3.5 h-3.5" />
                      )}
                    </div>

                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      {/* Top metadata row */}
                      <div className="flex items-center justify-between gap-1 mb-1">
                        {isAnnouncement ? (
                          <div className="flex items-center space-x-1.5 flex-wrap">
                            <span
                              className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border ${announcementBadge.bgColor}`}
                            >
                              {announcementBadge.label}
                            </span>
                            {n.promo_category && (
                              <span className="text-[10px] text-slate-400 font-medium">
                                • {n.promo_category.replace(/_/g, ' ')}
                              </span>
                            )}
                          </div>
                        ) : isPromo ? (
                          <div className="flex items-center space-x-1.5 flex-wrap">
                            <span
                              className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border ${promoBadge.bgColor}`}
                            >
                              {promoBadge.label}
                            </span>
                            {timeRemaining && (
                              <span className="text-[10px] text-amber-400 font-mono flex items-center space-x-1">
                                <Clock className="w-2.5 h-2.5 inline" />
                                <span>{timeRemaining}</span>
                              </span>
                            )}
                          </div>
                        ) : (
                          <span
                            className={`font-semibold truncate ${
                              !n.is_read ? 'text-slate-100' : 'text-slate-300'
                            }`}
                          >
                            {n.title}
                          </span>
                        )}
                        <span className="text-[10px] text-slate-500 whitespace-nowrap ml-auto">
                          {formatTimestamp(n.created_at)}
                        </span>
                      </div>

                      {/* Title if promotional or announcement */}
                      {(isPromo || isAnnouncement) && (
                        <div className="font-semibold text-slate-100 text-xs mb-1">
                          {n.title}
                        </div>
                      )}

                      {/* Main description */}
                      <p className="text-[11px] text-slate-300 leading-relaxed whitespace-pre-line">
                        {n.message}
                      </p>

                      {/* Action Link for Announcement */}
                      {isAnnouncement && n.action_link && (
                        <div className="mt-2.5 pt-2 border-t border-slate-800/80">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setIsOpen(false);
                              if (n.action_link?.startsWith('/invest') && onNavigate) {
                                onNavigate('investments');
                              } else if (n.action_link?.startsWith('/deposit') && onOpenCheckout) {
                                onOpenCheckout();
                              } else if (n.action_link && onNavigate) {
                                onNavigate(n.action_link.replace(/^\//, ''));
                              }
                            }}
                            className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-lg text-[10px] transition-all flex items-center space-x-1 shadow-sm shadow-amber-500/20"
                          >
                            <span>Open Announcement Link</span>
                            <ArrowRight className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      )}

                      {/* Promotional Breakdown Box */}
                      {isPromo && promo && (
                        <div className="mt-2.5 p-2.5 rounded-xl bg-slate-900/90 border border-slate-800 space-y-2">
                          <div className="grid grid-cols-2 gap-2 text-[10px]">
                            {promo.category === 'FEE_DISCOUNT' && (
                              <>
                                <div>
                                  <span className="text-slate-500 block">Normal Fee:</span>
                                  <span className="line-through text-slate-400 font-mono">
                                    R {promo.normal_fee_amount?.toFixed(2)}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-emerald-400 font-bold block">
                                    Discounted Fee:
                                  </span>
                                  <span className="text-emerald-300 font-mono font-bold text-xs">
                                    R{' '}
                                    {Math.max(
                                      0,
                                      promo.normal_fee_amount -
                                        (promo.discount_type === 'PERCENTAGE'
                                          ? (promo.normal_fee_amount * promo.discount_value) / 100
                                          : promo.discount_value)
                                    ).toFixed(2)}
                                  </span>
                                </div>
                              </>
                            )}

                            {promo.category === 'CASH_REWARD' && (
                              <>
                                <div>
                                  <span className="text-slate-500 block">Reward Voucher:</span>
                                  <span className="text-amber-300 font-mono font-bold text-xs">
                                    R {promo.reward_amount?.toFixed(2)}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-slate-500 block">Min Qualifying:</span>
                                  <span className="text-slate-300 font-mono">
                                    R {promo.min_deposit_amount?.toLocaleString('en-ZA')}
                                  </span>
                                </div>
                              </>
                            )}

                            {promo.category === 'SPECIAL_OFFER' && (
                              <>
                                <div>
                                  <span className="text-slate-500 block">Eligible Product:</span>
                                  <span className="text-cyan-300 font-medium">
                                    {promo.product_name || 'Enterprise Mining'}
                                  </span>
                                </div>
                                <div>
                                  <span className="text-slate-500 block">Setup Surcharge:</span>
                                  <span className="text-emerald-400 font-bold font-mono">
                                    Waived (Save R1,000)
                                  </span>
                                </div>
                              </>
                            )}

                            {promo.category === 'MONTH_END' && (
                              <>
                                <div>
                                  <span className="text-slate-500 block">Bonus Hash Power:</span>
                                  <span className="text-purple-300 font-bold font-mono text-xs">
                                    +10% Computational
                                  </span>
                                </div>
                                <div>
                                  <span className="text-slate-500 block">Qualifying Plans:</span>
                                  <span className="text-slate-300 font-medium">
                                    All new allocations
                                  </span>
                                </div>
                              </>
                            )}
                          </div>

                          {/* Action Buttons for Offer */}
                          <div className="pt-1 flex items-center justify-between gap-2 border-t border-slate-800/80">
                            {/* Cash Reward Claim button */}
                            {promo.category === 'CASH_REWARD' ? (
                              n.promo_claim_status === 'APPROVED' ? (
                                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-lg border border-emerald-500/20">
                                  ✓ Voucher Credited to Balance
                                </span>
                              ) : n.promo_claim_status === 'PENDING_APPROVAL' ? (
                                <span className="text-[10px] font-medium text-amber-300 bg-amber-500/10 px-2 py-1 rounded-lg border border-amber-500/20">
                                  ⏳ Claim Pending Admin Review
                                </span>
                              ) : (
                                <button
                                  onClick={(e) =>
                                    handleClaimReward(n.promo_run_id || promo.run_id, n.id, e)
                                  }
                                  disabled={claimingRunId === (n.promo_run_id || promo.run_id)}
                                  className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-lg text-[10px] transition-all flex items-center space-x-1 shadow-sm shadow-amber-500/20"
                                >
                                  <Gift className="w-3 h-3" />
                                  <span>
                                    {claimingRunId === (n.promo_run_id || promo.run_id)
                                      ? 'Submitting...'
                                      : 'Claim R350 Reward'}
                                  </span>
                                </button>
                              )
                            ) : (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setIsOpen(false);
                                  if (promo.cta_route === '/investments' && onNavigate) {
                                    onNavigate('investments');
                                  } else if (onOpenCheckout) {
                                    onOpenCheckout();
                                  }
                                }}
                                className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-black font-bold rounded-lg text-[10px] transition-all flex items-center space-x-1 shadow-sm shadow-amber-500/20"
                              >
                                <span>{promo.cta_label || 'Activate Offer'}</span>
                                <ArrowRight className="w-2.5 h-2.5" />
                              </button>
                            )}

                            {/* Risk disclaimer toggle */}
                            <button
                              onClick={(e) => toggleDisclaimer(n.id, e)}
                              className="text-[9px] text-slate-500 hover:text-slate-300 flex items-center space-x-0.5 ml-auto"
                            >
                              <ShieldAlert className="w-2.5 h-2.5" />
                              <span>Terms & Risks</span>
                              {isDisclaimerOpen ? (
                                <ChevronUp className="w-2.5 h-2.5" />
                              ) : (
                                <ChevronDown className="w-2.5 h-2.5" />
                              )}
                            </button>
                          </div>

                          {/* Collapsible Disclaimer */}
                          {isDisclaimerOpen && (
                            <div className="p-2 rounded bg-slate-950/80 border border-slate-800/80 text-[9px] text-slate-400 leading-normal">
                              {promo.disclaimer ||
                                'Promotional terms apply. Digital asset mining involves hash power allocation and market fluctuation. Past performance does not guarantee future yields.'}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Ticket link if ticket reply */}
                      {n.ticket_id && (
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            if (onOpenTicket) {
                              setIsOpen(false);
                              onOpenTicket(n.ticket_id!);
                            }
                          }}
                          className="mt-1.5 flex items-center text-[10px] text-amber-400 font-medium cursor-pointer hover:underline"
                        >
                          <span>View support ticket conversation</span>
                          <ArrowRight className="w-2.5 h-2.5 ml-1" />
                        </div>
                      )}
                    </div>

                    {/* Delete notification */}
                    <button
                      onClick={(e) => handleDelete(n.id, e)}
                      className="text-slate-600 hover:text-red-400 p-1 opacity-60 hover:opacity-100 shrink-0"
                      title="Dismiss"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
