export interface User {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  country?: string;
  role: 'client' | 'admin';
  status: 'active' | 'suspended';
  kycStatus?: 'unverified' | 'pending' | 'verified' | 'rejected';
  mustChangePassword?: boolean;
  createdAt?: string;
}

export interface InvestmentProduct {
  id: string;
  slug: string;
  name: string;
  description: string;
  minAmount: number;
  features: string[];
  currency: string;
}

export interface Transaction {
  id: string;
  reference: string;
  amount: number;
  currency: string;
  fee: number;
  paymentMethod: 'payfast' | 'bank_transfer';
  paymentProvider: string;
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'CANCELLED' | 'REVERSED';
  providerReference?: string;
  notes?: string;
  productName?: string;
  productSlug?: string;
  customerEmail?: string;
  customerName?: string;
  createdAt: string;
}

export interface InvestmentAllocation {
  id: string;
  amountRequested: number;
  amountAllocated: number;
  status: 'ACTIVE' | 'PENDING_FUNDING' | 'COMPLETED' | 'CANCELLED';
  terms: string;
  productName: string;
  productSlug: string;
  productDescription?: string;
  transactionReference?: string;
  createdAt: string;
}

export interface FinancialSummary {
  userId: string;
  confirmedDeposits: number;
  allocatedCapital: number;
  availableBalance: number;
  pendingWithdrawals: number;
  completedWithdrawals: number;
  activeInvestmentsCount: number;
}

export interface WithdrawalRecord {
  id: string;
  amount: number;
  currency: string;
  fee: number;
  bankName: string;
  accountNumber: string;
  accountHolder: string;
  branchCode: string;
  status: 'PENDING_REVIEW' | 'APPROVED' | 'PROCESSING' | 'COMPLETED' | 'REJECTED';
  reviewNotes?: string;
  createdAt: string;
  customerEmail?: string;
}

export interface AuditLog {
  id: string;
  adminId?: string;
  adminEmail: string;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  ipAddress?: string;
  createdAt: string;
}

export interface ReceiptData {
  receiptNumber: string;
  businessName: string;
  transactionReference: string;
  customerName: string;
  customerEmail: string;
  investmentProduct: string;
  amount: number;
  currency: string;
  fee: number;
  paymentProvider: string;
  paymentMethod: string;
  paymentStatus: string;
  transactionDate: string;
  closingMessage: string;
}

export type TicketCategory =
  | 'general_support'
  | 'complaints'
  | 'deposits'
  | 'withdrawals'
  | 'account_verification'
  | 'technical_problems'
  | 'other_enquiries';

export type TicketPriority = 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT';
export type TicketStatus = 'OPEN' | 'IN_PROGRESS' | 'AWAITING_CUSTOMER' | 'RESOLVED' | 'CLOSED';

export interface SupportTicket {
  id: string;
  reference: string;
  user_id: string;
  subject: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  created_at: string;
  updated_at: string;
  last_activity_at: string;
  customer_email?: string;
  customer_first_name?: string;
  customer_last_name?: string;
  customer_phone?: string;
  customer_country?: string;
  customer_kyc_status?: string;
  customer_account_status?: string;
  message_count?: number;
  total_messages?: number;
  last_sender_role?: 'client' | 'admin';
}

export interface TicketMessage {
  id: string;
  ticket_id?: string;
  sender_id: string;
  sender_role: 'client' | 'admin';
  sender_name: string;
  message: string;
  is_internal_note?: number;
  attachment_name?: string | null;
  attachment_data?: string | null;
  created_at: string;
}

export type PromotionCategory = 'FEE_DISCOUNT' | 'CASH_REWARD' | 'SPECIAL_OFFER' | 'MONTH_END';
export type PromotionDiscountType = 'PERCENTAGE' | 'FIXED_AMOUNT' | 'NONE';
export type PromotionTargetAudience = 'ALL_CLIENTS' | 'VERIFIED_KYC_ONLY' | 'ACTIVE_INVESTORS';

export interface PromotionalOfferTemplate {
  id: string;
  slot_key: string;
  title: string;
  category: PromotionCategory;
  schedule_day: number;
  schedule_time_sast: string;
  discount_type: PromotionDiscountType;
  discount_value: number;
  normal_fee_amount: number;
  min_deposit_amount: number;
  reward_amount: number;
  product_id?: string;
  product_name?: string;
  validity_hours: number;
  target_audience: PromotionTargetAudience;
  description: string;
  disclaimer: string;
  cta_label: string;
  cta_route: string;
  is_enabled: number;
  updated_at: string;
}

export interface PromotionalOfferRun {
  id: string;
  idempotency_key: string;
  template_id: string;
  offer_title: string;
  slot_key: string;
  trigger_type: 'AUTOMATIC_SCHEDULE' | 'MANUAL_TRIGGER' | 'TEST_DISPATCH';
  published_at: string;
  expires_at: string;
  recipient_count: number;
  status: 'ACTIVE' | 'EXPIRED' | 'CANCELLED_KILL_SWITCH';
  killed_by_admin?: string;
  killed_at?: string;
}

export interface PromotionalRewardClaim {
  id: string;
  run_id: string;
  user_id: string;
  user_email: string;
  reward_amount: number;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  claim_notes?: string;
  admin_notes?: string;
  reviewed_by?: string;
  reviewed_at?: string;
  created_at: string;
}

export interface PromoNotificationData {
  category: PromotionCategory;
  slot_key: string;
  discount_type: PromotionDiscountType;
  discount_value: number;
  normal_fee_amount: number;
  min_deposit_amount: number;
  reward_amount: number;
  product_name?: string;
  expires_at: string;
  disclaimer: string;
  cta_label: string;
  cta_route: string;
  run_id: string;
  claim_id?: string;
  claim_status?: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
}

export type AnnouncementCategory =
  | 'SYSTEM_MAINTENANCE'
  | 'COMPANY_NEWS'
  | 'KYC_VERIFICATION'
  | 'PAYMENTS_WITHDRAWALS'
  | 'INVESTMENT_INFO'
  | 'SECURITY_ALERTS'
  | 'SERVICE_AVAILABILITY'
  | 'GENERAL_ANNOUNCEMENT'
  | 'OTHER';

export type AnnouncementPriority = 'INFORMATIONAL' | 'IMPORTANT' | 'URGENT';

export type AnnouncementStatus = 'DRAFT' | 'SCHEDULED' | 'PUBLISHED' | 'CANCELLED' | 'ARCHIVED';

export type AnnouncementRecurrence = 'NONE' | 'DAILY' | 'WEEKLY' | 'MONTHLY';

export type AIWritingStyle =
  | 'professional_reassuring'
  | 'formal_corporate'
  | 'simple_clear'
  | 'urgent_operational'
  | 'friendly_customer';

export type AIAssistantAction =
  | 'GENERATE'
  | 'REGENERATE'
  | 'MAKE_SHORTER'
  | 'MAKE_FORMAL'
  | 'SIMPLIFY'
  | 'IMPROVE_CLARITY';

export interface StructuredAnnouncementDetails {
  whatHappened: string;
  whyItMatters: string;
  effectiveDate: string;
  duration?: string;
  affectedServices?: string;
  requiredAction?: string;
  factualNotes?: string;
}

export interface AudienceCriteria {
  general: 'ALL_CLIENTS' | 'INDIVIDUAL_CLIENTS';
  selectedUserIds?: string[];
  plans?: ('STARTER' | 'GROWTH' | 'PROFESSIONAL' | 'ELITE')[];
  kycStatuses?: ('verified' | 'unverified' | 'pending_review' | 'rejected')[];
  paymentStatuses?: ('PENDING_PAYMENT' | 'SUCCESSFUL_PAYMENT' | 'FAILED_PAYMENT')[];
  investmentActivity?: 'ALL' | 'ACTIVE_ONLY' | 'NO_ACTIVE' | 'APPROACHING_MATURITY';
}

export interface GlobalAnnouncement {
  id: string;
  title: string;
  category: AnnouncementCategory;
  priority: AnnouncementPriority;
  status: AnnouncementStatus;
  message: string;
  structured_details?: StructuredAnnouncementDetails;
  structured_details_json?: string;
  audience_filter?: AudienceCriteria;
  audience_filter_json?: string;
  recipient_count: number;
  delivered_count: number;
  read_count: number;
  read_rate?: number;
  scheduled_for?: string | null;
  recurrence_pattern: AnnouncementRecurrence;
  recurrence_end_date?: string | null;
  published_at?: string | null;
  created_by_admin: string;
  approved_by_admin?: string | null;
  action_link?: string | null;
  created_at: string;
  updated_at: string;
}

export interface AnnouncementRevision {
  id: string;
  announcement_id: string;
  revision_number: number;
  title: string;
  message: string;
  priority: AnnouncementPriority;
  category: AnnouncementCategory;
  audience_summary: string;
  changed_by_admin: string;
  change_reason?: string;
  created_at: string;
}

export interface AnnouncementAnalytics {
  totalAnnouncements: number;
  publishedAnnouncements: number;
  draftAnnouncements: number;
  scheduledAnnouncements: number;
  cancelledAnnouncements: number;
  totalRecipientsReached: number;
  totalDelivered: number;
  totalRead: number;
  totalUnread: number;
  overallReadRate: number;
  categoryBreakdown: Record<string, number>;
  priorityBreakdown: Record<string, number>;
}

export interface CustomerNotification {
  id: string;
  user_id: string;
  ticket_id?: string;
  ticket_reference?: string;
  title: string;
  message: string;
  type:
    | 'TICKET_REPLY'
    | 'TICKET_CREATED'
    | 'STATUS_CHANGE'
    | 'SYSTEM'
    | 'SECURITY'
    | 'DOCUMENT'
    | 'PROMOTION_DISCOUNT'
    | 'PROMOTION_REWARD'
    | 'PROMOTION_INVESTMENT'
    | 'PROMOTION_MONTH_END'
    | 'ANNOUNCEMENT'
    | 'ANNOUNCEMENT_URGENT';
  is_read: number;
  created_at: string;
  promo_run_id?: string;
  promo_category?: PromotionCategory;
  promo_expiry?: string;
  promo_data?: string | PromoNotificationData;
  promo_claim_id?: string;
  promo_claim_status?: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  announcement_id?: string;
  priority?: AnnouncementPriority;
  action_link?: string;
}

export type DocumentCategory =
  | 'ID_DOCUMENT'
  | 'PROOF_OF_PAYMENT'
  | 'ADDRESS_VERIFICATION'
  | 'SUPPORTING_DOC';

export type DocumentStatus = 'PENDING' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED';

export interface ClientDocument {
  id: string;
  user_id: string;
  name: string;
  category: DocumentCategory;
  file_type: string;
  file_size: number;
  status: DocumentStatus;
  rejection_reason?: string | null;
  reviewed_by?: string | null;
  reviewed_at?: string | null;
  created_at: string;
  updated_at?: string;
  customer_email?: string;
  customer_first_name?: string;
  customer_last_name?: string;
  customer_phone?: string;
  customer_kyc_status?: string;
}

export interface DocumentReviewLog {
  id: string;
  document_id: string;
  admin_id: string;
  admin_email: string;
  action: string;
  notes?: string | null;
  created_at: string;
}

export interface SecurityEvent {
  id: string;
  event_type: string;
  description: string;
  ip_address?: string;
  displayIp?: string;
  user_agent?: string;
  created_at: string;
}

export interface UserSession {
  id: string;
  deviceInfo: string;
  displayIp: string;
  lastActiveAt: string;
  createdAt: string;
  isRevoked: boolean;
  isCurrent: boolean;
}

export interface SecurityOverviewData {
  hasSecurityQuestion: boolean;
  securityQuestion: string | null;
  securityQuestionUpdatedAt: string | null;
  phone: string | null;
  isPhoneVerified: boolean;
  city: string | null;
  address: string | null;
  documentsSummary: {
    total: number;
    approved: number;
    pending: number;
    rejected: number;
    underReview: number;
  };
  activeSessionsCount: number;
  recentActivity: SecurityEvent[];
}

export interface InvestmentPerformanceItem {
  id: string;
  userId: string;
  productId: string;
  transactionId: string;
  transactionReference: string;
  paymentMethod: string;
  planName: string;
  planSlug: string;
  termVersion: number;
  investedCapital: number;
  currency: string;
  returnRate: number;
  durationDays: number;
  calculationMethod: string;
  activatedAt: string;
  maturityDate: string;
  remainingSeconds: number;
  isMatured: boolean;
  status: 'ACTIVE' | 'MATURED' | 'SETTLED' | 'CANCELLED';
  projectedProfit: number;
  projectedTotal: number;
  currentValuation: number;
  realizedPnL: number;
  settlementStatus: 'UNSETTLED' | 'PENDING_SETTLEMENT' | 'SETTLED' | 'CANCELLED';
  settlementDate?: string | null;
  settlementAmount?: number;
  settlementNotes?: string | null;
  termsText: string;
  createdAt: string;
  updatedAt: string;
}

export interface InvestmentDailyRecord {
  id: string;
  investmentId: string;
  userId: string;
  recordDate: string;
  openingValue: number;
  closingValue: number;
  dailyChange: number;
  dailyPercentage: number;
  cumulativeChange: number;
  projectedValue: number;
  classification: 'ACTUAL' | 'PROJECTED' | 'ADJUSTED' | 'SETTLED';
  dataSource: string;
  notes?: string;
  createdAt: string;
}

export interface InvestmentChartPoint {
  date: string;
  timestamp: number;
  actualValue: number | null;
  projectedValue: number | null;
  principalBaseline: number;
  isProjectedOnly: boolean;
  label?: string;
}

export interface InvestmentPerformanceDashboardData {
  zeroState: boolean;
  serverTime: string;
  metrics: {
    totalInvestedCapital: number;
    currentInvestmentValue: number;
    actualRealizedPnL: number;
    projectedReturns: number;
    activeInvestmentsCount: number;
    maturedInvestmentsCount: number;
    pendingPurchasesCount: number;
    dailyRecordedChange: number;
    dailyRecordedPercentage: number;
    nextMaturityDate: string | null;
    nextMaturityRemainingSeconds: number | null;
  };
  chartData: InvestmentChartPoint[];
  investments: InvestmentPerformanceItem[];
  pendingPurchases: {
    id: string;
    reference: string;
    amount: number;
    currency: string;
    paymentMethod: string;
    productName: string;
    createdAt: string;
  }[];
  disclosures: {
    projectionNotice: string;
    custodyNotice: string;
    regulatoryNotice: string;
  };
}

