import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { InvestmentProduct } from './types/index.js';
import { Navbar } from './components/Navbar.js';
import { Footer } from './components/Footer.js';
import { CheckoutModal } from './components/CheckoutModal.js';
import { ClientAuthModal } from './pages/ClientAuthModal.js';
import { Home } from './pages/Home.js';
import { Investments } from './pages/Investments.js';
import { HowItWorks } from './pages/HowItWorks.js';
import { Security } from './pages/Security.js';
import { About } from './pages/About.js';
import { FAQ } from './pages/FAQ.js';
import { Contact } from './pages/Contact.js';
import { PrivacyPolicy } from './pages/PrivacyPolicy.js';
import { Terms } from './pages/Terms.js';
import { RefundPolicy } from './pages/RefundPolicy.js';
import { CancellationPolicy } from './pages/CancellationPolicy.js';
import { DeliveryPolicy } from './pages/DeliveryPolicy.js';
import { RiskDisclosure } from './pages/RiskDisclosure.js';
import { AdminLogin } from './pages/AdminLogin.js';
import { AdminDashboard } from './pages/AdminDashboard.js';
import { CustomerDashboard } from './pages/CustomerDashboard.js';
import { PaymentSuccess } from './pages/PaymentSuccess.js';
import { PaymentFailed } from './pages/PaymentFailed.js';
import { ResetPasswordModal } from './components/ResetPasswordModal.js';
import { CryptoIntelligence } from './pages/CryptoIntelligence.js';

function AppContent() {
  const { user, isLoading } = useAuth();

  // Navigation view state
  const [currentView, setCurrentView] = useState<string>('home');
  const [urlReference, setUrlReference] = useState<string>('');

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<InvestmentProduct | null>(null);
  const [resetToken, setResetToken] = useState<string | null>(null);
  const [dashboardInitialTab, setDashboardInitialTab] = useState<string | undefined>(undefined);
  const [adminInitialTab, setAdminInitialTab] = useState<string | undefined>(undefined);

  // Initialize view from URL
  useEffect(() => {
    const handleUrlRouting = () => {
      const path = window.location.pathname.toLowerCase();
      const params = new URLSearchParams(window.location.search);
      const pageParam = (params.get('page') || '').toLowerCase();
      const tabParam = (params.get('tab') || '').toLowerCase();
      const ref = params.get('reference') || params.get('m_payment_id') || '';
      const rToken = params.get('resetToken') || params.get('token');

      if (rToken) {
        setResetToken(rToken);
      }

      if (path.includes('payment-success') || (ref && !path.includes('failed'))) {
        setUrlReference(ref);
        setCurrentView('payment-success');
      } else if (path.includes('payment-failed')) {
        setUrlReference(ref);
        setCurrentView('payment-failed');
      } else if (path.includes('admin-login')) {
        setCurrentView('admin-login');
      } else if (path.includes('business-finance') || pageParam === 'admin-business-finance' || pageParam === 'business-finance' || (path.includes('admin') && tabParam === 'business-finance')) {
        setAdminInitialTab('business-finance');
        setCurrentView('admin-dashboard');
      } else if (path.includes('data-sources') || pageParam === 'admin-data-sources' || pageParam === 'data-sources' || (path.includes('admin') && tabParam === 'data-sources')) {
        setAdminInitialTab('data-sources');
        setCurrentView('admin-dashboard');
      } else if (path.includes('admin-dashboard') || path.includes('admin')) {
        if (tabParam) setAdminInitialTab(tabParam);
        setCurrentView('admin-dashboard');
      } else if (path.includes('crypto-intelligence') || pageParam === 'crypto-intelligence') {
        setCurrentView('crypto-intelligence');
      } else if (path.includes('customer-financial-overview') || pageParam === 'customer-financial-overview' || (path.includes('dashboard') && tabParam === 'financial-overview')) {
        setDashboardInitialTab('financial-overview');
        setCurrentView('customer-dashboard');
      } else if (path.includes('investment-dashboard') || pageParam === 'investment-dashboard') {
        setDashboardInitialTab('investment-dashboard');
        setCurrentView('customer-dashboard');
      } else if (path.includes('dashboard')) {
        if (tabParam) setDashboardInitialTab(tabParam);
        setCurrentView('customer-dashboard');
      } else if (path.includes('refund') || pageParam === 'refund-policy') {
        setCurrentView('refund-policy');
      } else if (path.includes('cancellation') || pageParam === 'cancellation-policy') {
        setCurrentView('cancellation-policy');
      } else if (path.includes('delivery') || path.includes('fulfilment') || pageParam === 'delivery-policy') {
        setCurrentView('delivery-policy');
      } else if (path.includes('terms') || pageParam === 'terms') {
        setCurrentView('terms');
      } else if (path.includes('privacy') || pageParam === 'privacy-policy') {
        setCurrentView('privacy-policy');
      } else if (path.includes('risk') || pageParam === 'risk-disclosure') {
        setCurrentView('risk-disclosure');
      } else if (pageParam) {
        setCurrentView(pageParam);
      }
    };

    handleUrlRouting();
    window.addEventListener('popstate', handleUrlRouting);
    return () => window.removeEventListener('popstate', handleUrlRouting);
  }, []);

  const navigateTo = (view: string) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    let url = '/';
    if (view === 'admin-login') {
      setCurrentView('admin-login');
      url = '/admin-login';
    } else if (view === 'admin-dashboard') {
      setCurrentView('admin-dashboard');
      url = '/admin-dashboard';
    } else if (view === 'admin-business-finance') {
      setAdminInitialTab('business-finance');
      setCurrentView('admin-dashboard');
      url = '/admin-dashboard?tab=business-finance';
    } else if (view === 'admin-data-sources') {
      setAdminInitialTab('data-sources');
      setCurrentView('admin-dashboard');
      url = '/admin-dashboard?tab=data-sources';
    } else if (view === 'customer-financial-overview') {
      setDashboardInitialTab('financial-overview');
      setCurrentView('customer-dashboard');
      url = '/dashboard?tab=financial-overview';
    } else if (view === 'customer-dashboard') {
      setCurrentView('customer-dashboard');
      url = '/dashboard';
    } else if (view === 'crypto-intelligence') {
      setCurrentView('crypto-intelligence');
      url = '/?page=crypto-intelligence';
    } else if (view !== 'home') {
      setCurrentView(view);
      url = `/?page=${view}`;
    } else {
      setCurrentView('home');
    }
    window.history.pushState({}, '', url);
  };

  const handleOpenAuth = (mode: 'login' | 'register') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handleOpenCheckoutWithProduct = (product?: InvestmentProduct) => {
    if (product) setSelectedProduct(product);
    setCheckoutModalOpen(true);
  };

  // Views that take full window without default public header/footer
  const isFullScreenAdmin = currentView === 'admin-dashboard';
  const isFullScreenCustomer = currentView === 'customer-dashboard';
  const isAdminLogin = currentView === 'admin-login';

  return (
    <div className="min-h-screen flex flex-col bg-[#070b12] text-slate-100">
      {/* Checkout Modal */}
      {checkoutModalOpen && (
        <CheckoutModal
          initialProduct={selectedProduct}
          onClose={() => setCheckoutModalOpen(false)}
          onSuccess={(ref) => {
            setUrlReference(ref);
          }}
        />
      )}

      {/* Auth Modal */}
      {authModalOpen && (
        <ClientAuthModal
          initialMode={authModalMode}
          onClose={() => setAuthModalOpen(false)}
          onSuccess={() => {
            setAuthModalOpen(false);
            navigateTo('customer-dashboard');
          }}
          onSwitchToAdmin={() => {
            setAuthModalOpen(false);
            navigateTo('admin-login');
          }}
        />
      )}

      {/* Reset Password Modal (Triggered by secure email link) */}
      {resetToken && (
        <ResetPasswordModal
          token={resetToken}
          onClose={() => {
            setResetToken(null);
            window.history.replaceState({}, '', '/');
          }}
          onSuccess={(targetRole) => {
            setResetToken(null);
            window.history.replaceState({}, '', '/');
            if (targetRole === 'admin') {
              navigateTo('admin-login');
            } else {
              handleOpenAuth('login');
            }
          }}
        />
      )}

      {/* Public Navbar (Hidden inside full dashboards or dedicated admin login) */}
      {!isFullScreenAdmin && !isFullScreenCustomer && !isAdminLogin && (
        <Navbar
          currentView={currentView}
          onNavigate={navigateTo}
          onOpenAuth={handleOpenAuth}
          onOpenCheckout={() => handleOpenCheckoutWithProduct()}
        />
      )}

      {/* Main View Router */}
      <div className="flex-1">
        {currentView === 'home' && (
          <Home
            onExploreInvestments={() => navigateTo('investments')}
            onHowItWorks={() => navigateTo('how-it-works')}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onOpenCheckout={() => handleOpenCheckoutWithProduct()}
          />
        )}

        {currentView === 'investments' && (
          <Investments
            onSelectProduct={(p) => setSelectedProduct(p)}
            onOpenCheckout={() => handleOpenCheckoutWithProduct()}
          />
        )}

        {currentView === 'how-it-works' && (
          <HowItWorks onOpenCheckout={() => handleOpenCheckoutWithProduct()} />
        )}

        {currentView === 'security' && <Security />}
        {currentView === 'about' && <About />}
        {currentView === 'faq' && <FAQ />}
        {currentView === 'contact' && <Contact />}
        {currentView === 'privacy-policy' && <PrivacyPolicy />}
        {currentView === 'terms' && <Terms onNavigate={navigateTo} />}
        {currentView === 'refund-policy' && <RefundPolicy onNavigate={navigateTo} />}
        {currentView === 'cancellation-policy' && <CancellationPolicy onNavigate={navigateTo} />}
        {currentView === 'delivery-policy' && <DeliveryPolicy onNavigate={navigateTo} />}
        {currentView === 'risk-disclosure' && <RiskDisclosure />}

        {currentView === 'admin-login' && (
          <AdminLogin
            onSuccess={() => navigateTo('admin-dashboard')}
            onBackToSite={() => navigateTo('home')}
          />
        )}

        {currentView === 'admin-dashboard' && (
          <AdminDashboard
            initialTab={adminInitialTab}
            onNavigateHome={() => navigateTo('home')}
          />
        )}

        {currentView === 'crypto-intelligence' && (
          <CryptoIntelligence
            onOpenCheckout={() => handleOpenCheckoutWithProduct()}
            onOpenAuth={handleOpenAuth}
            onNavigateHome={() => navigateTo('home')}
          />
        )}

        {currentView === 'customer-dashboard' && (
          <CustomerDashboard
            initialTab={dashboardInitialTab}
            onOpenCheckout={() => handleOpenCheckoutWithProduct()}
            onNavigateHome={() => navigateTo('home')}
          />
        )}

        {currentView === 'payment-success' && (
          <PaymentSuccess
            reference={urlReference}
            onNavigateDashboard={() => navigateTo('customer-dashboard')}
            onNavigateInvestments={() => navigateTo('investments')}
          />
        )}

        {currentView === 'payment-failed' && (
          <PaymentFailed
            reference={urlReference}
            onRetry={() => handleOpenCheckoutWithProduct()}
            onNavigateInvestments={() => navigateTo('investments')}
            onNavigateContact={() => navigateTo('contact')}
          />
        )}
      </div>

      {/* Public Footer */}
      {!isFullScreenAdmin && !isFullScreenCustomer && !isAdminLogin && (
        <Footer onNavigate={navigateTo} />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
