import { Database } from 'sql.js';
import { saveDb } from '../db/database.js';

export interface EmailParams {
  to: string;
  subject: string;
  htmlContent: string;
  adminLogDetails?: string;
}

export async function sendEmailNotification(
  db: Database,
  params: EmailParams
): Promise<{ success: boolean; simulated: boolean; provider?: string }> {
  const { to, subject, htmlContent, adminLogDetails } = params;
  const now = new Date().toISOString();
  const resendApiKey = process.env.RESEND_API_KEY || (process.env.EMAIL_PROVIDER === 'resend' ? process.env.EMAIL_API_KEY : '');
  const emailApiKey = resendApiKey || process.env.EMAIL_API_KEY || '';
  const isResend = !!resendApiKey || process.env.EMAIL_PROVIDER === 'resend';
  const from = process.env.EMAIL_FROM || 'Global Finance Crypto Mining <support@globalfinancecryptomining.co.za>';

  let dispatched = false;
  let status = 'STORED_PENDING_PROVIDER';

  if (emailApiKey && isResend) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${emailApiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from,
          to: [to],
          subject,
          html: htmlContent,
        }),
      });

      if (response.ok) {
        dispatched = true;
        status = 'DISPATCHED_RESEND';
        console.log(`[EMAIL RESEND DISPATCHED] To: ${to} | Subject: "${subject}"`);
      } else {
        const errText = await response.text();
        console.warn(`[EMAIL RESEND FAILED] Status ${response.status}: ${errText}`);
        status = 'FAILED_RESEND_API';
      }
    } catch (apiErr) {
      console.error('[EMAIL RESEND EXCEPTION]', apiErr);
      status = 'FAILED_RESEND_NETWORK';
    }
  } else {
    console.log(`[EMAIL SIMULATED / AUDITED] To: ${to} | Subject: "${subject}".`);
  }

  // Always record notification in audit log for transparent tracking and compliance
  try {
    const logId = 'email_log_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'SYSTEM', 'system@globalfinancecryptomining.co.za', 'EMAIL_NOTIFICATION', 'CUSTOMER', ?, ?, '127.0.0.1', ?)`,
      [
        logId,
        to,
        JSON.stringify({
          to,
          subject,
          status,
          dispatched,
          details: adminLogDetails || subject,
        }),
        now,
      ]
    );
    saveDb();
  } catch (err) {
    console.error('[EMAIL] Failed to log email event:', err);
  }

  return { success: true, simulated: !dispatched, provider: dispatched ? 'resend' : 'audit_storage' };
}
