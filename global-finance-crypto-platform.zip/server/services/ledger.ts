import { Database } from 'sql.js';
import { queryOne, queryAll, saveDb } from '../db/database.js';

export interface UserFinancialSummary {
  userId: string;
  confirmedDeposits: number;
  allocatedCapital: number;
  availableBalance: number;
  pendingDeposits: number;
  pendingWithdrawals: number;
  completedWithdrawals: number;
  activeInvestmentsCount: number;
}

export function getUserFinancialSummary(db: Database, userId: string): UserFinancialSummary {
  // Confirmed deposits: sum of DEPOSIT credits
  const depRow = queryOne(
    db,
    `SELECT COALESCE(SUM(credit), 0) as total FROM financial_ledger WHERE user_id = ? AND entry_type = 'DEPOSIT'`,
    [userId]
  );
  const confirmedDeposits = depRow ? Number(depRow.total) : 0;

  // Allocated capital: sum of ALLOCATION debits
  const allocRow = queryOne(
    db,
    `SELECT COALESCE(SUM(debit), 0) as total FROM financial_ledger WHERE user_id = ? AND entry_type = 'ALLOCATION'`,
    [userId]
  );
  const allocatedCapital = allocRow ? Number(allocRow.total) : 0;

  // Pending withdrawals: sum of pending requests
  const pendRow = queryOne(
    db,
    `SELECT COALESCE(SUM(amount), 0) as total FROM withdrawals WHERE user_id = ? AND status IN ('PENDING_REVIEW', 'APPROVED', 'PROCESSING')`,
    [userId]
  );
  const pendingWithdrawals = pendRow ? Number(pendRow.total) : 0;

  // Completed withdrawals: sum of WITHDRAWAL_PAID
  const compRow = queryOne(
    db,
    `SELECT COALESCE(SUM(debit), 0) as total FROM financial_ledger WHERE user_id = ? AND entry_type = 'WITHDRAWAL_PAID'`,
    [userId]
  );
  const completedWithdrawals = compRow ? Number(compRow.total) : 0;

  // Active investments count
  const invRow = queryOne(
    db,
    `SELECT COUNT(*) as count FROM investment_allocations WHERE user_id = ? AND status = 'ACTIVE'`,
    [userId]
  );
  const activeInvestmentsCount = invRow ? Number(invRow.count) : 0;

  // Pending deposits: sum of pending transactions
  const pendDepRow = queryOne(
    db,
    `SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = ? AND status = 'PENDING'`,
    [userId]
  );
  const pendingDeposits = pendDepRow ? Number(pendDepRow.total) : 0;

  // Latest balance from financial_ledger using strict rowid order
  const lastLedger = queryOne(
    db,
    `SELECT balance_after FROM financial_ledger WHERE user_id = ? ORDER BY rowid DESC LIMIT 1`,
    [userId]
  );
  const availableBalance = lastLedger ? Number(lastLedger.balance_after) : 0;

  return {
    userId,
    confirmedDeposits,
    allocatedCapital,
    availableBalance,
    pendingDeposits,
    pendingWithdrawals,
    completedWithdrawals,
    activeInvestmentsCount,
  };
}

export function recordDepositAndAllocation(
  db: Database,
  params: {
    userId: string;
    transactionId: string;
    productId: string;
    amount: number;
    reference: string;
    productName: string;
  }
): void {
  const { userId, transactionId, productId, amount, reference, productName } = params;

  // Prevent duplicate processing
  const existingDeposit = queryOne(
    db,
    `SELECT id FROM financial_ledger WHERE transaction_id = ? AND entry_type = 'DEPOSIT'`,
    [transactionId]
  );
  if (existingDeposit) {
    console.warn(`[LEDGER] Transaction ${transactionId} already has recorded ledger entries.`);
    return;
  }

  const now = new Date().toISOString();

  // Get current balance
  const currentSummary = getUserFinancialSummary(db, userId);
  const currentBalance = currentSummary.availableBalance;

  // 1. Credit Deposit
  const balanceAfterDeposit = currentBalance + amount;
  const depositEntryId = 'led_dep_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO financial_ledger (id, transaction_id, user_id, entry_type, debit, credit, balance_after, description, created_at)
     VALUES (?, ?, ?, 'DEPOSIT', 0, ?, ?, ?, ?)`,
    [
      depositEntryId,
      transactionId,
      userId,
      amount,
      balanceAfterDeposit,
      `Deposit confirmed for transaction ${reference}`,
      now,
    ]
  );

  // 2. Debit Allocation towards the selected investment product
  const balanceAfterAllocation = balanceAfterDeposit - amount;
  const allocEntryId = 'led_alc_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO financial_ledger (id, transaction_id, user_id, entry_type, debit, credit, balance_after, description, created_at)
     VALUES (?, ?, ?, 'ALLOCATION', ?, 0, ?, ?, ?)`,
    [
      allocEntryId,
      transactionId,
      userId,
      amount,
      balanceAfterAllocation,
      `Investment capital allocation: ${productName} (Ref: ${reference})`,
      now,
    ]
  );

  // 3. Look up authoritative product terms
  const product = queryOne(
    db,
    'SELECT name, return_rate, duration_days, term_version, return_type FROM investment_products WHERE id = ?',
    [productId]
  );

  const planName = product?.name || productName;
  const returnRate = product?.return_rate || 0.75;
  const durationDays = product?.duration_days || 5;
  const termVersion = product?.term_version || 1;
  const calculationMethod = product?.return_type || 'PROFIT_ON_CAPITAL';

  const maturityDate = new Date(new Date(now).getTime() + durationDays * 24 * 60 * 60 * 1000).toISOString();
  const projectedProfit = Math.round(amount * returnRate * 100) / 100;
  const projectedTotal = Math.round((amount + projectedProfit) * 100) / 100;

  // 4. Create investment allocation record with immutable snapshot terms
  const allocId = 'inv_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO investment_allocations (
      id, user_id, product_id, transaction_id, amount_requested, amount_allocated, status, terms,
      plan_name, term_version, return_rate, duration_days, calculation_method,
      activated_at, maturity_date, projected_profit, projected_total,
      current_valuation, realized_pnl, settlement_status, created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, 'ACTIVE', 'Subject to Global Finance digital infrastructure terms and regulatory review.',
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'UNSETTLED', ?, ?)`,
    [
      allocId,
      userId,
      productId,
      transactionId,
      amount,
      amount,
      planName,
      termVersion,
      returnRate,
      durationDays,
      calculationMethod,
      now,
      maturityDate,
      projectedProfit,
      projectedTotal,
      amount, // Initial verified recorded valuation equals capital
      now,
      now,
    ]
  );

  // 5. Create initial Day 1 daily performance milestone record
  const drId = 'dr_init_' + Math.random().toString(36).substring(2, 11);
  const recordDate = now.slice(0, 10);
  db.run(
    `INSERT INTO investment_daily_records (
      id, investment_id, user_id, record_date, opening_value, closing_value,
      daily_change, daily_percentage, cumulative_change, projected_value,
      classification, data_source, notes, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, ?, 'ACTUAL', 'VERIFIED_PAYMENT_ALLOCATION', ?, ?)`,
    [
      drId,
      allocId,
      userId,
      recordDate,
      amount,
      amount,
      amount,
      `Initial verified capital allocation via transaction ${reference}`,
      now,
    ]
  );

  // 6. Record audit event
  const auditId = 'ia_init_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO investment_audit_logs (
      id, investment_id, action, actor_type, actor_id, previous_state, new_state, reason, created_at
    ) VALUES (?, ?, 'INVESTMENT_ACTIVATED', 'SYSTEM', 'PAYMENT_VERIFIER', 'PENDING_PAYMENT', 'ACTIVE', ?, ?)`,
    [
      auditId,
      allocId,
      JSON.stringify({
        transactionReference: reference,
        amount,
        planName,
        returnRate,
        durationDays,
        maturityDate,
      }),
      now,
    ]
  );

  saveDb();
}
