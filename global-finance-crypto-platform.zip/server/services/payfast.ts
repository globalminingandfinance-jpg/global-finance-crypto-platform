import crypto from 'crypto';

export interface PayFastConfig {
  merchantId: string;
  merchantKey: string;
  passphrase?: string;
  environment: 'test' | 'live';
}

export function getPayFastConfig(): PayFastConfig {
  return {
    merchantId: process.env.PAYFAST_MERCHANT_ID || '10000100',
    merchantKey: process.env.PAYFAST_MERCHANT_KEY || '46f0cd694581a',
    passphrase: process.env.PAYFAST_PASSPHRASE || '',
    environment: (process.env.PAYFAST_ENVIRONMENT === 'live' ? 'live' : 'test') as 'test' | 'live',
  };
}

export function getPayFastProcessUrl(): string {
  const config = getPayFastConfig();
  return config.environment === 'live'
    ? 'https://www.payfast.co.za/eng/process'
    : 'https://sandbox.payfast.co.za/eng/process';
}

export function getPayFastValidateUrl(): string {
  const config = getPayFastConfig();
  return config.environment === 'live'
    ? 'https://www.payfast.co.za/eng/query/validate'
    : 'https://sandbox.payfast.co.za/eng/query/validate';
}

/**
 * Generate MD5 signature according to PayFast specification.
 * Concatenates all non-empty key=value pairs (encoded, spaces as +) and appends passphrase if configured.
 */
export function generatePayFastSignature(
  data: Record<string, any>,
  passphrase?: string
): string {
  // Exclude signature field itself
  const keys = Object.keys(data).filter(
    (key) => key !== 'signature' && data[key] !== '' && data[key] !== null && data[key] !== undefined
  );

  const pfOutput = keys
    .map((key) => {
      const val = String(data[key]).trim();
      return `${key}=${encodeURIComponent(val).replace(/%20/g, '+')}`;
    })
    .join('&');

  let stringToHash = pfOutput;
  if (passphrase && passphrase.trim().length > 0) {
    stringToHash += `&passphrase=${encodeURIComponent(passphrase.trim()).replace(/%20/g, '+')}`;
  }

  return crypto.createHash('md5').update(stringToHash).digest('hex');
}

/**
 * Verify incoming ITN (Instant Transaction Notification) signature.
 */
export function verifyPayFastSignature(
  payload: Record<string, any>,
  receivedSignature: string,
  passphrase?: string
): boolean {
  if (!receivedSignature) return false;
  const calculatedSignature = generatePayFastSignature(payload, passphrase);
  return calculatedSignature.toLowerCase() === receivedSignature.toLowerCase();
}

/**
 * Validate ITN with PayFast's validation server
 */
export async function validateWithPayFastServer(
  payload: Record<string, any>
): Promise<boolean> {
  const validateUrl = getPayFastValidateUrl();
  const formBody = Object.keys(payload)
    .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(String(payload[key]))}`)
    .join('&');

  try {
    const response = await fetch(validateUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formBody,
      signal: AbortSignal.timeout(6000),
    });

    const text = (await response.text()).trim();
    return text === 'VALID';
  } catch (error) {
    console.warn('[PAYFAST] Server-to-server validation timed out or unavailable:', error);
    // In sandbox or isolated dev environments without public reverse route, fallback safely
    return false;
  }
}
