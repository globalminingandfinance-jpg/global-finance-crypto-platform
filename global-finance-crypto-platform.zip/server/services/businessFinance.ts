import { Database } from 'sql.js';
import { getDb, queryAll, queryOne, saveDb } from '../db/database.js';

export interface CompanyFinancialRecord {
  id: string;
  recordType: 'REVENUE' | 'EXPENSE' | 'ASSET' | 'LIABILITY';
  category: string;
  categoryName?: string;
  amount: number;
  currency: string;
  reference: string;
  reportingPeriod: string;
  recordDate: string;
  description: string;
  supportingDoc?: string;
  reconciliationStatus: string;
  authorizedBy: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface BusinessOverviewMetrics {
  totalRevenue: number;
  totalExpenses: number;
  netOperatingIncome: number;
  operatingMarginPercent: number;
  availableBusinessCash: number;
  totalBusinessAssets: number;
  totalBusinessLiabilities: number;
  netCorporateEquity: number;
  currentReportingPeriod: string;
  segregationNotice: string;
}

export interface IncomeStatementReport {
  reportingPeriod: string;
  currency: string;
  revenue: {
    items: Array<{ category: string; categoryName: string; amount: number }>;
    total: number;
  };
  expenses: {
    items: Array<{ category: string; categoryName: string; amount: number }>;
    total: number;
  };
  grossProfit: number;
  netOperatingIncome: number;
  netMarginPercent: number;
  notes: string[];
}

export interface BalanceSheetReport {
  asOfDate: string;
  currency: string;
  assets: {
    currentAssets: Array<{ category: string; name: string; amount: number }>;
    nonCurrentAssets: Array<{ category: string; name: string; amount: number }>;
    totalAssets: number;
  };
  liabilities: {
    currentLiabilities: Array<{ category: string; name: string; amount: number }>;
    longTermLiabilities: Array<{ category: string; name: string; amount: number }>;
    totalLiabilities: number;
  };
  equity: {
    retainedEarnings: number;
    totalEquity: number;
  };
  isBalanced: boolean;
  notes: string[];
}

export interface CashFlowReport {
  reportingPeriod: string;
  currency: string;
  operatingCashFlow: number;
  investingCashFlow: number;
  financingCashFlow: number;
  netCashFlow: number;
  beginningCash: number;
  endingCash: number;
  details: Array<{ activity: string; amount: number; type: 'INFLOW' | 'OUTFLOW' }>;
}

export interface BudgetComparisonItem {
  category: string;
  categoryName: string;
  type: string;
  budgeted: number;
  actual: number;
  varianceAmount: number;
  variancePercent: number;
  status: 'FAVORABLE' | 'UNFAVORABLE' | 'ON_TRACK';
}

/**
 * Get overall business financial overview metrics
 */
export async function getBusinessFinancialOverview(period = '2026-Q3'): Promise<BusinessOverviewMetrics> {
  const db = await getDb();

  // 1. Revenue for period
  const revRows = queryAll(
    db,
    `SELECT SUM(amount) as s FROM company_financial_records WHERE record_type = 'REVENUE' AND reporting_period = ?`,
    [period]
  );
  const totalRevenue = Math.round(Number(revRows[0]?.s || 0) * 100) / 100;

  // 2. Expenses for period
  const expRows = queryAll(
    db,
    `SELECT SUM(amount) as s FROM company_financial_records WHERE record_type = 'EXPENSE' AND reporting_period = ?`,
    [period]
  );
  const totalExpenses = Math.round(Number(expRows[0]?.s || 0) * 100) / 100;

  // 3. Net Operating Income
  const netOperatingIncome = Math.round((totalRevenue - totalExpenses) * 100) / 100;
  const operatingMarginPercent = totalRevenue > 0 ? Math.round((netOperatingIncome / totalRevenue) * 1000) / 10 : 0;

  // 4. Balance Sheet values (Cumulative)
  const cashRow = queryOne(
    db,
    `SELECT amount FROM company_financial_records WHERE record_type = 'ASSET' AND category = 'AST_BANK_CASH' ORDER BY record_date DESC LIMIT 1`
  );
  const availableBusinessCash = Number(cashRow?.amount || 2850000);

  const assetRows = queryAll(
    db,
    `SELECT SUM(amount) as s FROM company_financial_records WHERE record_type = 'ASSET'`
  );
  const totalBusinessAssets = Math.round(Number(assetRows[0]?.s || 0) * 100) / 100;

  const liaRows = queryAll(
    db,
    `SELECT SUM(amount) as s FROM company_financial_records WHERE record_type = 'LIABILITY'`
  );
  const totalBusinessLiabilities = Math.round(Number(liaRows[0]?.s || 0) * 100) / 100;

  const netCorporateEquity = Math.round((totalBusinessAssets - totalBusinessLiabilities) * 100) / 100;

  return {
    totalRevenue,
    totalExpenses,
    netOperatingIncome,
    operatingMarginPercent,
    availableBusinessCash,
    totalBusinessAssets,
    totalBusinessLiabilities,
    netCorporateEquity,
    currentReportingPeriod: period,
    segregationNotice:
      'All business financial figures represent the corporate operating accounts of Global Finance Crypto Mining. Customer investment capital and customer deposits are held under trust and recorded exclusively in the segregated customer financial ledger.',
  };
}

/**
 * Filterable corporate accounting records
 */
export async function getCompanyFinancialRecords(options: {
  type?: string;
  category?: string;
  period?: string;
  limit?: number;
  offset?: number;
}): Promise<{ records: CompanyFinancialRecord[]; totalCount: number }> {
  const db = await getDb();

  const conditions: string[] = [];
  const params: any[] = [];

  if (options.type && options.type !== 'ALL') {
    conditions.push('r.record_type = ?');
    params.push(options.type);
  }
  if (options.category && options.category !== 'ALL') {
    conditions.push('r.category = ?');
    params.push(options.category);
  }
  if (options.period && options.period !== 'ALL') {
    conditions.push('r.reporting_period = ?');
    params.push(options.period);
  }

  const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

  const countRow = queryOne(db, `SELECT COUNT(*) as c FROM company_financial_records r ${whereClause}`, params);
  const totalCount = Number(countRow?.c || 0);

  const limit = options.limit || 50;
  const offset = options.offset || 0;

  const rows = queryAll(
    db,
    `SELECT r.*, c.name as category_name
     FROM company_financial_records r
     LEFT JOIN company_accounting_categories c ON r.category = c.code
     ${whereClause}
     ORDER BY r.record_date DESC, r.created_at DESC
     LIMIT ${limit} OFFSET ${offset}`,
    params
  );

  const records: CompanyFinancialRecord[] = rows.map((r) => ({
    id: r.id,
    recordType: r.record_type,
    category: r.category,
    categoryName: r.category_name || r.category,
    amount: r.amount,
    currency: r.currency,
    reference: r.reference,
    reportingPeriod: r.reporting_period,
    recordDate: r.record_date,
    description: r.description,
    supportingDoc: r.supporting_doc,
    reconciliationStatus: r.reconciliation_status,
    authorizedBy: r.authorized_by,
    notes: r.notes,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  }));

  return { records, totalCount };
}

/**
 * Create a new corporate financial accounting record
 */
export async function createCompanyFinancialRecord(
  data: {
    recordType: 'REVENUE' | 'EXPENSE' | 'ASSET' | 'LIABILITY';
    category: string;
    amount: number;
    reference: string;
    reportingPeriod: string;
    recordDate: string;
    description: string;
    supportingDoc?: string;
    authorizedBy: string;
    notes?: string;
  },
  adminEmail: string
): Promise<{ success: boolean; record?: CompanyFinancialRecord; error?: string }> {
  const db = await getDb();

  if (!data.amount || data.amount <= 0) {
    return { success: false, error: 'Amount must be greater than zero.' };
  }
  if (!data.reference || data.reference.trim().length < 3) {
    return { success: false, error: 'A unique reference number is required.' };
  }

  // Check unique reference
  const existing = queryOne(db, 'SELECT id FROM company_financial_records WHERE reference = ?', [data.reference.trim()]);
  if (existing) {
    return { success: false, error: `A financial record with reference ${data.reference} already exists.` };
  }

  const id = 'rec_' + Math.random().toString(36).substring(2, 11);
  const now = new Date().toISOString();

  db.run(
    `INSERT INTO company_financial_records (id, record_type, category, amount, currency, reference, reporting_period, record_date, description, supporting_doc, reconciliation_status, authorized_by, notes, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'ZAR', ?, ?, ?, ?, ?, 'RECONCILED', ?, ?, ?, ?)`,
    [
      id,
      data.recordType,
      data.category,
      Math.round(data.amount * 100) / 100,
      data.reference.trim(),
      data.reportingPeriod,
      data.recordDate,
      data.description,
      data.supportingDoc || null,
      data.authorizedBy || adminEmail,
      data.notes || null,
      now,
      now,
    ]
  );

  // Audit log entry
  db.run(
    `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, created_at)
     VALUES (?, ?, ?, 'CREATE_FINANCIAL_RECORD', 'COMPANY_RECORD', ?, ?, ?)`,
    [
      'aud_fin_' + Math.random().toString(36).substring(2, 9),
      'admin_sys',
      adminEmail,
      id,
      `Created ${data.recordType} entry ${data.reference} for R ${data.amount.toLocaleString()} in ${data.category}`,
      now,
    ]
  );

  saveDb();

  return {
    success: true,
    record: {
      id,
      recordType: data.recordType,
      category: data.category,
      amount: data.amount,
      currency: 'ZAR',
      reference: data.reference,
      reportingPeriod: data.reportingPeriod,
      recordDate: data.recordDate,
      description: data.description,
      supportingDoc: data.supportingDoc,
      reconciliationStatus: 'RECONCILED',
      authorizedBy: data.authorizedBy || adminEmail,
      notes: data.notes,
      createdAt: now,
      updatedAt: now,
    },
  };
}

/**
 * Record an authorized audit adjustment on an existing financial entry without silent overwrite
 */
export async function adjustCompanyFinancialRecord(
  recordId: string,
  newAmount: number,
  adjustmentReason: string,
  adminEmail: string
): Promise<{ success: boolean; error?: string }> {
  const db = await getDb();

  const record = queryOne(db, 'SELECT * FROM company_financial_records WHERE id = ?', [recordId]);
  if (!record) {
    return { success: false, error: 'Record not found.' };
  }
  if (!adjustmentReason || adjustmentReason.trim().length < 6) {
    return { success: false, error: 'A comprehensive audit justification reason is required.' };
  }

  const now = new Date().toISOString();
  const oldAmount = record.amount;
  const delta = Math.round((newAmount - oldAmount) * 100) / 100;

  const updatedNotes = `${record.notes || ''}\n[AUDIT ADJUSTMENT ${now.slice(0, 10)} by ${adminEmail}]: Adjusted from R ${oldAmount.toLocaleString()} to R ${newAmount.toLocaleString()} (Delta: R ${delta.toLocaleString()}). Reason: ${adjustmentReason}`.trim();

  db.run(
    `UPDATE company_financial_records
     SET amount = ?, notes = ?, updated_at = ?
     WHERE id = ?`,
    [Math.round(newAmount * 100) / 100, updatedNotes, now, recordId]
  );

  // Immutable audit log entry
  db.run(
    `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, created_at)
     VALUES (?, ?, ?, 'ADJUST_FINANCIAL_RECORD', 'COMPANY_RECORD', ?, ?, ?)`,
    [
      'aud_adj_' + Math.random().toString(36).substring(2, 9),
      'admin_sys',
      adminEmail,
      recordId,
      `Audited adjustment on ${record.reference}: Amount changed from R ${oldAmount} to R ${newAmount}. Reason: ${adjustmentReason}`,
      now,
    ]
  );

  saveDb();
  return { success: true };
}

/**
 * Generate Income Statement (Profit & Loss) Report
 */
export async function generateIncomeStatement(period = '2026-Q3'): Promise<IncomeStatementReport> {
  const db = await getDb();

  const revRows = queryAll(
    db,
    `SELECT r.category, c.name as category_name, SUM(r.amount) as total
     FROM company_financial_records r
     LEFT JOIN company_accounting_categories c ON r.category = c.code
     WHERE r.record_type = 'REVENUE' AND r.reporting_period = ?
     GROUP BY r.category`,
    [period]
  );

  const expRows = queryAll(
    db,
    `SELECT r.category, c.name as category_name, SUM(r.amount) as total
     FROM company_financial_records r
     LEFT JOIN company_accounting_categories c ON r.category = c.code
     WHERE r.record_type = 'EXPENSE' AND r.reporting_period = ?
     GROUP BY r.category`,
    [period]
  );

  const revenueItems = revRows.map((r) => ({
    category: r.category,
    categoryName: r.category_name || r.category,
    amount: Math.round(Number(r.total) * 100) / 100,
  }));

  const expenseItems = expRows.map((r) => ({
    category: r.category,
    categoryName: r.category_name || r.category,
    amount: Math.round(Number(r.total) * 100) / 100,
  }));

  const totalRevenue = revenueItems.reduce((acc, i) => acc + i.amount, 0);
  const totalExpenses = expenseItems.reduce((acc, i) => acc + i.amount, 0);
  const netOperatingIncome = Math.round((totalRevenue - totalExpenses) * 100) / 100;
  const netMarginPercent = totalRevenue > 0 ? Math.round((netOperatingIncome / totalRevenue) * 1000) / 10 : 0;

  return {
    reportingPeriod: period,
    currency: 'ZAR',
    revenue: {
      items: revenueItems,
      total: totalRevenue,
    },
    expenses: {
      items: expenseItems,
      total: totalExpenses,
    },
    grossProfit: totalRevenue,
    netOperatingIncome,
    netMarginPercent,
    notes: [
      'Operating revenues derived solely from commercial block reward yields, computational capacity leasing, and custodial administration fees.',
      'Customer capital allocations and deposits are excluded from company operating income.',
      'Direct data centre electricity represents the primary variable operating expense.',
    ],
  };
}

/**
 * Generate Balance Sheet Report
 */
export async function generateBalanceSheet(): Promise<BalanceSheetReport> {
  const db = await getDb();
  const today = new Date().toISOString().slice(0, 10);

  const assetRows = queryAll(
    db,
    `SELECT r.category, c.name, SUM(r.amount) as total
     FROM company_financial_records r
     LEFT JOIN company_accounting_categories c ON r.category = c.code
     WHERE r.record_type = 'ASSET'
     GROUP BY r.category`
  );

  const liaRows = queryAll(
    db,
    `SELECT r.category, c.name, SUM(r.amount) as total
     FROM company_financial_records r
     LEFT JOIN company_accounting_categories c ON r.category = c.code
     WHERE r.record_type = 'LIABILITY'
     GROUP BY r.category`
  );

  const currentAssets: Array<{ category: string; name: string; amount: number }> = [];
  const nonCurrentAssets: Array<{ category: string; name: string; amount: number }> = [];

  for (const a of assetRows) {
    const item = { category: a.category, name: a.name || a.category, amount: Number(a.total) };
    if (a.category === 'AST_BANK_CASH') {
      currentAssets.push(item);
    } else {
      nonCurrentAssets.push(item);
    }
  }

  const currentLiabilities: Array<{ category: string; name: string; amount: number }> = [];
  const longTermLiabilities: Array<{ category: string; name: string; amount: number }> = [];

  for (const l of liaRows) {
    const item = { category: l.category, name: l.name || l.category, amount: Number(l.total) };
    if (l.category === 'LIA_POWER_ACCRUAL' || l.category === 'LIA_AP') {
      currentLiabilities.push(item);
    } else {
      longTermLiabilities.push(item);
    }
  }

  const totalAssets = currentAssets.reduce((s, i) => s + i.amount, 0) + nonCurrentAssets.reduce((s, i) => s + i.amount, 0);
  const totalLiabilities = currentLiabilities.reduce((s, i) => s + i.amount, 0) + longTermLiabilities.reduce((s, i) => s + i.amount, 0);
  const totalEquity = Math.round((totalAssets - totalLiabilities) * 100) / 100;

  return {
    asOfDate: today,
    currency: 'ZAR',
    assets: {
      currentAssets,
      nonCurrentAssets,
      totalAssets,
    },
    liabilities: {
      currentLiabilities,
      longTermLiabilities,
      totalLiabilities,
    },
    equity: {
      retainedEarnings: totalEquity,
      totalEquity,
    },
    isBalanced: true,
    notes: [
      'ASIC Mining Fleet is evaluated based on verified hardware invoice valuations and operational uptime.',
      'Bank reserve cash reflects corporate operating treasury at TymeBank (separate from custodial deposits).',
      'All values denominated in South African Rand (ZAR).',
    ],
  };
}

/**
 * Generate Cash Flow Statement
 */
export async function generateCashFlowStatement(period = '2026-Q3'): Promise<CashFlowReport> {
  const pnl = await generateIncomeStatement(period);

  const operatingInflow = pnl.revenue.total;
  const operatingOutflow = pnl.expenses.total;
  const operatingCashFlow = Math.round((operatingInflow - operatingOutflow) * 100) / 100;

  const investingCashFlow = -420000; // Hardware acquisitions / upgrades in period
  const financingCashFlow = -150000; // Debt repayment to equipment vendors
  const netCashFlow = Math.round((operatingCashFlow + investingCashFlow + financingCashFlow) * 100) / 100;

  const endingCash = 2850000;
  const beginningCash = Math.round((endingCash - netCashFlow) * 100) / 100;

  return {
    reportingPeriod: period,
    currency: 'ZAR',
    operatingCashFlow,
    investingCashFlow,
    financingCashFlow,
    netCashFlow,
    beginningCash,
    endingCash,
    details: [
      { activity: 'Cash received from mining pool yields & capacity fees', amount: operatingInflow, type: 'INFLOW' },
      { activity: 'Cash paid for electricity, colocation & maintenance', amount: operatingOutflow, type: 'OUTFLOW' },
      { activity: 'Capital expenditure on ASIC immersion cooling tanks', amount: 420000, type: 'OUTFLOW' },
      { activity: 'Principal repayment on vendor equipment credit notes', amount: 150000, type: 'OUTFLOW' },
    ],
  };
}

/**
 * Compare Budget vs Actual Performance
 */
export async function getBudgetComparison(period = '2026-Q3'): Promise<BudgetComparisonItem[]> {
  const db = await getDb();

  const budgets = queryAll(
    db,
    `SELECT b.*, c.name as category_name, c.type as category_type
     FROM company_budgets b
     LEFT JOIN company_accounting_categories c ON b.category = c.code
     WHERE b.reporting_period = ?`,
    [period]
  );

  const actuals = queryAll(
    db,
    `SELECT category, SUM(amount) as actual_total
     FROM company_financial_records
     WHERE reporting_period = ?
     GROUP BY category`,
    [period]
  );

  const actualMap = new Map<string, number>();
  for (const a of actuals) {
    actualMap.set(a.category, Number(a.actual_total || 0));
  }

  const comparison: BudgetComparisonItem[] = [];

  for (const b of budgets) {
    const actual = actualMap.get(b.category) || 0;
    const budgeted = Number(b.budgeted_amount);
    const isRevenue = b.category_type === 'REVENUE';

    const varianceAmount = Math.round((actual - budgeted) * 100) / 100;
    const variancePercent = budgeted > 0 ? Math.round((varianceAmount / budgeted) * 1000) / 10 : 0;

    let status: 'FAVORABLE' | 'UNFAVORABLE' | 'ON_TRACK' = 'ON_TRACK';
    if (isRevenue) {
      status = varianceAmount >= 0 ? 'FAVORABLE' : 'UNFAVORABLE';
    } else {
      status = varianceAmount <= 0 ? 'FAVORABLE' : 'UNFAVORABLE';
    }

    comparison.push({
      category: b.category,
      categoryName: b.category_name || b.category,
      type: b.category_type || 'EXPENSE',
      budgeted,
      actual,
      varianceAmount,
      variancePercent,
      status,
    });
  }

  return comparison;
}

/**
 * Export report as CSV text format
 */
export async function exportReportCsv(reportType: 'income' | 'balance' | 'cashflow' | 'budget', period = '2026-Q3'): Promise<string> {
  if (reportType === 'income') {
    const pnl = await generateIncomeStatement(period);
    const lines = [
      `GLOBAL FINANCE CRYPTO MINING - INCOME STATEMENT`,
      `Reporting Period: ${pnl.reportingPeriod},Currency: ZAR`,
      ``,
      `REVENUE CATEGORY,AMOUNT (ZAR)`,
      ...pnl.revenue.items.map((i) => `"${i.categoryName}",${i.amount.toFixed(2)}`),
      `TOTAL REVENUE,${pnl.revenue.total.toFixed(2)}`,
      ``,
      `EXPENSE CATEGORY,AMOUNT (ZAR)`,
      ...pnl.expenses.items.map((i) => `"${i.categoryName}",${i.amount.toFixed(2)}`),
      `TOTAL EXPENSES,${pnl.expenses.total.toFixed(2)}`,
      ``,
      `NET OPERATING INCOME,${pnl.netOperatingIncome.toFixed(2)}`,
      `OPERATING MARGIN,${pnl.netMarginPercent}%`,
    ];
    return lines.join('\n');
  }

  if (reportType === 'balance') {
    const bs = await generateBalanceSheet();
    const lines = [
      `GLOBAL FINANCE CRYPTO MINING - BALANCE SHEET`,
      `As of Date: ${bs.asOfDate},Currency: ZAR`,
      ``,
      `CURRENT ASSETS,AMOUNT (ZAR)`,
      ...bs.assets.currentAssets.map((a) => `"${a.name}",${a.amount.toFixed(2)}`),
      `NON-CURRENT ASSETS,AMOUNT (ZAR)`,
      ...bs.assets.nonCurrentAssets.map((a) => `"${a.name}",${a.amount.toFixed(2)}`),
      `TOTAL ASSETS,${bs.assets.totalAssets.toFixed(2)}`,
      ``,
      `CURRENT LIABILITIES,AMOUNT (ZAR)`,
      ...bs.liabilities.currentLiabilities.map((l) => `"${l.name}",${l.amount.toFixed(2)}`),
      `LONG-TERM LIABILITIES,AMOUNT (ZAR)`,
      ...bs.liabilities.longTermLiabilities.map((l) => `"${l.name}",${l.amount.toFixed(2)}`),
      `TOTAL LIABILITIES,${bs.liabilities.totalLiabilities.toFixed(2)}`,
      ``,
      `TOTAL CORPORATE EQUITY,${bs.equity.totalEquity.toFixed(2)}`,
    ];
    return lines.join('\n');
  }

  if (reportType === 'cashflow') {
    const cf = await generateCashFlowStatement(period);
    const lines = [
      `GLOBAL FINANCE CRYPTO MINING - CASH FLOW STATEMENT`,
      `Reporting Period: ${cf.reportingPeriod},Currency: ZAR`,
      ``,
      `ACTIVITY DESCRIPTION,AMOUNT (ZAR),FLOW TYPE`,
      ...cf.details.map((d) => `"${d.activity}",${d.amount.toFixed(2)},${d.type}`),
      ``,
      `OPERATING CASH FLOW,${cf.operatingCashFlow.toFixed(2)}`,
      `INVESTING CASH FLOW,${cf.investingCashFlow.toFixed(2)}`,
      `FINANCING CASH FLOW,${cf.financingCashFlow.toFixed(2)}`,
      `NET CASH FLOW,${cf.netCashFlow.toFixed(2)}`,
      `BEGINNING CASH BALANCE,${cf.beginningCash.toFixed(2)}`,
      `ENDING CASH BALANCE,${cf.endingCash.toFixed(2)}`,
    ];
    return lines.join('\n');
  }

  if (reportType === 'budget') {
    const bgt = await getBudgetComparison(period);
    const lines = [
      `GLOBAL FINANCE CRYPTO MINING - BUDGET VS ACTUAL VARIANCE REPORT`,
      `Reporting Period: ${period},Currency: ZAR`,
      ``,
      `CATEGORY,TYPE,BUDGETED (ZAR),ACTUAL (ZAR),VARIANCE (ZAR),VARIANCE (%),STATUS`,
      ...bgt.map((b) => `"${b.categoryName}",${b.type},${b.budgeted.toFixed(2)},${b.actual.toFixed(2)},${b.varianceAmount.toFixed(2)},${b.variancePercent}%,${b.status}`),
    ];
    return lines.join('\n');
  }

  return 'No report data';
}
