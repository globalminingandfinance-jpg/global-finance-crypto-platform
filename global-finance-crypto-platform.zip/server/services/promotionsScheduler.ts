import { Database as SqlJsDatabase } from 'sql.js';
import { queryOne, queryAll, saveDb, getDb } from '../db/database.js';
import { getUserFinancialSummary } from './ledger.js';
import { executeScheduledAnnouncementsCheck } from './announcements.js';

export interface SASTDateParts {
  year: number;
  month: number; // 1-12
  day: number; // 1-31
  hour: number; // 0-23
  minute: number; // 0-59
  second: number;
  daysInMonth: number;
  isLastDayOfMonth: boolean;
  dateStr: string; // YYYY-MM-DD
  timeStr: string; // HH:MM
  sastFormatted: string;
}

/**
 * Extracts South Africa Standard Time (Africa/Johannesburg, UTC+2) parts reliably,
 * regardless of the host server's local timezone.
 */
export function getSASTDateParts(date: Date = new Date()): SASTDateParts {
  const formatter = new Intl.DateTimeFormat('en-ZA', {
    timeZone: 'Africa/Johannesburg',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });

  const parts = formatter.formatToParts(date);
  const partMap: Record<string, string> = {};
  for (const p of parts) {
    partMap[p.type] = p.value;
  }

  const year = parseInt(partMap.year, 10);
  const month = parseInt(partMap.month, 10);
  const day = parseInt(partMap.day, 10);
  const hour = parseInt(partMap.hour, 10);
  const minute = parseInt(partMap.minute, 10);
  const second = parseInt(partMap.second || '0', 10);

  const daysInMonth = getDaysInMonth(year, month);
  const isLastDay = day === daysInMonth;

  const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
  const timeStr = `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;

  return {
    year,
    month,
    day,
    hour,
    minute,
    second,
    daysInMonth,
    isLastDayOfMonth: isLastDay,
    dateStr,
    timeStr,
    sastFormatted: `${dateStr} ${timeStr}:${String(second).padStart(2, '0')} SAST`,
  };
}

/**
 * Calculates the exact number of calendar days in a month for any year,
 * correctly handling 28/29 days in February (including leap years) and 30/31 days.
 */
export function getDaysInMonth(year: number, month: number): number {
  return new Date(year, month, 0).getDate();
}

/**
 * Computes net fee and savings based on discount type and value.
 */
export function calculateNetDiscount(
  normalFee: number,
  discountType: 'PERCENTAGE' | 'FIXED_AMOUNT' | 'NONE',
  discountValue: number
): { normalFee: number; discountAmount: number; netFee: number } {
  let discountAmount = 0;
  if (discountType === 'PERCENTAGE') {
    discountAmount = Math.round((normalFee * (discountValue / 100)) * 100) / 100;
  } else if (discountType === 'FIXED_AMOUNT') {
    discountAmount = Math.min(normalFee, discountValue);
  }
  const netFee = Math.max(0, Math.round((normalFee - discountAmount) * 100) / 100);
  return { normalFee, discountAmount, netFee };
}

/**
 * Calculates next upcoming publication dates for the 4 slots in SAST.
 */
export function getUpcomingSchedule(nowDate: Date = new Date()) {
  const sast = getSASTDateParts(nowDate);
  const slots = [
    { key: 'FLASH_DISCOUNT_6TH', name: 'Flash Investment Discount', targetDay: 6 },
    { key: 'CASH_REWARD_16TH', name: 'Cash-Value Reward', targetDay: 16 },
    { key: 'SPECIAL_OFFER_26TH', name: 'Special Investment Offer', targetDay: 26 },
    { key: 'MONTH_END_FINAL_DAY', name: 'Month-End Money Special', targetDay: sast.daysInMonth },
  ];

  return slots.map((s) => {
    let schedYear = sast.year;
    let schedMonth = sast.month;
    let targetDay = s.targetDay;

    // Check if this month's occurrence has already passed (or is today after 09:00)
    const isPast =
      sast.day > targetDay || (sast.day === targetDay && sast.hour >= 9);

    if (isPast) {
      schedMonth += 1;
      if (schedMonth > 12) {
        schedMonth = 1;
        schedYear += 1;
      }
      if (s.key === 'MONTH_END_FINAL_DAY') {
        targetDay = getDaysInMonth(schedYear, schedMonth);
      }
    }

    const nextDateStr = `${schedYear}-${String(schedMonth).padStart(2, '0')}-${String(targetDay).padStart(2, '0')} 09:00:00 SAST`;
    return {
      slotKey: s.key,
      name: s.name,
      dayOfMonth: s.targetDay === -1 ? 'Final Day' : `${targetDay}th`,
      nextScheduledSAST: nextDateStr,
      isNextMonth: isPast,
    };
  });
}

/**
 * Broadcasts an offer template to qualifying clients.
 * Guarantees zero duplicate broadcasts for the same monthly recurrence via idempotency keys.
 */
export async function broadcastPromotion(
  db: SqlJsDatabase,
  options: {
    templateId?: string;
    slotKey?: string;
    triggerType: 'AUTOMATIC_SCHEDULE' | 'MANUAL_TRIGGER' | 'TEST_DISPATCH';
    adminEmail?: string;
    testUserId?: string;
  }
): Promise<{
  success: boolean;
  skipped?: boolean;
  reason?: string;
  runId?: string;
  recipientCount?: number;
}> {
  const { templateId, slotKey, triggerType, adminEmail, testUserId } = options;

  let template: any = null;
  if (templateId) {
    template = queryOne(db, 'SELECT * FROM promotional_offer_templates WHERE id = ?', [templateId]);
  } else if (slotKey) {
    template = queryOne(db, 'SELECT * FROM promotional_offer_templates WHERE slot_key = ?', [slotKey]);
  }

  if (!template) {
    return { success: false, reason: 'Template not found' };
  }

  // Automatic runs must respect the master enable toggle
  if (triggerType === 'AUTOMATIC_SCHEDULE' && template.is_enabled === 0) {
    return { success: false, skipped: true, reason: 'Template is disabled by administrator' };
  }

  const sast = getSASTDateParts();
  let idempotencyKey = '';

  if (triggerType === 'AUTOMATIC_SCHEDULE') {
    idempotencyKey = `${template.slot_key}:${sast.year}-${String(sast.month).padStart(2, '0')}`;
    const existing = queryOne(
      db,
      'SELECT id, status, published_at FROM promotional_offer_runs WHERE idempotency_key = ?',
      [idempotencyKey]
    );
    if (existing) {
      return {
        success: true,
        skipped: true,
        reason: `Slot ${template.slot_key} already published for ${sast.year}-${String(sast.month).padStart(2, '0')}`,
        runId: existing.id,
      };
    }
  } else if (triggerType === 'TEST_DISPATCH') {
    idempotencyKey = `TEST:${template.slot_key}:${Date.now()}:${Math.random().toString(36).substring(2, 6)}`;
  } else {
    // Manual immediate trigger by admin
    idempotencyKey = `MANUAL:${template.slot_key}:${Date.now()}:${Math.random().toString(36).substring(2, 6)}`;
  }

  // Determine recipients
  let recipients: { id: string; email: string; first_name?: string }[] = [];

  if (triggerType === 'TEST_DISPATCH') {
    if (testUserId) {
      const u = queryOne(db, 'SELECT id, email, first_name FROM users WHERE id = ?', [testUserId]);
      if (u) recipients = [u];
    }
    if (recipients.length === 0 && adminEmail) {
      const u = queryOne(db, 'SELECT id, email, first_name FROM users WHERE LOWER(email) = LOWER(?)', [adminEmail]);
      if (u) recipients = [u];
    }
    if (recipients.length === 0) {
      // Pick first active user or admin
      const u = queryOne(db, 'SELECT id, email, first_name FROM users LIMIT 1');
      if (u) recipients = [u];
    }
  } else {
    const audience = template.target_audience || 'ALL_CLIENTS';
    if (audience === 'VERIFIED_KYC_ONLY') {
      recipients = queryAll(
        db,
        `SELECT id, email, first_name FROM users WHERE role = 'client' AND status = 'active' AND kyc_status = 'verified'`
      );
    } else if (audience === 'ACTIVE_INVESTORS') {
      recipients = queryAll(
        db,
        `SELECT DISTINCT u.id, u.email, u.first_name 
         FROM users u 
         JOIN investment_allocations a ON u.id = a.user_id 
         WHERE u.role = 'client' AND u.status = 'active' AND a.status = 'ACTIVE'`
      );
    } else {
      // ALL_CLIENTS default
      recipients = queryAll(
        db,
        `SELECT id, email, first_name FROM users WHERE role = 'client' AND status = 'active'`
      );
    }
  }

  const nowIso = new Date().toISOString();
  const validityHours = template.validity_hours || 48;
  const expiresAt = new Date(Date.now() + validityHours * 3600 * 1000).toISOString();
  const runId = 'run_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6);

  // Insert publication run record
  db.run(
    `INSERT INTO promotional_offer_runs (
      id, idempotency_key, template_id, offer_title, slot_key, trigger_type,
      published_at, expires_at, recipient_count, status
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'ACTIVE')`,
    [
      runId,
      idempotencyKey,
      template.id,
      template.title,
      template.slot_key,
      triggerType,
      nowIso,
      expiresAt,
      recipients.length,
    ]
  );

  // Map category to customer notification type
  let notifType = 'PROMOTION_DISCOUNT';
  if (template.category === 'CASH_REWARD') notifType = 'PROMOTION_REWARD';
  else if (template.category === 'SPECIAL_OFFER') notifType = 'PROMOTION_INVESTMENT';
  else if (template.category === 'MONTH_END') notifType = 'PROMOTION_MONTH_END';

  // Structured promo payload
  const promoData = JSON.stringify({
    category: template.category,
    slot_key: template.slot_key,
    discount_type: template.discount_type,
    discount_value: template.discount_value,
    normal_fee_amount: template.normal_fee_amount,
    min_deposit_amount: template.min_deposit_amount,
    reward_amount: template.reward_amount,
    product_name: template.product_name,
    expires_at: expiresAt,
    disclaimer: template.disclaimer,
    cta_label: template.cta_label,
    cta_route: template.cta_route,
    run_id: runId,
  });

  // Batch insert notifications for recipients
  for (const user of recipients) {
    const notifId = 'notif_promo_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO customer_notifications (
        id, user_id, title, message, type, is_read, created_at,
        promo_run_id, promo_category, promo_expiry, promo_data
      ) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)`,
      [
        notifId,
        user.id,
        template.title,
        template.description,
        notifType,
        nowIso,
        runId,
        template.category,
        expiresAt,
        promoData,
      ]
    );
  }

  // Audit log entry
  const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
     VALUES (?, ?, ?, 'PROMOTIONAL_OFFER_PUBLISHED', 'PROMOTION_RUN', ?, ?, '127.0.0.1', ?)`,
    [
      auditId,
      adminEmail || 'SYSTEM_SCHEDULER',
      adminEmail || 'system.scheduler@globalfinance.internal',
      runId,
      JSON.stringify({
        slotKey: template.slot_key,
        title: template.title,
        triggerType,
        recipients: recipients.length,
        idempotencyKey,
      }),
      nowIso,
    ]
  );

  saveDb();

  console.log(
    `[PROMOTIONS] Broadcast run ${runId} published (${template.slot_key}) to ${recipients.length} clients.`
  );

  return {
    success: true,
    runId,
    recipientCount: recipients.length,
  };
}

/**
 * Checks if current South Africa Standard Time matches any recurring monthly slot,
 * and publishes it if not already published for the month.
 */
export async function executeScheduledPromotionsCheck(db: SqlJsDatabase): Promise<{
  checkedAtSAST: string;
  triggeredSlots: string[];
}> {
  const sast = getSASTDateParts();
  const triggeredSlots: string[] = [];

  // Automated monthly promotions are published at or after 09:00 AM SAST
  if (sast.hour < 9) {
    return { checkedAtSAST: sast.sastFormatted, triggeredSlots };
  }

  const slotCandidates: { slotKey: string; isMatch: boolean }[] = [
    { slotKey: 'FLASH_DISCOUNT_6TH', isMatch: sast.day === 6 },
    { slotKey: 'CASH_REWARD_16TH', isMatch: sast.day === 16 },
    { slotKey: 'SPECIAL_OFFER_26TH', isMatch: sast.day === 26 },
    { slotKey: 'MONTH_END_FINAL_DAY', isMatch: sast.isLastDayOfMonth },
  ];

  for (const candidate of slotCandidates) {
    if (candidate.isMatch) {
      const result = await broadcastPromotion(db, {
        slotKey: candidate.slotKey,
        triggerType: 'AUTOMATIC_SCHEDULE',
      });
      if (result.success && !result.skipped) {
        triggeredSlots.push(candidate.slotKey);
      }
    }
  }

  return { checkedAtSAST: sast.sastFormatted, triggeredSlots };
}

/**
 * Emergency Kill Switch: immediately revokes an active promotion run.
 */
export function killPromotionRun(
  db: SqlJsDatabase,
  runId: string,
  adminEmail: string
): { success: boolean; error?: string } {
  const run = queryOne(db, 'SELECT * FROM promotional_offer_runs WHERE id = ?', [runId]);
  if (!run) {
    return { success: false, error: 'Promotion run not found' };
  }

  const now = new Date().toISOString();
  db.run(
    `UPDATE promotional_offer_runs 
     SET status = 'CANCELLED_KILL_SWITCH', killed_by_admin = ?, killed_at = ? 
     WHERE id = ?`,
    [adminEmail, now, runId]
  );

  // Mark pending claims for this run as REJECTED due to kill switch
  db.run(
    `UPDATE promotional_reward_claims 
     SET status = 'REJECTED', admin_notes = 'Promotion revoked by administration via emergency kill switch.', reviewed_by = ?, reviewed_at = ?
     WHERE run_id = ? AND status = 'PENDING_APPROVAL'`,
    [adminEmail, now, runId]
  );

  // Audit log entry
  const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
     VALUES (?, 'ADMIN', ?, 'PROMOTION_KILL_SWITCH_ACTIVATED', 'PROMOTION_RUN', ?, ?, '127.0.0.1', ?)`,
    [
      auditId,
      adminEmail,
      runId,
      `Emergency kill switch engaged for run ${runId} (${run.slot_key})`,
      now,
    ]
  );

  saveDb();
  console.log(`[PROMOTIONS] Emergency kill switch activated for run ${runId} by ${adminEmail}.`);
  return { success: true };
}

/**
 * Submits a client reward claim for the 16th Cash-Value Reward.
 */
export function submitRewardClaim(
  db: SqlJsDatabase,
  params: {
    runId: string;
    userId: string;
    userEmail: string;
    notes?: string;
  }
): { success: boolean; claimId?: string; error?: string } {
  const { runId, userId, userEmail, notes } = params;

  // Check run status
  const run = queryOne(db, 'SELECT * FROM promotional_offer_runs WHERE id = ?', [runId]);
  if (!run) {
    return { success: false, error: 'Promotional offer run not found.' };
  }
  if (run.status !== 'ACTIVE') {
    return { success: false, error: 'This promotional offer is no longer active.' };
  }
  if (new Date(run.expires_at).getTime() < Date.now()) {
    return { success: false, error: 'This promotional offer has expired.' };
  }

  // Check template reward amount
  const template = queryOne(db, 'SELECT reward_amount FROM promotional_offer_templates WHERE id = ?', [run.template_id]);
  const rewardAmount = template ? Number(template.reward_amount) : 350.00;

  // Prevent duplicate claims by same client
  const existingClaim = queryOne(
    db,
    'SELECT id, status FROM promotional_reward_claims WHERE run_id = ? AND user_id = ?',
    [runId, userId]
  );
  if (existingClaim) {
    return {
      success: false,
      error: `You have already submitted a claim for this promotion (Status: ${existingClaim.status}).`,
    };
  }

  const claimId = 'claim_' + Math.random().toString(36).substring(2, 11);
  const now = new Date().toISOString();

  db.run(
    `INSERT INTO promotional_reward_claims (
      id, run_id, user_id, user_email, reward_amount, status, claim_notes, created_at
    ) VALUES (?, ?, ?, ?, ?, 'PENDING_APPROVAL', ?, ?)`,
    [claimId, runId, userId, userEmail, rewardAmount, notes || 'Client submitted claim for cash reward voucher', now]
  );

  saveDb();
  return { success: true, claimId };
}

/**
 * Approves or rejects a client reward claim.
 * When approved, applies credit to the client's financial ledger in a double-entry manner.
 */
export function reviewRewardClaim(
  db: SqlJsDatabase,
  params: {
    claimId: string;
    action: 'APPROVE' | 'REJECT';
    adminNotes?: string;
    adminEmail: string;
  }
): { success: boolean; error?: string } {
  const { claimId, action, adminNotes, adminEmail } = params;

  const claim = queryOne(db, 'SELECT * FROM promotional_reward_claims WHERE id = ?', [claimId]);
  if (!claim) {
    return { success: false, error: 'Claim not found.' };
  }
  if (claim.status !== 'PENDING_APPROVAL') {
    return { success: false, error: `Claim has already been reviewed (Status: ${claim.status}).` };
  }

  const now = new Date().toISOString();

  if (action === 'APPROVE') {
    const rewardAmount = Number(claim.reward_amount);

    // Apply ledger credit
    const userSummary = getUserFinancialSummary(db, claim.user_id);
    const newBalance = userSummary.availableBalance + rewardAmount;
    const ledgerId = 'led_rew_' + Math.random().toString(36).substring(2, 11);
    const txId = 'tx_rew_' + Math.random().toString(36).substring(2, 11);
    const txRef = 'REW-' + Date.now().toString(36).toUpperCase();

    const starterProduct = queryOne(db, 'SELECT id FROM investment_products LIMIT 1');
    const prodId = starterProduct?.id || 'prod_starter';

    // 1. Transaction record
    db.run(
      `INSERT INTO transactions (id, reference, user_id, product_id, amount, currency, fee, payment_method, payment_provider, status, notes, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'ZAR', 0, 'PROMOTION_VOUCHER', 'COMPANY_REWARD', 'COMPLETED', ?, ?, ?)`,
      [txId, txRef, claim.user_id, prodId, rewardAmount, 'Promotional Cash-Value Reward Voucher Credit', now, now]
    );

    // 2. Financial ledger double-entry credit
    db.run(
      `INSERT INTO financial_ledger (id, transaction_id, user_id, entry_type, debit, credit, balance_after, description, created_at)
       VALUES (?, ?, ?, 'DEPOSIT', 0, ?, ?, ?, ?)`,
      [
        ledgerId,
        txId,
        claim.user_id,
        rewardAmount,
        newBalance,
        `Promotional Cash-Value Reward Voucher Credit (Ref: ${txRef})`,
        now,
      ]
    );

    // 3. Mark claim approved
    db.run(
      `UPDATE promotional_reward_claims 
       SET status = 'APPROVED', admin_notes = ?, reviewed_by = ?, reviewed_at = ? 
       WHERE id = ?`,
      [adminNotes || 'Reward voucher approved and credited to account balance.', adminEmail, now, claimId]
    );

    // 4. Send customer notification confirmation
    const notifId = 'notif_rew_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO customer_notifications (
        id, user_id, title, message, type, is_read, created_at
      ) VALUES (?, ?, ?, ?, 'SYSTEM', 0, ?)`,
      [
        notifId,
        claim.user_id,
        'Cash Reward Voucher Approved!',
        `Your promotional reward of R${rewardAmount.toFixed(2)} has been verified and credited directly to your available mining balance.`,
        now,
      ]
    );

    // 5. Audit log
    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'PROMOTION_CLAIM_APPROVED', 'REWARD_CLAIM', ?, ?, '127.0.0.1', ?)`,
      [
        auditId,
        adminEmail,
        claimId,
        `Approved reward claim of R${rewardAmount.toFixed(2)} for user ${claim.user_email}`,
        now,
      ]
    );
  } else {
    // REJECT
    db.run(
      `UPDATE promotional_reward_claims 
       SET status = 'REJECTED', admin_notes = ?, reviewed_by = ?, reviewed_at = ? 
       WHERE id = ?`,
      [adminNotes || 'Reward voucher claim rejected.', adminEmail, now, claimId]
    );

    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'PROMOTION_CLAIM_REJECTED', 'REWARD_CLAIM', ?, ?, '127.0.0.1', ?)`,
      [auditId, adminEmail, claimId, `Rejected reward claim for user ${claim.user_email}: ${adminNotes || 'N/A'}`, now]
    );
  }

  saveDb();
  return { success: true };
}

let schedulerTimer: NodeJS.Timeout | null = null;

/**
 * Initializes the background scheduler service.
 * Ticks every 60 seconds with full error isolation.
 */
export function startPromotionsScheduler() {
  if (schedulerTimer) {
    clearInterval(schedulerTimer);
  }

  console.log('[PROMOTIONS] Background scheduler service started (Africa/Johannesburg, 09:00 SAST sync).');

  const tick = async () => {
    try {
      const db = await getDb();
      await executeScheduledPromotionsCheck(db);
      executeScheduledAnnouncementsCheck(db);
    } catch (err) {
      console.error('[PROMOTIONS SCHEDULER ERROR]', err);
    }
  };

  // Immediate check on startup
  setTimeout(tick, 3000);

  // Recurring check every 60 seconds
  schedulerTimer = setInterval(tick, 60000);
}
