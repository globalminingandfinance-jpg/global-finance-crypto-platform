import { Database as SqlJsDatabase } from 'sql.js';
import { queryOne, queryAll, saveDb } from '../db/database.js';
import { GoogleGenAI } from '@google/genai';
import {
  AudienceCriteria,
  AnnouncementCategory,
  AnnouncementPriority,
  StructuredAnnouncementDetails,
  AIWritingStyle,
  AIAssistantAction,
  GlobalAnnouncement,
  AnnouncementAnalytics,
} from '../../src/types/index.js';

/**
 * Resolves qualifying recipient accounts from real database records based on audience filters.
 */
export function resolveAudienceRecipients(
  db: SqlJsDatabase,
  criteria: AudienceCriteria
): { id: string; email: string; first_name?: string; last_name?: string; kyc_status?: string }[] {
  // If individual clients explicitly selected
  if (criteria.general === 'INDIVIDUAL_CLIENTS') {
    if (!criteria.selectedUserIds || criteria.selectedUserIds.length === 0) {
      return [];
    }
    const placeholders = criteria.selectedUserIds.map(() => '?').join(',');
    return queryAll(
      db,
      `SELECT id, email, first_name, last_name, kyc_status
       FROM users
       WHERE id IN (${placeholders}) AND role = 'client' AND status = 'active'`,
      criteria.selectedUserIds
    );
  }

  // Base query: all active clients
  let conditions: string[] = ["role = 'client'", "status = 'active'"];
  const params: any[] = [];

  // KYC Filter
  if (criteria.kycStatuses && criteria.kycStatuses.length > 0) {
    const kycPlaceholders = criteria.kycStatuses.map(() => '?').join(',');
    conditions.push(`kyc_status IN (${kycPlaceholders})`);
    params.push(...criteria.kycStatuses);
  }

  // Investment Plan Filter (Starter, Growth, Professional, Elite)
  if (criteria.plans && criteria.plans.length > 0) {
    const planSlugs = criteria.plans.map((p) => p.toLowerCase());
    const planPlaceholders = planSlugs.map(() => '?').join(',');
    conditions.push(`id IN (
      SELECT DISTINCT a.user_id 
      FROM investment_allocations a 
      JOIN investment_products p ON a.product_id = p.id 
      WHERE LOWER(p.slug) IN (${planPlaceholders}) AND a.status IN ('ACTIVE', 'MATURED')
    )`);
    params.push(...planSlugs);
  }

  // Payment Status Filter
  if (criteria.paymentStatuses && criteria.paymentStatuses.length > 0) {
    const paymentClauses: string[] = [];
    if (criteria.paymentStatuses.includes('SUCCESSFUL_PAYMENT')) {
      paymentClauses.push(`id IN (SELECT DISTINCT user_id FROM transactions WHERE status = 'COMPLETED')`);
    }
    if (criteria.paymentStatuses.includes('PENDING_PAYMENT')) {
      paymentClauses.push(`id IN (SELECT DISTINCT user_id FROM transactions WHERE status = 'PENDING')`);
    }
    if (criteria.paymentStatuses.includes('FAILED_PAYMENT')) {
      paymentClauses.push(`id IN (SELECT DISTINCT user_id FROM transactions WHERE status = 'FAILED')`);
    }
    if (paymentClauses.length > 0) {
      conditions.push(`(${paymentClauses.join(' OR ')})`);
    }
  }

  // Investment Activity Filter
  if (criteria.investmentActivity === 'ACTIVE_ONLY') {
    conditions.push(`id IN (SELECT DISTINCT user_id FROM investment_allocations WHERE status = 'ACTIVE')`);
  } else if (criteria.investmentActivity === 'NO_ACTIVE') {
    conditions.push(`id NOT IN (SELECT DISTINCT user_id FROM investment_allocations WHERE status = 'ACTIVE')`);
  } else if (criteria.investmentActivity === 'APPROACHING_MATURITY') {
    // Maturing within the next 7 days
    const nowIso = new Date().toISOString();
    const sevenDaysIso = new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString();
    conditions.push(`id IN (
      SELECT DISTINCT user_id FROM investment_allocations 
      WHERE status = 'ACTIVE' AND maturity_date IS NOT NULL AND maturity_date BETWEEN ? AND ?
    )`);
    params.push(nowIso, sevenDaysIso);
  }

  const query = `
    SELECT id, email, first_name, last_name, kyc_status
    FROM users
    WHERE ${conditions.join(' AND ')}
    ORDER BY created_at DESC
  `;

  return queryAll(db, query, params);
}

/**
 * Masks an email address safely for administrator recipient previews without exposing full emails.
 */
export function maskEmail(email: string): string {
  const parts = email.split('@');
  if (parts.length !== 2) return email;
  const name = parts[0];
  const domain = parts[1];
  const maskedName = name.length <= 2 ? name[0] + '***' : name[0] + '***' + name[name.length - 1];
  return `${maskedName}@${domain}`;
}

/**
 * Generates or refines an announcement message with Gemini API using strictly verified facts.
 */
export async function generateAIMessage(params: {
  title: string;
  category: AnnouncementCategory;
  priority: AnnouncementPriority;
  structuredDetails?: StructuredAnnouncementDetails;
  audienceSummary?: string;
  writingStyle?: AIWritingStyle;
  action?: AIAssistantAction;
  currentMessage?: string;
}): Promise<{ success: boolean; message?: string; error?: string }> {
  const {
    title,
    category,
    priority,
    structuredDetails,
    audienceSummary,
    writingStyle = 'professional_reassuring',
    action = 'GENERATE',
    currentMessage,
  } = params;

  try {
    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    let stylePrompt = 'Professional and reassuring fintech tone.';
    if (writingStyle === 'formal_corporate') stylePrompt = 'Formal corporate, executive, and precise tone.';
    else if (writingStyle === 'simple_clear') stylePrompt = 'Simple, clear, and easy to understand without financial jargon.';
    else if (writingStyle === 'urgent_operational') stylePrompt = 'Direct, clear, urgent operational notice.';
    else if (writingStyle === 'friendly_customer') stylePrompt = 'Warm, helpful, and friendly customer service update.';

    let actionInstruction = 'Draft a complete, authoritative customer announcement.';
    if (action === 'MAKE_SHORTER') actionInstruction = 'Make the current message significantly more concise while preserving every essential fact.';
    else if (action === 'MAKE_FORMAL') actionInstruction = 'Rewrite the current message into a formal executive corporate tone.';
    else if (action === 'SIMPLIFY') actionInstruction = 'Simplify the language and sentence structure for maximum readability.';
    else if (action === 'IMPROVE_CLARITY') actionInstruction = 'Improve clarity, flow, and paragraph structure.';

    const prompt = `
You are the authorized executive communications assistant for "Global Finance Crypto Mining" (a South African digital asset computing infrastructure and investment platform).

TASK:
${actionInstruction}

ANNOUNCEMENT METADATA:
- Title: "${title}"
- Category: ${category}
- Priority Level: ${priority}
- Target Audience: ${audienceSummary || 'All Registered Clients'}
- Desired Style: ${stylePrompt}

ADMINISTRATOR SUPPLIED FACTS:
- What Happened / Changing: ${structuredDetails?.whatHappened || 'None provided'}
- Why Clients Need to Know: ${structuredDetails?.whyItMatters || 'None provided'}
- Effective Date & Time: ${structuredDetails?.effectiveDate || 'Immediate'}
- Expected Duration: ${structuredDetails?.duration || 'N/A'}
- Services Affected: ${structuredDetails?.affectedServices || 'General Platform'}
- Required Client Action: ${structuredDetails?.requiredAction || 'No action required'}
- Additional Factual Notes: ${structuredDetails?.factualNotes || 'None'}

${currentMessage ? `CURRENT DRAFT TO MODIFY:\n"""${currentMessage}"""` : ''}

CRITICAL FINANCIAL & ACCURACY SAFEGUARDS (MANDATORY):
1. Rely SOLELY on the supplied facts. Do NOT invent dates, deadlines, platform outages, financial figures, or operational outcomes.
2. Never claim an unverified payment has been received or approved.
3. Never claim an investment generated a profit unless stated in the facts.
4. Never guarantee fixed investment yields or promise risk-free capital returns.
5. Never invent regulatory licenses, insurances, or government approvals.
6. If critical details are missing, include a polite instruction or placeholder like "[Please verify your details in the client portal]".
7. Keep the message ready to send directly to clients. Do not include markdown code blocks, conversational greetings to the admin, or meta-commentary.
    `.trim();

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction:
          'You are a senior compliance and financial communications editor. Generate clean, professional text without markdown triple backticks.',
      },
    });

    const generatedText = response.text?.trim() || '';
    if (!generatedText) {
      return { success: false, error: 'AI returned an empty response. Please check prompt details.' };
    }

    return { success: true, message: generatedText };
  } catch (err: any) {
    console.error('[AI ANNOUNCEMENT GENERATION ERROR]', err);
    return {
      success: false,
      error:
        err.message ||
        'AI generation service unavailable. You may write or edit the message manually.',
    };
  }
}

/**
 * Publishes an announcement immediately to all qualifying recipients.
 */
export function publishAnnouncement(
  db: SqlJsDatabase,
  announcementId: string,
  adminEmail: string
): { success: boolean; recipientCount?: number; error?: string } {
  const announcement = queryOne(
    db,
    'SELECT * FROM global_announcements WHERE id = ?',
    [announcementId]
  );
  if (!announcement) {
    return { success: false, error: 'Announcement not found.' };
  }

  let criteria: AudienceCriteria = { general: 'ALL_CLIENTS' };
  try {
    criteria = JSON.parse(announcement.audience_filter_json);
  } catch {}

  // Resolve actual qualifying clients right now
  const recipients = resolveAudienceRecipients(db, criteria);
  const nowIso = new Date().toISOString();

  // Notification type based on priority
  const notifType =
    announcement.priority === 'URGENT' ? 'ANNOUNCEMENT_URGENT' : 'ANNOUNCEMENT';

  // Batch insert notifications
  for (const user of recipients) {
    const notifId = 'notif_ann_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO customer_notifications (
        id, user_id, title, message, type, is_read, created_at,
        announcement_id, priority, action_link, promo_category
      ) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?)`,
      [
        notifId,
        user.id,
        announcement.title,
        announcement.message,
        notifType,
        nowIso,
        announcement.id,
        announcement.priority,
        announcement.action_link || null,
        announcement.category,
      ]
    );
  }

  // Update announcement state
  db.run(
    `UPDATE global_announcements SET
      status = 'PUBLISHED',
      published_at = ?,
      recipient_count = ?,
      delivered_count = ?,
      approved_by_admin = COALESCE(approved_by_admin, ?),
      updated_at = ?
     WHERE id = ?`,
    [nowIso, recipients.length, recipients.length, adminEmail, nowIso, announcementId]
  );

  // Record audit log
  const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
     VALUES (?, 'ADMIN', ?, 'ANNOUNCEMENT_PUBLISHED', 'GLOBAL_ANNOUNCEMENT', ?, ?, '127.0.0.1', ?)`,
    [
      auditId,
      adminEmail,
      announcementId,
      `Published announcement "${announcement.title}" (${announcement.category}) to ${recipients.length} clients. Priority: ${announcement.priority}`,
      nowIso,
    ]
  );

  saveDb();
  console.log(
    `[ANNOUNCEMENTS] Published "${announcement.title}" to ${recipients.length} clients by ${adminEmail}.`
  );

  return { success: true, recipientCount: recipients.length };
}

/**
 * Computes communication analytics from the database.
 */
export function getAnnouncementAnalytics(db: SqlJsDatabase): AnnouncementAnalytics {
  const totalRow = queryOne(db, 'SELECT COUNT(*) as c FROM global_announcements');
  const publishedRow = queryOne(db, "SELECT COUNT(*) as c FROM global_announcements WHERE status = 'PUBLISHED'");
  const draftRow = queryOne(db, "SELECT COUNT(*) as c FROM global_announcements WHERE status = 'DRAFT'");
  const scheduledRow = queryOne(db, "SELECT COUNT(*) as c FROM global_announcements WHERE status = 'SCHEDULED'");
  const cancelledRow = queryOne(db, "SELECT COUNT(*) as c FROM global_announcements WHERE status = 'CANCELLED'");

  // Notification delivery and read metrics for announcements
  const notifStats = queryOne(
    db,
    `SELECT 
       COUNT(*) as total_recipients,
       SUM(CASE WHEN is_read = 1 THEN 1 ELSE 0 END) as total_read,
       SUM(CASE WHEN is_read = 0 THEN 1 ELSE 0 END) as total_unread
     FROM customer_notifications 
     WHERE announcement_id IS NOT NULL`
  );

  const totalRecipients = notifStats ? Number(notifStats.total_recipients || 0) : 0;
  const totalRead = notifStats ? Number(notifStats.total_read || 0) : 0;
  const totalUnread = notifStats ? Number(notifStats.total_unread || 0) : 0;
  const readRate = totalRecipients > 0 ? Math.round((totalRead / totalRecipients) * 1000) / 10 : 0;

  // Category breakdown
  const categoryRows = queryAll(
    db,
    'SELECT category, COUNT(*) as count FROM global_announcements GROUP BY category'
  );
  const categoryBreakdown: Record<string, number> = {};
  for (const r of categoryRows) {
    categoryBreakdown[r.category] = Number(r.count);
  }

  // Priority breakdown
  const priorityRows = queryAll(
    db,
    'SELECT priority, COUNT(*) as count FROM global_announcements GROUP BY priority'
  );
  const priorityBreakdown: Record<string, number> = {};
  for (const r of priorityRows) {
    priorityBreakdown[r.priority] = Number(r.count);
  }

  return {
    totalAnnouncements: totalRow ? Number(totalRow.c) : 0,
    publishedAnnouncements: publishedRow ? Number(publishedRow.c) : 0,
    draftAnnouncements: draftRow ? Number(draftRow.c) : 0,
    scheduledAnnouncements: scheduledRow ? Number(scheduledRow.c) : 0,
    cancelledAnnouncements: cancelledRow ? Number(cancelledRow.c) : 0,
    totalRecipientsReached: totalRecipients,
    totalDelivered: totalRecipients,
    totalRead,
    totalUnread,
    overallReadRate: readRate,
    categoryBreakdown,
    priorityBreakdown,
  };
}

/**
 * Checks for scheduled announcements that are due for publication.
 */
export function executeScheduledAnnouncementsCheck(db: SqlJsDatabase): void {
  const nowIso = new Date().toISOString();
  const scheduledList = queryAll(
    db,
    `SELECT * FROM global_announcements 
     WHERE status = 'SCHEDULED' AND scheduled_for IS NOT NULL AND scheduled_for <= ?`,
    [nowIso]
  );

  for (const a of scheduledList) {
    const res = publishAnnouncement(db, a.id, a.created_by_admin || 'SYSTEM_SCHEDULER');
    if (res.success) {
      // If recurring, schedule the next recurrence
      if (a.recurrence_pattern && a.recurrence_pattern !== 'NONE') {
        const curDate = new Date(a.scheduled_for);
        let nextDate = new Date(curDate);

        if (a.recurrence_pattern === 'DAILY') {
          nextDate.setDate(nextDate.getDate() + 1);
        } else if (a.recurrence_pattern === 'WEEKLY') {
          nextDate.setDate(nextDate.getDate() + 7);
        } else if (a.recurrence_pattern === 'MONTHLY') {
          nextDate.setMonth(nextDate.getMonth() + 1);
        }

        const shouldContinue =
          !a.recurrence_end_date || nextDate.getTime() <= new Date(a.recurrence_end_date).getTime();

        if (shouldContinue) {
          const nextIso = nextDate.toISOString();
          // Create new scheduled occurrence record
          const nextId = 'ann_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6);
          db.run(
            `INSERT INTO global_announcements (
              id, title, category, priority, status, message, structured_details_json,
              audience_filter_json, recipient_count, delivered_count, read_count,
              scheduled_for, recurrence_pattern, recurrence_end_date, created_by_admin, action_link,
              created_at, updated_at
            ) VALUES (?, ?, ?, ?, 'SCHEDULED', ?, ?, ?, 0, 0, 0, ?, ?, ?, ?, ?, ?, ?)`,
            [
              nextId,
              a.title,
              a.category,
              a.priority,
              a.message,
              a.structured_details_json,
              a.audience_filter_json,
              nextIso,
              a.recurrence_pattern,
              a.recurrence_end_date,
              a.created_by_admin,
              a.action_link,
              nowIso,
              nowIso,
            ]
          );
          console.log(`[ANNOUNCEMENTS] Scheduled next recurring announcement ${nextId} for ${nextIso}`);
        }
      }
    }
  }
}
