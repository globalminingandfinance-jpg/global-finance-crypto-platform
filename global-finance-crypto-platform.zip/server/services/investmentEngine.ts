import { Database } from 'sql.js';
import { queryOne, queryAll, saveDb } from '../db/database.js';

export interface InvestmentTerms {
  planName: string;
  termVersion: number;
  returnRate: number;
  durationDays: number;
  calculationMethod: 'PROFIT_ON_CAPITAL';
}

/**
 * Calculates projected returns with decimal-safe integer rounding to 2 places.
 */
export function calculateProjectedProfit(
  principal: number,
  returnRate: number,
  calculationMethod: string = 'PROFIT_ON_CAPITAL'
): { projectedProfit: number; projectedTotal: number } {
  const safePrincipal = Math.max(0, Number(principal) || 0);
  const safeRate = Math.max(0, Number(returnRate) || 0);

  if (calculationMethod === 'PROFIT_ON_CAPITAL') {
    const projectedProfit = Math.round(safePrincipal * safeRate * 100) / 100;
    const projectedTotal = Math.round((safePrincipal + projectedProfit) * 100) / 100;
    return { projectedProfit, projectedTotal };
  }

  // Fallback for direct multiplier rate
  const total = Math.round(safePrincipal * safeRate * 100) / 100;
  const profit = Math.max(0, Math.round((total - safePrincipal) * 100) / 100);
  return { projectedProfit: profit, projectedTotal: total };
}

/**
 * Calculates remaining duration from server authoritative timestamps.
 */
export function calculateDurationMetrics(activatedAt: string, maturityDate: string, serverNow: Date = new Date()) {
  const start = new Date(activatedAt).getTime();
  const end = new Date(maturityDate).getTime();
  const now = serverNow.getTime();

  const totalDurationSeconds = Math.max(1, Math.floor((end - start) / 1000));
  const elapsedSeconds = Math.max(0, Math.min(totalDurationSeconds, Math.floor((now - start) / 1000)));
  const remainingSeconds = Math.max(0, Math.floor((end - now) / 1000));
  const isMatured = now >= end;
  const progressPercentage = Math.min(100, Math.max(0, Math.round((elapsedSeconds / totalDurationSeconds) * 100)));

  return {
    totalDurationSeconds,
    elapsedSeconds,
    remainingSeconds,
    isMatured,
    progressPercentage,
  };
}

/**
 * Safe percentage change calculation preventing division by zero.
 */
export function calculateDailyPerformance(
  previousValue: number,
  currentValue: number
): { change: number; percentage: number } {
  const prev = Number(previousValue) || 0;
  const curr = Number(currentValue) || 0;
  const change = Math.round((curr - prev) * 100) / 100;

  if (prev <= 0) {
    return { change, percentage: 0 };
  }

  const percentage = Math.round(((curr - prev) / prev) * 10000) / 100;
  return { change, percentage };
}

/**
 * Idempotently evaluates maturity for an investment.
 * If elapsed >= duration and status is ACTIVE, updates to MATURED.
 */
export function evaluateInvestmentMaturity(
  db: Database,
  investmentId: string,
  serverNow: Date = new Date()
): void {
  const inv = queryOne(
    db,
    'SELECT id, status, maturity_date, settlement_status FROM investment_allocations WHERE id = ?',
    [investmentId]
  );

  if (!inv || inv.status === 'SETTLED' || inv.status === 'CANCELLED') {
    return;
  }

  const maturityTime = new Date(inv.maturity_date).getTime();
  const nowTime = serverNow.getTime();

  if (nowTime >= maturityTime && inv.status === 'ACTIVE') {
    const nowIso = serverNow.toISOString();
    db.run(
      `UPDATE investment_allocations 
       SET status = 'MATURED',
           settlement_status = CASE WHEN settlement_status = 'SETTLED' THEN 'SETTLED' ELSE 'MATURED_PENDING_SETTLEMENT' END,
           updated_at = ?
       WHERE id = ?`,
      [nowIso, investmentId]
    );

    // Record system audit log
    const auditId = 'ia_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO investment_audit_logs (id, investment_id, action, actor_type, actor_id, previous_state, new_state, reason, created_at)
       VALUES (?, ?, 'MATURITY_REACHED', 'SYSTEM', 'CRON_ENGINE', 'ACTIVE', 'MATURED', 'Investment maturity date reached authoritative schedule', ?)`,
      [auditId, investmentId, nowIso]
    );

    saveDb();
  }
}

/**
 * Evaluates all active investments for maturity across the system.
 */
export function evaluateAllActiveInvestments(db: Database, serverNow: Date = new Date()): void {
  const activeInvs = queryAll(
    db,
    "SELECT id FROM investment_allocations WHERE status = 'ACTIVE'"
  );

  for (const inv of activeInvs) {
    evaluateInvestmentMaturity(db, inv.id, serverNow);
  }
}

/**
 * Authoritative settlement of a matured investment by administrator.
 * Fully audited, ledger-backed, and strictly idempotent.
 */
export function settleMaturedInvestment(
  db: Database,
  params: {
    investmentId: string;
    adminId: string;
    adminEmail: string;
    notes?: string;
  }
): { success: boolean; error?: string; settlementAmount?: number } {
  const { investmentId, adminId, adminEmail, notes } = params;

  const inv = queryOne(
    db,
    `SELECT a.*, u.email as user_email, u.first_name, u.last_name, p.name as product_name
     FROM investment_allocations a
     JOIN users u ON a.user_id = u.id
     JOIN investment_products p ON a.product_id = p.id
     WHERE a.id = ?`,
    [investmentId]
  );

  if (!inv) {
    return { success: false, error: 'Investment record not found.' };
  }

  if (inv.settlement_status === 'SETTLED' || inv.status === 'SETTLED') {
    return { success: false, error: 'This investment has already been settled. Duplicate settlement rejected.' };
  }

  const now = new Date();
  const maturityTime = new Date(inv.maturity_date).getTime();
  if (now.getTime() < maturityTime) {
    return {
      success: false,
      error: `Investment has not reached maturity date yet (Matures on ${new Date(inv.maturity_date).toLocaleDateString()}).`,
    };
  }

  const settlementAmount = Number(inv.projected_total || inv.amount_allocated);
  const realizedPnL = Number(inv.projected_profit || 0);
  const nowIso = now.toISOString();

  // 1. Credit the client's financial ledger with settlement payout
  const ledgerId = 'led_stl_' + Math.random().toString(36).substring(2, 11);
  const lastLedger = queryOne(
    db,
    'SELECT balance_after FROM financial_ledger WHERE user_id = ? ORDER BY rowid DESC LIMIT 1',
    [inv.user_id]
  );
  const currentBalance = lastLedger ? Number(lastLedger.balance_after) : 0;
  const newBalance = currentBalance + settlementAmount;

  db.run(
    `INSERT INTO financial_ledger (id, transaction_id, user_id, entry_type, debit, credit, balance_after, description, created_at)
     VALUES (?, ?, ?, 'INVESTMENT_SETTLED', 0, ?, ?, ?, ?)`,
    [
      ledgerId,
      inv.transaction_id,
      inv.user_id,
      settlementAmount,
      newBalance,
      `Maturity Settlement: ${inv.product_name} (Capital R${inv.amount_allocated} + Return R${realizedPnL})`,
      nowIso,
    ]
  );

  // 2. Update investment allocation status
  db.run(
    `UPDATE investment_allocations
     SET status = 'SETTLED',
         settlement_status = 'SETTLED',
         realized_pnl = ?,
         settlement_amount = ?,
         settlement_date = ?,
         settlement_notes = ?,
         current_valuation = ?,
         updated_at = ?
     WHERE id = ?`,
    [
      realizedPnL,
      settlementAmount,
      nowIso,
      notes || `Maturity settlement processed by ${adminEmail}`,
      settlementAmount,
      nowIso,
      investmentId,
    ]
  );

  // 3. Insert final settled daily record
  const drId = 'dr_stl_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO investment_daily_records (id, investment_id, user_id, record_date, opening_value, closing_value, daily_change, daily_percentage, cumulative_change, projected_value, classification, data_source, notes, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?, ?, 'SETTLED', 'AUDITED_ADMIN_SETTLEMENT', ?, ?)`,
    [
      drId,
      investmentId,
      inv.user_id,
      nowIso.slice(0, 10),
      inv.current_valuation,
      settlementAmount,
      realizedPnL,
      realizedPnL,
      settlementAmount,
      `Full capital and contractual return settled to client account by ${adminEmail}`,
      nowIso,
    ]
  );

  // 4. Record audit log
  const auditId = 'ia_stl_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO investment_audit_logs (id, investment_id, action, actor_type, actor_id, previous_state, new_state, reason, created_at)
     VALUES (?, ?, 'INVESTMENT_SETTLED', 'ADMIN', ?, 'MATURED', 'SETTLED', ?, ?)`,
    [
      auditId,
      investmentId,
      adminId,
      JSON.stringify({
        adminEmail,
        settlementAmount,
        realizedPnL,
        notes: notes || 'Standard maturity completion',
      }),
      nowIso,
    ]
  );

  // 5. Send in-app notification to the customer
  const notifId = 'notif_stl_' + Math.random().toString(36).substring(2, 11);
  db.run(
    `INSERT INTO customer_notifications (id, user_id, ticket_id, title, message, type, is_read, created_at)
     VALUES (?, ?, NULL, ?, ?, 'SETTLEMENT', 0, ?)`,
    [
      notifId,
      inv.user_id,
      `Investment Matured & Settled: ${inv.product_name}`,
      `Your investment in ${inv.product_name} has matured and a total settlement of R${settlementAmount.toLocaleString('en-ZA', { minimumFractionDigits: 2 })} has been credited to your available balance.`,
      nowIso,
    ]
  );

  saveDb();

  return { success: true, settlementAmount };
}

/**
 * Builds standard chart coordinates separating actual recorded historical valuations
 * from projected contractual trajectories.
 */
export function buildInvestmentChartSeries(
  allocations: any[],
  dailyRecords: any[],
  serverNow: Date = new Date()
) {
  // If zero allocations, return genuine zero flatline
  if (allocations.length === 0) {
    const today = serverNow.toISOString().slice(0, 10);
    const zeroSeries = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(serverNow.getTime() - i * 24 * 60 * 60 * 1000);
      zeroSeries.push({
        date: d.toISOString().slice(0, 10),
        timestamp: d.getTime(),
        actualValue: 0,
        projectedValue: 0,
        principalBaseline: 0,
        isProjectedOnly: false,
        label: d.toLocaleDateString('en-ZA', { month: 'short', day: 'numeric' }),
      });
    }
    return zeroSeries;
  }

  // Aggregate total principal
  const totalPrincipal = allocations.reduce((sum, a) => sum + Number(a.amount_allocated || 0), 0);
  const earliestActivation = allocations.reduce((earliest, a) => {
    const actTime = new Date(a.activated_at || a.created_at).getTime();
    return Math.min(earliest, actTime);
  }, serverNow.getTime());

  const latestMaturity = allocations.reduce((latest, a) => {
    const matTime = new Date(a.maturity_date).getTime();
    return Math.max(latest, matTime);
  }, serverNow.getTime());

  // Collect records by date
  const recordsByDate = new Map<string, { actual: number; projected: number }>();
  for (const dr of dailyRecords) {
    const dateKey = dr.record_date;
    const existing = recordsByDate.get(dateKey) || { actual: 0, projected: 0 };
    if (dr.classification === 'ACTUAL' || dr.classification === 'SETTLED' || dr.classification === 'ADJUSTED') {
      existing.actual += Number(dr.closing_value || 0);
    }
    existing.projected += Number(dr.projected_value || dr.closing_value || 0);
    recordsByDate.set(dateKey, existing);
  }

  const series = [];
  const oneDayMs = 24 * 60 * 60 * 1000;
  const startDay = new Date(earliestActivation);
  startDay.setHours(0, 0, 0, 0);

  const endDay = new Date(Math.max(latestMaturity, serverNow.getTime()));
  endDay.setHours(0, 0, 0, 0);

  const todayStr = serverNow.toISOString().slice(0, 10);
  const totalProjectedFinal = allocations.reduce((sum, a) => sum + Number(a.projected_total || a.amount_allocated), 0);

  let cur = new Date(startDay.getTime());
  while (cur.getTime() <= endDay.getTime()) {
    const dateStr = cur.toISOString().slice(0, 10);
    const isPastOrToday = dateStr <= todayStr;
    const isPast = dateStr < todayStr;
    const isFuture = dateStr > todayStr;

    const rec = recordsByDate.get(dateStr);
    let actualVal: number | null = null;
    let projVal: number | null = null;

    if (isPastOrToday) {
      if (rec && rec.actual > 0) {
        actualVal = rec.actual;
      } else {
        // Current recorded valuation up to today
        actualVal = allocations.reduce((sum, a) => {
          const act = new Date(a.activated_at || a.created_at).toISOString().slice(0, 10);
          if (dateStr >= act) {
            return sum + Number(a.current_valuation || a.amount_allocated);
          }
          return sum;
        }, 0);
      }
      projVal = actualVal;
    }

    if (isFuture) {
      // Future projection: distinct from actual, rises towards projected total
      const totalSpan = Math.max(1, endDay.getTime() - serverNow.getTime());
      const elapsedFuture = cur.getTime() - serverNow.getTime();
      const futureFactor = Math.min(1, elapsedFuture / totalSpan);

      const baseVal = allocations.reduce((sum, a) => sum + Number(a.current_valuation || a.amount_allocated), 0);
      projVal = Math.round((baseVal + (totalProjectedFinal - baseVal) * futureFactor) * 100) / 100;
      actualVal = null; // Strictly no actual recorded data for future dates!
    }

    series.push({
      date: dateStr,
      timestamp: cur.getTime(),
      actualValue: actualVal,
      projectedValue: projVal,
      principalBaseline: totalPrincipal,
      isProjectedOnly: isFuture,
      label: cur.toLocaleDateString('en-ZA', { month: 'short', day: 'numeric' }),
    });

    cur = new Date(cur.getTime() + oneDayMs);
  }

  return series;
}
