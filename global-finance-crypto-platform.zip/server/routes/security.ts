import { Router, Response } from 'express';
import crypto from 'crypto';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { getDb, queryOne, queryAll, saveDb, VAULT_DIR, recordSecurityEvent } from '../db/database.js';
import { requireAuth, AuthRequest, createRateLimiter } from '../middleware/auth.js';
import { sendEmailNotification } from '../services/email.js';
import { parseDeviceInfo } from './auth.js';

const router = Router();
const secLimiter = createRateLimiter(60000, 10);

// Preset list of standard security questions
export const STANDARD_SECURITY_QUESTIONS = [
  'What was the name of your first elementary or primary school?',
  'In what city or town did your parents meet?',
  'What is the maiden name of your mother or grandmother?',
  'What was the make and model of your first vehicle?',
  'What was the name of your first childhood pet?',
  'What was the name of the street where you grew up?',
];

// Helper: Sanitize IP for display
function maskIp(ip: string | undefined): string {
  if (!ip || ip === 'unknown' || ip === '::1' || ip === '127.0.0.1') return '127.0.0.1 (Local Session)';
  const parts = ip.split('.');
  if (parts.length === 4) {
    return `${parts[0]}.${parts[1]}.***.***`;
  }
  return ip.slice(0, 8) + '...';
}

// 1. SECURITY OVERVIEW
router.get('/overview', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const userId = req.user!.id;

    // Check security question
    const secQ = queryOne(
      db,
      'SELECT question, updated_at FROM user_security_questions WHERE user_id = ?',
      [userId]
    );

    // User details (phone verification, city, address)
    const user = queryOne(
      db,
      'SELECT email, phone, country, phone_verified, city, address FROM users WHERE id = ?',
      [userId]
    );

    // Document counts
    const docCounts = queryAll(
      db,
      'SELECT status, COUNT(*) as count FROM client_documents WHERE user_id = ? GROUP BY status',
      [userId]
    );
    const docs = {
      total: 0,
      approved: 0,
      pending: 0,
      rejected: 0,
      underReview: 0,
    };
    for (const d of docCounts) {
      docs.total += d.count;
      if (d.status === 'APPROVED') docs.approved = d.count;
      else if (d.status === 'PENDING') docs.pending = d.count;
      else if (d.status === 'UNDER_REVIEW') docs.underReview = d.count;
      else if (d.status === 'REJECTED') docs.rejected = d.count;
    }

    // Recent activity (last 5)
    const recentActivity = queryAll(
      db,
      'SELECT id, event_type, description, ip_address, user_agent, created_at FROM security_events WHERE user_id = ? ORDER BY created_at DESC LIMIT 5',
      [userId]
    );

    // Active sessions count
    const activeSessions = queryAll(
      db,
      'SELECT id FROM user_sessions WHERE user_id = ? AND is_revoked = 0',
      [userId]
    );

    res.json({
      hasSecurityQuestion: !!secQ,
      securityQuestion: secQ ? secQ.question : null,
      securityQuestionUpdatedAt: secQ ? secQ.updated_at : null,
      phone: user?.phone || null,
      isPhoneVerified: Boolean(user?.phone_verified),
      city: user?.city || null,
      address: user?.address || null,
      documentsSummary: docs,
      activeSessionsCount: Math.max(activeSessions.length, 1),
      recentActivity: recentActivity.map((a) => ({
        ...a,
        displayIp: maskIp(a.ip_address),
      })),
    });
  } catch (err) {
    console.error('[SECURITY OVERVIEW ERROR]', err);
    res.status(500).json({ error: 'Failed to load security overview.' });
  }
});

// 2. CHANGE PASSWORD
router.post('/change-password', requireAuth, secLimiter, async (req: AuthRequest, res: Response) => {
  try {
    const { currentPassword, newPassword, confirmPassword, signOutOtherSessions } = req.body;
    const userId = req.user!.id;

    if (!currentPassword || !newPassword) {
      res.status(400).json({ error: 'Current password and new password are required.' });
      return;
    }

    if (newPassword !== confirmPassword) {
      res.status(400).json({ error: 'New password and confirmation do not match.' });
      return;
    }

    if (String(newPassword).length < 8) {
      res.status(400).json({ error: 'New password must be at least 8 characters long.' });
      return;
    }

    // Require complexity
    const pwdStr = String(newPassword);
    const hasUpper = /[A-Z]/.test(pwdStr);
    const hasLower = /[a-z]/.test(pwdStr);
    const hasNumOrSpec = /[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwdStr);
    if (!hasUpper || !hasLower || !hasNumOrSpec) {
      res.status(400).json({
        error: 'Password must contain uppercase and lowercase letters, and at least one number or symbol.',
      });
      return;
    }

    const db = await getDb();
    const user = queryOne(
      db,
      'SELECT id, email, password_hash, first_name FROM users WHERE id = ?',
      [userId]
    );

    if (!user) {
      res.status(404).json({ error: 'User account not found.' });
      return;
    }

    // Verify current password
    const matches = bcrypt.compareSync(currentPassword, user.password_hash);
    if (!matches) {
      const ip = req.ip || req.socket.remoteAddress || 'unknown';
      const userAgent = req.headers['user-agent'] || 'unknown';
      recordSecurityEvent(
        db,
        userId,
        'PASSWORD_CHANGE_FAILED',
        'Password change rejected: incorrect current password entered',
        ip,
        parseDeviceInfo(userAgent)
      );
      res.status(400).json({ error: 'The current password you entered is incorrect.' });
      return;
    }

    // Prevent reusing current password
    if (bcrypt.compareSync(newPassword, user.password_hash)) {
      res.status(400).json({ error: 'New password cannot be identical to your current password.' });
      return;
    }

    // Hash new password securely
    const salt = bcrypt.genSaltSync(12);
    const newHash = bcrypt.hashSync(newPassword, salt);
    const now = new Date().toISOString();

    const userRole = queryOne(db, 'SELECT role, email FROM users WHERE id = ?', [userId]);
    const envAdminEmail = (process.env.INITIAL_ADMIN_EMAIL || '').toLowerCase().trim();
    const userEmailLower = String(userRole?.email || '').toLowerCase().trim();
    const isUserAdmin = userRole?.role === 'admin' ||
      userEmailLower === 'globalfinancecryptomining@gmail.com' ||
      userEmailLower === 'globalminingandfinance@gmail.com' ||
      (envAdminEmail && userEmailLower === envAdminEmail);

    if (isUserAdmin) {
      db.run(
        `UPDATE users 
         SET password_hash = ?, role = 'admin', must_change_password = 0, session_version = session_version + 1, updated_at = ? 
         WHERE role = 'admin' OR LOWER(email) IN (LOWER(?), LOWER(?), LOWER(?))`,
        [newHash, now, 'globalfinancecryptomining@gmail.com', 'globalminingandfinance@gmail.com', envAdminEmail || 'globalfinancecryptomining@gmail.com']
      );
    } else {
      db.run(
        'UPDATE users SET password_hash = ?, session_version = session_version + 1, updated_at = ? WHERE id = ?',
        [newHash, now, userId]
      );
    }

    if (signOutOtherSessions) {
      db.run('UPDATE user_sessions SET is_revoked = 1 WHERE user_id = ?', [userId]);
    }

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      userId,
      'PASSWORD_CHANGED',
      signOutOtherSessions
        ? 'Account password changed successfully (other active sessions signed out)'
        : 'Account password changed successfully',
      ip,
      parseDeviceInfo(userAgent)
    );

    // In-app notification
    const notifId = 'notif_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO customer_notifications (id, user_id, title, message, type, is_read, created_at)
       VALUES (?, ?, 'Security Alert: Password Updated', 'Your Global Finance account password was successfully updated.', 'SECURITY', 0, ?)`,
      [notifId, userId, now]
    );

    saveDb();

    // Email notification
    await sendEmailNotification(db, {
      to: user.email,
      subject: 'Security Alert: Your Password Was Updated',
      htmlContent: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; color: #1e293b; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px;">
          <h2 style="color: #0f172a; margin-top: 0;">Password Successfully Changed</h2>
          <p>Hello ${user.first_name || 'Client'},</p>
          <p>The password for your Global Finance Crypto Mining account was updated on <strong>${new Date().toUTCString()}</strong>.</p>
          <p><strong>Device:</strong> ${parseDeviceInfo(userAgent)}</p>
          <p style="font-size: 13px; color: #64748b;">If you performed this change, you can safely disregard this email. If you did not authorize this change, please report it via the Security Activity panel immediately.</p>
        </div>
      `,
      adminLogDetails: `Password change alert sent to ${user.email}`,
    });

    res.json({ message: 'Your password has been changed successfully.' });
  } catch (err: any) {
    console.error('[SECURITY CHANGE PASSWORD ERROR]', err);
    res.status(500).json({ error: 'Failed to change password. Please try again.' });
  }
});

// 3. PERSONAL SECURITY QUESTION
router.get('/security-question', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const record = queryOne(
      db,
      'SELECT question, updated_at FROM user_security_questions WHERE user_id = ?',
      [req.user!.id]
    );

    res.json({
      configured: !!record,
      question: record ? record.question : null,
      updatedAt: record ? record.updated_at : null,
      standardQuestions: STANDARD_SECURITY_QUESTIONS,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve security question status.' });
  }
});

router.post('/security-question', requireAuth, secLimiter, async (req: AuthRequest, res: Response) => {
  try {
    const { currentPassword, question, answer } = req.body;
    const userId = req.user!.id;

    if (!currentPassword || !question || !answer) {
      res.status(400).json({ error: 'Current password, security question, and answer are required.' });
      return;
    }

    const questionTrimmed = String(question).trim();
    const answerTrimmed = String(answer).trim().toLowerCase();

    if (questionTrimmed.length < 5 || questionTrimmed.length > 200) {
      res.status(400).json({ error: 'Security question must be between 5 and 200 characters.' });
      return;
    }

    if (answerTrimmed.length < 2 || answerTrimmed.length > 100) {
      res.status(400).json({ error: 'Security answer must be at least 2 characters.' });
      return;
    }

    const db = await getDb();
    const user = queryOne(db, 'SELECT password_hash FROM users WHERE id = ?', [userId]);
    if (!user || !bcrypt.compareSync(currentPassword, user.password_hash)) {
      res.status(400).json({ error: 'Current password incorrect. Re-authentication is required to update security questions.' });
      return;
    }

    // Hash normalized answer with bcrypt (never store plaintext)
    const salt = bcrypt.genSaltSync(12);
    const answerHash = bcrypt.hashSync(answerTrimmed, salt);
    const now = new Date().toISOString();

    db.run(
      `INSERT INTO user_security_questions (user_id, question, answer_hash, updated_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(user_id) DO UPDATE SET question = excluded.question, answer_hash = excluded.answer_hash, updated_at = excluded.updated_at`,
      [userId, questionTrimmed, answerHash, now]
    );

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      userId,
      'SECURITY_QUESTION_UPDATED',
      'Personal security question configured/updated with salted one-way hash',
      ip,
      parseDeviceInfo(userAgent)
    );
    saveDb();

    res.json({
      message: 'Personal security question successfully configured.',
      question: questionTrimmed,
    });
  } catch (err: any) {
    console.error('[SECURITY QUESTION ERROR]', err);
    res.status(500).json({ error: 'Failed to configure security question.' });
  }
});

// 4. PHONE NUMBER AND PERSONAL DETAILS
// Request OTP for phone verification
router.post('/phone/request-otp', requireAuth, secLimiter, async (req: AuthRequest, res: Response) => {
  try {
    const { newPhone, currentPassword } = req.body;
    const userId = req.user!.id;

    if (!newPhone || !currentPassword) {
      res.status(400).json({ error: 'New phone number and current password are required.' });
      return;
    }

    const phoneTrimmed = String(newPhone).trim().replace(/[^\d+]/g, '');
    if (phoneTrimmed.length < 8 || phoneTrimmed.length > 16) {
      res.status(400).json({ error: 'Please enter a valid phone number (e.g. +27 82 123 4567).' });
      return;
    }

    const db = await getDb();
    const user = queryOne(db, 'SELECT password_hash, email FROM users WHERE id = ?', [userId]);
    if (!user || !bcrypt.compareSync(currentPassword, user.password_hash)) {
      res.status(400).json({ error: 'Current password verification failed.' });
      return;
    }

    // Invalidate previous unverified OTPs
    db.run('UPDATE phone_verifications SET verified = 2 WHERE user_id = ? AND verified = 0', [userId]);

    // Generate 6-digit numeric OTP
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 minutes
    const now = new Date().toISOString();
    const verId = 'otp_' + Math.random().toString(36).substring(2, 11);

    db.run(
      `INSERT INTO phone_verifications (id, user_id, phone, otp_code, expires_at, verified, created_at)
       VALUES (?, ?, ?, ?, ?, 0, ?)`,
      [verId, userId, phoneTrimmed, otpCode, expiresAt, now]
    );

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      userId,
      'PHONE_OTP_REQUESTED',
      `Phone verification code dispatched for ${phoneTrimmed}`,
      ip,
      parseDeviceInfo(userAgent)
    );
    saveDb();

    // Send email copy of security notification
    await sendEmailNotification(db, {
      to: user.email,
      subject: 'Security Notice: Phone Verification Code',
      htmlContent: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; color: #1e293b; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px;">
          <h2 style="color: #0f172a; margin-top: 0;">Phone Number Verification</h2>
          <p>A request was made to update your verified contact phone number to <strong>${phoneTrimmed}</strong>.</p>
          <div style="margin: 20px 0; padding: 16px; background: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; text-align: center;">
            <span style="font-size: 28px; font-weight: bold; letter-spacing: 6px; color: #d97706;">${otpCode}</span>
          </div>
          <p style="font-size: 13px; color: #64748b;">This verification code is valid for 10 minutes. If you did not make this request, please change your password immediately.</p>
        </div>
      `,
      adminLogDetails: `Phone OTP generated for user ${userId}`,
    });

    res.json({
      message: `A 6-digit verification code has been dispatched to ${phoneTrimmed} and your registered email.`,
      previewCode: otpCode, // Provided for smooth demonstration in test environment
      expiresInMinutes: 10,
    });
  } catch (err: any) {
    console.error('[PHONE OTP REQUEST ERROR]', err);
    res.status(500).json({ error: 'Failed to request phone verification.' });
  }
});

// Verify OTP and commit phone update
router.post('/phone/verify-otp', requireAuth, secLimiter, async (req: AuthRequest, res: Response) => {
  try {
    const { newPhone, otpCode } = req.body;
    const userId = req.user!.id;

    if (!newPhone || !otpCode) {
      res.status(400).json({ error: 'Phone number and verification code are required.' });
      return;
    }

    const phoneTrimmed = String(newPhone).trim().replace(/[^\d+]/g, '');
    const codeTrimmed = String(otpCode).trim();

    const db = await getDb();
    const verification = queryOne(
      db,
      'SELECT id, otp_code, expires_at, verified FROM phone_verifications WHERE user_id = ? AND phone = ? AND verified = 0 ORDER BY created_at DESC LIMIT 1',
      [userId, phoneTrimmed]
    );

    if (!verification) {
      res.status(400).json({ error: 'No active verification request found for this phone number. Please request a new code.' });
      return;
    }

    if (new Date(verification.expires_at).getTime() < Date.now()) {
      res.status(400).json({ error: 'Verification code has expired. Please request a new code.' });
      return;
    }

    if (verification.otp_code !== codeTrimmed) {
      res.status(400).json({ error: 'Incorrect verification code. Please check and try again.' });
      return;
    }

    const now = new Date().toISOString();

    // Mark verified
    db.run('UPDATE phone_verifications SET verified = 1 WHERE id = ?', [verification.id]);

    // Update user record
    db.run(
      'UPDATE users SET phone = ?, phone_verified = 1, updated_at = ? WHERE id = ?',
      [phoneTrimmed, now, userId]
    );

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      userId,
      'PHONE_VERIFIED',
      `Registered phone number updated to ${phoneTrimmed} after cryptographic OTP verification`,
      ip,
      parseDeviceInfo(userAgent)
    );

    // In-app notification
    const notifId = 'notif_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO customer_notifications (id, user_id, title, message, type, is_read, created_at)
       VALUES (?, ?, 'Contact Details Updated', 'Your registered phone number has been verified and updated successfully.', 'SECURITY', 0, ?)`,
      [notifId, userId, now]
    );

    saveDb();

    res.json({
      message: 'Phone number verified and updated successfully.',
      phone: phoneTrimmed,
    });
  } catch (err: any) {
    console.error('[PHONE VERIFY OTP ERROR]', err);
    res.status(500).json({ error: 'Failed to verify phone number.' });
  }
});

// Update personal details (City & Address)
router.post('/personal-details', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { city, address } = req.body;
    const userId = req.user!.id;

    const cityClean = city ? String(city).trim().slice(0, 80) : '';
    const addressClean = address ? String(address).trim().slice(0, 200) : '';

    const db = await getDb();
    const now = new Date().toISOString();

    db.run(
      'UPDATE users SET city = ?, address = ?, updated_at = ? WHERE id = ?',
      [cityClean, addressClean, now, userId]
    );

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      userId,
      'PERSONAL_DETAILS_UPDATED',
      'Residential address and profile details updated',
      ip,
      parseDeviceInfo(userAgent)
    );
    saveDb();

    res.json({
      message: 'Personal details updated successfully.',
      city: cityClean,
      address: addressClean,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update personal details.' });
  }
});

// 5. SECURE DOCUMENT VAULT
// List documents for authenticated client
router.get('/documents', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const docs = queryAll(
      db,
      `SELECT id, name, category, file_type, file_size, status, rejection_reason, reviewed_at, created_at
       FROM client_documents
       WHERE user_id = ?
       ORDER BY created_at DESC`,
      [req.user!.id]
    );

    res.json({ documents: docs });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load documents.' });
  }
});

// Upload document into private vault
router.post('/documents/upload', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { name, category, fileType, fileData, fileSize } = req.body;
    const userId = req.user!.id;

    if (!name || !category || !fileType || !fileData) {
      res.status(400).json({ error: 'Document name, category, file type, and file content are required.' });
      return;
    }

    const validCategories = [
      'ID_DOCUMENT',
      'PROOF_OF_PAYMENT',
      'ADDRESS_VERIFICATION',
      'SUPPORTING_DOC',
    ];
    if (!validCategories.includes(category)) {
      res.status(400).json({ error: 'Invalid document category specified.' });
      return;
    }

    const allowedMimeTypes = [
      'application/pdf',
      'image/jpeg',
      'image/jpg',
      'image/png',
      'image/webp',
    ];
    if (!allowedMimeTypes.includes(fileType.toLowerCase())) {
      res.status(400).json({ error: 'Unsupported file type. Only PDF and image documents (JPEG, PNG, WebP) are accepted.' });
      return;
    }

    // Decode base64 file data
    let base64Clean = fileData;
    if (base64Clean.includes('base64,')) {
      base64Clean = base64Clean.split('base64,')[1];
    }
    const buffer = Buffer.from(base64Clean, 'base64');

    // Max 5 MB limit
    const MAX_SIZE = 5 * 1024 * 1024;
    if (buffer.length > MAX_SIZE) {
      res.status(400).json({ error: 'File size exceeds maximum allowed limit of 5 MB.' });
      return;
    }

    // Generate safe storage filename on private disk
    let ext = '.bin';
    if (fileType.includes('pdf')) ext = '.pdf';
    else if (fileType.includes('jpeg') || fileType.includes('jpg')) ext = '.jpg';
    else if (fileType.includes('png')) ext = '.png';
    else if (fileType.includes('webp')) ext = '.webp';

    const safeStorageFileName = `vault_${Date.now()}_${crypto.randomBytes(12).toString('hex')}${ext}`;
    const storagePath = path.join(VAULT_DIR, safeStorageFileName);

    // Save to disk in private vault directory (not in public web folder)
    fs.writeFileSync(storagePath, buffer);

    const docId = 'doc_' + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();
    const docNameClean = String(name).trim().slice(0, 100);

    const db = await getDb();
    db.run(
      `INSERT INTO client_documents (id, user_id, name, category, file_type, file_size, storage_path, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)`,
      [docId, userId, docNameClean, category, fileType, buffer.length, safeStorageFileName, now, now]
    );

    // Record review log entry
    db.run(
      `INSERT INTO document_review_logs (id, document_id, admin_id, admin_email, action, notes, created_at)
       VALUES (?, ?, 'SYSTEM', 'system@vault', 'SUBMITTED', 'Uploaded by client into secure vault', ?)`,
      ['dlog_' + Math.random().toString(36).substring(2, 11), docId, now]
    );

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      userId,
      'DOCUMENT_UPLOADED',
      `Document "${docNameClean}" (${category}) uploaded to private vault for administrative review`,
      ip,
      parseDeviceInfo(userAgent)
    );

    saveDb();

    res.status(201).json({
      message: 'Document uploaded successfully to private secure vault. Status: Under Standard Review.',
      document: {
        id: docId,
        name: docNameClean,
        category,
        fileType,
        fileSize: buffer.length,
        status: 'PENDING',
        createdAt: now,
      },
    });
  } catch (err: any) {
    console.error('[DOCUMENT UPLOAD ERROR]', err);
    res.status(500).json({ error: 'Failed to upload document.' });
  }
});

// Download/View document (ownership verified)
router.get('/documents/:id/download', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const doc = queryOne(
      db,
      'SELECT id, user_id, name, file_type, storage_path FROM client_documents WHERE id = ?',
      [id]
    );

    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }

    // Strict access control: must be owner or admin
    if (doc.user_id !== req.user!.id && req.user!.role !== 'admin') {
      res.status(403).json({ error: 'Access denied. You do not have permission to view this document.' });
      return;
    }

    const filePath = path.join(VAULT_DIR, doc.storage_path);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'Stored document file could not be located in private storage.' });
      return;
    }

    const safeFilename = doc.name.replace(/[^a-zA-Z0-9.-]/g, '_');
    res.setHeader('Content-Type', doc.file_type);
    res.setHeader('Content-Disposition', `inline; filename="${safeFilename}"`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-cache, no-store');

    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  } catch (err) {
    console.error('[DOCUMENT DOWNLOAD ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve document.' });
  }
});

// Delete document (only allowed if PENDING or REJECTED)
router.delete('/documents/:id', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const doc = queryOne(
      db,
      'SELECT id, user_id, name, status, storage_path FROM client_documents WHERE id = ?',
      [id]
    );

    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }

    if (doc.user_id !== req.user!.id && req.user!.role !== 'admin') {
      res.status(403).json({ error: 'Access denied.' });
      return;
    }

    if (doc.status === 'APPROVED' && req.user!.role !== 'admin') {
      res.status(400).json({ error: 'Approved compliance documents cannot be deleted directly. Please contact support if an update is required.' });
      return;
    }

    // Delete file from disk
    const filePath = path.join(VAULT_DIR, doc.storage_path);
    if (fs.existsSync(filePath)) {
      try { fs.unlinkSync(filePath); } catch (_) {}
    }

    db.run('DELETE FROM document_review_logs WHERE document_id = ?', [id]);
    db.run('DELETE FROM client_documents WHERE id = ?', [id]);

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      req.user!.id,
      'DOCUMENT_DELETED',
      `Document "${doc.name}" securely deleted from vault`,
      ip,
      parseDeviceInfo(userAgent)
    );
    saveDb();

    res.json({ message: 'Document has been removed from your vault.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete document.' });
  }
});

// 6. SECURITY ACTIVITY AND NOTIFICATIONS
router.get('/activity', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const events = queryAll(
      db,
      'SELECT id, event_type, description, ip_address, user_agent, created_at FROM security_events WHERE user_id = ? ORDER BY created_at DESC LIMIT 50',
      [req.user!.id]
    );

    res.json({
      events: events.map((e) => ({
        ...e,
        displayIp: maskIp(e.ip_address),
      })),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load security activity.' });
  }
});

// Report suspicious activity
router.post('/report-suspicious', requireAuth, secLimiter, async (req: AuthRequest, res: Response) => {
  try {
    const { eventId, details } = req.body;
    const userId = req.user!.id;
    const user = req.user!;

    const db = await getDb();
    const now = new Date().toISOString();
    const ticketId = 'tkt_' + Math.random().toString(36).substring(2, 11);
    const refNum = `GF-SEC-${Math.floor(10000 + Math.random() * 90000)}`;

    const eventRecord = eventId
      ? queryOne(db, 'SELECT event_type, description, created_at FROM security_events WHERE id = ? AND user_id = ?', [eventId, userId])
      : null;

    const eventDetails = eventRecord
      ? `Reported Event: [${eventRecord.event_type}] ${eventRecord.description} (${eventRecord.created_at})\n`
      : '';
    const fullMessage = `${eventDetails}Client Alert Details:\n${details || 'Client flagged unrecognized account activity.'}\n\nPlease audit active sessions and verify identity immediately.`;

    // Create high-priority security ticket
    db.run(
      `INSERT INTO support_tickets (id, reference, user_id, subject, category, priority, status, created_at, updated_at, last_activity_at)
       VALUES (?, ?, ?, 'URGENT: Suspicious Account Activity Report', 'ACCOUNT_VERIFICATION', 'URGENT', 'OPEN', ?, ?, ?)`,
      [ticketId, refNum, userId, now, now, now]
    );

    // Initial message
    const msgId = 'tmsg_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO ticket_messages (id, ticket_id, sender_id, sender_role, sender_name, message, is_internal_note, created_at)
       VALUES (?, ?, ?, 'CLIENT', ?, ?, 0, ?)`,
      [msgId, ticketId, userId, `${user.first_name} ${user.last_name}`, fullMessage, now]
    );

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      userId,
      'SUSPICIOUS_ACTIVITY_REPORTED',
      `Suspicious activity reported by client. Urgent ticket ${refNum} generated.`,
      ip,
      parseDeviceInfo(userAgent)
    );
    saveDb();

    // Send admin notification
    await sendEmailNotification(db, {
      to: 'globalfinancecryptomining@gmail.com',
      subject: `[URGENT SECURITY ALERT] Account Activity Flagged — ${refNum}`,
      htmlContent: `
        <div style="font-family: sans-serif; padding: 20px; color: #1e293b;">
          <h2 style="color: #b91c1c;">URGENT: Client Reported Suspicious Activity</h2>
          <p><strong>Customer:</strong> ${user.first_name} ${user.last_name} (${user.email})</p>
          <p><strong>Ticket Reference:</strong> ${refNum}</p>
          <p><strong>Details:</strong></p>
          <pre style="background: #f1f5f9; padding: 12px; border-radius: 6px;">${fullMessage}</pre>
        </div>
      `,
      adminLogDetails: `Suspicious activity flagged by ${user.email} (ref: ${refNum})`,
    });

    res.json({
      message: 'Security alert successfully recorded. Our operations desk has been dispatched and an urgent ticket has been created.',
      reference: refNum,
      ticketId,
    });
  } catch (err: any) {
    console.error('[REPORT SUSPICIOUS ERROR]', err);
    res.status(500).json({ error: 'Failed to report suspicious activity.' });
  }
});

// 7. ACTIVE SESSIONS
router.get('/sessions', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const sessions = queryAll(
      db,
      'SELECT id, device_info, ip_address, last_active_at, created_at, is_revoked FROM user_sessions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20',
      [req.user!.id]
    );

    res.json({
      sessions: sessions.map((s, idx) => ({
        id: s.id,
        deviceInfo: s.device_info,
        displayIp: maskIp(s.ip_address),
        lastActiveAt: s.last_active_at,
        createdAt: s.created_at,
        isRevoked: Boolean(s.is_revoked),
        isCurrent: idx === 0 && !s.is_revoked,
      })),
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve active sessions.' });
  }
});

// Revoke sessions
router.post('/sessions/revoke', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { sessionId, revokeAllOthers } = req.body;
    const userId = req.user!.id;
    const db = await getDb();
    const now = new Date().toISOString();

    if (revokeAllOthers) {
      // Find latest session for this user to preserve as current
      const latest = queryOne(
        db,
        'SELECT id FROM user_sessions WHERE user_id = ? AND is_revoked = 0 ORDER BY created_at DESC LIMIT 1',
        [userId]
      );
      if (latest) {
        db.run('UPDATE user_sessions SET is_revoked = 1 WHERE user_id = ? AND id != ?', [userId, latest.id]);
      } else {
        db.run('UPDATE user_sessions SET is_revoked = 1 WHERE user_id = ?', [userId]);
      }
      db.run('UPDATE users SET session_version = session_version + 1, updated_at = ? WHERE id = ?', [now, userId]);
    } else if (sessionId) {
      db.run('UPDATE user_sessions SET is_revoked = 1 WHERE user_id = ? AND id = ?', [userId, sessionId]);
    } else {
      res.status(400).json({ error: 'Session ID or revokeAllOthers flag required.' });
      return;
    }

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      userId,
      'SESSIONS_REVOKED',
      revokeAllOthers ? 'All other active sessions revoked' : `Specific session ${sessionId} revoked`,
      ip,
      parseDeviceInfo(userAgent)
    );
    saveDb();

    res.json({ message: 'Session(s) revoked successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to revoke session.' });
  }
});

export default router;
