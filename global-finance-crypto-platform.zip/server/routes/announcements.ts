import { Router, Response } from 'express';
import { getDb, queryOne, queryAll, saveDb } from '../db/database.js';
import { requireAuth, requireAdmin, AuthRequest } from '../middleware/auth.js';
import {
  resolveAudienceRecipients,
  maskEmail,
  generateAIMessage,
  publishAnnouncement,
  getAnnouncementAnalytics,
} from '../services/announcements.js';
import { AudienceCriteria, GlobalAnnouncement } from '../../src/types/index.js';

const router = Router();
router.use(requireAuth);
router.use(requireAdmin);

// 1. Overview & Analytics
router.get('/overview', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const analytics = getAnnouncementAnalytics(db);

    const announcements = queryAll(
      db,
      `SELECT * FROM global_announcements 
       ORDER BY CASE 
         WHEN status = 'SCHEDULED' THEN 1 
         WHEN status = 'DRAFT' THEN 2 
         WHEN status = 'PUBLISHED' THEN 3 
         ELSE 4 
       END, updated_at DESC
       LIMIT 50`
    );

    // Compute live read counts for published announcements
    for (const a of announcements) {
      if (a.status === 'PUBLISHED') {
        const stats = queryOne(
          db,
          `SELECT 
             COUNT(*) as delivered,
             SUM(CASE WHEN is_read = 1 THEN 1 ELSE 0 END) as read_count
           FROM customer_notifications
           WHERE announcement_id = ?`,
          [a.id]
        );
        if (stats) {
          a.delivered_count = Number(stats.delivered || 0);
          a.read_count = Number(stats.read_count || 0);
          a.read_rate = a.delivered_count > 0 ? Math.round((a.read_count / a.delivered_count) * 1000) / 10 : 0;
        }
      }
    }

    res.json({ analytics, announcements });
  } catch (err: any) {
    console.error('[ANNOUNCEMENTS OVERVIEW ERROR]', err);
    res.status(500).json({ error: 'Failed to load announcements overview.' });
  }
});

// 2. Client search for individual selection
router.get('/clients', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const q = ((req.query.q as string) || '').trim().toLowerCase();

    let query = `
      SELECT id, email, first_name, last_name, phone, kyc_status, created_at
      FROM users
      WHERE role = 'client' AND status = 'active'
    `;
    const params: any[] = [];

    if (q) {
      query += ` AND (LOWER(email) LIKE ? OR LOWER(first_name) LIKE ? OR LOWER(last_name) LIKE ?)`;
      params.push(`%${q}%`, `%${q}%`, `%${q}%`);
    }

    query += ' ORDER BY created_at DESC LIMIT 50';

    const clients = queryAll(db, query, params);
    res.json({ clients });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to search clients.' });
  }
});

// 3. Recipient Count & Safe Preview
router.post('/preview-recipients', async (req: AuthRequest, res: Response) => {
  try {
    const { criteria } = req.body;
    if (!criteria) {
      res.status(400).json({ error: 'Audience criteria required.' });
      return;
    }

    const db = await getDb();
    const recipients = resolveAudienceRecipients(db, criteria);

    // Create safe masked preview
    const previewList = recipients.slice(0, 15).map((r) => ({
      id: r.id,
      name: `${r.first_name || ''} ${r.last_name || ''}`.trim() || 'Client',
      maskedEmail: maskEmail(r.email),
      kycStatus: r.kyc_status || 'unverified',
    }));

    res.json({
      totalCount: recipients.length,
      sampleRecipients: previewList,
    });
  } catch (err: any) {
    console.error('[PREVIEW RECIPIENTS ERROR]', err);
    res.status(500).json({ error: 'Failed to preview recipients.' });
  }
});

// 4. AI Message Assistant
router.post('/ai-generate', async (req: AuthRequest, res: Response) => {
  try {
    const {
      title,
      category,
      priority,
      structuredDetails,
      audienceSummary,
      writingStyle,
      action,
      currentMessage,
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ error: 'Announcement title is required to generate a message.' });
      return;
    }

    const result = await generateAIMessage({
      title: title.trim(),
      category: category || 'GENERAL_ANNOUNCEMENT',
      priority: priority || 'INFORMATIONAL',
      structuredDetails,
      audienceSummary,
      writingStyle,
      action,
      currentMessage,
    });

    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }

    // Record audit event for AI generation
    const db = await getDb();
    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    const nowIso = new Date().toISOString();
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'ANNOUNCEMENT_AI_GENERATED', 'AI_ASSISTANT', ?, ?, '127.0.0.1', ?)`,
      [
        auditId,
        req.user!.email,
        title.slice(0, 50),
        `AI generated announcement draft for "${title}" (${writingStyle || 'professional_reassuring'})`,
        nowIso,
      ]
    );
    saveDb();

    res.json({ success: true, message: result.message });
  } catch (err: any) {
    console.error('[AI ASSISTANT ROUTE ERROR]', err);
    res.status(500).json({ error: 'AI generation service failed.' });
  }
});

// 5. Create Announcement (Draft, Scheduled, or Immediate Publish)
router.post('/', async (req: AuthRequest, res: Response) => {
  try {
    const {
      title,
      category,
      priority,
      message,
      structuredDetails,
      audienceCriteria,
      status, // 'DRAFT', 'SCHEDULED', 'PUBLISHED'
      scheduledFor,
      recurrencePattern,
      recurrenceEndDate,
      actionLink,
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ error: 'Announcement title is required.' });
      return;
    }
    if (!message || !message.trim()) {
      res.status(400).json({ error: 'Announcement message body is required.' });
      return;
    }

    const db = await getDb();
    const id = 'ann_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 6);
    const nowIso = new Date().toISOString();
    const adminEmail = req.user!.email;

    const initialStatus = status === 'SCHEDULED' ? 'SCHEDULED' : status === 'PUBLISHED' ? 'PUBLISHED' : 'DRAFT';

    db.run(
      `INSERT INTO global_announcements (
        id, title, category, priority, status, message, structured_details_json,
        audience_filter_json, recipient_count, delivered_count, read_count,
        scheduled_for, recurrence_pattern, recurrence_end_date, created_by_admin, action_link,
        created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        title.trim(),
        category || 'GENERAL_ANNOUNCEMENT',
        priority || 'INFORMATIONAL',
        initialStatus === 'PUBLISHED' ? 'DRAFT' : initialStatus, // will publish below if PUBLISHED requested
        message.trim(),
        structuredDetails ? JSON.stringify(structuredDetails) : null,
        audienceCriteria ? JSON.stringify(audienceCriteria) : JSON.stringify({ general: 'ALL_CLIENTS' }),
        scheduledFor || null,
        recurrencePattern || 'NONE',
        recurrenceEndDate || null,
        adminEmail,
        actionLink || null,
        nowIso,
        nowIso,
      ]
    );

    // Initial revision record
    db.run(
      `INSERT INTO announcement_revisions (
        id, announcement_id, revision_number, title, message, priority, category, audience_summary,
        changed_by_admin, change_reason, created_at
      ) VALUES (?, ?, 1, ?, ?, ?, ?, ?, ?, 'Initial Creation', ?)`,
      [
        'rev_' + Math.random().toString(36).substring(2, 11),
        id,
        title.trim(),
        message.trim(),
        priority || 'INFORMATIONAL',
        category || 'GENERAL_ANNOUNCEMENT',
        audienceCriteria?.general || 'ALL_CLIENTS',
        adminEmail,
        nowIso,
      ]
    );

    // Audit log
    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'ANNOUNCEMENT_CREATED', 'GLOBAL_ANNOUNCEMENT', ?, ?, '127.0.0.1', ?)`,
      [
        auditId,
        adminEmail,
        id,
        `Created announcement "${title.trim()}" (Status: ${initialStatus})`,
        nowIso,
      ]
    );

    saveDb();

    // If immediate publication requested
    if (status === 'PUBLISHED') {
      const pubRes = publishAnnouncement(db, id, adminEmail);
      if (!pubRes.success) {
        res.status(500).json({ error: pubRes.error });
        return;
      }
      res.json({
        success: true,
        announcementId: id,
        recipientCount: pubRes.recipientCount,
        message: `Announcement published successfully to ${pubRes.recipientCount} clients.`,
      });
      return;
    }

    res.json({
      success: true,
      announcementId: id,
      message:
        initialStatus === 'SCHEDULED'
          ? `Announcement scheduled successfully for ${scheduledFor}.`
          : 'Announcement draft saved successfully.',
    });
  } catch (err: any) {
    console.error('[CREATE ANNOUNCEMENT ERROR]', err);
    res.status(500).json({ error: 'Failed to create announcement.' });
  }
});

// 6. Get Single Announcement with Revision History and Delivery Detail
router.get('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    const announcement = queryOne(db, 'SELECT * FROM global_announcements WHERE id = ?', [id]);
    if (!announcement) {
      res.status(404).json({ error: 'Announcement not found.' });
      return;
    }

    const revisions = queryAll(
      db,
      'SELECT * FROM announcement_revisions WHERE announcement_id = ? ORDER BY revision_number DESC',
      [id]
    );

    // Client delivery details
    const deliveries = queryAll(
      db,
      `SELECT n.id, n.user_id, n.is_read, n.created_at, u.email, u.first_name, u.last_name
       FROM customer_notifications n
       JOIN users u ON n.user_id = u.id
       WHERE n.announcement_id = ?
       ORDER BY n.created_at DESC
       LIMIT 100`,
      [id]
    );

    const safeDeliveries = deliveries.map((d) => ({
      id: d.id,
      name: `${d.first_name || ''} ${d.last_name || ''}`.trim() || 'Client',
      maskedEmail: maskEmail(d.email),
      isRead: d.is_read === 1,
      deliveredAt: d.created_at,
    }));

    res.json({
      announcement,
      revisions,
      deliveries: safeDeliveries,
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to load announcement details.' });
  }
});

// 7. Update Announcement
router.put('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const {
      title,
      category,
      priority,
      message,
      structuredDetails,
      audienceCriteria,
      status,
      scheduledFor,
      recurrencePattern,
      recurrenceEndDate,
      actionLink,
      changeReason,
    } = req.body;

    const db = await getDb();
    const existing = queryOne(db, 'SELECT * FROM global_announcements WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Announcement not found.' });
      return;
    }

    const nowIso = new Date().toISOString();
    const adminEmail = req.user!.email;

    db.run(
      `UPDATE global_announcements SET
        title = COALESCE(?, title),
        category = COALESCE(?, category),
        priority = COALESCE(?, priority),
        message = COALESCE(?, message),
        structured_details_json = COALESCE(?, structured_details_json),
        audience_filter_json = COALESCE(?, audience_filter_json),
        status = COALESCE(?, status),
        scheduled_for = ?,
        recurrence_pattern = COALESCE(?, recurrence_pattern),
        recurrence_end_date = ?,
        action_link = ?,
        updated_at = ?
       WHERE id = ?`,
      [
        title ? title.trim() : null,
        category,
        priority,
        message ? message.trim() : null,
        structuredDetails ? JSON.stringify(structuredDetails) : null,
        audienceCriteria ? JSON.stringify(audienceCriteria) : null,
        status,
        scheduledFor || null,
        recurrencePattern,
        recurrenceEndDate || null,
        actionLink || null,
        nowIso,
        id,
      ]
    );

    // Increment revision
    const lastRev = queryOne(
      db,
      'SELECT MAX(revision_number) as max_rev FROM announcement_revisions WHERE announcement_id = ?',
      [id]
    );
    const nextRevNum = (lastRev?.max_rev || 1) + 1;

    db.run(
      `INSERT INTO announcement_revisions (
        id, announcement_id, revision_number, title, message, priority, category, audience_summary,
        changed_by_admin, change_reason, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        'rev_' + Math.random().toString(36).substring(2, 11),
        id,
        nextRevNum,
        title || existing.title,
        message || existing.message,
        priority || existing.priority,
        category || existing.category,
        audienceCriteria?.general || 'UPDATED',
        adminEmail,
        changeReason || 'Administrator content update',
        nowIso,
      ]
    );

    // Audit log
    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'ANNOUNCEMENT_UPDATED', 'GLOBAL_ANNOUNCEMENT', ?, ?, '127.0.0.1', ?)`,
      [
        auditId,
        adminEmail,
        id,
        `Updated announcement "${title || existing.title}" (Rev ${nextRevNum})`,
        nowIso,
      ]
    );

    saveDb();
    res.json({ success: true, message: 'Announcement updated successfully.' });
  } catch (err: any) {
    console.error('[UPDATE ANNOUNCEMENT ERROR]', err);
    res.status(500).json({ error: 'Failed to update announcement.' });
  }
});

// 8. Publish Announcement Immediately
router.post('/:id/publish', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const adminEmail = req.user!.email;

    const result = publishAnnouncement(db, id, adminEmail);
    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }

    res.json({
      success: true,
      recipientCount: result.recipientCount,
      message: `Announcement successfully published to ${result.recipientCount} clients.`,
    });
  } catch (err: any) {
    console.error('[PUBLISH ANNOUNCEMENT ERROR]', err);
    res.status(500).json({ error: 'Failed to publish announcement.' });
  }
});

// 9. Cancel Scheduled Announcement
router.post('/:id/cancel', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const nowIso = new Date().toISOString();
    const adminEmail = req.user!.email;

    db.run(
      `UPDATE global_announcements SET status = 'CANCELLED', updated_at = ? WHERE id = ?`,
      [nowIso, id]
    );

    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'ANNOUNCEMENT_CANCELLED', 'GLOBAL_ANNOUNCEMENT', ?, 'Cancelled scheduled announcement', '127.0.0.1', ?)`,
      [auditId, adminEmail, id, nowIso]
    );

    saveDb();
    res.json({ success: true, message: 'Scheduled announcement has been cancelled.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to cancel announcement.' });
  }
});

// 10. Archive Announcement
router.post('/:id/archive', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const nowIso = new Date().toISOString();
    const adminEmail = req.user!.email;

    db.run(
      `UPDATE global_announcements SET status = 'ARCHIVED', updated_at = ? WHERE id = ?`,
      [nowIso, id]
    );

    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'ANNOUNCEMENT_ARCHIVED', 'GLOBAL_ANNOUNCEMENT', ?, 'Archived announcement', '127.0.0.1', ?)`,
      [auditId, adminEmail, id, nowIso]
    );

    saveDb();
    res.json({ success: true, message: 'Announcement archived successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to archive announcement.' });
  }
});

// 11. Delete Draft Announcement
router.delete('/:id', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    const existing = queryOne(db, 'SELECT status, title FROM global_announcements WHERE id = ?', [id]);
    if (!existing) {
      res.status(404).json({ error: 'Announcement not found.' });
      return;
    }
    if (existing.status === 'PUBLISHED') {
      res.status(400).json({ error: 'Published announcements cannot be deleted. Please archive them instead.' });
      return;
    }

    db.run('DELETE FROM announcement_revisions WHERE announcement_id = ?', [id]);
    db.run('DELETE FROM global_announcements WHERE id = ?', [id]);

    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    const nowIso = new Date().toISOString();
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'ANNOUNCEMENT_DRAFT_DELETED', 'GLOBAL_ANNOUNCEMENT', ?, ?, '127.0.0.1', ?)`,
      [auditId, req.user!.email, id, `Deleted announcement draft "${existing.title}"`, nowIso]
    );

    saveDb();
    res.json({ success: true, message: 'Draft deleted successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete draft.' });
  }
});

export default router;
