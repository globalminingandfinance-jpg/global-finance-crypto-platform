import { Router, Response } from 'express';
import { getDb, queryOne, queryAll, saveDb } from '../db/database.js';
import { requireAuth, AuthRequest } from '../middleware/auth.js';
import { getUserFinancialSummary } from '../services/ledger.js';
import { sendEmailNotification } from '../services/email.js';

const router = Router();

// Customer Overview & Stats
router.get('/overview', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();

    // Financial ledger calculations
    const summary = getUserFinancialSummary(db, userId);

    // Active investment allocations
    const activeInvestments = queryAll(
      db,
      `SELECT a.id, a.amount_requested, a.amount_allocated, a.status, a.created_at,
              p.name as product_name, p.slug as product_slug, p.description as product_description
       FROM investment_allocations a
       JOIN investment_products p ON a.product_id = p.id
       WHERE a.user_id = ?
       ORDER BY a.created_at DESC`,
      [userId]
    );

    // Recent transactions
    const recentTransactions = queryAll(
      db,
      `SELECT t.id, t.reference, t.amount, t.currency, t.fee, t.payment_method, t.payment_provider, t.status, t.created_at,
              p.name as product_name
       FROM transactions t
       JOIN investment_products p ON t.product_id = p.id
       WHERE t.user_id = ?
       ORDER BY t.created_at DESC
       LIMIT 10`,
      [userId]
    );

    // Pending payments
    const pendingPayments = queryAll(
      db,
      `SELECT t.id, t.reference, t.amount, t.currency, t.payment_method, t.created_at, p.name as product_name
       FROM transactions t
       JOIN investment_products p ON t.product_id = p.id
       WHERE t.user_id = ? AND t.status = 'PENDING'
       ORDER BY t.created_at DESC`,
      [userId]
    );

    res.json({
      profile: {
        id: req.user!.id,
        email: req.user!.email,
        firstName: req.user!.first_name,
        lastName: req.user!.last_name,
        role: req.user!.role,
      },
      financialSummary: summary,
      activeInvestments,
      recentTransactions,
      pendingPayments,
    });
  } catch (err) {
    console.error('[CUSTOMER OVERVIEW ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve dashboard overview.' });
  }
});

// My Investments
router.get('/investments', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();

    const investments = queryAll(
      db,
      `SELECT a.id, a.amount_requested, a.amount_allocated, a.status, a.terms, a.created_at,
              p.name as product_name, p.slug as product_slug, p.description as product_description,
              t.reference as transaction_reference, t.payment_method
       FROM investment_allocations a
       JOIN investment_products p ON a.product_id = p.id
       JOIN transactions t ON a.transaction_id = t.id
       WHERE a.user_id = ?
       ORDER BY a.created_at DESC`,
      [userId]
    );

    res.json({ investments });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve investment records.' });
  }
});

// Transactions
router.get('/transactions', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();

    const transactions = queryAll(
      db,
      `SELECT t.id, t.reference, t.amount, t.currency, t.fee, t.payment_method, t.payment_provider, t.status, t.notes, t.created_at,
              p.name as product_name
       FROM transactions t
       JOIN investment_products p ON t.product_id = p.id
       WHERE t.user_id = ?
       ORDER BY t.created_at DESC`,
      [userId]
    );

    res.json({ transactions });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve transactions.' });
  }
});

// Withdrawal Request Creation
router.post('/withdrawals', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { amount, bankName, accountNumber, accountHolder, branchCode } = req.body;

    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) {
      res.status(400).json({ error: 'Please enter a valid withdrawal amount.' });
      return;
    }

    if (!bankName || !accountNumber || !accountHolder || !branchCode) {
      res.status(400).json({ error: 'All banking details (Bank, Account Number, Account Holder, Branch Code) are required.' });
      return;
    }

    const db = await getDb();
    const summary = getUserFinancialSummary(db, userId);

    if (numericAmount > summary.availableBalance) {
      res.status(400).json({
        error: `Insufficient available balance. Your current available balance is R${summary.availableBalance}. Allocated investment capital cannot be withdrawn directly without formal redemption review.`,
      });
      return;
    }

    const withdrawalId = 'wd_' + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();

    db.run(
      `INSERT INTO withdrawals (id, user_id, amount, currency, fee, bank_name, account_number, account_holder, branch_code, status, created_at, updated_at)
       VALUES (?, ?, ?, 'ZAR', 0, ?, ?, ?, ?, 'PENDING_REVIEW', ?, ?)`,
      [
        withdrawalId,
        userId,
        numericAmount,
        String(bankName).trim(),
        String(accountNumber).trim(),
        String(accountHolder).trim(),
        String(branchCode).trim(),
        now,
        now,
      ]
    );

    saveDb();

    res.status(201).json({
      message: 'Withdrawal request submitted successfully. It will undergo administrative review and reconciliation.',
      withdrawalId,
    });
  } catch (err) {
    console.error('[WITHDRAWAL SUBMISSION ERROR]', err);
    res.status(500).json({ error: 'Failed to submit withdrawal request.' });
  }
});

// Customer Withdrawals List
router.get('/withdrawals', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();

    const withdrawals = queryAll(
      db,
      `SELECT id, amount, currency, fee, bank_name, account_number, account_holder, branch_code, status, review_notes, created_at
       FROM withdrawals
       WHERE user_id = ?
       ORDER BY created_at DESC`,
      [userId]
    );

    res.json({ withdrawals });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load withdrawal history.' });
  }
});

// Support message submission (legacy/contact form)
router.post('/support', async (req: AuthRequest, res: Response) => {
  try {
    const { name, email, subject, message } = req.body;
    if (!name || !email || !subject || !message) {
      res.status(400).json({ error: 'All fields are required.' });
      return;
    }

    const db = await getDb();
    const msgId = 'msg_' + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();
    const userId = req.user?.id || null;

    db.run(
      `INSERT INTO support_messages (id, user_id, name, email, subject, message, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'UNREAD', ?)`,
      [msgId, userId, String(name).trim(), String(email).trim(), String(subject).trim(), String(message).trim(), now]
    );

    saveDb();
    res.json({ message: 'Support message received. Our compliance team will respond promptly.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to send support message.' });
  }
});

// Helper to generate unique ticket reference (e.g. GF-2026-00042)
function generateTicketReference(db: any): string {
  const year = new Date().getFullYear();
  const pattern = `GF-${year}-%`;
  const countRow = queryOne(db, 'SELECT COUNT(*) as c FROM support_tickets WHERE reference LIKE ?', [pattern]);
  let seq = ((countRow?.c || 0) + 1).toString().padStart(5, '0');
  let ref = `GF-${year}-${seq}`;

  // Collision safety check
  let exists = queryOne(db, 'SELECT id FROM support_tickets WHERE reference = ?', [ref]);
  let attempts = 0;
  while (exists && attempts < 10) {
    attempts++;
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    ref = `GF-${year}-${randomSuffix}`;
    exists = queryOne(db, 'SELECT id FROM support_tickets WHERE reference = ?', [ref]);
  }
  return ref;
}

const ALLOWED_TICKET_CATEGORIES = [
  'general_support',
  'complaints',
  'deposits',
  'withdrawals',
  'account_verification',
  'technical_problems',
  'other_enquiries',
];

// ==============================================================================
// CUSTOMER SUPPORT TICKETS & COMPLAINTS
// ==============================================================================

// Create New Ticket
router.post('/tickets', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const userEmail = req.user!.email;
    const userName = `${req.user!.first_name} ${req.user!.last_name}`.trim();
    const { subject, category, description, attachmentName, attachmentData } = req.body;

    // Validation
    if (!subject || typeof subject !== 'string' || subject.trim().length < 3) {
      res.status(400).json({ error: 'Subject must be at least 3 characters long.' });
      return;
    }
    if (!category || !ALLOWED_TICKET_CATEGORIES.includes(category)) {
      res.status(400).json({ error: 'Please select a valid ticket category.' });
      return;
    }
    if (!description || typeof description !== 'string' || description.trim().length < 5) {
      res.status(400).json({ error: 'Description must be at least 5 characters long.' });
      return;
    }

    const db = await getDb();
    const ticketId = 'tkt_' + Math.random().toString(36).substring(2, 11);
    const reference = generateTicketReference(db);
    const now = new Date().toISOString();

    // 1. Insert Support Ticket
    db.run(
      `INSERT INTO support_tickets (id, reference, user_id, subject, category, priority, status, created_at, updated_at, last_activity_at)
       VALUES (?, ?, ?, ?, ?, 'NORMAL', 'OPEN', ?, ?, ?)`,
      [ticketId, reference, userId, subject.trim(), category, now, now, now]
    );

    // 2. Insert First Message (Customer's initial description)
    const messageId = 'tmsg_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO ticket_messages (id, ticket_id, sender_id, sender_role, sender_name, message, is_internal_note, attachment_name, attachment_data, created_at)
       VALUES (?, ?, ?, 'client', ?, ?, 0, ?, ?, ?)`,
      [
        messageId,
        ticketId,
        userId,
        userName,
        description.trim(),
        attachmentName ? String(attachmentName).trim() : null,
        attachmentData ? String(attachmentData) : null,
        now,
      ]
    );

    // 3. Create In-App Notification for Customer
    const notifId = 'notif_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO customer_notifications (id, user_id, ticket_id, title, message, type, is_read, created_at)
       VALUES (?, ?, ?, ?, ?, 'TICKET_CREATED', 0, ?)`,
      [
        notifId,
        userId,
        ticketId,
        `Ticket Submitted: ${reference}`,
        `Your enquiry regarding "${subject.trim()}" has been registered. Reference: ${reference}.`,
        now,
      ]
    );

    // 4. Record in Audit Logs
    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'TICKET_CREATED', 'TICKET', ?, ?, ?, ?)`,
      [
        auditId,
        userId,
        userEmail,
        ticketId,
        JSON.stringify({ reference, category, subject: subject.trim() }),
        req.ip || '127.0.0.1',
        now,
      ]
    );

    saveDb();

    // 5. Send Email Confirmation to Customer
    sendEmailNotification(db, {
      to: userEmail,
      subject: `[${reference}] Support Ticket Received: ${subject.trim()}`,
      htmlContent: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #1e293b;">
          <h2 style="color: #d97706; margin-bottom: 8px;">Global Finance Crypto Mining Support</h2>
          <p>Dear ${userName},</p>
          <p>Thank you for reaching out to customer support. Your enquiry has been received and assigned reference number: <strong>${reference}</strong>.</p>
          <div style="background: #f8fafc; border-left: 4px solid #d97706; padding: 12px 16px; margin: 16px 0;">
            <p style="margin: 0 0 6px 0;"><strong>Category:</strong> ${category.replace('_', ' ').toUpperCase()}</p>
            <p style="margin: 0 0 6px 0;"><strong>Subject:</strong> ${subject.trim()}</p>
            <p style="margin: 0;"><strong>Reference:</strong> ${reference}</p>
          </div>
          <p>Our support and compliance team will review your message promptly. You can track this ticket and view responses directly in your Client Portal.</p>
          <p style="margin-top: 24px; font-size: 12px; color: #64748b;">Global Finance Crypto Mining • Authorized Digital Mining Platform</p>
        </div>
      `,
      adminLogDetails: `Confirmation email sent for ticket ${reference}`,
    }).catch((err) => console.error('[EMAIL TICKET CREATION ERROR]', err));

    res.status(201).json({
      success: true,
      message: 'Support ticket successfully created.',
      ticket: {
        id: ticketId,
        reference,
        subject: subject.trim(),
        category,
        priority: 'NORMAL',
        status: 'OPEN',
        createdAt: now,
      },
    });
  } catch (err) {
    console.error('[TICKET CREATION ERROR]', err);
    res.status(500).json({ error: 'Failed to create support ticket. Please try again.' });
  }
});

// List Customer's Own Tickets
router.get('/tickets', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();

    const tickets = queryAll(
      db,
      `SELECT t.id, t.reference, t.subject, t.category, t.priority, t.status, t.created_at, t.updated_at, t.last_activity_at,
              (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = t.id AND is_internal_note = 0) as message_count,
              (SELECT sender_role FROM ticket_messages WHERE ticket_id = t.id AND is_internal_note = 0 ORDER BY created_at DESC LIMIT 1) as last_sender_role
       FROM support_tickets t
       WHERE t.user_id = ?
       ORDER BY t.last_activity_at DESC`,
      [userId]
    );

    res.json({ tickets });
  } catch (err) {
    console.error('[FETCH TICKETS ERROR]', err);
    res.status(500).json({ error: 'Failed to load tickets.' });
  }
});

// Get Specific Ticket Conversation (Excluding internal notes!)
router.get('/tickets/:id', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const ticketId = req.params.id;
    const db = await getDb();

    // Enforce ownership: customer can ONLY view their own ticket
    const ticket = queryOne(
      db,
      `SELECT id, reference, user_id, subject, category, priority, status, created_at, updated_at, last_activity_at
       FROM support_tickets
       WHERE id = ? AND user_id = ?`,
      [ticketId, userId]
    );

    if (!ticket) {
      res.status(404).json({ error: 'Support ticket not found or access denied.' });
      return;
    }

    // Messages: STRICTLY filter out internal notes (`is_internal_note = 0`)
    const messages = queryAll(
      db,
      `SELECT id, sender_id, sender_role, sender_name, message, attachment_name, attachment_data, created_at
       FROM ticket_messages
       WHERE ticket_id = ? AND is_internal_note = 0
       ORDER BY created_at ASC`,
      [ticketId]
    );

    res.json({ ticket, messages });
  } catch (err) {
    console.error('[GET TICKET DETAILS ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve ticket conversation.' });
  }
});

// Customer Send Follow-Up Message on Own Ticket
router.post('/tickets/:id/messages', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const userName = `${req.user!.first_name} ${req.user!.last_name}`.trim();
    const ticketId = req.params.id;
    const { message, attachmentName, attachmentData } = req.body;

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      res.status(400).json({ error: 'Message cannot be empty.' });
      return;
    }

    const db = await getDb();

    // Verify ownership
    const ticket = queryOne(
      db,
      'SELECT id, reference, subject, status FROM support_tickets WHERE id = ? AND user_id = ?',
      [ticketId, userId]
    );

    if (!ticket) {
      res.status(404).json({ error: 'Ticket not found or access denied.' });
      return;
    }

    const messageId = 'tmsg_' + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();

    // Insert customer reply
    db.run(
      `INSERT INTO ticket_messages (id, ticket_id, sender_id, sender_role, sender_name, message, is_internal_note, attachment_name, attachment_data, created_at)
       VALUES (?, ?, ?, 'client', ?, ?, 0, ?, ?, ?)`,
      [
        messageId,
        ticketId,
        userId,
        userName,
        message.trim(),
        attachmentName ? String(attachmentName).trim() : null,
        attachmentData ? String(attachmentData) : null,
        now,
      ]
    );

    // If ticket was resolved or awaiting customer, reopen to IN_PROGRESS
    let newStatus = ticket.status;
    if (ticket.status === 'AWAITING_CUSTOMER' || ticket.status === 'RESOLVED' || ticket.status === 'CLOSED') {
      newStatus = 'IN_PROGRESS';
    }

    db.run(
      `UPDATE support_tickets SET status = ?, last_activity_at = ?, updated_at = ? WHERE id = ?`,
      [newStatus, now, now, ticketId]
    );

    saveDb();

    res.json({
      success: true,
      message: {
        id: messageId,
        sender_id: userId,
        sender_role: 'client',
        sender_name: userName,
        message: message.trim(),
        attachment_name: attachmentName ? String(attachmentName).trim() : null,
        attachment_data: attachmentData ? String(attachmentData) : null,
        created_at: now,
      },
      updatedStatus: newStatus,
    });
  } catch (err) {
    console.error('[TICKET REPLY ERROR]', err);
    res.status(500).json({ error: 'Failed to post reply.' });
  }
});

// ==============================================================================
// CUSTOMER NOTIFICATIONS CENTRE
// ==============================================================================

// Get customer notifications & unread count
router.get('/notifications', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();

    const notifications = queryAll(
      db,
      `SELECT n.id, n.ticket_id, n.title, n.message, n.type, n.is_read, n.created_at,
              n.promo_run_id, n.promo_category, n.promo_expiry, n.promo_data,
              n.announcement_id, n.priority, n.action_link,
              t.reference as ticket_reference,
              c.id as promo_claim_id, c.status as promo_claim_status
       FROM customer_notifications n
       LEFT JOIN support_tickets t ON n.ticket_id = t.id
       LEFT JOIN promotional_reward_claims c ON n.promo_run_id = c.run_id AND c.user_id = n.user_id
       WHERE n.user_id = ?
       ORDER BY n.created_at DESC
       LIMIT 50`,
      [userId]
    );

    const unreadRow = queryOne(
      db,
      'SELECT COUNT(*) as c FROM customer_notifications WHERE user_id = ? AND is_read = 0',
      [userId]
    );
    const unreadCount = unreadRow?.c || 0;

    res.json({ notifications, unreadCount });
  } catch (err) {
    console.error('[FETCH NOTIFICATIONS ERROR]', err);
    res.status(500).json({ error: 'Failed to load notifications.' });
  }
});

// Mark single notification as read
router.patch('/notifications/:id/read', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const notifId = req.params.id;
    const db = await getDb();

    db.run(
      'UPDATE customer_notifications SET is_read = 1 WHERE id = ? AND user_id = ?',
      [notifId, userId]
    );
    saveDb();

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update notification.' });
  }
});

// Mark all notifications as read
router.post('/notifications/mark-all-read', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();

    db.run('UPDATE customer_notifications SET is_read = 1 WHERE user_id = ?', [userId]);
    saveDb();

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to mark notifications as read.' });
  }
});

// Dismiss / Delete single notification
router.delete('/notifications/:id', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const notifId = req.params.id;
    const db = await getDb();

    db.run('DELETE FROM customer_notifications WHERE id = ? AND user_id = ?', [notifId, userId]);
    saveDb();

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete notification.' });
  }
});

// GET /api/customer/financial-overview — Comprehensive Personal Financial Overview
router.get('/financial-overview', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();

    // 1. Authoritative double-entry ledger balances
    const summary = getUserFinancialSummary(db, userId);

    // 2. Active investments
    const activeAllocations = queryAll(
      db,
      `SELECT a.*, p.name as product_name
       FROM investment_allocations a
       JOIN investment_products p ON a.product_id = p.id
       WHERE a.user_id = ? AND a.status IN ('ACTIVE', 'MATURED')
       ORDER BY a.created_at DESC`,
      [userId]
    );

    // 3. Customer verified crypto holdings
    const holdings = queryAll(
      db,
      `SELECT * FROM customer_crypto_holdings WHERE user_id = ? ORDER BY symbol ASC`,
      [userId]
    );

    // 4. Current market prices from crypto service
    let marketPrices: Record<string, { priceZar: number; priceUsd: number }> = {
      BTC: { priceZar: 1205420, priceUsd: 68450 },
      ETH: { priceZar: 46680, priceUsd: 2652 },
      SOL: { priceZar: 2715, priceUsd: 154.2 },
    };

    try {
      const { getMarketOverview } = await import('../services/cryptoMarket.js');
      const market = await getMarketOverview();
      for (const c of market.coins) {
        marketPrices[c.symbol.toUpperCase()] = { priceZar: c.priceZar, priceUsd: c.priceUsd };
      }
    } catch (_) {}

    // 5. Value crypto holdings
    let totalCryptoValuationZar = 0;
    const valuedHoldings = holdings.map((h) => {
      const p = marketPrices[h.symbol.toUpperCase()] || { priceZar: 0, priceUsd: 0 };
      const valZar = Math.round(Number(h.quantity) * p.priceZar * 100) / 100;
      const valUsd = Math.round(Number(h.quantity) * p.priceUsd * 100) / 100;
      totalCryptoValuationZar += valZar;
      return {
        id: h.id,
        symbol: h.symbol,
        network: h.network,
        quantity: h.quantity,
        custodyType: h.custody_type,
        currentPriceZar: p.priceZar,
        currentPriceUsd: p.priceUsd,
        valuationZar: valZar,
        valuationUsd: valUsd,
        lastVerifiedAt: h.last_verified_at,
      };
    });

    // 6. Total combined portfolio valuation
    // Portfolio = Available Cash + Active Capital + Crypto Holdings
    const availableCash = summary.availableBalance || 0;
    const allocatedCapital = summary.allocatedCapital || 0;
    const totalPortfolioValuationZar = Math.round((availableCash + allocatedCapital + totalCryptoValuationZar) * 100) / 100;

    // 7. Statement ledger entries (Recent 25)
    const ledgerEntries = queryAll(
      db,
      `SELECT id, transaction_id, entry_type, debit, credit, balance_after, description, created_at
       FROM financial_ledger
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT 25`,
      [userId]
    );

    res.json({
      currency: 'ZAR',
      summary: {
        confirmedDeposits: summary.confirmedDeposits,
        allocatedCapital: summary.allocatedCapital,
        availableCash: summary.availableBalance,
        pendingDeposits: summary.pendingDeposits,
        pendingWithdrawals: summary.pendingWithdrawals,
        activeInvestmentsCount: summary.activeInvestmentsCount,
      },
      cryptoHoldings: valuedHoldings,
      totalCryptoValuationZar,
      totalPortfolioValuationZar,
      assetAllocation: {
        cashPercent: totalPortfolioValuationZar > 0 ? Math.round((availableCash / totalPortfolioValuationZar) * 1000) / 10 : 0,
        computingPercent: totalPortfolioValuationZar > 0 ? Math.round((allocatedCapital / totalPortfolioValuationZar) * 1000) / 10 : 0,
        cryptoPercent: totalPortfolioValuationZar > 0 ? Math.round((totalCryptoValuationZar / totalPortfolioValuationZar) * 1000) / 10 : 0,
      },
      recentLedgerActivity: ledgerEntries,
      asOf: new Date().toISOString(),
      disclosures: [
        'Internal account cash balances are verified on the immutable financial ledger and distinguished from custodial crypto assets.',
        'Cryptocurrency valuations are calculated using current market spot prices from our connected market intelligence feed.',
        'Allocated computational capital reflects active hardware mining contracts subject to platform terms.',
      ],
    });
  } catch (err: any) {
    console.error('[FINANCIAL OVERVIEW ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve financial overview.' });
  }
});

// GET /api/customer/statement/download — Official CSV Account Statement
router.get('/statement/download', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();
    const user = req.user!;

    const entries = queryAll(
      db,
      `SELECT id, transaction_id, entry_type, debit, credit, balance_after, description, created_at
       FROM financial_ledger
       WHERE user_id = ?
       ORDER BY created_at ASC`,
      [userId]
    );

    const summary = getUserFinancialSummary(db, userId);
    const nowStr = new Date().toISOString().slice(0, 10);

    const lines = [
      `GLOBAL FINANCE CRYPTO MINING - OFFICIAL CLIENT FINANCIAL STATEMENT`,
      `Account Holder: ${user.first_name} ${user.last_name}`,
      `Email: ${user.email}`,
      `Statement Date: ${nowStr}`,
      `Currency: ZAR`,
      ``,
      `ACCOUNT FINANCIAL SUMMARY`,
      `Total Confirmed Deposits: R ${summary.confirmedDeposits.toFixed(2)}`,
      `Allocated Computational Capital: R ${summary.allocatedCapital.toFixed(2)}`,
      `Available Unallocated Cash: R ${summary.availableBalance.toFixed(2)}`,
      `Pending Deposits: R ${summary.pendingDeposits.toFixed(2)}`,
      `Pending Withdrawals: R ${summary.pendingWithdrawals.toFixed(2)}`,
      ``,
      `TRANSACTION LEDGER HISTORY`,
      `DATE,REFERENCE,ENTRY TYPE,DEBIT (ZAR),CREDIT (ZAR),BALANCE AFTER (ZAR),DESCRIPTION`,
      ...entries.map((e) => {
        const d = e.created_at.slice(0, 19).replace('T', ' ');
        return `"${d}","${e.id}","${e.entry_type}",${Number(e.debit).toFixed(2)},${Number(e.credit).toFixed(2)},${Number(e.balance_after).toFixed(2)},"${(e.description || '').replace(/"/g, '""')}"`;
      }),
    ];

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="GF_Statement_${user.last_name}_${nowStr}.csv"`);
    res.send(lines.join('\n'));
  } catch (err: any) {
    console.error('[STATEMENT DOWNLOAD ERROR]', err);
    res.status(500).json({ error: 'Failed to generate financial statement.' });
  }
});

export default router;
