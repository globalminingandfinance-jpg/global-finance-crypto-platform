import { Router, Response } from 'express';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import { getDb, queryOne, queryAll, saveDb, VAULT_DIR } from '../db/database.js';
import { requireAuth, requireAdmin, AuthRequest } from '../middleware/auth.js';
import { recordDepositAndAllocation } from '../services/ledger.js';
import { sendEmailNotification } from '../services/email.js';

const router = Router();

// Secure Initial Administrator Provisioning Endpoint
router.post('/provision', async (req: AuthRequest, res: Response) => {
  try {
    const { secret, password, email } = req.body;
    const requiredSecret = process.env.INITIAL_ADMIN_PROVISIONING_SECRET;

    if (!requiredSecret || !secret || secret !== requiredSecret) {
      res.status(403).json({ error: 'Invalid or missing provisioning authorization token.' });
      return;
    }

    const adminEmail = (email || process.env.INITIAL_ADMIN_EMAIL || 'globalfinancecryptomining@gmail.com').toLowerCase().trim();
    if (!password || password.length < 10) {
      res.status(400).json({ error: 'Admin password must be at least 10 characters long.' });
      return;
    }

    const db = await getDb();
    const existing = queryOne(db, 'SELECT id FROM users WHERE email = ?', [adminEmail]);
    const salt = bcrypt.genSaltSync(12);
    const hash = bcrypt.hashSync(password, salt);
    const now = new Date().toISOString();

    if (existing) {
      db.run(
        `UPDATE users SET password_hash = ?, role = 'admin', status = 'active', must_change_password = 1, updated_at = ? WHERE id = ?`,
        [hash, now, existing.id]
      );
    } else {
      const id = 'admin_' + Math.random().toString(36).substring(2, 11);
      db.run(
        `INSERT INTO users (id, email, password_hash, first_name, last_name, phone, country, role, status, must_change_password, kyc_status, created_at, updated_at)
         VALUES (?, ?, ?, 'Global', 'Administrator', '+27000000000', 'South Africa', 'admin', 'active', 1, 'verified', ?, ?)`,
        [id, adminEmail, hash, now, now]
      );
    }

    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'SYSTEM', ?, 'ADMIN_PROVISIONED_VIA_ENDPOINT', 'USER', ?, 'Administrator explicitly provisioned via authorized secret', ?, ?)`,
      ['audit_' + Math.random().toString(36).substring(2, 11), adminEmail, adminEmail, req.ip || '127.0.0.1', now]
    );

    saveDb();

    res.json({
      message: `Administrator account (${adminEmail}) successfully provisioned. You may now log in at /admin-login.`,
    });
  } catch (err) {
    console.error('[ADMIN PROVISION ERROR]', err);
    res.status(500).json({ error: 'Administrator provisioning failed.' });
  }
});

// All following routes require authentication & admin role
router.use(requireAuth);
router.use(requireAdmin);

// Overview Stats
router.get('/overview', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();

    // Customer counts
    const totalCustomers = queryOne(db, "SELECT COUNT(*) as c FROM users WHERE role = 'client'")?.c || 0;
    const activeCustomers = queryOne(db, "SELECT COUNT(*) as c FROM users WHERE role = 'client' AND status = 'active'")?.c || 0;
    const suspendedCustomers = queryOne(db, "SELECT COUNT(*) as c FROM users WHERE role = 'client' AND status = 'suspended'")?.c || 0;
    const verifiedCustomers = queryOne(db, "SELECT COUNT(*) as c FROM users WHERE role = 'client' AND kyc_status = 'verified'")?.c || 0;

    // Transaction stats
    const totalTx = queryOne(db, 'SELECT COUNT(*) as c FROM transactions')?.c || 0;
    const successTx = queryOne(db, "SELECT COUNT(*) as c FROM transactions WHERE status = 'SUCCESS'")?.c || 0;
    const pendingTx = queryOne(db, "SELECT COUNT(*) as c FROM transactions WHERE status = 'PENDING'")?.c || 0;
    const failedTx = queryOne(db, "SELECT COUNT(*) as c FROM transactions WHERE status IN ('FAILED', 'CANCELLED')")?.c || 0;

    // Volume & ledger totals
    const totalDeposits = queryOne(db, "SELECT COALESCE(SUM(credit), 0) as s FROM financial_ledger WHERE entry_type = 'DEPOSIT'")?.s || 0;
    const totalAllocations = queryOne(db, "SELECT COALESCE(SUM(debit), 0) as s FROM financial_ledger WHERE entry_type = 'ALLOCATION'")?.s || 0;

    // Withdrawals
    const pendingWithdrawalsCount = queryOne(db, "SELECT COUNT(*) as c FROM withdrawals WHERE status = 'PENDING_REVIEW'")?.c || 0;
    const pendingWithdrawalsAmount = queryOne(db, "SELECT COALESCE(SUM(amount), 0) as s FROM withdrawals WHERE status = 'PENDING_REVIEW'")?.s || 0;
    const completedWithdrawalsAmount = queryOne(db, "SELECT COALESCE(SUM(amount), 0) as s FROM withdrawals WHERE status = 'COMPLETED'")?.s || 0;

    res.json({
      customers: {
        total: totalCustomers,
        active: activeCustomers,
        suspended: suspendedCustomers,
        verified: verifiedCustomers,
      },
      transactions: {
        total: totalTx,
        success: successTx,
        pending: pendingTx,
        failed: failedTx,
      },
      financials: {
        totalConfirmedDeposits: totalDeposits,
        totalAllocatedInvestments: totalAllocations,
        pendingWithdrawalsCount,
        pendingWithdrawalsAmount,
        completedWithdrawalsAmount,
      },
    });
  } catch (err) {
    console.error('[ADMIN OVERVIEW ERROR]', err);
    res.status(500).json({ error: 'Failed to generate administrative overview.' });
  }
});

// Customer Management Directory
router.get('/customers', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const query = req.query.q ? String(req.query.q).toLowerCase().trim() : '';

    let sql = `
      SELECT u.id, u.email, u.first_name, u.last_name, u.phone, u.country, u.role, u.status, u.kyc_status, u.created_at,
             COALESCE((SELECT SUM(credit) FROM financial_ledger WHERE user_id = u.id AND entry_type = 'DEPOSIT'), 0) as total_deposited,
             COALESCE((SELECT SUM(debit) FROM financial_ledger WHERE user_id = u.id AND entry_type = 'ALLOCATION'), 0) as total_allocated
      FROM users u
      WHERE u.role = 'client'
    `;

    const params: any[] = [];
    if (query) {
      sql += ` AND (LOWER(u.email) LIKE ? OR LOWER(u.first_name) LIKE ? OR LOWER(u.last_name) LIKE ?)`;
      params.push(`%${query}%`, `%${query}%`, `%${query}%`);
    }

    sql += ` ORDER BY u.created_at DESC`;

    const customers = queryAll(db, sql, params);
    res.json({ customers });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve customers.' });
  }
});

// Update Customer Status (Suspend / Reactivate)
router.post('/customers/:id/status', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { status, reason } = req.body;

    if (!['active', 'suspended'].includes(status)) {
      res.status(400).json({ error: 'Invalid customer status.' });
      return;
    }

    if (!reason || reason.trim().length < 5) {
      res.status(400).json({ error: 'A clear administrative reason is required for status changes.' });
      return;
    }

    const db = await getDb();
    const target = queryOne(db, 'SELECT id, email, first_name, last_name FROM users WHERE id = ?', [id]);
    if (!target) {
      res.status(404).json({ error: 'Customer not found.' });
      return;
    }

    const now = new Date().toISOString();
    db.run('UPDATE users SET status = ?, updated_at = ? WHERE id = ?', [status, now, id]);

    // Record audit trail
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'CUSTOMER_STATUS_CHANGED', 'USER', ?, ?, ?, ?)`,
      [
        'audit_' + Math.random().toString(36).substring(2, 11),
        req.user!.id,
        req.user!.email,
        id,
        JSON.stringify({ newStatus: status, reason: reason.trim(), customerEmail: target.email }),
        req.ip || '127.0.0.1',
        now,
      ]
    );

    saveDb();
    res.json({ message: `Customer status updated to ${status}.` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update customer status.' });
  }
});

// Transactions Management Directory
router.get('/transactions', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const status = req.query.status ? String(req.query.status) : '';
    const q = req.query.q ? String(req.query.q).trim() : '';

    let sql = `
      SELECT t.id, t.reference, t.amount, t.currency, t.fee, t.payment_method, t.payment_provider, t.status, t.provider_reference, t.notes, t.created_at,
             p.name as product_name,
             u.email as customer_email, u.first_name, u.last_name
      FROM transactions t
      JOIN investment_products p ON t.product_id = p.id
      JOIN users u ON t.user_id = u.id
      WHERE 1=1
    `;

    const params: any[] = [];
    if (status) {
      sql += ' AND t.status = ?';
      params.push(status);
    }
    if (q) {
      sql += ' AND (t.reference LIKE ? OR u.email LIKE ?)';
      params.push(`%${q}%`, `%${q}%`);
    }

    sql += ' ORDER BY t.created_at DESC';

    const transactions = queryAll(db, sql, params);
    res.json({ transactions });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve transactions.' });
  }
});

// Bank Transfer Manual Reconciliation Workflow
router.post('/transactions/:id/reconcile-bank-transfer', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { bankReferenceNotes, receivedAmount } = req.body;

    const db = await getDb();
    const transaction = queryOne(
      db,
      `SELECT t.*, p.name as product_name, u.email as user_email, u.first_name, u.last_name
       FROM transactions t
       JOIN investment_products p ON t.product_id = p.id
       JOIN users u ON t.user_id = u.id
       WHERE t.id = ?`,
      [id]
    );

    if (!transaction) {
      res.status(404).json({ error: 'Transaction not found.' });
      return;
    }

    if (transaction.status === 'SUCCESS') {
      res.status(400).json({ error: 'This transaction has already been verified and reconciled.' });
      return;
    }

    const verifiedAmount = Number(receivedAmount || transaction.amount);
    if (verifiedAmount !== Number(transaction.amount)) {
      res.status(400).json({
        error: `Received amount (R${verifiedAmount}) does not match required transaction amount (R${transaction.amount}).`,
      });
      return;
    }

    const now = new Date().toISOString();
    const adminRef = `BANK_RECON_${req.user!.email}_${Date.now()}`;

    // Update transaction
    db.run(
      `UPDATE transactions SET status = 'SUCCESS', provider_reference = ?, notes = ?, updated_at = ? WHERE id = ?`,
      [adminRef, `Reconciled manually by ${req.user!.email}: ${bankReferenceNotes || 'Bank receipt verified.'}`, now, id]
    );

    // Record in financial ledger
    recordDepositAndAllocation(db, {
      userId: transaction.user_id,
      transactionId: transaction.id,
      productId: transaction.product_id,
      amount: Number(transaction.amount),
      reference: transaction.reference,
      productName: transaction.product_name,
    });

    // Audit log
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'BANK_TRANSFER_RECONCILED', 'TRANSACTION', ?, ?, ?, ?)`,
      [
        'audit_' + Math.random().toString(36).substring(2, 11),
        req.user!.id,
        req.user!.email,
        id,
        JSON.stringify({
          reference: transaction.reference,
          amount: transaction.amount,
          notes: bankReferenceNotes,
          reconciledBy: req.user!.email,
        }),
        req.ip || '127.0.0.1',
        now,
      ]
    );

    // Send customer notification
    sendEmailNotification(db, {
      to: transaction.user_email,
      subject: 'Global Finance Crypto Mining — Bank Transfer Confirmed',
      htmlContent: `Dear ${transaction.first_name},\nYour direct bank transfer of R${transaction.amount} for ${transaction.product_name} (Ref: ${transaction.reference}) has been verified and allocated.`,
      adminLogDetails: `Manual reconciliation confirmed for ${transaction.reference}`,
    });

    saveDb();

    res.json({ message: `Transaction ${transaction.reference} successfully reconciled and allocated.` });
  } catch (err) {
    console.error('[ADMIN RECONCILE ERROR]', err);
    res.status(500).json({ error: 'Failed to reconcile bank transfer.' });
  }
});

// PayFast Notifications & Webhook Logs
router.get('/payments', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const notifications = queryAll(
      db,
      `SELECT id, transaction_reference, pf_payment_id, payment_status, amount_gross, amount_fee, amount_net, verified, created_at
       FROM payfast_notifications
       ORDER BY created_at DESC
       LIMIT 50`
    );

    res.json({ notifications });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve PayFast notifications.' });
  }
});

// Withdrawals Directory & Review
router.get('/withdrawals', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const withdrawals = queryAll(
      db,
      `SELECT w.*, u.email as customer_email, u.first_name, u.last_name
       FROM withdrawals w
       JOIN users u ON w.user_id = u.id
       ORDER BY w.created_at DESC`
    );

    res.json({ withdrawals });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load withdrawals.' });
  }
});

// Review Withdrawal (Approve / Reject)
router.post('/withdrawals/:id/review', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { action, notes } = req.body; // 'APPROVE' or 'REJECT'

    if (!['APPROVE', 'REJECT'].includes(action)) {
      res.status(400).json({ error: 'Invalid action.' });
      return;
    }

    const db = await getDb();
    const withdrawal = queryOne(db, 'SELECT * FROM withdrawals WHERE id = ?', [id]);
    if (!withdrawal) {
      res.status(404).json({ error: 'Withdrawal not found.' });
      return;
    }

    if (withdrawal.status !== 'PENDING_REVIEW') {
      res.status(400).json({ error: `Withdrawal has already been marked as ${withdrawal.status}.` });
      return;
    }

    const now = new Date().toISOString();
    const newStatus = action === 'APPROVE' ? 'COMPLETED' : 'REJECTED';

    db.run(
      `UPDATE withdrawals SET status = ?, reviewed_by = ?, review_notes = ?, updated_at = ? WHERE id = ?`,
      [newStatus, req.user!.id, notes || `${action} by ${req.user!.email}`, now, id]
    );

    // If completed, record debit in financial ledger
    if (newStatus === 'COMPLETED') {
      const summary = queryOne(
        db,
        `SELECT balance_after FROM financial_ledger WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 1`,
        [withdrawal.user_id]
      );
      const currentBalance = summary ? Number(summary.balance_after) : 0;
      const balanceAfter = Math.max(0, currentBalance - Number(withdrawal.amount));

      db.run(
        `INSERT INTO financial_ledger (id, user_id, entry_type, debit, credit, balance_after, description, created_at)
         VALUES (?, ?, 'WITHDRAWAL_PAID', ?, 0, ?, ?, ?)`,
        [
          'led_wd_' + Math.random().toString(36).substring(2, 11),
          withdrawal.user_id,
          withdrawal.amount,
          balanceAfter,
          `Payout completed via bank transfer to ${withdrawal.bank_name} (...${withdrawal.account_number.slice(-4)})`,
          now,
        ]
      );
    }

    // Audit log
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'WITHDRAWAL_REVIEWED', 'WITHDRAWAL', ?, ?, ?, ?)`,
      [
        'audit_' + Math.random().toString(36).substring(2, 11),
        req.user!.id,
        req.user!.email,
        id,
        JSON.stringify({ action: newStatus, amount: withdrawal.amount, notes, customerId: withdrawal.user_id }),
        req.ip || '127.0.0.1',
        now,
      ]
    );

    saveDb();
    res.json({ message: `Withdrawal successfully ${newStatus.toLowerCase()}.` });
  } catch (err) {
    res.status(500).json({ error: 'Failed to process withdrawal review.' });
  }
});

// Audit Logs
router.get('/audit-logs', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const logs = queryAll(
      db,
      `SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100`
    );

    res.json({ logs });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load audit logs.' });
  }
});

// ==============================================================================
// ADMINISTRATOR SUPPORT & COMPLAINTS MANAGEMENT
// ==============================================================================

// Tickets Overview KPI Stats
router.get('/tickets/stats', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();

    const total = queryOne(db, 'SELECT COUNT(*) as c FROM support_tickets')?.c || 0;
    const newTickets = queryOne(db, "SELECT COUNT(*) as c FROM support_tickets WHERE status = 'OPEN'")?.c || 0;
    const inProgress = queryOne(db, "SELECT COUNT(*) as c FROM support_tickets WHERE status = 'IN_PROGRESS'")?.c || 0;
    const awaitingCustomer = queryOne(db, "SELECT COUNT(*) as c FROM support_tickets WHERE status = 'AWAITING_CUSTOMER'")?.c || 0;
    const resolved = queryOne(db, "SELECT COUNT(*) as c FROM support_tickets WHERE status IN ('RESOLVED', 'CLOSED')")?.c || 0;

    res.json({
      total,
      new: newTickets,
      open: newTickets + inProgress,
      inProgress,
      awaitingCustomer,
      resolved,
    });
  } catch (err) {
    console.error('[ADMIN TICKET STATS ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve ticket statistics.' });
  }
});

// Searchable & Filterable Ticket List
router.get('/tickets', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const { q, category, priority, status, customerId, page = '1', limit = '50' } = req.query;

    const pageNum = Math.max(1, parseInt(page as string, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit as string, 10) || 50));
    const offset = (pageNum - 1) * limitNum;

    let whereClauses: string[] = [];
    let params: any[] = [];

    if (q && typeof q === 'string' && q.trim()) {
      const search = `%${q.trim()}%`;
      whereClauses.push(
        `(t.reference LIKE ? OR t.subject LIKE ? OR u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)`
      );
      params.push(search, search, search, search, search);
    }

    if (category && typeof category === 'string' && category.trim()) {
      whereClauses.push('t.category = ?');
      params.push(category.trim());
    }

    if (priority && typeof priority === 'string' && priority.trim()) {
      whereClauses.push('t.priority = ?');
      params.push(priority.trim());
    }

    if (status && typeof status === 'string' && status.trim()) {
      whereClauses.push('t.status = ?');
      params.push(status.trim());
    }

    if (customerId && typeof customerId === 'string' && customerId.trim()) {
      whereClauses.push('t.user_id = ?');
      params.push(customerId.trim());
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    const countSql = `
      SELECT COUNT(*) as c
      FROM support_tickets t
      JOIN users u ON t.user_id = u.id
      ${whereSql}
    `;
    const totalCount = queryOne(db, countSql, params)?.c || 0;

    const dataSql = `
      SELECT t.id, t.reference, t.user_id, t.subject, t.category, t.priority, t.status,
             t.created_at, t.updated_at, t.last_activity_at,
             u.email as customer_email, u.first_name as customer_first_name, u.last_name as customer_last_name,
             (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = t.id) as total_messages,
             (SELECT sender_role FROM ticket_messages WHERE ticket_id = t.id ORDER BY created_at DESC LIMIT 1) as last_sender_role
      FROM support_tickets t
      JOIN users u ON t.user_id = u.id
      ${whereSql}
      ORDER BY t.last_activity_at DESC
      LIMIT ? OFFSET ?
    `;

    const tickets = queryAll(db, dataSql, [...params, limitNum, offset]);

    res.json({
      tickets,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limitNum),
      },
    });
  } catch (err) {
    console.error('[ADMIN LIST TICKETS ERROR]', err);
    res.status(500).json({ error: 'Failed to load tickets.' });
  }
});

// Detailed Ticket View (including internal notes and full history)
router.get('/tickets/:id', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const ticketId = req.params.id;

    const ticket = queryOne(
      db,
      `SELECT t.id, t.reference, t.user_id, t.subject, t.category, t.priority, t.status,
              t.created_at, t.updated_at, t.last_activity_at,
              u.email as customer_email, u.first_name as customer_first_name, u.last_name as customer_last_name,
              u.phone as customer_phone, u.country as customer_country, u.kyc_status as customer_kyc_status,
              u.status as customer_account_status
       FROM support_tickets t
       JOIN users u ON t.user_id = u.id
       WHERE t.id = ?`,
      [ticketId]
    );

    if (!ticket) {
      res.status(404).json({ error: 'Ticket not found.' });
      return;
    }

    // Administrators see ALL messages, including private internal notes
    const messages = queryAll(
      db,
      `SELECT id, ticket_id, sender_id, sender_role, sender_name, message, is_internal_note,
              attachment_name, attachment_data, created_at
       FROM ticket_messages
       WHERE ticket_id = ?
       ORDER BY created_at ASC`,
      [ticketId]
    );

    res.json({ ticket, messages });
  } catch (err) {
    console.error('[ADMIN GET TICKET DETAILS ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve ticket details.' });
  }
});

// Admin Reply or Internal Note Composer
router.post('/tickets/:id/messages', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const ticketId = req.params.id;
    const adminId = req.user!.id;
    const adminEmail = req.user!.email;
    const { message, isInternalNote = false, statusUpdate, attachmentName, attachmentData } = req.body;

    if (!message || typeof message !== 'string' || message.trim().length === 0) {
      res.status(400).json({ error: 'Message cannot be empty.' });
      return;
    }

    // Find ticket and customer
    const ticket = queryOne(
      db,
      `SELECT t.id, t.reference, t.subject, t.status, t.user_id,
              u.email as customer_email, u.first_name as customer_first_name, u.last_name as customer_last_name
       FROM support_tickets t
       JOIN users u ON t.user_id = u.id
       WHERE t.id = ?`,
      [ticketId]
    );

    if (!ticket) {
      res.status(404).json({ error: 'Ticket not found.' });
      return;
    }

    const messageId = 'tmsg_' + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();
    const isNote = isInternalNote ? 1 : 0;

    // 1. Insert Message
    db.run(
      `INSERT INTO ticket_messages (id, ticket_id, sender_id, sender_role, sender_name, message, is_internal_note, attachment_name, attachment_data, created_at)
       VALUES (?, ?, ?, 'admin', 'Global Finance Support', ?, ?, ?, ?, ?)`,
      [
        messageId,
        ticketId,
        adminId,
        message.trim(),
        isNote,
        attachmentName ? String(attachmentName).trim() : null,
        attachmentData ? String(attachmentData) : null,
        now,
      ]
    );

    // 2. Update Ticket Status & Last Activity
    let nextStatus = ticket.status;
    if (statusUpdate && typeof statusUpdate === 'string') {
      nextStatus = statusUpdate;
    } else if (!isNote) {
      // Default to awaiting customer response when admin sends a public reply
      nextStatus = 'AWAITING_CUSTOMER';
    }

    db.run(
      `UPDATE support_tickets SET status = ?, last_activity_at = ?, updated_at = ? WHERE id = ?`,
      [nextStatus, now, now, ticketId]
    );

    // 3. If Customer-Facing Reply: Create Notification and Send Email
    if (!isNote) {
      // In-app Notification for Customer
      const notifId = 'notif_' + Math.random().toString(36).substring(2, 11);
      const excerpt = message.trim().length > 60 ? `${message.trim().substring(0, 57)}...` : message.trim();
      db.run(
        `INSERT INTO customer_notifications (id, user_id, ticket_id, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, 'TICKET_REPLY', 0, ?)`,
        [
          notifId,
          ticket.user_id,
          ticketId,
          `Support replied to ticket ${ticket.reference}`,
          `Support has replied to "${ticket.subject}": "${excerpt}"`,
          now,
        ]
      );

      // Email Dispatch via Resend integration / audited service
      sendEmailNotification(db, {
        to: ticket.customer_email,
        subject: `[${ticket.reference}] Support Response: ${ticket.subject}`,
        htmlContent: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #1e293b;">
            <h2 style="color: #d97706; margin-bottom: 8px;">Global Finance Crypto Mining Support</h2>
            <p>Dear ${ticket.customer_first_name} ${ticket.customer_last_name},</p>
            <p>An authorized support specialist has responded to your ticket <strong>${ticket.reference}</strong> regarding "<em>${ticket.subject}</em>":</p>
            <div style="background: #f8fafc; border-left: 4px solid #d97706; padding: 14px 18px; margin: 16px 0; border-radius: 4px; white-space: pre-wrap; font-size: 14px;">
              ${message.trim()}
            </div>
            <p>To reply or view the full conversation history, please log in to your Client Portal:</p>
            <p style="margin: 20px 0;">
              <a href="${process.env.APP_URL || 'https://ais-dev-ny23twsshey7l5r5uptwoc-691001745580.europe-west2.run.app'}/?page=dashboard" 
                 style="background: #d97706; color: #ffffff; padding: 10px 20px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">
                View Ticket in Portal
              </a>
            </p>
            <p style="font-size: 12px; color: #64748b; margin-top: 24px;">Reference: ${ticket.reference} • Global Finance Crypto Mining Compliance</p>
          </div>
        `,
        adminLogDetails: `Admin reply dispatched for ticket ${ticket.reference}`,
      }).catch((err) => console.error('[EMAIL ADMIN REPLY ERROR]', err));
    }

    // 4. Audit Log
    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, ?, 'TICKET', ?, ?, ?, ?)`,
      [
        auditId,
        adminId,
        adminEmail,
        isNote ? 'ADMIN_TICKET_INTERNAL_NOTE' : 'ADMIN_TICKET_REPLY',
        ticketId,
        JSON.stringify({
          reference: ticket.reference,
          isInternalNote: !!isNote,
          newStatus: nextStatus,
          messageLength: message.trim().length,
        }),
        req.ip || '127.0.0.1',
        now,
      ]
    );

    saveDb();

    res.json({
      success: true,
      message: {
        id: messageId,
        ticket_id: ticketId,
        sender_id: adminId,
        sender_role: 'admin',
        sender_name: 'Global Finance Support',
        message: message.trim(),
        is_internal_note: isNote,
        attachment_name: attachmentName ? String(attachmentName).trim() : null,
        attachment_data: attachmentData ? String(attachmentData) : null,
        created_at: now,
      },
      updatedStatus: nextStatus,
    });
  } catch (err) {
    console.error('[ADMIN POST MESSAGE ERROR]', err);
    res.status(500).json({ error: 'Failed to post message.' });
  }
});

// Update Ticket Status or Priority
router.patch('/tickets/:id', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const ticketId = req.params.id;
    const adminId = req.user!.id;
    const adminEmail = req.user!.email;
    const { status, priority } = req.body;

    const ticket = queryOne(
      db,
      'SELECT id, reference, subject, status, priority, user_id FROM support_tickets WHERE id = ?',
      [ticketId]
    );

    if (!ticket) {
      res.status(404).json({ error: 'Ticket not found.' });
      return;
    }

    const updates: string[] = [];
    const params: any[] = [];
    const now = new Date().toISOString();

    if (status && ['OPEN', 'IN_PROGRESS', 'AWAITING_CUSTOMER', 'RESOLVED', 'CLOSED'].includes(status)) {
      updates.push('status = ?');
      params.push(status);
    }

    if (priority && ['LOW', 'NORMAL', 'HIGH', 'URGENT'].includes(priority)) {
      updates.push('priority = ?');
      params.push(priority);
    }

    if (updates.length === 0) {
      res.status(400).json({ error: 'No valid status or priority update provided.' });
      return;
    }

    updates.push('updated_at = ?');
    params.push(now);

    params.push(ticketId);

    db.run(`UPDATE support_tickets SET ${updates.join(', ')} WHERE id = ?`, params);

    // If status changed, notify customer in-app
    if (status && status !== ticket.status) {
      const notifId = 'notif_' + Math.random().toString(36).substring(2, 11);
      const readableStatus = status.replace('_', ' ').toLowerCase();
      db.run(
        `INSERT INTO customer_notifications (id, user_id, ticket_id, title, message, type, is_read, created_at)
         VALUES (?, ?, ?, ?, ?, 'STATUS_CHANGE', 0, ?)`,
        [
          notifId,
          ticket.user_id,
          ticketId,
          `Ticket Status Updated: ${ticket.reference}`,
          `Your ticket "${ticket.subject}" has been marked as ${readableStatus}.`,
          now,
        ]
      );
    }

    // Audit Log
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'ADMIN_TICKET_STATUS_UPDATE', 'TICKET', ?, ?, ?, ?)`,
      [
        'audit_' + Math.random().toString(36).substring(2, 11),
        adminId,
        adminEmail,
        ticketId,
        JSON.stringify({
          reference: ticket.reference,
          oldStatus: ticket.status,
          newStatus: status || ticket.status,
          oldPriority: ticket.priority,
          newPriority: priority || ticket.priority,
        }),
        req.ip || '127.0.0.1',
        now,
      ]
    );

    saveDb();

    res.json({
      success: true,
      ticket: {
        id: ticketId,
        reference: ticket.reference,
        status: status || ticket.status,
        priority: priority || ticket.priority,
        updatedAt: now,
      },
    });
  } catch (err) {
    console.error('[ADMIN UPDATE TICKET ERROR]', err);
    res.status(500).json({ error: 'Failed to update ticket.' });
  }
});

// =========================================================================
// SECURE DOCUMENT VAULT & KYC COMPLIANCE MANAGEMENT (ADMIN)
// =========================================================================

// Document Vault KPIs
router.get('/documents/stats', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const rows = queryAll(
      db,
      'SELECT status, COUNT(*) as count FROM client_documents GROUP BY status'
    );

    const stats = {
      total: 0,
      pending: 0,
      underReview: 0,
      approved: 0,
      rejected: 0,
    };

    for (const r of rows) {
      stats.total += r.count;
      if (r.status === 'PENDING') stats.pending = r.count;
      else if (r.status === 'UNDER_REVIEW') stats.underReview = r.count;
      else if (r.status === 'APPROVED') stats.approved = r.count;
      else if (r.status === 'REJECTED') stats.rejected = r.count;
    }

    res.json(stats);
  } catch (err) {
    console.error('[ADMIN DOC STATS ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve document statistics.' });
  }
});

// List submitted documents with filters & pagination
router.get('/documents', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const { status, category, search, page = '1', limit = '25' } = req.query;

    const pageNum = Math.max(1, parseInt(page as string, 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(limit as string, 10) || 25));
    const offset = (pageNum - 1) * limitNum;

    const whereClauses: string[] = [];
    const params: any[] = [];

    if (status && typeof status === 'string' && status !== 'ALL') {
      whereClauses.push('d.status = ?');
      params.push(status.trim());
    }

    if (category && typeof category === 'string' && category !== 'ALL') {
      whereClauses.push('d.category = ?');
      params.push(category.trim());
    }

    if (search && typeof search === 'string' && search.trim()) {
      const q = `%${search.trim().toLowerCase()}%`;
      whereClauses.push('(LOWER(d.name) LIKE ? OR LOWER(u.email) LIKE ? OR LOWER(u.first_name || " " || u.last_name) LIKE ?)');
      params.push(q, q, q);
    }

    const whereSql = whereClauses.length > 0 ? `WHERE ${whereClauses.join(' AND ')}` : '';

    const countSql = `
      SELECT COUNT(*) as c
      FROM client_documents d
      JOIN users u ON d.user_id = u.id
      ${whereSql}
    `;
    const totalCount = queryOne(db, countSql, params)?.c || 0;

    const dataSql = `
      SELECT d.id, d.user_id, d.name, d.category, d.file_type, d.file_size, d.status,
             d.rejection_reason, d.reviewed_by, d.reviewed_at, d.created_at, d.updated_at,
             u.email as customer_email, u.first_name as customer_first_name, u.last_name as customer_last_name,
             u.phone as customer_phone, u.kyc_status as customer_kyc_status
      FROM client_documents d
      JOIN users u ON d.user_id = u.id
      ${whereSql}
      ORDER BY d.created_at DESC
      LIMIT ? OFFSET ?
    `;

    const documents = queryAll(db, dataSql, [...params, limitNum, offset]);

    res.json({
      documents,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total: totalCount,
        totalPages: Math.ceil(totalCount / limitNum),
      },
    });
  } catch (err) {
    console.error('[ADMIN LIST DOCUMENTS ERROR]', err);
    res.status(500).json({ error: 'Failed to load documents queue.' });
  }
});

// Detailed Document View with Audit History
router.get('/documents/:id', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const docId = req.params.id;

    const doc = queryOne(
      db,
      `SELECT d.id, d.user_id, d.name, d.category, d.file_type, d.file_size, d.status,
              d.rejection_reason, d.reviewed_by, d.reviewed_at, d.created_at, d.updated_at,
              u.email as customer_email, u.first_name as customer_first_name, u.last_name as customer_last_name,
              u.phone as customer_phone, u.kyc_status as customer_kyc_status
       FROM client_documents d
       JOIN users u ON d.user_id = u.id
       WHERE d.id = ?`,
      [docId]
    );

    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }

    const reviewLogs = queryAll(
      db,
      'SELECT id, document_id, admin_id, admin_email, action, notes, created_at FROM document_review_logs WHERE document_id = ? ORDER BY created_at ASC',
      [docId]
    );

    res.json({ document: doc, reviewLogs });
  } catch (err) {
    console.error('[ADMIN GET DOCUMENT DETAILS ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve document details.' });
  }
});

// Authorized and Audited Document File Viewing
router.get('/documents/:id/view', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const docId = req.params.id;
    const admin = req.user!;

    const doc = queryOne(
      db,
      'SELECT id, user_id, name, file_type, storage_path FROM client_documents WHERE id = ?',
      [docId]
    );

    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }

    const filePath = path.join(VAULT_DIR, doc.storage_path);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'Document file not found in vault storage.' });
      return;
    }

    const now = new Date().toISOString();
    const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';

    // Record audited administrative view
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'DOCUMENT_AUDIT_VIEWED', 'DOCUMENT', ?, ?, ?, ?)`,
      [
        'audit_' + Math.random().toString(36).substring(2, 11),
        admin.id,
        admin.email,
        docId,
        `Administrator inspected private document "${doc.name}" in compliance vault`,
        ip,
        now,
      ]
    );

    db.run(
      `INSERT INTO document_review_logs (id, document_id, admin_id, admin_email, action, notes, created_at)
       VALUES (?, ?, ?, ?, 'VIEWED', 'Document inspected by authorized staff in secure viewer', ?)`,
      [
        'dlog_' + Math.random().toString(36).substring(2, 11),
        docId,
        admin.id,
        admin.email,
        now,
      ]
    );
    saveDb();

    const safeFilename = doc.name.replace(/[^a-zA-Z0-9.-]/g, '_');
    res.setHeader('Content-Type', doc.file_type);
    res.setHeader('Content-Disposition', `inline; filename="${safeFilename}"`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-cache, no-store');

    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);
  } catch (err) {
    console.error('[ADMIN VIEW DOCUMENT FILE ERROR]', err);
    res.status(500).json({ error: 'Failed to access document file.' });
  }
});

// Review Document: Approve, Reject, or Mark Under Review
router.post('/documents/:id/review', async (req: AuthRequest, res: Response) => {
  try {
    const { action, notes } = req.body;
    const docId = req.params.id;
    const admin = req.user!;

    if (!['APPROVE', 'REJECT', 'UNDER_REVIEW'].includes(action)) {
      res.status(400).json({ error: 'Valid review action is required (APPROVE, REJECT, or UNDER_REVIEW).' });
      return;
    }

    if (action === 'REJECT' && (!notes || !String(notes).trim())) {
      res.status(400).json({ error: 'Please provide an administrative explanation / reason when rejecting a document.' });
      return;
    }

    const db = await getDb();
    const doc = queryOne(
      db,
      `SELECT d.id, d.user_id, d.name, d.category, d.status,
              u.email as customer_email, u.first_name as customer_first_name
       FROM client_documents d
       JOIN users u ON d.user_id = u.id
       WHERE d.id = ?`,
      [docId]
    );

    if (!doc) {
      res.status(404).json({ error: 'Document not found.' });
      return;
    }

    const now = new Date().toISOString();
    const targetStatus = action === 'APPROVE' ? 'APPROVED' : action === 'REJECT' ? 'REJECTED' : 'UNDER_REVIEW';
    const reasonText = action === 'REJECT' ? String(notes).trim() : null;

    // Update document record
    db.run(
      `UPDATE client_documents
       SET status = ?, rejection_reason = ?, reviewed_by = ?, reviewed_at = ?, updated_at = ?
       WHERE id = ?`,
      [targetStatus, reasonText, admin.email, now, now, docId]
    );

    // If ID_DOCUMENT is approved, update user kyc_status to verified
    if (action === 'APPROVE' && doc.category === 'ID_DOCUMENT') {
      db.run('UPDATE users SET kyc_status = "verified", updated_at = ? WHERE id = ?', [now, doc.user_id]);
    }

    // Record review log
    db.run(
      `INSERT INTO document_review_logs (id, document_id, admin_id, admin_email, action, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        'dlog_' + Math.random().toString(36).substring(2, 11),
        docId,
        admin.id,
        admin.email,
        action,
        notes ? String(notes).trim() : `Document marked as ${targetStatus}`,
        now,
      ]
    );

    // Record audit log
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'DOCUMENT_REVIEW_DECISION', 'DOCUMENT', ?, ?, ?, ?)`,
      [
        'audit_' + Math.random().toString(36).substring(2, 11),
        admin.id,
        admin.email,
        docId,
        JSON.stringify({
          documentName: doc.name,
          category: doc.category,
          decision: targetStatus,
          reason: reasonText,
          customerEmail: doc.customer_email,
        }),
        req.ip || '127.0.0.1',
        now,
      ]
    );

    // In-app customer notification
    const notifTitle = action === 'APPROVE'
      ? `Document Approved: ${doc.name}`
      : action === 'REJECT'
      ? `Document Review Outcome: ${doc.name}`
      : `Document Under Review: ${doc.name}`;

    const notifMessage = action === 'APPROVE'
      ? `Your document "${doc.name}" has been reviewed and approved by compliance.`
      : action === 'REJECT'
      ? `Your document "${doc.name}" was rejected. Reason: ${reasonText}`
      : `Your document "${doc.name}" is currently under secondary administrative review.`;

    const notifId = 'notif_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO customer_notifications (id, user_id, title, message, type, is_read, created_at)
       VALUES (?, ?, ?, ?, 'DOCUMENT', 0, ?)`,
      [notifId, doc.user_id, notifTitle, notifMessage, now]
    );

    saveDb();

    // Send email to customer
    await sendEmailNotification(db, {
      to: doc.customer_email,
      subject: `Global Finance Compliance Notice — ${notifTitle}`,
      htmlContent: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; color: #1e293b; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px;">
          <h2 style="color: ${action === 'APPROVE' ? '#059669' : action === 'REJECT' ? '#dc2626' : '#d97706'}; margin-top: 0;">
            ${notifTitle}
          </h2>
          <p>Hello ${doc.customer_first_name || 'Client'},</p>
          <p>${notifMessage}</p>
          ${action === 'REJECT' ? `<div style="padding: 12px 16px; background: #fef2f2; border-left: 4px solid #ef4444; border-radius: 4px; margin: 16px 0;"><p style="margin: 0; font-weight: bold; color: #991b1b;">Rejection Explanation:</p><p style="margin: 4px 0 0 0; color: #b91c1c;">${reasonText}</p></div><p style="font-size: 13px; color: #64748b;">You can replace this document with a corrected copy anytime inside your client Security Centre.</p>` : ''}
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0;" />
          <p style="font-size: 11px; color: #94a3b8;">Global Finance Crypto Mining • Security & Compliance Operations</p>
        </div>
      `,
      adminLogDetails: `Document review decision (${targetStatus}) email dispatched to ${doc.customer_email}`,
    });

    res.json({
      success: true,
      message: `Document status updated to ${targetStatus}.`,
      document: {
        id: docId,
        status: targetStatus,
        reviewedBy: admin.email,
        reviewedAt: now,
        rejectionReason: reasonText,
      },
    });
  } catch (err) {
    console.error('[ADMIN REVIEW DOCUMENT ERROR]', err);
    res.status(500).json({ error: 'Failed to complete document review.' });
  }
});

// ==========================================
// INVESTMENT MANAGEMENT & AUDITED SETTLEMENT
// ==========================================

// 1. List all investments with filtering and metrics
router.get('/investments', requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const status = req.query.status ? String(req.query.status) : '';
    const q = req.query.q ? String(req.query.q).trim() : '';
    const page = Math.max(1, parseInt(String(req.query.page || '1'), 10));
    const limit = Math.min(100, Math.max(10, parseInt(String(req.query.limit || '20'), 10)));
    const offset = (page - 1) * limit;

    let sql = `
      SELECT a.*,
             u.email as customer_email, u.first_name as customer_first_name, u.last_name as customer_last_name,
             p.name as product_name, p.slug as product_slug,
             t.reference as transaction_reference, t.payment_method
      FROM investment_allocations a
      JOIN users u ON a.user_id = u.id
      JOIN investment_products p ON a.product_id = p.id
      JOIN transactions t ON a.transaction_id = t.id
      WHERE 1=1
    `;
    const params: any[] = [];

    if (status && status !== 'ALL') {
      sql += ' AND a.status = ?';
      params.push(status);
    }

    if (q) {
      sql += ' AND (a.id LIKE ? OR t.reference LIKE ? OR u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)';
      params.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`);
    }

    sql += ' ORDER BY a.created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const investments = queryAll(db, sql, params);

    // Count query for pagination
    let countSql = `
      SELECT COUNT(*) as total
      FROM investment_allocations a
      JOIN users u ON a.user_id = u.id
      JOIN transactions t ON a.transaction_id = t.id
      WHERE 1=1
    `;
    const countParams: any[] = [];
    if (status && status !== 'ALL') {
      countSql += ' AND a.status = ?';
      countParams.push(status);
    }
    if (q) {
      countSql += ' AND (a.id LIKE ? OR t.reference LIKE ? OR u.email LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ?)';
      countParams.push(`%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`, `%${q}%`);
    }
    const totalRow = queryOne(db, countSql, countParams);
    const total = totalRow ? Number(totalRow.total) : 0;

    // Aggregate summary metrics across all investments
    const activeStats = queryOne(
      db,
      `SELECT COUNT(*) as count, COALESCE(SUM(amount_allocated), 0) as total_capital, COALESCE(SUM(projected_profit), 0) as total_projected_profit
       FROM investment_allocations WHERE status = 'ACTIVE'`
    );
    const maturedStats = queryOne(
      db,
      `SELECT COUNT(*) as count, COALESCE(SUM(amount_allocated), 0) as total_capital
       FROM investment_allocations WHERE status = 'MATURED'`
    );
    const settledStats = queryOne(
      db,
      `SELECT COUNT(*) as count, COALESCE(SUM(settlement_amount), 0) as total_settled, COALESCE(SUM(realized_pnl), 0) as total_realized_pnl
       FROM investment_allocations WHERE status = 'SETTLED'`
    );

    res.json({
      investments,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit) || 1,
      },
      metrics: {
        activeCount: activeStats ? Number(activeStats.count) : 0,
        activeCapital: activeStats ? Number(activeStats.total_capital) : 0,
        activeProjectedProfit: activeStats ? Number(activeStats.total_projected_profit) : 0,
        maturedCount: maturedStats ? Number(maturedStats.count) : 0,
        maturedCapital: maturedStats ? Number(maturedStats.total_capital) : 0,
        settledCount: settledStats ? Number(settledStats.count) : 0,
        settledAmount: settledStats ? Number(settledStats.total_settled) : 0,
        realizedPnL: settledStats ? Number(settledStats.total_realized_pnl) : 0,
      },
    });
  } catch (err) {
    console.error('[ADMIN GET INVESTMENTS ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve investments list.' });
  }
});

// 2. Inspect individual investment with full audit trail and history
router.get('/investments/:id', requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    const investment = queryOne(
      db,
      `SELECT a.*,
              u.email as customer_email, u.first_name as customer_first_name, u.last_name as customer_last_name, u.phone as customer_phone,
              p.name as product_name, p.slug as product_slug,
              t.reference as transaction_reference, t.payment_method, t.payment_provider, t.status as transaction_status
       FROM investment_allocations a
       JOIN users u ON a.user_id = u.id
       JOIN investment_products p ON a.product_id = p.id
       JOIN transactions t ON a.transaction_id = t.id
       WHERE a.id = ?`,
      [id]
    );

    if (!investment) {
      res.status(404).json({ error: 'Investment not found.' });
      return;
    }

    const dailyRecords = queryAll(
      db,
      'SELECT * FROM investment_daily_records WHERE investment_id = ? ORDER BY record_date DESC',
      [id]
    );

    const auditLogs = queryAll(
      db,
      'SELECT * FROM investment_audit_logs WHERE investment_id = ? ORDER BY created_at DESC',
      [id]
    );

    res.json({ investment, dailyRecords, auditLogs });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve investment details.' });
  }
});

// 3. Audited settlement of a matured investment
router.post('/investments/:id/settle', requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { notes } = req.body;
    const admin = req.user!;
    const db = await getDb();

    const { settleMaturedInvestment } = await import('../services/investmentEngine.js');

    const result = settleMaturedInvestment(db, {
      investmentId: id,
      adminId: admin.id,
      adminEmail: admin.email,
      notes: notes ? String(notes).trim() : undefined,
    });

    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }

    res.json({
      success: true,
      message: `Investment settled successfully. Credited R${result.settlementAmount?.toLocaleString()} to customer ledger balance.`,
      settlementAmount: result.settlementAmount,
    });
  } catch (err: any) {
    console.error('[ADMIN SETTLE ERROR]', err);
    res.status(500).json({ error: err.message || 'Failed to process settlement.' });
  }
});

// 4. Record audited valuation adjustment
router.post('/investments/:id/record-valuation', requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { newValuation, reason } = req.body;
    const admin = req.user!;

    if (newValuation === undefined || isNaN(Number(newValuation)) || Number(newValuation) <= 0) {
      res.status(400).json({ error: 'A valid positive numerical valuation is required.' });
      return;
    }

    if (!reason || String(reason).trim().length < 5) {
      res.status(400).json({ error: 'An authoritative audit reason is required (minimum 5 characters).' });
      return;
    }

    const db = await getDb();
    const inv = queryOne(
      db,
      'SELECT id, user_id, current_valuation, amount_allocated FROM investment_allocations WHERE id = ?',
      [id]
    );

    if (!inv) {
      res.status(404).json({ error: 'Investment not found.' });
      return;
    }

    const numericVal = Math.round(Number(newValuation) * 100) / 100;
    const prevVal = Number(inv.current_valuation || inv.amount_allocated);
    const change = Math.round((numericVal - prevVal) * 100) / 100;
    const pct = prevVal > 0 ? Math.round(((numericVal - prevVal) / prevVal) * 10000) / 100 : 0;
    const nowIso = new Date().toISOString();

    // Update investment allocation
    db.run(
      'UPDATE investment_allocations SET current_valuation = ?, updated_at = ? WHERE id = ?',
      [numericVal, nowIso, id]
    );

    // Insert daily record
    const drId = 'dr_adj_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO investment_daily_records (
        id, investment_id, user_id, record_date, opening_value, closing_value,
        daily_change, daily_percentage, cumulative_change, projected_value,
        classification, data_source, notes, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'ADJUSTED', 'ADMIN_AUDITED_VALUATION', ?, ?)`,
      [
        drId,
        id,
        inv.user_id,
        nowIso.slice(0, 10),
        prevVal,
        numericVal,
        change,
        pct,
        change,
        numericVal,
        `Adjusted by ${admin.email}: ${reason}`,
        nowIso,
      ]
    );

    // Audit log
    const auditId = 'ia_adj_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO investment_audit_logs (id, investment_id, action, actor_type, actor_id, previous_state, new_state, reason, created_at)
       VALUES (?, ?, 'VALUATION_ADJUSTED', 'ADMIN', ?, ?, ?, ?, ?)`,
      [
        auditId,
        id,
        admin.id,
        JSON.stringify({ previousValuation: prevVal }),
        JSON.stringify({ newValuation: numericVal, change, percentage: pct }),
        String(reason).trim(),
        nowIso,
      ]
    );

    saveDb();

    res.json({
      success: true,
      message: `Valuation updated to R${numericVal.toLocaleString()}. Audit event logged.`,
      currentValuation: numericVal,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to record valuation adjustment.' });
  }
});

// 5. Plan terms and term versions inspection
router.get('/investments-plans', requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const products = queryAll(db, 'SELECT * FROM investment_products ORDER BY min_amount ASC');
    const versions = queryAll(db, 'SELECT * FROM investment_plan_versions ORDER BY created_at DESC');

    res.json({ products, versions });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve plan configurations.' });
  }
});

// 6. Update plan terms (versioned, immutable to existing investments)
router.put('/investments-plans/:id', requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { returnRate, durationDays, notes } = req.body;
    const admin = req.user!;

    if (!returnRate || isNaN(Number(returnRate)) || Number(returnRate) <= 0) {
      res.status(400).json({ error: 'Valid return rate is required (e.g. 0.85 for 85%).' });
      return;
    }
    if (!durationDays || isNaN(Number(durationDays)) || Number(durationDays) < 1) {
      res.status(400).json({ error: 'Valid duration in days is required.' });
      return;
    }

    const db = await getDb();
    const product = queryOne(db, 'SELECT * FROM investment_products WHERE id = ?', [id]);
    if (!product) {
      res.status(404).json({ error: 'Product not found.' });
      return;
    }

    const newRate = Number(returnRate);
    const newDays = parseInt(String(durationDays), 10);
    const newVersion = (product.term_version || 1) + 1;
    const nowIso = new Date().toISOString();

    // 1. Update product with new term version (only affects future purchases)
    db.run(
      `UPDATE investment_products 
       SET return_rate = ?, duration_days = ?, term_version = ?
       WHERE id = ?`,
      [newRate, newDays, newVersion, id]
    );

    // 2. Insert new term version record
    const verId = 'ver_' + product.slug + '_v' + newVersion;
    db.run(
      `INSERT INTO investment_plan_versions (id, product_id, version, name, return_rate, duration_days, return_type, min_amount, created_by, effective_from, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'PROFIT_ON_CAPITAL', ?, ?, ?, ?, ?)`,
      [
        verId,
        product.id,
        newVersion,
        product.name,
        newRate,
        newDays,
        product.min_amount,
        admin.email,
        nowIso,
        notes || `Updated to version ${newVersion} by ${admin.email}`,
        nowIso,
      ]
    );

    saveDb();

    res.json({
      success: true,
      message: `Plan terms updated to Version ${newVersion}. Existing investments remain governed by their locked purchase snapshot terms.`,
      product: {
        id: product.id,
        name: product.name,
        returnRate: newRate,
        durationDays: newDays,
        termVersion: newVersion,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update plan configuration.' });
  }
});

export default router;
