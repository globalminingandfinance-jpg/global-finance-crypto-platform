import { Router, Request, Response } from 'express';
import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { getDb, queryOne, queryAll, saveDb, recordSecurityEvent, PRIMARY_ADMIN_EMAIL, ALIAS_ADMIN_EMAIL } from '../db/database.js';
import { requireAuth, AuthRequest, createRateLimiter } from '../middleware/auth.js';
import { sendEmailNotification } from '../services/email.js';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'gfc-mining-secure-secret-key-2026';
const authLimiter = createRateLimiter(60000, 10);
const recoveryLimiter = createRateLimiter(60000, 5);

export function parseDeviceInfo(userAgent: string | undefined): string {
  if (!userAgent) return 'Web Browser / Standard Client';
  const ua = userAgent.toLowerCase();
  let os = 'Desktop';
  if (/windows/i.test(ua)) os = 'Windows PC';
  else if (/macintosh|mac os x/i.test(ua)) os = 'macOS';
  else if (/android/i.test(ua)) os = 'Android Mobile';
  else if (/iphone|ipad|ipod/i.test(ua)) os = 'iOS Device';
  else if (/linux/i.test(ua)) os = 'Linux OS';

  let browser = 'Browser';
  if (/edg/i.test(ua)) browser = 'Edge';
  else if (/chrome/i.test(ua)) browser = 'Chrome';
  else if (/firefox/i.test(ua)) browser = 'Firefox';
  else if (/safari/i.test(ua)) browser = 'Safari';

  return `${browser} on ${os}`;
}

function generateToken(user: { id: string; email: string; role: string }): string {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

// Client Registration
router.post('/register', authLimiter, async (req: Request, res: Response) => {
  try {
    const { firstName, lastName, email, phone, country, password } = req.body;

    if (!firstName || !lastName || !email || !password) {
      res.status(400).json({ error: 'First name, last name, email, and password are required.' });
      return;
    }

    const emailTrimmed = String(email).toLowerCase().trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailTrimmed)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }

    if (String(password).length < 8) {
      res.status(400).json({ error: 'Password must be at least 8 characters long.' });
      return;
    }

    const db = await getDb();
    const existing = queryOne(db, 'SELECT id FROM users WHERE email = ?', [emailTrimmed]);
    if (existing) {
      res.status(400).json({ error: 'An account with this email address already exists.' });
      return;
    }

    const salt = bcrypt.genSaltSync(12);
    const passwordHash = bcrypt.hashSync(password, salt);
    const userId = 'usr_' + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    db.run(
      `INSERT INTO users (id, email, password_hash, first_name, last_name, phone, country, role, status, must_change_password, kyc_status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'client', 'active', 0, 'unverified', ?, ?)`,
      [
        userId,
        emailTrimmed,
        passwordHash,
        String(firstName).trim(),
        String(lastName).trim(),
        phone ? String(phone).trim() : '',
        country ? String(country).trim() : 'South Africa',
        now,
        now,
      ]
    );

    // Initial session
    const sessionId = 'sess_' + Math.random().toString(36).substring(2, 11);
    const sessionToken = crypto.randomBytes(24).toString('hex');
    db.run(
      `INSERT INTO user_sessions (id, user_id, session_token, device_info, ip_address, last_active_at, is_revoked, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 0, ?)`,
      [sessionId, userId, sessionToken, parseDeviceInfo(userAgent), ip, now, now]
    );

    recordSecurityEvent(
      db,
      userId,
      'ACCOUNT_CREATED',
      'Client account registered successfully',
      ip,
      parseDeviceInfo(userAgent)
    );

    saveDb();

    const token = generateToken({ id: userId, email: emailTrimmed, role: 'client' });
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 7 * 86400000 });

    res.status(201).json({
      message: 'Account created successfully.',
      token,
      user: {
        id: userId,
        email: emailTrimmed,
        firstName: String(firstName).trim(),
        lastName: String(lastName).trim(),
        role: 'client',
        status: 'active',
        kycStatus: 'unverified',
      },
    });
  } catch (err: any) {
    console.error('[AUTH REGISTER ERROR]', err);
    res.status(500).json({ error: 'Failed to complete registration. Please try again.' });
  }
});

// Client Login
router.post('/login', authLimiter, async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const emailTrimmed = String(email).toLowerCase().trim();
    const db = await getDb();
    const user = queryOne(
      db,
      'SELECT id, email, password_hash, first_name, last_name, role, status, kyc_status, must_change_password FROM users WHERE email = ?',
      [emailTrimmed]
    );

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    const deviceInfo = parseDeviceInfo(userAgent);
    const now = new Date().toISOString();

    if (!user) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    if (user.status === 'suspended') {
      res.status(403).json({ error: 'Your account has been suspended. Please contact support.' });
      return;
    }

    const passwordMatch = bcrypt.compareSync(password, user.password_hash);
    if (!passwordMatch) {
      recordSecurityEvent(
        db,
        user.id,
        'LOGIN_FAILED',
        'Failed sign-in attempt with incorrect password',
        ip,
        deviceInfo
      );
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    // Record session
    const sessionId = 'sess_' + Math.random().toString(36).substring(2, 11);
    const sessionToken = crypto.randomBytes(24).toString('hex');
    db.run(
      `INSERT INTO user_sessions (id, user_id, session_token, device_info, ip_address, last_active_at, is_revoked, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 0, ?)`,
      [sessionId, user.id, sessionToken, deviceInfo, ip, now, now]
    );

    recordSecurityEvent(
      db,
      user.id,
      'LOGIN_SUCCESS',
      `Successful client sign-in from ${deviceInfo}`,
      ip,
      deviceInfo
    );
    saveDb();

    const token = generateToken({ id: user.id, email: user.email, role: user.role });
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 7 * 86400000 });

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: user.role,
        status: user.status,
        kycStatus: user.kyc_status,
      },
    });
  } catch (err: any) {
    console.error('[AUTH LOGIN ERROR]', err);
    res.status(500).json({ error: 'Authentication failed. Please try again.' });
  }
});

// Password Recovery: Request Reset Link
router.post('/forgot-password', recoveryLimiter, async (req: Request, res: Response) => {
  try {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ error: 'Email address is required.' });
      return;
    }

    const emailTrimmed = String(email).toLowerCase().trim();
    const isKnownAdminAlias = emailTrimmed === PRIMARY_ADMIN_EMAIL || emailTrimmed === ALIAS_ADMIN_EMAIL;
    const db = await getDb();
    let user = queryOne(
      db,
      'SELECT id, email, first_name, status, role FROM users WHERE email = ?',
      [emailTrimmed]
    );

    if (!user && isKnownAdminAlias) {
      user = queryOne(
        db,
        `SELECT id, email, first_name, status, role FROM users WHERE role = 'admin' ORDER BY updated_at DESC LIMIT 1`
      );
    }

    const genericSuccess = {
      message: 'If an account associated with that email address exists, a secure password-reset link has been dispatched.',
    };

    if (!user || user.status === 'suspended') {
      // Do not disclose whether email exists (generic rate-limited response)
      res.json(genericSuccess);
      return;
    }

    // Invalidate existing unused tokens for this user
    db.run('UPDATE password_resets SET used = 1 WHERE user_id = ? AND used = 0', [user.id]);

    // Generate cryptographic reset token (32 bytes = 64 hex chars)
    const rawToken = crypto.randomBytes(32).toString('hex');
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString(); // 1 hour validity
    const now = new Date().toISOString();
    const resetId = 'rst_' + Math.random().toString(36).substring(2, 11);

    db.run(
      `INSERT INTO password_resets (id, user_id, token_hash, expires_at, used, created_at)
       VALUES (?, ?, ?, ?, 0, ?)`,
      [resetId, user.id, tokenHash, expiresAt, now]
    );

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      user.id,
      'PASSWORD_RESET_REQUESTED',
      'Password recovery link requested',
      ip,
      parseDeviceInfo(userAgent)
    );
    saveDb();

    // Construct link
    const host = req.get('host') || 'localhost:3000';
    const protocol = req.protocol === 'https' || req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
    const resetUrl = `${protocol}://${host}/?resetToken=${rawToken}`;

    // Dispatch email
    await sendEmailNotification(db, {
      to: user.email,
      subject: 'Global Finance — Password Reset Request',
      htmlContent: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; color: #1e293b; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px;">
          <h2 style="color: #0f172a; margin-top: 0;">Password Recovery Request</h2>
          <p>Hello ${user.first_name || 'Valued Client'},</p>
          <p>We received a request to reset the password for your Global Finance Crypto Mining account.</p>
          <div style="margin: 24px 0; text-align: center;">
            <a href="${resetUrl}" style="display: inline-block; padding: 12px 28px; background: #f59e0b; color: #000000; text-decoration: none; font-weight: bold; border-radius: 8px;">Reset Password</a>
          </div>
          <p style="font-size: 13px; color: #64748b;">Or paste this link into your browser: <br/><a href="${resetUrl}" style="color: #d97706; word-break: break-all;">${resetUrl}</a></p>
          <p style="font-size: 13px; color: #64748b;"><strong>Note:</strong> This single-use link expires in 60 minutes. If you did not request this change, please contact our support team immediately.</p>
          <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0;" />
          <p style="font-size: 11px; color: #94a3b8;">Global Finance Crypto Mining • Digital Infrastructure & Custody Solutions</p>
        </div>
      `,
      adminLogDetails: `Password reset dispatched to ${user.email} (token ID: ${resetId})`,
    });

    res.json(genericSuccess);
  } catch (err: any) {
    console.error('[FORGOT PASSWORD ERROR]', err);
    res.status(500).json({ error: 'Failed to process recovery request. Please try again later.' });
  }
});

// Password Recovery: Verify Token
router.get('/verify-reset-token', async (req: Request, res: Response) => {
  try {
    const rawToken = req.query.token as string;
    if (!rawToken || typeof rawToken !== 'string') {
      res.status(400).json({ valid: false, error: 'Token parameter is missing.' });
      return;
    }

    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const db = await getDb();
    const record = queryOne(
      db,
      'SELECT id, user_id, expires_at, used FROM password_resets WHERE token_hash = ?',
      [tokenHash]
    );

    if (!record) {
      res.status(400).json({ valid: false, error: 'Password reset link is invalid or has already been used.' });
      return;
    }

    if (record.used === 1) {
      res.status(400).json({ valid: false, error: 'This password reset link has already been used.' });
      return;
    }

    if (new Date(record.expires_at).getTime() < Date.now()) {
      res.status(400).json({ valid: false, error: 'This password reset link has expired. Please request a new one.' });
      return;
    }

    const user = queryOne(db, 'SELECT id, email, role FROM users WHERE id = ?', [record.user_id]);
    const envAdminEmail = (process.env.INITIAL_ADMIN_EMAIL || '').toLowerCase().trim();
    const userEmailLower = String(user?.email || '').toLowerCase().trim();
    const isKnownAdmin = user?.role === 'admin' || userEmailLower === PRIMARY_ADMIN_EMAIL.toLowerCase() || userEmailLower === ALIAS_ADMIN_EMAIL.toLowerCase() || (envAdminEmail && userEmailLower === envAdminEmail);

    res.json({
      valid: true,
      role: isKnownAdmin ? 'admin' : (user?.role || 'client'),
      email: user?.email,
      message: 'Token verified.'
    });
  } catch (err) {
    res.status(500).json({ valid: false, error: 'Failed to verify token.' });
  }
});

// Password Recovery: Perform Password Reset
router.post('/reset-password', recoveryLimiter, async (req: Request, res: Response) => {
  try {
    const { token: rawToken, newPassword } = req.body;

    if (!rawToken || !newPassword) {
      res.status(400).json({ error: 'Reset token and new password are required.' });
      return;
    }

    if (String(newPassword).length < 8) {
      res.status(400).json({ error: 'New password must be at least 8 characters long.' });
      return;
    }

    // Require complexity
    const pwdStr = String(newPassword);
    const hasUpper = /[A-Z]/.test(pwdStr);
    const hasLower = /[a-z]/.test(pwdStr);
    const hasNumOrSpec = /[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(pwdStr);
    if (!hasUpper || !hasLower || !hasNumOrSpec) {
      res.status(400).json({
        error: 'Password must contain uppercase and lowercase letters, and at least one number or symbol.',
      });
      return;
    }

    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const db = await getDb();
    const record = queryOne(
      db,
      'SELECT id, user_id, expires_at, used FROM password_resets WHERE token_hash = ?',
      [tokenHash]
    );

    if (!record || record.used === 1 || new Date(record.expires_at).getTime() < Date.now()) {
      res.status(400).json({
        error: 'This reset link is invalid or has expired. Please request a new recovery link.',
      });
      return;
    }

    const user = queryOne(db, 'SELECT id, email, first_name, role FROM users WHERE id = ?', [record.user_id]);
    if (!user) {
      res.status(404).json({ error: 'Associated user account not found.' });
      return;
    }

    // Hash new password securely with bcrypt 12 rounds
    const salt = bcrypt.genSaltSync(12);
    const newHash = bcrypt.hashSync(pwdStr, salt);
    const now = new Date().toISOString();

    const envAdminEmail = (process.env.INITIAL_ADMIN_EMAIL || '').toLowerCase().trim();
    const userEmailLower = String(user.email || '').toLowerCase().trim();
    const isUserAdmin = user.role === 'admin' ||
      userEmailLower === PRIMARY_ADMIN_EMAIL.toLowerCase() ||
      userEmailLower === ALIAS_ADMIN_EMAIL.toLowerCase() ||
      (envAdminEmail && userEmailLower === envAdminEmail);

    // Update password, clear must_change_password flag, increment session_version to invalidate old tokens
    if (isUserAdmin) {
      db.run(
        `UPDATE users 
         SET password_hash = ?, role = 'admin', must_change_password = 0, session_version = session_version + 1, updated_at = ? 
         WHERE role = 'admin' OR LOWER(email) IN (LOWER(?), LOWER(?), LOWER(?))`,
        [newHash, now, PRIMARY_ADMIN_EMAIL, ALIAS_ADMIN_EMAIL, envAdminEmail || PRIMARY_ADMIN_EMAIL]
      );
    } else {
      db.run(
        'UPDATE users SET password_hash = ?, must_change_password = 0, session_version = session_version + 1, updated_at = ? WHERE id = ?',
        [newHash, now, user.id]
      );
    }

    // Mark reset record as used
    db.run('UPDATE password_resets SET used = 1 WHERE id = ?', [record.id]);

    // Invalidate existing sessions
    db.run('UPDATE user_sessions SET is_revoked = 1 WHERE user_id = ?', [user.id]);

    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';
    recordSecurityEvent(
      db,
      user.id,
      'PASSWORD_RESET_COMPLETED',
      'Password successfully recovered and updated via single-use reset token',
      ip,
      parseDeviceInfo(userAgent)
    );
    saveDb();

    // Send confirmation email
    await sendEmailNotification(db, {
      to: user.email,
      subject: 'Global Finance — Password Successfully Updated',
      htmlContent: `
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 24px; color: #1e293b; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px;">
          <h2 style="color: #0f172a; margin-top: 0;">Password Successfully Reset</h2>
          <p>Hello ${user.first_name || 'Valued User'},</p>
          <p>This is confirmation that the password for your Global Finance Crypto Mining account was changed on <strong>${new Date().toUTCString()}</strong>.</p>
          <p style="font-size: 13px; color: #64748b;">If you performed this action, no further steps are needed. If you did not make this change, please contact our emergency support team immediately.</p>
        </div>
      `,
      adminLogDetails: `Password change confirmation dispatched to ${user.email}`,
    });

    res.json({ message: 'Your password has been reset successfully. You may now sign in with your new password.' });
  } catch (err: any) {
    console.error('[RESET PASSWORD ERROR]', err);
    res.status(500).json({ error: 'Failed to reset password. Please try again.' });
  }
});

// Administrator Login (Dedicated Protected Route)
router.post('/admin-login', authLimiter, async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: 'Administrator email and password are required.' });
      return;
    }

    const emailTrimmed = String(email).toLowerCase().trim();
    const envAdminEmail = (process.env.INITIAL_ADMIN_EMAIL || '').toLowerCase().trim();
    const isKnownAdminAlias =
      emailTrimmed === PRIMARY_ADMIN_EMAIL.toLowerCase() ||
      emailTrimmed === ALIAS_ADMIN_EMAIL.toLowerCase() ||
      (envAdminEmail && emailTrimmed === envAdminEmail);

    let db;
    try {
      db = await getDb();
    } catch (dbErr) {
      console.error('[ADMIN LOGIN DB CONNECTION ERROR]', dbErr);
      res.status(503).json({ error: 'Authentication service temporarily unavailable. Database connection issue.' });
      return;
    }

    // Look up by case-insensitive email match first
    let user = queryOne(
      db,
      'SELECT id, email, password_hash, first_name, last_name, role, status, must_change_password FROM users WHERE LOWER(email) = LOWER(?)',
      [emailTrimmed]
    );

    // If not found by exact email or not marked admin, check aliases
    if ((!user || user.role !== 'admin') && isKnownAdminAlias) {
      user = queryOne(
        db,
        `SELECT id, email, password_hash, first_name, last_name, role, status, must_change_password 
         FROM users 
         WHERE (LOWER(email) = LOWER(?) OR LOWER(email) IN (LOWER(?), LOWER(?), LOWER(?))) AND role = 'admin'
         ORDER BY must_change_password ASC, updated_at DESC LIMIT 1`,
        [emailTrimmed, PRIMARY_ADMIN_EMAIL, ALIAS_ADMIN_EMAIL, envAdminEmail || PRIMARY_ADMIN_EMAIL]
      );
    }

    // Explicit check: must exist, must have role === 'admin'
    if (!user || user.role !== 'admin') {
      res.status(401).json({ error: 'Invalid administrator credentials.' });
      return;
    }

    if (user.status === 'suspended') {
      res.status(403).json({ error: 'Administrator access is suspended.' });
      return;
    }

    const match = bcrypt.compareSync(String(password), user.password_hash);
    if (!match) {
      res.status(401).json({ error: 'Invalid administrator credentials.' });
      return;
    }

    const now = new Date().toISOString();
    const ip = req.ip || req.socket.remoteAddress || 'unknown';

    // Synchronize password hash to all admin aliases so divergent passwords can never occur
    if (isKnownAdminAlias) {
      try {
        db.run(
          `UPDATE users 
           SET password_hash = ?, role = 'admin', status = 'active', updated_at = ? 
           WHERE role = 'admin' OR LOWER(email) IN (LOWER(?), LOWER(?), LOWER(?))`,
          [user.password_hash, now, PRIMARY_ADMIN_EMAIL, ALIAS_ADMIN_EMAIL, envAdminEmail || PRIMARY_ADMIN_EMAIL]
        );
      } catch (_) {}
    }

    // Record login in audit log
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'ADMIN_LOGIN_SUCCESS', 'SYSTEM', 'SESSION', 'Administrator logged into management portal', ?, ?)`,
      ['audit_' + Math.random().toString(36).substring(2, 11), user.id, user.email, ip, now]
    );
    saveDb();

    const token = generateToken({ id: user.id, email: user.email, role: 'admin' });
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 86400000 });

    res.json({
      token,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: 'admin',
        mustChangePassword: Boolean(user.must_change_password),
      },
    });
  } catch (err: any) {
    console.error('[ADMIN LOGIN ERROR]', err);
    res.status(500).json({ error: 'Authentication service temporarily unavailable. Internal server error.' });
  }
});

// Admin change password (required on first login if flagged)
router.post('/admin-change-password', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    if (!req.user || req.user.role !== 'admin') {
      res.status(403).json({ error: 'Unauthorized.' });
      return;
    }

    const { currentPassword, newPassword } = req.body;
    if (!newPassword || newPassword.length < 10) {
      res.status(400).json({ error: 'New password must be at least 10 characters long.' });
      return;
    }

    const db = await getDb();
    const user = queryOne(db, 'SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
    if (!user) {
      res.status(404).json({ error: 'Admin user not found.' });
      return;
    }

    if (currentPassword && !bcrypt.compareSync(currentPassword, user.password_hash)) {
      res.status(400).json({ error: 'Current password incorrect.' });
      return;
    }

    const salt = bcrypt.genSaltSync(12);
    const newHash = bcrypt.hashSync(newPassword, salt);
    const now = new Date().toISOString();

    // Update ALL admin aliases transactionally
    const envAdminEmail = (process.env.INITIAL_ADMIN_EMAIL || '').toLowerCase().trim();
    db.run(
      `UPDATE users 
       SET password_hash = ?, role = 'admin', must_change_password = 0, session_version = session_version + 1, updated_at = ? 
       WHERE role = 'admin' OR LOWER(email) IN (LOWER(?), LOWER(?), LOWER(?))`,
      [newHash, now, PRIMARY_ADMIN_EMAIL, ALIAS_ADMIN_EMAIL, envAdminEmail || PRIMARY_ADMIN_EMAIL]
    );

    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, ?, ?, 'PASSWORD_CHANGE', 'USER', ?, 'Administrator updated password successfully', ?, ?)`,
      ['audit_' + Math.random().toString(36).substring(2, 11), req.user.id, req.user.email, req.user.id, req.ip || '127.0.0.1', now]
    );
    saveDb();

    res.json({ message: 'Password updated successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update password.' });
  }
});

// Current User Profile
router.get('/me', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const user = queryOne(
      db,
      'SELECT id, email, first_name, last_name, phone, country, role, status, kyc_status, must_change_password, created_at FROM users WHERE id = ?',
      [req.user!.id]
    );

    if (!user) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    res.json({
      id: user.id,
      email: user.email,
      firstName: user.first_name,
      lastName: user.last_name,
      phone: user.phone,
      country: user.country,
      role: user.role,
      status: user.status,
      kycStatus: user.kyc_status,
      mustChangePassword: Boolean(user.must_change_password),
      createdAt: user.created_at,
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to load profile.' });
  }
});

// Logout
router.post('/logout', (req: Request, res: Response) => {
  res.clearCookie('token');
  res.json({ message: 'Logged out successfully.' });
});

export default router;
