import { Router, Request, Response } from 'express';
import { getDb, queryAll, queryOne } from '../db/database.js';
import { requireAuth, AuthRequest } from '../middleware/auth.js';
import {
  calculateDurationMetrics,
  calculateDailyPerformance,
  evaluateInvestmentMaturity,
  buildInvestmentChartSeries,
} from '../services/investmentEngine.js';

const router = Router();

// Public: List active investment products and permitted amounts
router.get('/products', async (req: Request, res: Response) => {
  try {
    const db = await getDb();
    const rows = queryAll(
      db,
      'SELECT id, slug, name, description, min_amount, return_rate, duration_days, return_type, term_version, features_json, active FROM investment_products WHERE active = 1 ORDER BY min_amount ASC'
    );

    const products = rows.map((p) => ({
      id: p.id,
      slug: p.slug,
      name: p.name,
      description: p.description,
      minAmount: p.min_amount,
      returnRate: p.return_rate ?? 0.75,
      durationDays: p.duration_days ?? 5,
      returnType: p.return_type ?? 'PROFIT_ON_CAPITAL',
      termVersion: p.term_version ?? 1,
      features: JSON.parse(p.features_json || '[]'),
      currency: 'ZAR',
    }));

    res.json({
      products,
      permittedAmounts: [500, 1000, 2500, 5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2000000],
      standardPermittedAmounts: [500, 1000, 2500, 5000],
      elitePermittedAmounts: [10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2000000],
      currency: 'ZAR',
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve investment products.' });
  }
});

// Authenticated: Comprehensive Investment Performance Dashboard
router.get('/dashboard', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();
    const serverNow = new Date();

    // 1. Fetch all investment allocations for this user
    const rawAllocations = queryAll(
      db,
      `SELECT a.*, p.name as product_name, p.slug as product_slug,
              t.reference as transaction_reference, t.payment_method
       FROM investment_allocations a
       JOIN investment_products p ON a.product_id = p.id
       JOIN transactions t ON a.transaction_id = t.id
       WHERE a.user_id = ?
       ORDER BY a.created_at DESC`,
      [userId]
    );

    // 2. Evaluate maturity for any active investments
    for (const alloc of rawAllocations) {
      if (alloc.status === 'ACTIVE') {
        evaluateInvestmentMaturity(db, alloc.id, serverNow);
      }
    }

    // Refresh allocations after evaluation
    const allocations = queryAll(
      db,
      `SELECT a.*, p.name as product_name, p.slug as product_slug,
              t.reference as transaction_reference, t.payment_method
       FROM investment_allocations a
       JOIN investment_products p ON a.product_id = p.id
       JOIN transactions t ON a.transaction_id = t.id
       WHERE a.user_id = ?
       ORDER BY a.created_at DESC`,
      [userId]
    );

    // 3. Fetch pending unverified transactions for this user
    const pendingPurchases = queryAll(
      db,
      `SELECT t.id, t.reference, t.amount, t.currency, t.payment_method, t.created_at,
              p.name as product_name
       FROM transactions t
       JOIN investment_products p ON t.product_id = p.id
       WHERE t.user_id = ? AND t.status = 'PENDING'
       ORDER BY t.created_at DESC`,
      [userId]
    );

    // 4. Fetch daily performance records for this user
    const dailyRecords = queryAll(
      db,
      `SELECT * FROM investment_daily_records WHERE user_id = ? ORDER BY record_date ASC`,
      [userId]
    );

    // 5. Zero State check: genuine zero when no active or historical allocations exist
    const isZeroState = allocations.length === 0;

    let totalInvestedCapital = 0;
    let currentInvestmentValue = 0;
    let actualRealizedPnL = 0;
    let projectedReturns = 0;
    let activeInvestmentsCount = 0;
    let maturedInvestmentsCount = 0;
    let nextMaturityDate: string | null = null;
    let nextMaturityRemainingSeconds: number | null = null;

    const formattedInvestments = allocations.map((a) => {
      const durationMetrics = calculateDurationMetrics(a.activated_at || a.created_at, a.maturity_date, serverNow);
      const isMatured = durationMetrics.isMatured || a.status === 'MATURED' || a.status === 'SETTLED';

      const investedCapital = Number(a.amount_allocated || 0);
      totalInvestedCapital += investedCapital;

      if (a.status === 'ACTIVE') {
        activeInvestmentsCount++;
        projectedReturns += Number(a.projected_profit || 0);
        currentInvestmentValue += Number(a.current_valuation || investedCapital);

        if (
          !nextMaturityDate ||
          new Date(a.maturity_date).getTime() < new Date(nextMaturityDate).getTime()
        ) {
          nextMaturityDate = a.maturity_date;
          nextMaturityRemainingSeconds = durationMetrics.remainingSeconds;
        }
      } else if (a.status === 'MATURED') {
        maturedInvestmentsCount++;
        currentInvestmentValue += Number(a.current_valuation || investedCapital);
      } else if (a.status === 'SETTLED') {
        maturedInvestmentsCount++;
        actualRealizedPnL += Number(a.realized_pnl || 0);
      }

      return {
        id: a.id,
        userId: a.user_id,
        productId: a.product_id,
        transactionId: a.transaction_id,
        transactionReference: a.transaction_reference,
        paymentMethod: a.payment_method,
        planName: a.plan_name || a.product_name,
        planSlug: a.product_slug,
        termVersion: a.term_version || 1,
        investedCapital,
        currency: 'ZAR',
        returnRate: Number(a.return_rate || 0.75),
        durationDays: Number(a.duration_days || 5),
        calculationMethod: a.calculation_method || 'PROFIT_ON_CAPITAL',
        activatedAt: a.activated_at || a.created_at,
        maturityDate: a.maturity_date,
        remainingSeconds: durationMetrics.remainingSeconds,
        isMatured,
        status: a.status,
        projectedProfit: Number(a.projected_profit || 0),
        projectedTotal: Number(a.projected_total || 0),
        currentValuation: Number(a.current_valuation || investedCapital),
        realizedPnL: Number(a.realized_pnl || 0),
        settlementStatus: a.settlement_status || 'UNSETTLED',
        settlementDate: a.settlement_date,
        settlementAmount: a.settlement_amount ? Number(a.settlement_amount) : undefined,
        settlementNotes: a.settlement_notes,
        termsText: a.terms,
        createdAt: a.created_at,
        updatedAt: a.updated_at,
      };
    });

    // 6. Calculate daily recorded change from real daily records
    let dailyRecordedChange = 0;
    let dailyRecordedPercentage = 0;

    if (dailyRecords.length > 0) {
      const todayStr = serverNow.toISOString().slice(0, 10);
      const todayRecords = dailyRecords.filter((r) => r.record_date === todayStr);
      if (todayRecords.length > 0) {
        dailyRecordedChange = todayRecords.reduce((sum, r) => sum + Number(r.daily_change || 0), 0);
        dailyRecordedPercentage = todayRecords.reduce((sum, r) => sum + Number(r.daily_percentage || 0), 0);
      } else {
        const lastRecord = dailyRecords[dailyRecords.length - 1];
        dailyRecordedChange = Number(lastRecord.daily_change || 0);
        dailyRecordedPercentage = Number(lastRecord.daily_percentage || 0);
      }
    }

    // 7. Generate chart coordinates separating actual from projected
    const chartData = buildInvestmentChartSeries(allocations, dailyRecords, serverNow);

    res.json({
      zeroState: isZeroState,
      serverTime: serverNow.toISOString(),
      metrics: {
        totalInvestedCapital: Math.round(totalInvestedCapital * 100) / 100,
        currentInvestmentValue: Math.round(currentInvestmentValue * 100) / 100,
        actualRealizedPnL: Math.round(actualRealizedPnL * 100) / 100,
        projectedReturns: Math.round(projectedReturns * 100) / 100,
        activeInvestmentsCount,
        maturedInvestmentsCount,
        pendingPurchasesCount: pendingPurchases.length,
        dailyRecordedChange: Math.round(dailyRecordedChange * 100) / 100,
        dailyRecordedPercentage: Math.round(dailyRecordedPercentage * 100) / 100,
        nextMaturityDate,
        nextMaturityRemainingSeconds,
      },
      chartData,
      investments: formattedInvestments,
      pendingPurchases: pendingPurchases.map((p) => ({
        id: p.id,
        reference: p.reference,
        amount: Number(p.amount),
        currency: p.currency,
        paymentMethod: p.payment_method,
        productName: p.product_name,
        createdAt: p.created_at,
      })),
      disclosures: {
        projectionNotice:
          'Projected returns are estimates based on the stated contractual investment terms and assumptions. They are not evidence of profits already earned. Actual performance and amounts payable depend on the applicable terms, verified records, and the investment settlement status.',
        custodyNotice:
          'All invested principal amounts are recorded in the immutable double-entry ledger. Capital custody safeguards are applied in accordance with South African digital asset policies.',
        regulatoryNotice:
          'Digital asset mining allocations carry technical and operational considerations. Stated contractual rates represent infrastructure yield targets, not licensed banking deposits.',
      },
    });
  } catch (err: any) {
    console.error('[INVESTMENT DASHBOARD ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve investment dashboard data.' });
  }
});

// Authenticated: Detailed view of a single investment
router.get('/item/:id', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const db = await getDb();
    const serverNow = new Date();

    // Verify ownership
    const a = queryOne(
      db,
      `SELECT a.*, p.name as product_name, p.slug as product_slug, p.description as product_description,
              t.reference as transaction_reference, t.payment_method, t.payment_provider, t.status as transaction_status
       FROM investment_allocations a
       JOIN investment_products p ON a.product_id = p.id
       JOIN transactions t ON a.transaction_id = t.id
       WHERE a.id = ? AND a.user_id = ?`,
      [id, userId]
    );

    if (!a) {
      res.status(404).json({ error: 'Investment not found or you are not authorized to view this record.' });
      return;
    }

    // Evaluate maturity
    evaluateInvestmentMaturity(db, a.id, serverNow);

    const durationMetrics = calculateDurationMetrics(a.activated_at || a.created_at, a.maturity_date, serverNow);
    const isMatured = durationMetrics.isMatured || a.status === 'MATURED' || a.status === 'SETTLED';

    // Daily history records
    const dailyRecords = queryAll(
      db,
      'SELECT * FROM investment_daily_records WHERE investment_id = ? ORDER BY record_date ASC',
      [id]
    );

    // Audit logs for this investment
    const auditLogs = queryAll(
      db,
      'SELECT action, actor_type, reason, created_at FROM investment_audit_logs WHERE investment_id = ? ORDER BY created_at DESC',
      [id]
    );

    // Individual chart coordinates
    const chartData = buildInvestmentChartSeries([a], dailyRecords, serverNow);

    res.json({
      investment: {
        id: a.id,
        userId: a.user_id,
        productId: a.product_id,
        transactionId: a.transaction_id,
        transactionReference: a.transaction_reference,
        paymentMethod: a.payment_method,
        paymentProvider: a.payment_provider,
        planName: a.plan_name || a.product_name,
        planSlug: a.product_slug,
        planDescription: a.product_description,
        termVersion: a.term_version || 1,
        investedCapital: Number(a.amount_allocated || 0),
        currency: 'ZAR',
        returnRate: Number(a.return_rate || 0.75),
        durationDays: Number(a.duration_days || 5),
        calculationMethod: a.calculation_method || 'PROFIT_ON_CAPITAL',
        activatedAt: a.activated_at || a.created_at,
        maturityDate: a.maturity_date,
        remainingSeconds: durationMetrics.remainingSeconds,
        elapsedSeconds: durationMetrics.elapsedSeconds,
        totalDurationSeconds: durationMetrics.totalDurationSeconds,
        progressPercentage: durationMetrics.progressPercentage,
        isMatured,
        status: a.status,
        projectedProfit: Number(a.projected_profit || 0),
        projectedTotal: Number(a.projected_total || 0),
        currentValuation: Number(a.current_valuation || a.amount_allocated),
        realizedPnL: Number(a.realized_pnl || 0),
        settlementStatus: a.settlement_status || 'UNSETTLED',
        settlementDate: a.settlement_date,
        settlementAmount: a.settlement_amount ? Number(a.settlement_amount) : undefined,
        settlementNotes: a.settlement_notes,
        termsText: a.terms,
        createdAt: a.created_at,
        updatedAt: a.updated_at,
      },
      dailyRecords,
      auditLogs,
      chartData,
      serverTime: serverNow.toISOString(),
    });
  } catch (err: any) {
    console.error('[INVESTMENT ITEM ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve investment details.' });
  }
});

// Authenticated: Paginated Daily Performance History for an investment
router.get('/item/:id/history', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const db = await getDb();

    // Verify ownership
    const ownerCheck = queryOne(
      db,
      'SELECT id FROM investment_allocations WHERE id = ? AND user_id = ?',
      [id, userId]
    );

    if (!ownerCheck) {
      res.status(404).json({ error: 'Investment not found or unauthorized.' });
      return;
    }

    const page = Math.max(1, parseInt(String(req.query.page || '1'), 10));
    const limit = Math.min(50, Math.max(5, parseInt(String(req.query.limit || '10'), 10)));
    const offset = (page - 1) * limit;

    const totalCountRow = queryOne(
      db,
      'SELECT COUNT(*) as total FROM investment_daily_records WHERE investment_id = ?',
      [id]
    );
    const total = totalCountRow ? Number(totalCountRow.total) : 0;

    const records = queryAll(
      db,
      `SELECT * FROM investment_daily_records 
       WHERE investment_id = ? 
       ORDER BY record_date DESC, created_at DESC 
       LIMIT ? OFFSET ?`,
      [id, limit, offset]
    );

    res.json({
      records,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit) || 1,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve investment history.' });
  }
});

// Authenticated: Idempotent maturity check requested by client countdown
router.post('/item/:id/check-maturity', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const userId = req.user!.id;
    const db = await getDb();

    const ownerCheck = queryOne(
      db,
      'SELECT id, status, maturity_date, settlement_status FROM investment_allocations WHERE id = ? AND user_id = ?',
      [id, userId]
    );

    if (!ownerCheck) {
      res.status(404).json({ error: 'Investment not found or unauthorized.' });
      return;
    }

    evaluateInvestmentMaturity(db, id, new Date());

    const updated = queryOne(
      db,
      'SELECT status, settlement_status, maturity_date FROM investment_allocations WHERE id = ?',
      [id]
    );

    res.json({
      status: updated?.status,
      settlementStatus: updated?.settlement_status,
      isMatured: updated?.status === 'MATURED' || updated?.status === 'SETTLED',
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to evaluate maturity.' });
  }
});

export default router;
