import { Router, Request, Response } from 'express';
import { getDb, queryOne, queryAll, saveDb } from '../db/database.js';
import {
  getPayFastConfig,
  getPayFastProcessUrl,
  generatePayFastSignature,
  verifyPayFastSignature,
} from '../services/payfast.js';
import { recordDepositAndAllocation } from '../services/ledger.js';
import { sendEmailNotification } from '../services/email.js';
import { requireAuth, AuthRequest } from '../middleware/auth.js';

const router = Router();

const STANDARD_AMOUNTS = [500, 1000, 2500, 5000];
const ELITE_AMOUNTS = [10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2000000];
const PERMITTED_AMOUNTS = [...STANDARD_AMOUNTS, ...ELITE_AMOUNTS];

// Initialize Payment (PayFast or Bank Transfer)
router.post('/initialize', async (req: Request, res: Response) => {
  try {
    const {
      productId,
      amount,
      paymentMethod,
      firstName,
      lastName,
      email,
      phone,
      country,
      userId: suppliedUserId,
    } = req.body;

    // Validate customer details
    if (!firstName || !lastName || !email) {
      res.status(400).json({ error: 'Customer first name, last name, and email are required.' });
      return;
    }

    const emailTrimmed = String(email).toLowerCase().trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailTrimmed)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }

    // Validate amount against permitted set
    const numericAmount = Number(amount);
    if (!PERMITTED_AMOUNTS.includes(numericAmount)) {
      res.status(400).json({
        error: `Invalid investment amount. Permitted amounts are: R${PERMITTED_AMOUNTS.map(a => a.toLocaleString()).join(', R')}.`,
      });
      return;
    }

    // Validate payment method
    if (!['payfast', 'bank_transfer'].includes(paymentMethod)) {
      res.status(400).json({ error: 'Invalid payment method selected.' });
      return;
    }

    const db = await getDb();

    // Authoritative product retrieval from DB
    const product = queryOne(
      db,
      'SELECT id, slug, name, min_amount FROM investment_products WHERE (id = ? OR slug = ?) AND active = 1',
      [productId, productId]
    );

    if (!product) {
      res.status(400).json({ error: 'Selected investment product does not exist or is inactive.' });
      return;
    }

    if (numericAmount < product.min_amount) {
      res.status(400).json({
        error: `The selected amount (R${numericAmount}) is below the minimum required for ${product.name} (R${product.min_amount}).`,
      });
      return;
    }

    // Associate or create customer record
    let customer = queryOne(db, 'SELECT id, email, first_name, last_name FROM users WHERE email = ?', [emailTrimmed]);
    const now = new Date().toISOString();

    if (!customer) {
      // Create registered customer account for this checkout
      const newUserId = 'usr_' + Math.random().toString(36).substring(2, 11);
      // Generate secure temporary random hash for account initialized via checkout
      const initialSecret = Math.random().toString(36).slice(-10);
      const bcrypt = (await import('bcryptjs')).default;
      const initialHash = bcrypt.hashSync(initialSecret, 10);

      db.run(
        `INSERT INTO users (id, email, password_hash, first_name, last_name, phone, country, role, status, must_change_password, kyc_status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'client', 'active', 0, 'unverified', ?, ?)`,
        [
          newUserId,
          emailTrimmed,
          initialHash,
          String(firstName).trim(),
          String(lastName).trim(),
          phone ? String(phone).trim() : '',
          country ? String(country).trim() : 'South Africa',
          now,
          now,
        ]
      );
      customer = { id: newUserId, email: emailTrimmed, first_name: firstName, last_name: lastName };
    }

    // Generate unique transaction reference (e.g. GF-20261014-ABCDEF12)
    const dateStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randomHex = Math.random().toString(36).substring(2, 10).toUpperCase();
    const reference = `GF-${dateStr}-${randomHex}`;
    const transactionId = 'tx_' + Math.random().toString(36).substring(2, 11);

    // Create pending transaction in DB
    db.run(
      `INSERT INTO transactions (id, reference, user_id, product_id, amount, currency, fee, payment_method, payment_provider, status, notes, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'ZAR', 0, ?, ?, 'PENDING', ?, ?, ?)`,
      [
        transactionId,
        reference,
        customer.id,
        product.id,
        numericAmount,
        paymentMethod,
        paymentMethod === 'payfast' ? 'payfast' : 'manual_bank',
        `Investment in ${product.name}`,
        now,
        now,
      ]
    );

    saveDb();

    const baseUrl = process.env.APP_URL || (req.protocol + '://' + req.get('host'));

    if (paymentMethod === 'payfast') {
      const pfConfig = getPayFastConfig();
      const returnUrl = `${baseUrl}/payment-success?reference=${reference}`;
      const cancelUrl = `${baseUrl}/payment-failed?reference=${reference}`;
      const notifyUrl = `${baseUrl}/api/payments/payfast/notify`;

      // Official PayFast payload structure
      const payfastPayload: Record<string, string> = {
        merchant_id: pfConfig.merchantId,
        merchant_key: pfConfig.merchantKey,
        return_url: returnUrl,
        cancel_url: cancelUrl,
        notify_url: notifyUrl,
        name_first: String(firstName).trim(),
        name_last: String(lastName).trim(),
        email_address: emailTrimmed,
        m_payment_id: reference,
        amount: numericAmount.toFixed(2),
        item_name: `Global Finance: ${product.name}`,
        item_description: `Digital capital allocation for ${product.name}`,
      };

      const signature = generatePayFastSignature(payfastPayload, pfConfig.passphrase);
      payfastPayload.signature = signature;

      res.status(200).json({
        success: true,
        paymentMethod: 'payfast',
        reference,
        transactionId,
        processUrl: getPayFastProcessUrl(),
        environment: pfConfig.environment,
        payfastPayload,
      });
      return;
    }

    // Bank Transfer workflow
    res.status(200).json({
      success: true,
      paymentMethod: 'bank_transfer',
      reference,
      transactionId,
      amount: numericAmount,
      currency: 'ZAR',
      productName: product.name,
      bankingDetails: {
        accountName: '[BAHOLO CONSULTING]',
        bankName: '[TymeBank/GoTymeBank]',
        accountNumber: '[53002153808]',
        branchCode: '[678910]',
        reference: reference,
        instructions:
          'Please transfer the exact amount using your unique reference as the payment beneficiary reference in your transfer description. CRITICAL: This payment can ONLY be performed directly inside your official banking application (e.g. TymeBank/GoTymeBank app). Do NOT attempt payment at retail tills or ATM deposits.',
        bankingAppOnlyNotice:
          'CRITICAL REQUIREMENT: This payment can ONLY be performed inside your official banking application.',
      },
    });
  } catch (err: any) {
    console.error('[PAYMENT INITIALIZE ERROR]', err);
    res.status(500).json({ error: 'Unable to initialize payment transaction. Please try again.' });
  }
});

// PayFast Instant Transaction Notification (ITN) Handler
router.post('/payfast/notify', async (req: Request, res: Response) => {
  try {
    const payload = req.body;
    console.log('[PAYFAST ITN RECEIVED]', JSON.stringify(payload));

    const pfConfig = getPayFastConfig();
    const reference = payload.m_payment_id;
    const receivedSignature = payload.signature;
    const paymentStatus = payload.payment_status;
    const pfPaymentId = payload.pf_payment_id || '';
    const grossAmount = parseFloat(payload.amount_gross || '0');
    const feeAmount = parseFloat(payload.amount_fee || '0');
    const netAmount = parseFloat(payload.amount_net || '0');

    if (!reference) {
      console.error('[PAYFAST ITN] Missing transaction reference m_payment_id.');
      res.status(400).send('Missing reference');
      return;
    }

    // Verify signature
    const isValidSignature = verifyPayFastSignature(payload, receivedSignature, pfConfig.passphrase);
    if (!isValidSignature && pfConfig.environment === 'live') {
      console.error('[PAYFAST ITN] Invalid signature on live transaction:', reference);
      res.status(400).send('Invalid signature');
      return;
    }

    // Verify merchant ID
    if (String(payload.merchant_id) !== String(pfConfig.merchantId)) {
      console.error('[PAYFAST ITN] Merchant ID mismatch:', payload.merchant_id);
      res.status(400).send('Merchant ID mismatch');
      return;
    }

    const db = await getDb();
    const transaction = queryOne(
      db,
      `SELECT t.*, p.name as product_name, u.email as user_email, u.first_name, u.last_name
       FROM transactions t
       JOIN investment_products p ON t.product_id = p.id
       JOIN users u ON t.user_id = u.id
       WHERE t.reference = ?`,
      [reference]
    );

    if (!transaction) {
      console.error('[PAYFAST ITN] Transaction not found in database:', reference);
      res.status(404).send('Transaction not found');
      return;
    }

    // Idempotency check: Already processed?
    if (transaction.status === 'SUCCESS') {
      console.log(`[PAYFAST ITN IDEMPOTENCY] Transaction ${reference} is already confirmed as SUCCESS. Ignoring repeat notification.`);
      res.status(200).send('OK');
      return;
    }

    // Amount check (allowing minor decimal tolerance)
    if (Math.abs(grossAmount - Number(transaction.amount)) > 0.05) {
      console.error(`[PAYFAST ITN] Amount mismatch: Expected R${transaction.amount}, received R${grossAmount}`);
      db.run(
        `UPDATE transactions SET status = 'FAILED', notes = ?, updated_at = ? WHERE id = ?`,
        [`Amount mismatch: received R${grossAmount} vs expected R${transaction.amount}`, new Date().toISOString(), transaction.id]
      );
      saveDb();
      res.status(400).send('Amount mismatch');
      return;
    }

    const now = new Date().toISOString();

    // Log notification event
    const notifId = 'pn_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO payfast_notifications (id, transaction_reference, pf_payment_id, payment_status, amount_gross, amount_fee, amount_net, raw_payload, verified, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`,
      [
        notifId,
        reference,
        pfPaymentId,
        paymentStatus,
        grossAmount,
        feeAmount,
        netAmount,
        JSON.stringify(payload),
        now,
      ]
    );

    if (paymentStatus === 'COMPLETE') {
      // Mark transaction SUCCESS
      db.run(
        `UPDATE transactions SET status = 'SUCCESS', provider_reference = ?, updated_at = ? WHERE id = ?`,
        [pfPaymentId, now, transaction.id]
      );

      // Record in immutable financial ledger
      recordDepositAndAllocation(db, {
        userId: transaction.user_id,
        transactionId: transaction.id,
        productId: transaction.product_id,
        amount: Number(transaction.amount),
        reference: transaction.reference,
        productName: transaction.product_name,
      });

      // Send payment confirmation email
      sendEmailNotification(db, {
        to: transaction.user_email,
        subject: 'Global Finance Crypto Mining — Payment Confirmation',
        htmlContent: `Dear ${transaction.first_name},\nYour payment of R${transaction.amount} for ${transaction.product_name} (Ref: ${transaction.reference}) has been successfully confirmed.`,
        adminLogDetails: `Verified PayFast payment for ${transaction.reference} (R${transaction.amount})`,
      });

      saveDb();
      console.log(`[PAYFAST ITN SUCCESS] Transaction ${reference} successfully processed and allocated.`);
      res.status(200).send('OK');
      return;
    }

    if (paymentStatus === 'CANCELLED') {
      db.run(`UPDATE transactions SET status = 'CANCELLED', updated_at = ? WHERE id = ?`, [now, transaction.id]);
      saveDb();
      res.status(200).send('OK');
      return;
    }

    if (paymentStatus === 'FAILED') {
      db.run(`UPDATE transactions SET status = 'FAILED', updated_at = ? WHERE id = ?`, [now, transaction.id]);
      saveDb();
      res.status(200).send('OK');
      return;
    }

    res.status(200).send('OK');
  } catch (err) {
    console.error('[PAYFAST ITN HANDLER ERROR]', err);
    res.status(500).send('Internal server error');
  }
});

// Transaction Verification Endpoint
router.get('/verify/:reference', async (req: Request, res: Response) => {
  try {
    const { reference } = req.params;
    const db = await getDb();

    const transaction = queryOne(
      db,
      `SELECT t.id, t.reference, t.amount, t.currency, t.fee, t.payment_method, t.payment_provider, t.status, t.created_at,
              p.name as product_name, p.slug as product_slug,
              u.first_name, u.last_name, u.email
       FROM transactions t
       JOIN investment_products p ON t.product_id = p.id
       JOIN users u ON t.user_id = u.id
       WHERE t.reference = ?`,
      [reference]
    );

    if (!transaction) {
      res.status(404).json({ error: 'Transaction reference not found in system records.' });
      return;
    }

    res.json({
      verified: true,
      transaction: {
        id: transaction.id,
        reference: transaction.reference,
        amount: transaction.amount,
        currency: transaction.currency,
        fee: transaction.fee,
        paymentMethod: transaction.payment_method,
        paymentProvider: transaction.payment_provider,
        status: transaction.status,
        productName: transaction.product_name,
        productSlug: transaction.product_slug,
        customerName: `${transaction.first_name} ${transaction.last_name}`.trim(),
        customerEmail: transaction.email,
        createdAt: transaction.created_at,
      },
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to verify transaction status.' });
  }
});

// Authorized Transaction Receipt
router.get('/receipt/:reference', async (req: Request, res: Response) => {
  try {
    const { reference } = req.params;
    const db = await getDb();

    const transaction = queryOne(
      db,
      `SELECT t.id, t.reference, t.amount, t.currency, t.fee, t.payment_method, t.payment_provider, t.status, t.created_at,
              p.name as product_name,
              u.first_name, u.last_name, u.email
       FROM transactions t
       JOIN investment_products p ON t.product_id = p.id
       JOIN users u ON t.user_id = u.id
       WHERE t.reference = ?`,
      [reference]
    );

    if (!transaction) {
      res.status(404).json({ error: 'Transaction not found.' });
      return;
    }

    if (transaction.status !== 'SUCCESS') {
      res.status(400).json({
        error: 'Receipts can only be generated for confirmed, successfully verified transactions.',
        status: transaction.status,
      });
      return;
    }

    res.json({
      receiptNumber: `REC-${transaction.reference.replace('GF-', '')}`,
      businessName: 'GLOBAL FINANCE CRYPTO MINING',
      transactionReference: transaction.reference,
      customerName: `${transaction.first_name} ${transaction.last_name}`.trim(),
      customerEmail: transaction.email,
      investmentProduct: transaction.product_name,
      amount: transaction.amount,
      currency: transaction.currency,
      fee: transaction.fee,
      paymentProvider: transaction.payment_provider === 'payfast' ? 'PayFast (Pty) Ltd' : 'Direct Electronic Bank Transfer',
      paymentMethod: transaction.payment_method,
      paymentStatus: transaction.status,
      transactionDate: transaction.created_at,
      closingMessage: 'Thank you for using Global Finance Crypto Mining.',
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate receipt.' });
  }
});

export default router;
