import { Router, Response } from 'express';
import { getDb, queryOne, queryAll, saveDb } from '../db/database.js';
import { requireAuth, requireAdmin, AuthRequest } from '../middleware/auth.js';
import {
  getSASTDateParts,
  getUpcomingSchedule,
  broadcastPromotion,
  killPromotionRun,
  submitRewardClaim,
  reviewRewardClaim,
} from '../services/promotionsScheduler.js';

const router = Router();

// ==============================================================================
// CUSTOMER PROMOTION ENDPOINTS (Protected by requireAuth)
// ==============================================================================

// Submit claim for 16th Cash-Value Reward voucher
router.post('/claim-reward', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const userEmail = req.user!.email;
    const { runId, notes } = req.body;

    if (!runId) {
      res.status(400).json({ error: 'Promotion run ID is required.' });
      return;
    }

    const db = await getDb();
    const result = submitRewardClaim(db, {
      runId,
      userId,
      userEmail,
      notes,
    });

    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }

    res.json({
      success: true,
      claimId: result.claimId,
      message: 'Reward claim submitted successfully. Your claim is pending administrator review.',
    });
  } catch (err: any) {
    console.error('[PROMOTION CLAIM ERROR]', err);
    res.status(500).json({ error: 'Failed to submit reward claim.' });
  }
});

// Get active promotional offers for client
router.get('/active', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();
    const nowIso = new Date().toISOString();

    const runs = queryAll(
      db,
      `SELECT r.*, t.category, t.discount_type, t.discount_value, t.normal_fee_amount,
              t.min_deposit_amount, t.reward_amount, t.product_name, t.description,
              t.disclaimer, t.cta_label, t.cta_route,
              c.id as client_claim_id, c.status as client_claim_status
       FROM promotional_offer_runs r
       JOIN promotional_offer_templates t ON r.template_id = t.id
       LEFT JOIN promotional_reward_claims c ON r.id = c.run_id AND c.user_id = ?
       WHERE r.status = 'ACTIVE' AND r.expires_at > ?
       ORDER BY r.published_at DESC`,
      [userId, nowIso]
    );

    res.json({ activePromotions: runs });
  } catch (err: any) {
    console.error('[GET ACTIVE PROMOTIONS ERROR]', err);
    res.status(500).json({ error: 'Failed to fetch active promotions.' });
  }
});

// ==============================================================================
// ADMINISTRATOR PROMOTION ENDPOINTS (requireAuth + requireAdmin)
// ==============================================================================

export const adminPromotionsRouter = Router();
adminPromotionsRouter.use(requireAuth);
adminPromotionsRouter.use(requireAdmin);

// Get complete promotions overview
adminPromotionsRouter.get('/overview', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const sast = getSASTDateParts();
    const schedule = getUpcomingSchedule();

    const templates = queryAll(
      db,
      'SELECT * FROM promotional_offer_templates ORDER BY schedule_day ASC'
    );

    const recentRuns = queryAll(
      db,
      `SELECT r.*, t.category, t.discount_type, t.discount_value
       FROM promotional_offer_runs r
       JOIN promotional_offer_templates t ON r.template_id = t.id
       ORDER BY r.published_at DESC
       LIMIT 30`
    );

    const pendingClaims = queryAll(
      db,
      `SELECT c.*, r.offer_title
       FROM promotional_reward_claims c
       JOIN promotional_offer_runs r ON c.run_id = r.id
       WHERE c.status = 'PENDING_APPROVAL'
       ORDER BY c.created_at ASC`
    );

    const totalClaimsCount = queryOne(
      db,
      'SELECT COUNT(*) as c FROM promotional_reward_claims'
    )?.c || 0;

    res.json({
      currentSAST: sast,
      upcomingSchedule: schedule,
      templates,
      recentRuns,
      pendingClaims,
      totalClaimsCount,
    });
  } catch (err: any) {
    console.error('[ADMIN PROMOTIONS OVERVIEW ERROR]', err);
    res.status(500).json({ error: 'Failed to load promotions overview.' });
  }
});

// Get templates
adminPromotionsRouter.get('/templates', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const templates = queryAll(
      db,
      'SELECT * FROM promotional_offer_templates ORDER BY schedule_day ASC'
    );
    res.json({ templates });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to load templates.' });
  }
});

// Update template
adminPromotionsRouter.put('/templates/:id', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();
    const template = queryOne(db, 'SELECT * FROM promotional_offer_templates WHERE id = ?', [id]);
    if (!template) {
      res.status(404).json({ error: 'Template not found' });
      return;
    }

    const {
      title,
      description,
      discount_type,
      discount_value,
      normal_fee_amount,
      min_deposit_amount,
      reward_amount,
      product_name,
      validity_hours,
      target_audience,
      disclaimer,
      cta_label,
      cta_route,
      is_enabled,
    } = req.body;

    const now = new Date().toISOString();

    db.run(
      `UPDATE promotional_offer_templates SET
        title = COALESCE(?, title),
        description = COALESCE(?, description),
        discount_type = COALESCE(?, discount_type),
        discount_value = COALESCE(?, discount_value),
        normal_fee_amount = COALESCE(?, normal_fee_amount),
        min_deposit_amount = COALESCE(?, min_deposit_amount),
        reward_amount = COALESCE(?, reward_amount),
        product_name = COALESCE(?, product_name),
        validity_hours = COALESCE(?, validity_hours),
        target_audience = COALESCE(?, target_audience),
        disclaimer = COALESCE(?, disclaimer),
        cta_label = COALESCE(?, cta_label),
        cta_route = COALESCE(?, cta_route),
        is_enabled = COALESCE(?, is_enabled),
        updated_at = ?
       WHERE id = ?`,
      [
        title,
        description,
        discount_type,
        discount_value !== undefined ? Number(discount_value) : null,
        normal_fee_amount !== undefined ? Number(normal_fee_amount) : null,
        min_deposit_amount !== undefined ? Number(min_deposit_amount) : null,
        reward_amount !== undefined ? Number(reward_amount) : null,
        product_name,
        validity_hours !== undefined ? Number(validity_hours) : null,
        target_audience,
        disclaimer,
        cta_label,
        cta_route,
        is_enabled !== undefined ? Number(is_enabled) : null,
        now,
        id,
      ]
    );

    // Audit log
    const auditId = 'audit_' + Math.random().toString(36).substring(2, 11);
    db.run(
      `INSERT INTO audit_logs (id, admin_id, admin_email, action, target_type, target_id, details, ip_address, created_at)
       VALUES (?, 'ADMIN', ?, 'PROMOTION_TEMPLATE_UPDATED', 'PROMOTION_TEMPLATE', ?, ?, '127.0.0.1', ?)`,
      [
        auditId,
        req.user!.email,
        id,
        `Updated promotional offer template ${template.slot_key}: ${title || template.title}`,
        now,
      ]
    );

    saveDb();
    const updated = queryOne(db, 'SELECT * FROM promotional_offer_templates WHERE id = ?', [id]);
    res.json({ success: true, template: updated });
  } catch (err: any) {
    console.error('[UPDATE PROMOTION TEMPLATE ERROR]', err);
    res.status(500).json({ error: 'Failed to update template.' });
  }
});

// Trigger broadcast or test dispatch
adminPromotionsRouter.post('/templates/:id/trigger', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { isTest } = req.body;
    const db = await getDb();

    const triggerType = isTest ? 'TEST_DISPATCH' : 'MANUAL_TRIGGER';
    const result = await broadcastPromotion(db, {
      templateId: id,
      triggerType,
      adminEmail: req.user!.email,
      testUserId: req.user!.id,
    });

    if (!result.success) {
      res.status(400).json({ error: result.reason || 'Failed to dispatch offer.' });
      return;
    }

    res.json({
      success: true,
      message: isTest
        ? 'Test promotional notification sent to your administrator account.'
        : `Promotional offer broadcast dispatched successfully to ${result.recipientCount} clients.`,
      runId: result.runId,
      recipientCount: result.recipientCount,
    });
  } catch (err: any) {
    console.error('[TRIGGER PROMOTION ERROR]', err);
    res.status(500).json({ error: 'Failed to broadcast promotion.' });
  }
});

// Emergency kill switch
adminPromotionsRouter.post('/runs/:id/kill', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const db = await getDb();

    const result = killPromotionRun(db, id, req.user!.email);
    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }

    res.json({
      success: true,
      message: 'Promotional offer has been permanently revoked by Emergency Kill Switch.',
    });
  } catch (err: any) {
    console.error('[KILL PROMOTION ERROR]', err);
    res.status(500).json({ error: 'Failed to kill promotion run.' });
  }
});

// Get reward claims list
adminPromotionsRouter.get('/claims', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const claims = queryAll(
      db,
      `SELECT c.*, r.offer_title, u.first_name, u.last_name, u.kyc_status
       FROM promotional_reward_claims c
       JOIN promotional_offer_runs r ON c.run_id = r.id
       JOIN users u ON c.user_id = u.id
       ORDER BY c.created_at DESC`
    );
    res.json({ claims });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to load claims.' });
  }
});

// Review reward claim (Approve or Reject)
adminPromotionsRouter.post('/claims/:id/review', async (req: AuthRequest, res: Response) => {
  try {
    const { id } = req.params;
    const { action, notes } = req.body;

    if (!action || !['APPROVE', 'REJECT'].includes(action)) {
      res.status(400).json({ error: 'Valid action (APPROVE or REJECT) is required.' });
      return;
    }

    const db = await getDb();
    const result = reviewRewardClaim(db, {
      claimId: id,
      action,
      adminNotes: notes,
      adminEmail: req.user!.email,
    });

    if (!result.success) {
      res.status(400).json({ error: result.error });
      return;
    }

    res.json({
      success: true,
      message:
        action === 'APPROVE'
          ? 'Reward voucher approved. Capital has been credited directly to the client ledger balance.'
          : 'Reward voucher claim has been rejected.',
    });
  } catch (err: any) {
    console.error('[REVIEW CLAIM ERROR]', err);
    res.status(500).json({ error: 'Failed to review reward claim.' });
  }
});

export default router;
