import { Router, Request, Response } from 'express';
import {
  getMarketOverview,
  getCoinDetail,
  getHistoricalPrices,
  getMarketNews,
  getProviderStatusReport,
} from '../services/cryptoMarket.js';
import { requireAuth, AuthRequest } from '../middleware/auth.js';
import { getDb, queryAll, saveDb } from '../db/database.js';

const router = Router();

// GET /api/crypto/market — Live and cached cryptocurrency market overview
router.get('/market', async (req: Request, res: Response) => {
  try {
    const forceRefresh = req.query.refresh === 'true';
    const overview = await getMarketOverview(forceRefresh);
    res.json(overview);
  } catch (err: any) {
    console.error('[CRYPTO MARKET ROUTE ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve cryptocurrency market data.' });
  }
});

// GET /api/crypto/coin/:symbol — Detail metrics & indicators for individual asset
router.get('/coin/:symbol', async (req: Request, res: Response) => {
  try {
    const symbol = req.params.symbol;
    const detail = await getCoinDetail(symbol);
    if (!detail) {
      return res.status(404).json({ error: `Cryptocurrency ${symbol} not supported or found.` });
    }
    res.json(detail);
  } catch (err: any) {
    console.error('[CRYPTO COIN DETAIL ERROR]', err);
    res.status(500).json({ error: 'Failed to retrieve asset details.' });
  }
});

// GET /api/crypto/history/:symbol — Timeframe historical prices for interactive charts
router.get('/history/:symbol', async (req: Request, res: Response) => {
  try {
    const symbol = req.params.symbol;
    const timeframe = (req.query.timeframe as any) || '7d';
    const history = await getHistoricalPrices(symbol, timeframe);
    res.json(history);
  } catch (err: any) {
    console.error('[CRYPTO HISTORY ERROR]', err);
    res.status(500).json({ error: 'Failed to load historical chart data.' });
  }
});

// GET /api/crypto/news — Curated verified crypto market news
router.get('/news', async (req: Request, res: Response) => {
  try {
    const news = await getMarketNews();
    res.json({ news });
  } catch (err: any) {
    console.error('[CRYPTO NEWS ERROR]', err);
    res.status(500).json({ error: 'Failed to load cryptocurrency news.' });
  }
});

// GET /api/crypto/provider-status — Health & data freshness status
router.get('/provider-status', async (req: Request, res: Response) => {
  try {
    const status = await getProviderStatusReport();
    res.json(status);
  } catch (err: any) {
    console.error('[PROVIDER STATUS ERROR]', err);
    res.status(500).json({ error: 'Failed to load market data provider status.' });
  }
});

// GET /api/crypto/alerts — Customer's active price alerts (Auth required)
router.get('/alerts', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const db = await getDb();
    const alerts = queryAll(
      db,
      'SELECT * FROM crypto_price_alerts WHERE user_id = ? ORDER BY created_at DESC',
      [userId]
    );
    res.json({ alerts });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to load price alerts.' });
  }
});

// POST /api/crypto/alerts — Create price alert (Auth required)
router.post('/alerts', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const { symbol, targetPriceZar, condition } = req.body;

    if (!symbol || !targetPriceZar || targetPriceZar <= 0) {
      return res.status(400).json({ error: 'Valid symbol and positive target price in ZAR are required.' });
    }
    if (condition !== 'ABOVE' && condition !== 'BELOW') {
      return res.status(400).json({ error: 'Condition must be ABOVE or BELOW.' });
    }

    const db = await getDb();
    const alertId = 'alt_' + Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();

    db.run(
      `INSERT INTO crypto_price_alerts (id, user_id, symbol, target_price_zar, condition, status, created_at)
       VALUES (?, ?, ?, ?, ?, 'ACTIVE', ?)`,
      [alertId, userId, symbol.toUpperCase(), Number(targetPriceZar), condition, now]
    );
    saveDb();

    res.json({ success: true, alertId, message: `Alert configured for ${symbol.toUpperCase()} at R ${targetPriceZar.toLocaleString()}` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to create price alert.' });
  }
});

// DELETE /api/crypto/alerts/:id — Delete price alert
router.delete('/alerts/:id', requireAuth, async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.id;
    const alertId = req.params.id;
    const db = await getDb();

    db.run('DELETE FROM crypto_price_alerts WHERE id = ? AND user_id = ?', [alertId, userId]);
    saveDb();

    res.json({ success: true });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete alert.' });
  }
});

export default router;
