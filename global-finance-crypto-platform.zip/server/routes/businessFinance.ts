import { Router, Response } from 'express';
import { requireAdmin, AuthRequest } from '../middleware/auth.js';
import {
  getBusinessFinancialOverview,
  getCompanyFinancialRecords,
  createCompanyFinancialRecord,
  adjustCompanyFinancialRecord,
  generateIncomeStatement,
  generateBalanceSheet,
  generateCashFlowStatement,
  getBudgetComparison,
  exportReportCsv,
} from '../services/businessFinance.js';
import { getDb, queryAll, queryOne, saveDb } from '../db/database.js';

const router = Router();

// All routes require administrator role
router.use(requireAdmin);

// GET /api/business-finance/overview
router.get('/overview', async (req: AuthRequest, res: Response) => {
  try {
    const period = (req.query.period as string) || '2026-Q3';
    const overview = await getBusinessFinancialOverview(period);
    res.json(overview);
  } catch (err: any) {
    console.error('[BUSINESS FINANCE OVERVIEW ERROR]', err);
    res.status(500).json({ error: 'Failed to load business financial overview.' });
  }
});

// GET /api/business-finance/records
router.get('/records', async (req: AuthRequest, res: Response) => {
  try {
    const type = req.query.type as string;
    const category = req.query.category as string;
    const period = req.query.period as string;
    const limit = req.query.limit ? parseInt(req.query.limit as string, 10) : 50;
    const offset = req.query.offset ? parseInt(req.query.offset as string, 10) : 0;

    const result = await getCompanyFinancialRecords({ type, category, period, limit, offset });
    res.json(result);
  } catch (err: any) {
    console.error('[GET FINANCIAL RECORDS ERROR]', err);
    res.status(500).json({ error: 'Failed to load corporate financial records.' });
  }
});

// POST /api/business-finance/records
router.post('/records', async (req: AuthRequest, res: Response) => {
  try {
    const adminEmail = req.user!.email;
    const { recordType, category, amount, reference, reportingPeriod, recordDate, description, supportingDoc, notes } = req.body;

    if (!recordType || !category || !amount || !reference || !reportingPeriod || !recordDate || !description) {
      return res.status(400).json({ error: 'All primary financial entry fields are mandatory.' });
    }

    const result = await createCompanyFinancialRecord(
      {
        recordType,
        category,
        amount: Number(amount),
        reference,
        reportingPeriod,
        recordDate,
        description,
        supportingDoc,
        authorizedBy: adminEmail,
        notes,
      },
      adminEmail
    );

    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json(result);
  } catch (err: any) {
    console.error('[CREATE FINANCIAL RECORD ERROR]', err);
    res.status(500).json({ error: 'Failed to record financial entry.' });
  }
});

// POST /api/business-finance/records/:id/adjust
router.post('/records/:id/adjust', async (req: AuthRequest, res: Response) => {
  try {
    const adminEmail = req.user!.email;
    const recordId = req.params.id;
    const { newAmount, reason } = req.body;

    if (newAmount === undefined || isNaN(Number(newAmount))) {
      return res.status(400).json({ error: 'Valid adjusted amount is required.' });
    }
    if (!reason || reason.trim().length < 6) {
      return res.status(400).json({ error: 'A documented audit justification reason is required.' });
    }

    const result = await adjustCompanyFinancialRecord(recordId, Number(newAmount), reason, adminEmail);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }

    res.json({ success: true, message: 'Audited financial adjustment recorded.' });
  } catch (err: any) {
    console.error('[ADJUST FINANCIAL RECORD ERROR]', err);
    res.status(500).json({ error: 'Failed to process adjustment.' });
  }
});

// GET /api/business-finance/reports/:reportType
router.get('/reports/:reportType', async (req: AuthRequest, res: Response) => {
  try {
    const reportType = req.params.reportType;
    const period = (req.query.period as string) || '2026-Q3';

    if (reportType === 'income') {
      const data = await generateIncomeStatement(period);
      return res.json(data);
    }
    if (reportType === 'balance') {
      const data = await generateBalanceSheet();
      return res.json(data);
    }
    if (reportType === 'cashflow') {
      const data = await generateCashFlowStatement(period);
      return res.json(data);
    }
    if (reportType === 'budget') {
      const data = await getBudgetComparison(period);
      return res.json({ period, comparisons: data });
    }

    return res.status(400).json({ error: `Unknown report type: ${reportType}` });
  } catch (err: any) {
    console.error('[GENERATE REPORT ERROR]', err);
    res.status(500).json({ error: 'Failed to generate financial report.' });
  }
});

// GET /api/business-finance/budgets
router.get('/budgets', async (req: AuthRequest, res: Response) => {
  try {
    const period = (req.query.period as string) || '2026-Q3';
    const comparisons = await getBudgetComparison(period);
    res.json({ period, comparisons });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to load budget comparisons.' });
  }
});

// POST /api/business-finance/budgets
router.post('/budgets', async (req: AuthRequest, res: Response) => {
  try {
    const adminEmail = req.user!.email;
    const { reportingPeriod, category, budgetedAmount, forecastAssumptions } = req.body;

    if (!reportingPeriod || !category || budgetedAmount === undefined) {
      return res.status(400).json({ error: 'Period, category, and budgeted amount are required.' });
    }

    const db = await getDb();
    const existing = queryOne(db, 'SELECT id FROM company_budgets WHERE reporting_period = ? AND category = ?', [
      reportingPeriod,
      category,
    ]);

    const now = new Date().toISOString();

    if (existing) {
      db.run(
        `UPDATE company_budgets
         SET budgeted_amount = ?, forecast_assumptions = ?, updated_at = ?
         WHERE id = ?`,
        [Number(budgetedAmount), forecastAssumptions || null, now, existing.id]
      );
    } else {
      const id = 'bgt_' + Math.random().toString(36).substring(2, 9);
      db.run(
        `INSERT INTO company_budgets (id, reporting_period, category, budgeted_amount, forecast_assumptions, created_by, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [id, reportingPeriod, category, Number(budgetedAmount), forecastAssumptions || null, adminEmail, now, now]
      );
    }

    saveDb();
    res.json({ success: true, message: 'Budget updated successfully.' });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update budget.' });
  }
});

// GET /api/business-finance/categories
router.get('/categories', async (req: AuthRequest, res: Response) => {
  try {
    const db = await getDb();
    const categories = queryAll(db, 'SELECT * FROM company_accounting_categories ORDER BY type, name');
    res.json({ categories });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to load accounting categories.' });
  }
});

// GET /api/business-finance/export/:reportType
router.get('/export/:reportType', async (req: AuthRequest, res: Response) => {
  try {
    const reportType = req.params.reportType as any;
    const period = (req.query.period as string) || '2026-Q3';

    const csvContent = await exportReportCsv(reportType, period);

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="GF_${reportType}_${period}.csv"`);
    res.send(csvContent);
  } catch (err: any) {
    console.error('[EXPORT CSV ERROR]', err);
    res.status(500).json({ error: 'Failed to export CSV report.' });
  }
});

export default router;
