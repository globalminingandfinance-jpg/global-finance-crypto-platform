# Architecture Inspection Report & Implementation Plan: Automated Money Offers Manager

> **Status: IMPLEMENTED & VERIFIED** (All 53 verification suite tests passed, background scheduler active at 09:00 SAST, UI compiled with zero errors)

## 1. Executive Summary & Architecture Findings

A non-destructive, read-only architectural audit of the **Global Finance Crypto Mining** platform was performed to ensure complete preservation of all working services, security rules, and user interfaces while introducing an automated, money-focused recurring promotion engine.

### Architectural Findings

1. **Database & Storage Layer (`server/db/database.ts`)**:
   - The platform utilizes an embedded, persistent SQLite database stored in `/data/database.sqlite` (with file backup via `saveDb()`).
   - Existing tables include `users`, `investment_products`, `transactions`, `financial_ledger`, `withdrawals`, `support_tickets`, `ticket_messages`, `customer_notifications`, `client_documents`, and `business_finance_records`.
   - The table `customer_notifications` is already in production with fields `(id, user_id, ticket_id, title, message, type, is_read, created_at)`.
   - **Conclusion**: We can expand `customer_notifications` with backwards-compatible optional columns (or a dedicated promotion details reference) and add two dedicated tables: `promotional_offer_templates` and `promotional_offer_runs` with zero breaking changes.

2. **Scheduler & Timezone Handling**:
   - The runtime runs an Express server (`server.ts`).
   - Standard Node.js execution environment allows an in-process, non-blocking background scheduler tick (checking every 60 seconds).
   - Timezone requirement: South Africa Standard Time (`Africa/Johannesburg`, UTC+2).
   - Dynamic month-end calculation must compute the true final calendar day (28th/29th in February, 30th or 31st) and trigger at 09:00:00 SAST without server timezone drift.
   - Idempotency guarantees: Every publication will register a unique run key (`offer_slot_YYYY_MM`, e.g., `flash_discount_2026_11`), guaranteeing that server restarts, retries, or concurrent ticks never duplicate an offer.

3. **Administrator Portal (`AdminDashboard.tsx`, `server/routes/admin.ts`)**:
   - Role-based authorization (`requireAuth`, `requireAdmin`) protects all operational endpoints.
   - Admin tabs currently manage Overview, Customers, Transactions, PayFast, Withdrawals, Support, Documents, Business Finance, Data Sources, and Audit Logs.
   - A dedicated **"Automated Offers & Promotions"** tab will integrate seamlessly into this interface with complete template editing, schedule previews, live/kill switches, manual test dispatch, and claim review.

4. **Client Notification Panel (`NotificationCenter.tsx`, `CustomerDashboard.tsx`)**:
   - The existing notification bell in `CustomerDashboard.tsx` opens `NotificationCenter.tsx`.
   - Per your feedback, active offers will appear **exclusively inside the Notification Center bell dropdown panel**, keeping the dashboard layout clean and focused.
   - Notifications will display category badges, bold financial benefit headlines, explicit money breakdowns (fee, discount, net cost/benefit), countdown timers to SAST expiry, mandatory financial risk disclaimers, and interactive action buttons (Direct to Deposit, Invest, or Claim Reward).

5. **Cash-Value Reward Workflow (16th of Month)**:
   - In alignment with your choice and strict financial safety, clicking "Claim Reward" on the 16th cash-value notification will create a pending reward claim in a `promotional_reward_claims` queue for administrator review before any ledger credit is applied.

---

## 2. Database Schema Additions (Zero Breaking Changes)

All additions are executed via `CREATE TABLE IF NOT EXISTS` and non-destructive `ALTER TABLE` checks during server bootstrap:

### Table 1: `promotional_offer_templates`
Stores the configuration for the 4 monthly recurring slots (and any custom promotional templates):
- `id` (TEXT PRIMARY KEY) — e.g. `'slot_flash_discount'`, `'slot_cash_reward'`, `'slot_special_investment'`, `'slot_month_end'`.
- `slot_key` (TEXT UNIQUE) — `'FLASH_DISCOUNT_6TH'`, `'CASH_REWARD_16TH'`, `'SPECIAL_OFFER_26TH'`, `'MONTH_END_FINAL_DAY'`.
- `title` (TEXT) — Promotional headline.
- `category` (TEXT) — Category code (`FEE_DISCOUNT`, `CASH_REWARD`, `SPECIAL_OFFER`, `MONTH_END`).
- `schedule_day` (INTEGER) — Day of month (6, 16, 26, or -1 for dynamic last day).
- `schedule_time_sast` (TEXT) — Default `'09:00'`.
- `discount_type` (TEXT) — `'PERCENTAGE'`, `'FIXED_AMOUNT'`, or `'NONE'`.
- `discount_value` (REAL) — e.g., 20 (for 20%) or 150 (for R150 discount).
- `normal_fee_amount` (REAL) — Regular price/fee reference.
- `min_deposit_amount` (REAL) — Minimum qualifying deposit or investment.
- `reward_amount` (REAL) — Cash-value reward amount (ZAR).
- `product_id` (TEXT) — Referenced investment product ID if applicable.
- `product_name` (TEXT) — Cached product name.
- `validity_hours` (INTEGER) — Expiry duration in hours from publication.
- `target_audience` (TEXT) — User preference: `'ALL_CLIENTS'`, `'VERIFIED_KYC_ONLY'`, `'ACTIVE_INVESTORS'`.
- `description` (TEXT) — Detailed terms and promotional explanation.
- `disclaimer` (TEXT) — Mandatory regulatory risk and fee disclosure.
- `cta_label` (TEXT) — Action button label (e.g. `'Claim Cash Reward'`, `'Explore Investment Plan'`, `'Deposit Now'`).
- `cta_route` (TEXT) — In-app target action route.
- `is_enabled` (INTEGER DEFAULT 1) — Master toggle for this scheduled recurring offer.
- `updated_at` (TEXT) — Timestamp of last administrative edit.

### Table 2: `promotional_offer_runs` (Idempotency & Audit Log)
Guarantees zero duplicate broadcasts and tracks broadcast analytics:
- `id` (TEXT PRIMARY KEY) — Generated unique run ID.
- `idempotency_key` (TEXT UNIQUE) — e.g., `'FLASH_DISCOUNT_6TH:2026-11'`, `'MONTH_END_FINAL_DAY:2026-10'`.
- `template_id` (TEXT) — Foreign reference to template.
- `offer_title` (TEXT) — Snapshot of published title.
- `slot_key` (TEXT).
- `trigger_type` (TEXT) — `'AUTOMATIC_SCHEDULE'` or `'MANUAL_TRIGGER'`.
- `published_at` (TEXT) — ISO timestamp.
- `expires_at` (TEXT) — Calculated expiry timestamp (SAST).
- `recipient_count` (INTEGER) — Number of clients who received the broadcast notification.
- `status` (TEXT) — `'ACTIVE'`, `'EXPIRED'`, or `'CANCELLED_KILL_SWITCH'`.
- `killed_by_admin` (TEXT) — Admin email if killed prematurely.
- `killed_at` (TEXT).

### Table 3: `promotional_reward_claims`
Fulfills the client's explicit preference for claimable cash-value rewards:
- `id` (TEXT PRIMARY KEY).
- `run_id` (TEXT) — Link to publication run.
- `user_id` (TEXT) — Client ID.
- `user_email` (TEXT) — Client email.
- `reward_amount` (REAL) — Claimed amount in ZAR.
- `status` (TEXT) — `'PENDING_APPROVAL'`, `'APPROVED'`, `'REJECTED'`.
- `claim_notes` (TEXT).
- `admin_notes` (TEXT).
- `reviewed_by` (TEXT).
- `reviewed_at` (TEXT).
- `created_at` (TEXT).

### Backward-Compatible Updates to `customer_notifications`
- Add optional columns: `promo_run_id` (TEXT), `promo_category` (TEXT), `promo_expiry` (TEXT), `promo_data` (JSON TEXT).
- Existing ticket, security, and document notifications remain 100% unaffected.

---

## 3. Automated Scheduler Architecture (Africa/Johannesburg Time)

### Exact Monthly Timing Rules
All scheduling calculations evaluate strictly in South Africa Standard Time (UTC+2):
- **Slot 1 (6th of month, 09:00 SAST)**: Flash Investment Discount.
- **Slot 2 (16th of month, 09:00 SAST)**: Cash-Value Reward.
- **Slot 3 (26th of month, 09:00 SAST)**: Special Investment Offer.
- **Slot 4 (Final calendar day of month, 09:00 SAST)**: Month-End Money Special.
  - Dynamically calculated for any year/month using `new Date(year, monthIndex + 1, 0).getDate()` in SAST. Correctly handles February 28/29 (leap years) and 30/31-day months.

### Background Engine (`server/services/promotionsScheduler.ts`)
- Initialized on server startup in `server.ts`.
- Runs a non-blocking check every 60 seconds (`setInterval` with error boundary).
- Extracts current SAST date and time:
  ```ts
  const now = new Date();
  const sastFormatter = new Intl.DateTimeFormat('en-ZA', {
    timeZone: 'Africa/Johannesburg',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
  ```
- Evaluates if the current date matches the 6th, 16th, 26th, or last day of the month, and time is `>= 09:00` SAST.
- Checks `promotional_offer_runs` for `idempotency_key = '${slotKey}:${year}-${month}'`.
- If no run exists and the template is `is_enabled = 1`:
  1. Identifies qualifying clients based on template's `target_audience`.
  2. Inserts broadcast notifications into `customer_notifications` in an atomic database transaction.
  3. Records the successful run into `promotional_offer_runs`.
  4. Records an audit log in `audit_logs`.
  5. Emits console logging and saves database state (`saveDb()`).

---

## 4. Four Safe, Production-Ready Default Promotional Offers

Pre-seeded into `promotional_offer_templates` so the system works immediately out of the box:

1. **6th of Every Month — Flash Investment Discount**:
   - **Category**: `FEE_DISCOUNT`
   - **Headline**: "Flash 50% Platform Allocation Fee Discount"
   - **Normal Fee**: R250.00 | **Discount**: 50% (R125.00 off) | **Net Fee**: R125.00
   - **Qualifying Product**: Advanced Mining Plan (R5,000 min deposit)
   - **Validity**: 48 Hours from 09:00 SAST on the 6th
   - **CTA**: "Fund Allocation & Claim Discount" -> Checkout / Deposit
   - **Disclaimer**: "Promotional discount applies exclusively to administrative allocation fees. Cryptocurrency mining investments carry market risks. Past returns do not guarantee future yields."

2. **16th of Every Month — Mid-Month Cash-Value Reward**:
   - **Category**: `CASH_REWARD`
   - **Headline**: "R350 Mid-Month Capital Boost Voucher"
   - **Reward Value**: R350.00 ZAR credited towards active mining capacity
   - **Condition**: Available to clients funding an active allocation of R2,500 or more within the promotional window.
   - **Validity**: 72 Hours from 09:00 SAST on the 16th
   - **CTA**: "Claim Reward Voucher" (Generates pending review claim)
   - **Disclaimer**: "Vouchers are company-funded promotional credits credited upon administrative review and validation. Subject to platform terms and capital commitment periods."

3. **26th of Every Month — Special Investment Plan Spotlight**:
   - **Category**: `SPECIAL_OFFER`
   - **Headline**: "Elite Enterprise Mining Plan — Zero Surcharge Window"
   - **Product**: Elite Investment Plan (Real product configured in platform)
   - **Normal Surcharge**: R1,000 setup fee waived (100% discount on setup charges)
   - **Min Deposit**: R50,000
   - **Validity**: 96 Hours from 09:00 SAST on the 26th
   - **CTA**: "Review Elite Plan Terms" -> Investment Plans
   - **Disclaimer**: "Global Finance Crypto Mining provides hash power allocation. Crypto asset values fluctuate. No fixed interest or guaranteed profit yields are promised or implied."

4. **Final Calendar Day of Every Month — Month-End Money Special**:
   - **Category**: `MONTH_END`
   - **Headline**: "Month-End Booster: 10% Additional Hash Power Allocation"
   - **Benefit**: Complimentary 10% computational capacity bonus on any newly activated mining contract
   - **Validity**: Active until 23:59:59 SAST on the final day of the month
   - **CTA**: "Activate Month-End Plan" -> Checkout
   - **Disclaimer**: "Valid strictly until midnight on the final calendar day of the month. Validated against official South African Standard Time."

---

## 5. Administrator Portal Integration (`AdminDashboard.tsx`)

A new navigation item **"Automated Offers"** (with icon `Tag`) will be added to the Admin sidebar and mobile drawer:

### Sub-Features within the Offers Section
1. **Recurring Monthly Schedule Status**:
   - Visual timeline displaying the 4 monthly events with status indicators, next execution date/time in SAST, and countdown.
2. **Offer Templates Editor**:
   - Interactive cards for all 4 slots.
   - Form inputs to edit: Headline, Description, Discount Type (% or Fixed), Discount Value, Normal Fee, Reward Amount, Minimum Deposit, Validity Hours, Target Audience, and Mandatory Disclaimer.
   - **Enable / Disable Toggle Switch** per offer slot.
3. **Execution History & Live Active Offers**:
   - Tabular history showing: Slot, Run Key, Published At (SAST), Expiry, Recipient Count, and Status (`ACTIVE`, `EXPIRED`, `CANCELLED`).
   - **Emergency Kill Switch**: Button with confirmation dialog that immediately revokes an active promotion, cancels pending notification visibility, and logs the action in the audit trail.
4. **Manual Test Broadcast & Preview Modal**:
   - Allows the administrator to preview the offer card exactly as a customer sees it in the Notification Center.
   - "Send Test Notification to Admin Account" button for risk-free verification.
   - "Trigger Immediate Broadcast" button with explicit confirmation prompt.
5. **Reward Claims Management**:
   - Dedicated review table for pending claims submitted by clients from the 16th Cash Reward.
   - Administrator can Approve or Reject with notes. Approved claims credit the client's balance through the existing double-entry ledger.

---

## 6. Client Notification Panel Enhancements (`NotificationCenter.tsx`)

The existing notification dropdown will be enhanced:
- **Promo Badge & Highlight**: Distinct visual badges for promotional notifications (`Flash Discount`, `Cash Reward`, `Investment Special`, `Month-End`).
- **Financial Breakdown Card**:
  - Displays: Normal Fee/Price, Discount/Reward Amount, and Final Net Cost.
  - Live countdown indicator showing hours and minutes remaining until expiration in SAST.
- **Action Buttons**:
  - Direct deep links: "Claim Reward" (triggers claim flow), "Deposit Now", or "View Investment Plans".
- **Regulatory Transparency**:
  - Styled collapsible risk disclaimer banner on each financial offer.
- **User Actions**:
  - "Mark as Read" updates individual unread badge counter.
  - "Dismiss" removes notification for the specific user.

---

## 7. Security, Auditing & Idempotency Safeguards

1. **Role-Based Protection**: All promotional configuration endpoints (`/api/admin/promotions/*`) enforce `requireAuth` and `requireAdmin`.
2. **Double-Publication Prevention**: Unique database index on `idempotency_key` ensures concurrent ticks or restarts can never dispatch a monthly slot more than once.
3. **Financial Safety**: Zero automatic balance increases without human administrative review and double-entry ledger reconciliation.
4. **Strict Audit Trail**: Every change to an offer template, kill switch trigger, or publication broadcast is recorded in `audit_logs` with admin email, IP address, and timestamp.

---

## 8. Verification & Testing Plan

1. **Unit & Logic Tests (`tests/run-tests.ts`)**:
   - Test dynamic last-day-of-month calculation for 28-day Feb (non-leap), 29-day Feb (leap years), 30-day months (Apr, Jun, Sep, Nov), and 31-day months.
   - Test SAST timezone conversion logic (verifying 09:00 SAST regardless of host machine timezone).
   - Test scheduler idempotency: executing the scheduler twice for the same slot produces exactly one broadcast record and zero duplicate client notifications.
   - Test financial discount arithmetic (ensuring fee - discount = final fee without rounding errors).
2. **API Endpoint Verification**:
   - `GET /api/admin/promotions/templates` (Admin auth required).
   - `PUT /api/admin/promotions/templates/:id` (Validation and update).
   - `POST /api/admin/promotions/trigger-test` (Admin preview & test broadcast).
   - `POST /api/admin/promotions/runs/:id/kill` (Emergency kill switch).
   - `GET /api/customer/notifications` (Promo notifications rendered with badges and metadata).
   - `POST /api/customer/promotions/claim-reward` (Client claim submission).
   - `POST /api/admin/promotions/claims/:id/review` (Admin claim approval).
3. **Frontend UI Verification**:
   - Admin Portal: Verify the "Automated Offers" tab renders seamlessly, forms save correctly, and preview modal matches the client display.
   - Client Portal: Verify the Notification Center displays promo badges, monetary breakdown, countdown, and action button, and unread counters operate smoothly.
